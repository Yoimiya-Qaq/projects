<template>
  <view class="custom-interaction">
    <!-- 评论弹窗 -->
    <u-popup :show="show" mode="bottom" :round="round" :closeOnClickOverlay="closeOnClickOverlay" :customStyle="customStyle" :zIndex="995" @close="onClose" @open="onOpen">
      <view class="popup-comment">
        <!-- 艾特好友列表 -->
        <view class="friend-list" v-if="attentionList.length">
          <scroll-view class="scroll-box" :scroll-x="true" @scrolltolower="loadNextPage">
            <view class="friend-box">
              <view
                class="friend-item"
                v-for="(item, index) in attentionList"
                :key="index"
                @click.stop="
                  $u.throttle(() => {
                    selectUser(item, 'single')
                  }, 1000)
                "
              >
                <zero-lazy-load class="friend-item-img" :borderRadius="80" :image="item.userinfo.headUrl" :height="80" imgMode="aspectFill"></zero-lazy-load>
                <view class="friend-item-text u-line-1">{{ item.userinfo.nickName }}</view>
              </view>
            </view>
          </scroll-view>
        </view>
        <!-- 输入框 -->
        <view class="comment-textarea">
          <view class="textarea-box">
            <u-textarea
              ref="inputRef"
              v-model="messageContent"
              border="none"
              :maxlength="-1"
              autoHeight
              :showConfirmBar="false"
              :focus="isFocus"
              :placeholder="placeholder"
              placeholderStyle="color: #9fa0a1;"
              :cursor="cursorIndex"
              @input="onInput"
              @focus="showEmoji = false"
              @blur="setCursorAddress"
            ></u-textarea>
            <!-- <textarea ref="inputRef" v-model="messageContent" :maxlength="-1" auto-height :focus="isFocus" :placeholder="placeholder" placeholder-style="color: #9fa0a1;" :cursor="cursorIndex" @input="onInput" @focus="showEmoji = false"></textarea> -->
          </view>
          <!-- 上传的图片 -->
          <view class="photo-list" v-if="imgList.length">
            <view class="photo-list-item" v-for="(item, index) in imgList" :key="index">
              <image class="item-img" :src="item" mode="aspectFill" @click="handlePreviewImg(index)" />
              <image class="item-icon" src="@/static/images/white_close.png" mode="aspectFill" @click.stop="deleteImage(index)" />
            </view>
          </view>
        </view>
        <!-- 被@的人 -->
        <view class="at-list" v-if="atList.length" @click="$u.throttle(goAt)">
          <block v-for="(item, index) in atList" :key="index">
            <view class="at-list-item">@{{ item.userinfo.nickName }}</view>
          </block>
        </view>
        <!-- 操作按钮 -->
        <view class="comment-operate">
          <view class="operate-left">
            <image class="operate-left-icon" src="@/static/images/find_comment_emoji.png" mode="aspectFill" @click="openEmoji" />
            <image class="operate-left-icon" src="@/static/images/find_comment_photo.png" mode="aspectFill" @click="openPhoto" />
            <view class="icon-box">
              <image class="operate-left-icon" src="@/static/images/find_comment_at.png" mode="aspectFill" @click="$u.throttle(goAt)" />
              <text class="operate-left-num" v-show="atList.length > 0">{{ atList.length }}</text>
            </view>
          </view>
          <view class="operate-right" @click="$u.throttle(handleSend, 1000)">发送</view>
        </view>
      </view>
      <!-- 表情 -->
      <view class="comment-emoji" v-if="showEmoji">
        <emoji @swiperChange="selectEmoji" />
      </view>
    </u-popup>

    <!-- 相册权限弹窗 -->
    <accredit-popup ref="accreditRef" systemTitle="“一起一起”想访问您的相册" systemContent="用于使用上传图片功能" permisionID="android.permission.READ_EXTERNAL_STORAGE" cacheId="externalStorage" @successAccredit="handleUpload" />

    <!-- @列表弹窗 -->
    <!-- <custom-at-popup :show="showAtList" :checked="atList" @close="showAtList = false" @confirm="selectUser" /> -->

    <!-- loading 弹窗 -->
    <yue-loading :mask="true" loadTxet="上传中..." v-if="uploadLoading"></yue-loading>
  </view>
</template>

<script>
import MyInfo from '@/model/my'
import { uploadFile } from '@/utils/tools'

export default {
  name: 'CustomInteraction',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 0
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // placeholder
    placeholder: {
      type: String,
      default: '文明用语，友善交流…'
    },
    // 自定义样式
    customStyle: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      cursorIndex: 0, // 光标位置
      messageContent: '',
      oldMessage: '',
      isFocus: false,
      showEmoji: false,
      showAtList: false,
      uploadLoading: false,
      atList: [],
      imgList: [],
      pageNumber: 1,
      pageSize: 10,
      hasNextPage: true,
      attentionList: []
    }
  },
  watch: {
    showEmoji: {
      handler(val) {
        if (val) {
          uni.hideKeyboard()
        }
      }
    }
  },
  destroyed() {
    this.onClear()
  },
  methods: {
    // 弹窗打开
    onOpen() {
      this.isFocus = true
      this.showEmoji = false
      this.pageNumber = 1
      this.attentionList = []
      this.$emit('open')
    },
    // 弹窗关闭
    onClose() {
      this.$emit('close')
    },
    getDifferent(oldArr, newArr) {
      for (let i = 0; i < Math.max(oldArr.length, newArr.length); i++) {
        if (newArr[i] !== oldArr[i]) {
          return { str: newArr[i], index: i }
        }
      }
    },
    // 输入框输入
    onInput(e) {
      //旧字符串数组
      const oldArr = this.oldMessage.split('')
      //新字符串数组
      const newArr = e.split('')
      let obj = this.getDifferent(oldArr, newArr) || {}
      let contentStr = ''
      if (JSON.stringify(obj) != '{}' && newArr.length - oldArr.length == 1) {
        contentStr = obj.str
        this.cursorIndex = obj.index + 1
      }
      // 输入是@时
      if (contentStr === '@') {
        this.openAt()
      }
      this.oldMessage = e
    },
    // 失去焦点，设置光标位置
    setCursorAddress(event) {
      this.cursorIndex = event.detail.cursor
    },
    // 清空
    onClear() {
      this.messageContent = ''
      this.oldMessage = ''
      this.imgList = []
      this.atList = []
    },
    // 点击表情图标
    openEmoji() {
      this.showEmoji = !this.showEmoji
    },
    // 选中表情
    selectEmoji(item) {
      this.messageContent = this.messageContent.slice(0, this.cursorIndex) + item + this.messageContent.slice(this.cursorIndex)
      this.cursorIndex += item.length
      this.oldMessage = this.messageContent
    },
    // 点击图片图标
    openPhoto() {
      if (this.imgList && this.imgList.length == 3) {
        uni.showToast({
          title: '最多添加3张图片',
          icon: 'none'
        })
        return
      }
      this.showEmoji = false
      this.$refs.accreditRef.triggerEvent()
    },
    // 选择要上传的图片
    handleUpload() {
      let self = this
      // 选择图片
      uni.chooseImage({
        count: 3 - self.imgList.length,
        sourceType: ['album'],
        success: res => {
          let arr = res.tempFilePaths || []
          let imageSrcList = []
          for (let i = 0; i < arr.length; i++) {
            imageSrcList.push({ url: arr[i] })
          }
          let obj = {
            file: imageSrcList
          }
          self.afterReadImg(obj)
        }
      })
    },
    // 上传图片
    async afterReadImg(e) {
      this.uploadLoading = true
      let list = e.file || []
      let arr = list.filter(item => item.url.toLowerCase().includes('heic'))
      if (arr.length > 0) {
        uni.showToast({
          title: '暂不支持上传HEIC格式的文件',
          icon: 'none'
        })
      }
      list = list.filter(item => !item.url.includes('heic'))
      for (let i = 0; i < list.length; i++) {
        let imgUrl = await uploadFile(list[i].url)
        this.imgList.push(imgUrl)
      }
      this.uploadLoading = false
    },
    // 预览图片
    handlePreviewImg(e) {
      uni.previewImage({
        urls: this.imgList,
        current: e
      })
    },
    // 删除图片
    deleteImage(index) {
      this.imgList.splice(index, 1)
    },
    // 输入@，显示@列表
    openAt() {
      this.showEmoji = false
      this.pageNumber = 1
      this.attentionList = []
      this.getAtList()
    },
    // 跳转@列表
    goAt() {
      // this.showAtList = true
      let self = this
      getApp().globalData.interactionAtUserList = this.atList
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pagesFind/find/atList',
          events: {
            getChecked: function (data) {
              self.selectUser(data, 'mul')
            }
          }
        })
      })
    },
    // 获取关注列表
    getAtList() {
      let params = {
        pageNo: this.pageNumber,
        pageSize: this.pageSize
      }
      MyInfo.getAttentionList(params).then(res => {
        if (res.code == 'SUCCESS' && res.data) {
          this.hasNextPage = res.data.atentionList.hasNextPage
          let list = res.data.atentionList.list || []
          this.attentionList = [...this.attentionList, ...list]
          if (this.attentionList.length == 0) {
            uni.showToast({
              title: '目前没有可@人员',
              icon: 'none'
            })
          }
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 关注列表加载下一页
    loadNextPage() {
      if (this.hasNextPage) {
        this.pageNumber++
        this.getAtList()
      }
    },

    /**
     * 选择艾特的用户
     * @param {object} data: 为选择的用户数据
     * @param {string} type: single-单选  mul-多选
     */
    selectUser(data, type) {
      if (type == 'single') {
        // 输入@：单选
        let arr = this.atList.filter(item => item.userinfo.numberId == data.userinfo.numberId)
        this.messageContent = this.messageContent.slice(0, this.cursorIndex - 1) + this.messageContent.slice(this.cursorIndex)
        this.oldMessage = this.messageContent
        if (arr.length) {
          uni.showToast({
            title: '用户已存在',
            icon: 'none',
            duration: 1000
          })
        } else {
          this.atList.push(data)
        }
        // 关闭@好友显示
        this.attentionList = []
      } else {
        // 点击@图标：多选
        this.showAtList = false
        this.atList = [...data]
      }
    },
    // 处理输入框数据
    getMsg() {
      let arr = []
      let atUserList = []
      let atUserNameList = []
      let content = ''
      arr.push({
        type: 'text',
        text: this.messageContent
      })
      if (this.atList.length) {
        let list = this.atList.map(item => {
          return {
            type: 'name',
            id: item.userinfo.numberId,
            text: '@' + item.userinfo.nickName
          }
        })
        arr.push(...list)

        atUserList = this.atList.map(item => item.userinfo.numberId)
        atUserNameList = this.atList.map(item => '@' + item.userinfo.nickName)
      }
      content = atUserNameList.length ? this.messageContent + atUserNameList.join('') : this.messageContent
      return { atUserList, content, arr }
    },
    // 发送
    handleSend() {
      if (this.uploadLoading) {
        uni.showToast({
          title: '请等待图片上传完成',
          icon: 'none'
        })
        return
      }
      let inputData = this.getMsg()
      if ((!this.messageContent || !inputData.content) && !this.imgList.length) {
        uni.showToast({
          title: '评论内容不能为空',
          icon: 'none'
        })
        return
      }
      if (inputData.content.length > 1000) {
        uni.showToast({
          title: '评论内容不能超过1000个字',
          icon: 'none'
        })
        return
      }
      let type = this.placeholder !== '文明用语，友善交流…' ? 2 : 1
      let data = {
        content: inputData.arr.length ? JSON.stringify(inputData.arr) : '',
        contentImg: this.imgList && this.imgList.length ? this.imgList.join('&&') : '',
        taNumberIds: inputData.atUserList.join(',')
      }
      this.$emit('send', data, type)
      this.$nextTick(() => {
        this.onClear()
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-interaction {
  // 预览图片层级是999，弹窗层级和蒙版层级都要小于它
  /deep/.u-transition {
    z-index: 900 !important;
  }

  .popup-comment {
    padding: 0 30rpx;

    .friend-list {
      width: 100%;
      padding: 32rpx 0 22rpx;
      box-sizing: border-box;
      background-color: #ffffff;
      .scroll-box {
        height: 122rpx;

        .friend-box {
          display: flex;
          flex-wrap: nowrap;
          height: 100%;
        }
        .friend-item {
          flex-shrink: 0;
          width: 110rpx;
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-right: 30rpx;

          .friend-item-img {
            width: 80rpx;
            height: 80rpx;
            border-radius: 50%;
            margin-bottom: 10rpx;
          }
          .friend-item-text {
            font-size: 22rpx;
            color: #484848;
            line-height: 32rpx;
          }
        }
      }
    }

    .comment-textarea {
      width: 100%;
      background: #f6f6f8;
      border-radius: 40rpx;
      font-size: 26rpx;
      margin: 16rpx auto 20rpx;

      .textarea-box {
        padding: 22rpx 30rpx;
        border-radius: 40rpx;
        position: relative;

        // /deep/ uni-textarea {
        //   width: 100%;
        //   background: #f6f6f8;
        //   font-size: 28rpx !important;
        //   color: #2a343e;
        //   line-height: 44rpx;
        //   max-height: 132rpx !important;
        //   overflow-y: auto;
        // }
        /deep/.u-textarea {
          padding: 0;
          background-color: transparent;
          border-radius: 0;
        }
        /deep/.u-textarea__field {
          font-size: 28rpx !important;
          color: #2a343e;
          line-height: 44rpx;
          max-height: 132rpx !important;
          overflow-y: auto;
        }
      }
      .photo-list {
        height: 120rpx;
        padding: 0 30rpx 30rpx;
        .photo-list-item {
          width: 120rpx;
          height: 120rpx;
          margin-right: 12rpx;
          display: inline-block;
          position: relative;
          font-size: 0;
          .item-img {
            width: 100%;
            height: 100%;
            border-radius: 16rpx;
          }
          .item-icon {
            width: 16rpx;
            height: 16rpx;
            padding: 8rpx;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 0 16rpx 0 16rpx;
            position: absolute;
            top: 0;
            right: 0;
          }
        }
      }
    }

    .at-list {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      margin-bottom: 20rpx;
      .at-list-item {
        font-size: 24rpx;
        color: #fe5e10;
        line-height: 34rpx;
        margin-right: 6rpx;
      }
    }

    .comment-operate {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 20rpx;
      .operate-left {
        height: 64rpx;
        margin-left: -14rpx;
        display: flex;
        align-items: center;
        .icon-box {
          position: relative;
          font-size: 0;
        }
        .operate-left-icon {
          width: 36rpx;
          height: 36rpx;
          padding-right: 30rpx;
          padding: 14rpx;
          margin-right: 8rpx;
        }
        .operate-left-num {
          // font-size: 24rpx;
          // color: #fe5e10;
          // line-height: 34rpx;
          // position: absolute;
          // left: 54rpx;
          // top: 6rpx;
          width: 20rpx;
          height: 20rpx;
          border-radius: 6rpx;
          background-color: #fe5e10;
          font-size: 14rpx;
          color: #fff;
          line-height: 20rpx;
          text-align: center;
          position: absolute;
          left: 40rpx;
          top: 2rpx;
        }
      }
      .operate-right {
        height: 64rpx;
        font-size: 28rpx;
        color: #ffffff;
        line-height: 64rpx;
        padding: 0 40rpx;
        text-align: center;
        background: #fe5e10;
        border-radius: 40rpx;
      }
    }
  }
  .comment-emoji {
    width: 100%;
    padding: 0 30rpx;
    box-sizing: border-box;
  }
}
</style>
