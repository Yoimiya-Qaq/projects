<template>
  <!-- 一级评论列表 -->
  <view class="custom-comment-list">
    <!-- ----------------------------------------------精选评论start---------------------------------------------- -->
    <view class="featured-comments" v-if="featureList.length">
      <view class="title-box">精选评论</view>
      <view class="parent-list-item" v-for="(parentItem, parentIndex) in featureList" :key="parentItem.commentId">
        <image
          class="parent-list-item-img"
          :src="parentItem.userinfo.headUrl"
          @click.stop="
            $u.throttle(() => {
              goMyPage(parentItem.userinfo.numberId)
            })
          "
        />
        <view class="list-item-content" @click.stop="onReply(parentItem, parentIndex, true)" @longpress.stop="onLongPress(parentItem, parentIndex, true)" @touchend="touchEnd" @touchmove="touchMove">
          <view class="flex-box">
            <view class="flex-box-left">
              <view
                class="name"
                @click.stop="
                  $u.throttle(() => {
                    goMyPage(parentItem.userinfo.numberId)
                  })
                "
              >
                {{ parentItem.userinfo.nickName }}
                <text class="author-tag" v-if="parentItem.twitterCreateNumberId === parentItem.userinfo.numberId">作者</text>
              </view>
              <!-- 新的评论内容（数组格式） -->
              <view class="comment-text" v-if="parentItem.contentArr && parentItem.contentArr.length">
                <block v-for="(v1, i1) in parentItem.contentArr" :key="i1">
                  <text v-if="v1.type == 'text'">{{ v1.text }}</text>
                  <text
                    v-if="v1.type == 'name'"
                    style="color: #fe5e10"
                    @click.stop="
                      $u.throttle(() => {
                        goMyPage(v1.id)
                      })
                    "
                  >
                    {{ v1.text }}
                  </text>
                </block>
              </view>
              <!-- 兼容老版本的评论内容（字符串格式） -->
              <view class="comment-text" v-else>{{ parentItem.content }}</view>
            </view>
            <!-- 精选评论点赞 -->
            <view class="flex-box-right" @click.stop="handleLike(parentItem, 'first', true)">
              <image class="zan-icon" :src="parentItem.isZan ? require('@/static/images/find_like_a.png') : require('@/static/images/find_like.png')"></image>
              <view class="zan-num">{{ formatKWNumber(parentItem.zanCount) || 0 }}</view>
            </view>
          </view>
          <view class="img-list" v-if="parentItem.imgList && parentItem.imgList.length">
            <block v-for="(item, index) in parentItem.imgList" :key="index">
              <zero-lazy-load class="first-reply-img" :borderRadius="0" :image="item" :height="180" imgMode="aspectFill" @click.native.stop="handlePreviewImg(parentItem.imgList, index)"></zero-lazy-load>
            </block>
          </view>
          <view class="ability">
            <text class="time">{{ $u.timeFormat(parentItem.createTime, 'sendMsgFormat') || '' }}</text>
            <text v-if="parentItem.city">{{ ' · ' + parentItem.city }}</text>
            <text style="margin-left: 10rpx; color: #909396; font-weight: bold">回复</text>
          </view>
          <!-- 精选二级评论列表 -->
          <view class="child-list" v-if="parentItem.childCommentDTO.length">
            <block v-for="childItem in parentItem.childCommentDTO" :key="childItem.commentId">
              <view class="child-list-item">
                <image
                  class="child-list-item-img"
                  :src="childItem.userinfo.headUrl"
                  @click.stop="
                    $u.throttle(() => {
                      goMyPage(childItem.userinfo.numberId)
                    })
                  "
                />
                <view class="list-item-content" @click.stop="onReply(childItem, parentIndex, true)" @longpress.stop="onLongPress(childItem, parentIndex, true)" @touchend="touchEnd" @touchmove="touchMove">
                  <view class="flex-box">
                    <view class="flex-box-left">
                      <view
                        class="name"
                        @click.stop="
                          $u.throttle(() => {
                            goMyPage(childItem.userinfo.numberId)
                          })
                        "
                      >
                        {{ childItem.userinfo.nickName }}
                        <text class="author-tag" v-if="childItem.twitterCreateNumberId === childItem.userinfo.numberId">作者</text>
                      </view>
                      <!-- 新的评论内容（数组格式） -->
                      <view class="comment-text" v-if="childItem.contentArr && childItem.contentArr.length">
                        <block v-if="childItem.targetUserNickName">
                          <text style="margin-right: 8rpx">回复</text>
                          <text style="color: #afafaf">{{ childItem.targetUserNickName }}：</text>
                        </block>
                        <block v-for="(v1, i1) in childItem.contentArr" :key="i1">
                          <text v-if="v1.type == 'text'">{{ v1.text }}</text>
                          <text
                            v-if="v1.type == 'name'"
                            style="color: #fe5e10"
                            @click.stop="
                              $u.throttle(() => {
                                goMyPage(v1.id)
                              })
                            "
                          >
                            {{ v1.text }}
                          </text>
                        </block>
                      </view>
                      <!-- 兼容老版本的评论内容（字符串格式） -->
                      <view class="comment-text" v-else>
                        <block v-if="childItem.targetUserNickName">
                          <text style="margin-right: 8rpx">回复</text>
                          <text style="color: #afafaf">{{ childItem.targetUserNickName }}：</text>
                        </block>
                        {{ childItem.content }}
                      </view>
                    </view>
                    <!-- 精选二级评论点赞 -->
                    <view class="flex-box-right" @click.stop="handleLike(childItem, parentIndex, true)">
                      <image class="zan-icon" :src="childItem.isZan ? require('@/static/images/find_like_a.png') : require('@/static/images/find_like.png')"></image>
                      <view class="zan-num">{{ formatKWNumber(childItem.zanCount) || 0 }}</view>
                    </view>
                  </view>
                  <view class="img-list" v-if="childItem.imgList && childItem.imgList.length">
                    <block v-for="(item, index) in childItem.imgList" :key="index">
                      <zero-lazy-load class="second-reply-img" :borderRadius="0" :image="item" :height="150" imgMode="aspectFill" @click.native.stop="handlePreviewImg(childItem.imgList, index)"></zero-lazy-load>
                    </block>
                  </view>
                  <view class="ability">
                    <text class="time">{{ $u.timeFormat(childItem.createTime, 'sendMsgFormat') || '' }}</text>
                    <text v-if="childItem.city">{{ ' · ' + childItem.city }}</text>
                    <text style="margin-left: 10rpx; color: #909396; font-weight: bold">回复</text>
                  </view>
                </view>
              </view>
            </block>
          </view>
        </view>
      </view>

      <view class="space-box"></view>
      <view class="total-box">全部{{ formatKWNumber(totalCommentCount) || 0 }}条评论</view>
    </view>
    <!-- ----------------------------------------------精选评论end---------------------------------------------- -->

    <!-- ----------------------------------------------普通评论start---------------------------------------------- -->
    <block v-if="listData.length">
      <view class="parent-list-item" v-for="(parentItem, parentIndex) in listData" :key="parentItem.commentId">
        <image
          class="parent-list-item-img"
          :src="parentItem.userinfo.headUrl"
          @click.stop="
            $u.throttle(() => {
              goMyPage(parentItem.userinfo.numberId)
            })
          "
        />
        <view class="list-item-content" @click.stop="onReply(parentItem, parentIndex, false)" @longpress.stop="onLongPress(parentItem, parentIndex, false)" @touchend="touchEnd" @touchmove="touchMove">
          <view class="flex-box">
            <view class="flex-box-left">
              <view
                class="name"
                @click.stop="
                  $u.throttle(() => {
                    goMyPage(parentItem.userinfo.numberId)
                  })
                "
              >
                {{ parentItem.userinfo.nickName }}
                <text class="author-tag" v-if="parentItem.twitterCreateNumberId === parentItem.userinfo.numberId">作者</text>
              </view>
              <!-- 新的评论内容（数组格式） -->
              <view class="comment-text" v-if="parentItem.contentArr && parentItem.contentArr.length">
                <block v-for="(v1, i1) in parentItem.contentArr" :key="i1">
                  <text v-if="v1.type == 'text'">{{ v1.text }}</text>
                  <text
                    v-if="v1.type == 'name'"
                    style="color: #fe5e10"
                    @click.stop="
                      $u.throttle(() => {
                        goMyPage(v1.id)
                      })
                    "
                  >
                    {{ v1.text }}
                  </text>
                </block>
              </view>
              <!-- 兼容老版本的评论内容（字符串格式） -->
              <view class="comment-text" v-else>{{ parentItem.content }}</view>
            </view>
            <!-- 一级评论点赞 -->
            <view class="flex-box-right" @click.stop="handleLike(parentItem, 'first', false)">
              <image class="zan-icon" :src="parentItem.isZan ? require('@/static/images/find_like_a.png') : require('@/static/images/find_like.png')"></image>
              <view class="zan-num">{{ formatKWNumber(parentItem.zanCount) || 0 }}</view>
            </view>
          </view>
          <view class="img-list" v-if="parentItem.imgList && parentItem.imgList.length">
            <block v-for="(item, index) in parentItem.imgList" :key="index">
              <zero-lazy-load class="first-reply-img" :borderRadius="0" :image="item" :height="180" imgMode="aspectFill" @click.native.stop="handlePreviewImg(parentItem.imgList, index)"></zero-lazy-load>
            </block>
          </view>
          <view class="ability">
            <text class="time">{{ $u.timeFormat(parentItem.createTime, 'sendMsgFormat') || '' }}</text>
            <text v-if="parentItem.city">{{ ' · ' + parentItem.city }}</text>
            <text style="margin-left: 10rpx; color: #909396; font-weight: bold">回复</text>
          </view>
          <!-- 展开xx条回复，容错带出来的第一条评论被删了而后台没有带出新的第一条评论，导致所有二级评论都不展示的情况 -->
          <view class="reply-box2" v-if="!parentItem.childCommentDTO.length && Number(parentItem.commentCount) > 1" @click.stop="openChild(parentItem, parentIndex, false)">
            <view class="reply-box-text">展开{{ parentItem.commentCount || 0 }}条回复</view>
            <image class="reply-box-icon" src="@/static/images/find_arrow_down.png" />
          </view>
          <!-- 二级评论列表 -->
          <view class="child-list" v-if="parentItem.childCommentDTO && parentItem.childCommentDTO.length">
            <block v-for="childItem in parentItem.childCommentDTO" :key="childItem.commentId">
              <view class="child-list-item">
                <image
                  class="child-list-item-img"
                  :src="childItem.userinfo.headUrl"
                  @click.stop="
                    $u.throttle(() => {
                      goMyPage(childItem.userinfo.numberId)
                    })
                  "
                />
                <view class="list-item-content" @click.stop="onReply(childItem, parentIndex, false)" @longpress.stop="onLongPress(childItem, parentIndex, false)" @touchend="touchEnd" @touchmove="touchMove">
                  <view class="flex-box">
                    <view class="flex-box-left">
                      <view
                        class="name"
                        @click.stop="
                          $u.throttle(() => {
                            goMyPage(childItem.userinfo.numberId)
                          })
                        "
                      >
                        {{ childItem.userinfo.nickName }}
                        <text class="author-tag" v-if="childItem.twitterCreateNumberId === childItem.userinfo.numberId">作者</text>
                      </view>
                      <!-- 新的评论内容（数组格式） -->
                      <view class="comment-text" v-if="childItem.contentArr && childItem.contentArr.length">
                        <block v-if="childItem.targetUserNickName">
                          <text style="margin-right: 8rpx">回复</text>
                          <text style="color: #afafaf">{{ childItem.targetUserNickName }}：</text>
                        </block>
                        <block v-for="(v1, i1) in childItem.contentArr" :key="i1">
                          <text v-if="v1.type == 'text'">{{ v1.text }}</text>
                          <text
                            v-if="v1.type == 'name'"
                            style="color: #fe5e10"
                            @click.stop="
                              $u.throttle(() => {
                                goMyPage(v1.id)
                              })
                            "
                          >
                            {{ v1.text }}
                          </text>
                        </block>
                      </view>
                      <!-- 兼容老版本的评论内容（字符串格式） -->
                      <view class="comment-text" v-else>
                        <block v-if="childItem.targetUserNickName">
                          <text style="margin-right: 8rpx">回复</text>
                          <text style="color: #afafaf">{{ childItem.targetUserNickName }}：</text>
                        </block>
                        {{ childItem.content }}
                      </view>
                    </view>
                    <!-- 二级评论点赞 -->
                    <view class="flex-box-right" @click.stop="handleLike(childItem, parentIndex, false)">
                      <image class="zan-icon" :src="childItem.isZan ? require('@/static/images/find_like_a.png') : require('@/static/images/find_like.png')"></image>
                      <view class="zan-num">{{ formatKWNumber(childItem.zanCount) || 0 }}</view>
                    </view>
                  </view>
                  <view class="img-list" v-if="childItem.imgList && childItem.imgList.length">
                    <block v-for="(item, index) in childItem.imgList" :key="index">
                      <zero-lazy-load class="second-reply-img" :borderRadius="0" :image="item" :height="150" imgMode="aspectFill" @click.native.stop="handlePreviewImg(childItem.imgList, index)"></zero-lazy-load>
                    </block>
                  </view>
                  <view class="ability">
                    <text class="time">{{ $u.timeFormat(childItem.createTime, 'sendMsgFormat') || '' }}</text>
                    <text v-if="childItem.city">{{ ' · ' + childItem.city }}</text>
                    <text style="margin-left: 10rpx; color: #909396; font-weight: bold">回复</text>
                  </view>
                </view>
              </view>
              <!-- 展开xx条回复 -->
              <view class="reply-box" v-if="Number(parentItem.commentCount) > 1 && !parentItem.childLastKeyword && !childItem.notShow" @click.stop="openChild(parentItem, parentIndex, false)">
                <view class="reply-box-text">展开{{ parentItem.commentCount - 1 || 0 }}条回复</view>
                <image class="reply-box-icon" src="@/static/images/find_arrow_down.png" />
              </view>
            </block>
            <!-- 二级评论加载中状态 -->
            <u-loadmore class="tips-box" v-if="parentItem.secondLoadStatus == 'loading'" :status="parentItem.secondLoadStatus" :fontSize="20" nomore-text="到底了~" marginTop="0" marginBottom="0" />
            <!-- 展开更多回复 -->
            <view class="reply-box" v-if="Number(parentItem.commentCount) > 1 && parentItem.childLastKeyword && parentItem.secondLoadStatus === 'loadmore'" @click.stop="openChild(parentItem, parentIndex, false)">
              <view class="reply-box-text">展开更多回复</view>
              <image class="reply-box-icon" src="@/static/images/find_arrow_down.png"></image>
            </view>
          </view>
        </view>
      </view>
      <!-- 一级评论加载状态 -->
      <view class="first-tips-box">
        <u-loadmore :status="firstLoadStatus" :fontSize="20" nomore-text="到底了~" marginTop="0" marginBottom="0" />
      </view>
    </block>
    <!-- ----------------------------------------------普通评论end---------------------------------------------- -->
    <!-- 缺省图 -->
    <view class="empty-box" v-else>
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" mode="widthFix" />
      <view class="empty-text">暂无内容</view>
    </view>
  </view>
</template>

<script>
import { formatKWNumber } from '@/utils/tools'

export default {
  name: 'CustomCommentList',
  props: {
    /**
     * 精选评论
     */
    featureList: {
      type: Array,
      default: () => []
    },
    /**
     * 一级评论列表数据
     */
    listData: {
      type: Array,
      default: () => []
    },
    /**
     * 当前登录用户id
     */
    currUserId: {
      type: [String, Number],
      default: ''
    },
    /**
     * 评论总条数
     */
    totalCommentCount: {
      type: [String, Number],
      default: 0
    },
    /**
     * 一级评论加载状态
     */
    firstLoadStatus: {
      type: String,
      default: 'loadmore'
    }
  },
  data() {
    return {
      formatKWNumber,
      isLongtap: true, // 长按事件是否生效
      isLongPress: false // 区分长按和点击
    }
  },
  methods: {
    // 点击预览图片
    handlePreviewImg(list, e) {
      uni.previewImage({
        urls: list,
        current: e
      })
    },
    // 点赞评论
    handleLike(item, type, flag) {
      item.isFeature = flag
      this.$emit('like', item, type)
    },
    // 展开二级评论
    openChild(item, index, flag) {
      item.isFeature = flag
      this.$emit('open', item, index)
    },
    // 回复
    onReply(item, index, flag) {
      if (!this.isLongPress) {
        item.isFeature = flag
        this.$emit('reply', item, index)
      }
    },
    /**
     * 用来解决长按事件敏感触发的问题
     * touchEnd
     * touchMove
     */
    touchEnd() {
      this.isLongtap = true
      //延时执行为了防止 click() 还未判断 islongPress 的值就被置为 fasle
      setTimeout(() => {
        this.isLongPress = false
      }, 200)
    },
    // 手指触摸后的移动事件
    touchMove() {
      this.isLongtap = false
    },
    // 长按评论
    onLongPress(item, index, flag) {
      this.isLongPress = true
      if (!this.isLongtap) {
        // 当前是滑动事件，中断长按事件
        return
      }
      item.isFeature = flag
      this.$emit('longpress', item, index)
    },
    // 去个人主页
    goMyPage(numberId) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + numberId })
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-comment-list {
  min-height: 428rpx;

  .featured-comments {
    font-size: 28rpx;
    color: #373d44;
    line-height: 40rpx;
  }

  .title-box {
    font-size: 28rpx;
    color: #373d44;
    line-height: 40rpx;
    font-weight: bold;
    margin-bottom: 24rpx;
    margin-top: -14rpx;
  }

  .space-box {
    width: 750rpx;
    height: 16rpx;
    background: #f6f6f8;
    margin-left: -36rpx;
  }

  .total-box {
    padding: 24rpx 0 30rpx;
    font-size: 22rpx;
    color: #484848;
    line-height: 32rpx;
  }

  .parent-list-item {
    display: flex;
    margin-bottom: 30rpx;

    .parent-list-item-img {
      width: 60rpx;
      height: 60rpx;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .list-item-content {
      flex: 1;
      margin-left: 20rpx;

      .flex-box {
        display: flex;
        .flex-box-left {
          flex: 1;
          .name {
            font-size: 26rpx;
            color: #afafaf;
            line-height: 36rpx;
            display: inline-block;
            .author-tag {
              display: inline-block;
              font-size: 20rpx;
              color: #fe5e10;
              line-height: 28rpx;
              padding: 0 6rpx 2rpx;
              background: #ffede4;
              border-radius: 4rpx;
              margin-left: 12rpx;
            }
          }
          .comment-text {
            font-size: 28rpx;
            color: #333333;
            line-height: 40rpx;
            margin-top: 8rpx;
            word-break: break-all;
            line-break: anywhere;
            text-align: justify;
          }
        }
        .flex-box-right {
          flex-shrink: 0;
          font-size: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          padding-left: 24rpx;
          .zan-icon {
            width: 36rpx;
            height: 36rpx;
            margin-bottom: 10rpx;
          }
          .zan-num {
            font-size: 22rpx;
            color: #7a8086;
            line-height: 32rpx;
            text-align: center;
          }
        }
      }
      .img-list {
        display: flex;
        align-items: center;
        margin: 16rpx 0;
        .first-reply-img {
          width: 180rpx;
          height: 180rpx;
          margin-right: 6rpx;
        }
        .second-reply-img {
          width: 150rpx;
          height: 150rpx;
          margin-right: 6rpx;
        }
      }
      .ability {
        font-size: 22rpx;
        color: #8d939b;
        line-height: 32rpx;
        margin-top: 10rpx;
      }
    }

    .child-list {
      .child-list-item {
        display: flex;
        margin-top: 24rpx;
        &-img {
          width: 50rpx;
          height: 50rpx;
          border-radius: 50%;
          flex-shrink: 0;
        }
      }
      .reply-box {
        margin-top: 10rpx;
        margin-left: 70rpx;
        display: flex;
        align-items: center;

        .reply-box-text {
          font-size: 22rpx;
          color: #93939f;
          line-height: 32rpx;
        }
        .reply-box-icon {
          width: 10rpx;
          height: 8rpx;
          margin-left: 8rpx;
        }
      }
    }
    .reply-box2 {
      margin-top: 10rpx;
      display: flex;
      align-items: center;

      .reply-box-text {
        font-size: 22rpx;
        color: #93939f;
        line-height: 32rpx;
      }
      .reply-box-icon {
        width: 10rpx;
        height: 8rpx;
        margin-left: 8rpx;
      }
    }
  }
  .tips-box {
    height: 32rpx;
  }
  /deep/ .u-loadmore {
    display: inline-flex !important;
    margin-left: 40rpx;
  }
  /deep/.u-loadmore__content__text {
    line-height: 32rpx !important;
  }

  .first-tips-box {
    padding-top: 24rpx;
    /deep/ .u-loadmore {
      display: flex !important;
      margin-left: 0;
    }
  }

  .empty-box {
    text-align: center;
    font-size: 0;
    padding: 44rpx 0 114rpx;
    margin: 0 auto;
    .empty-img {
      width: 274rpx;
      height: 198rpx;
      margin-bottom: 18px;
    }
    .empty-text {
      font-size: 24rpx;
      color: #adb3ba;
      line-height: 34rpx;
    }
  }
}
</style>
