export function eventReceive() {
  uni.onNativeEventReceive((event, data) => {
    console.log('接收到宿主App消息：' + event + data)
    if (event == 'appData') {
      let datas = JSON.parse(data)
      let msgs = '接收到token:' + datas.token + ',numberId:' + datas.numberId + ',phone:' + datas.phone
      uni.setStorage({
        key: 'numberId',
        data: datas.numberId, //'62605101'
      })
      uni.setStorage({
        key: 'token',
        data: datas.token, //'5eea53d5888744918f036ccc5bbfc7edzo87xE',
      })
      uni.setStorage({
        key: 'phone',
        data: datas.phone, //'5eea53d5888744918f036ccc5bbfc7edzo87xE',
      })
      uni.setStorage({
        key: 'appVersion',
        data: datas.appVersion, //'5eea53d5888744918f036ccc5bbfc7edzo87xE',
      })
      // uni.showToast({
      //   title: msgs,
      //   icon: 'none',
      //   duration: 2000,
      // })
    }
    if (event == 'test') {
      let msgs = '接收到test:' + data
      // uni.showToast({
      //   title: msgs,
      //   icon: 'none',
      //   duration: 3000,
      // })
    }
  })
}
