<template>
  <view class="custom-modal-new-container">
    <u-popup :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onCancel" @open="onOpen">
      <!-- confirm弹框 -->
      <view class="confirm-wrap">
        <view class="confirm-wrap-title">{{ title }}</view>
        <view class="confirm-wrap-content">{{ content }}</view>
        <!-- 底部按钮 -->
        <view class="confirm-wrap-btns">
          <view class="left-btn" @click="onCancel">{{ cancelText }}</view>
          <view class="right-btn" @click="onConfirm">{{ confirmText }}</view>
        </view>
      </view>
    </u-popup>
  </view>
</template>

<script>
export default {
  name: 'CustomModalNew',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 24
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // 弹框标题
    title: {
      type: String,
      default: ''
    },
    // 弹框内容
    content: {
      type: String,
      default: ''
    },
    // 取消按钮的文字，type=alert时此参数无效
    cancelText: {
      type: String,
      default: '取消'
    },
    // 确认按钮的文字
    confirmText: {
      type: String,
      default: '确定'
    }
  },
  data() {
    return {}
  },
  methods: {
    onOpen() {
      this.$emit('open')
    },
    onCancel() {
      this.$emit('cancel')
    },
    onConfirm() {
      this.$emit('confirm')
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-modal-new-container {
  .confirm-wrap {
    width: 558rpx;
    padding: 0 46rpx;
    box-sizing: border-box;
    // 标题
    &-title {
      font-size: 32rpx;
      font-weight: bold;
      text-align: center;
      color: #333333;
      line-height: 50rpx;
      padding: 44rpx 0 30rpx;
    }
    // 内容
    &-content {
      font-size: 28rpx;
      font-weight: 500;
      text-align: center;
      color: #333333;
      line-height: 46rpx;
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      word-break: break-all;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    // 底部按钮
    &-btns {
      width: 100%;
      padding: 40rpx 0;
      display: flex;
      box-sizing: border-box;

      .left-btn {
        flex: 1;
        height: 72rpx;
        line-height: 72rpx;
        font-size: 28rpx;
        font-weight: bold;
        text-align: center;
        color: #838e9a;
        background: #e9ebef;
        border-radius: 40rpx;
        box-shadow: 0rpx 12rpx 16rpx 0rpx rgba(189, 194, 214, 0.14);
      }
      .right-btn {
        flex: 1;
        height: 72rpx;
        line-height: 72rpx;
        font-size: 28rpx;
        font-weight: bold;
        text-align: center;
        color: #ffffff;
        background: linear-gradient(90deg, #ff6a6a 1%, #ff4280);
        border-radius: 40rpx;
        box-shadow: 0rpx 12rpx 16rpx 0rpx rgba(220, 51, 69, 0.14);
        margin-left: 30rpx;
      }
    }
  }
}
</style>
