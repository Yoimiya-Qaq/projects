<template>
	<view class="template-box" v-if="templateList.length">
		<scroll-view class="scroll-template-box" scroll-y @scrolltolower="getTemplateList('nextPage')">
			<view class="white-fill-box"></view>
			<view class="template-list-box">
				<view class="title-box h-flex-sb">
					<view style="position: relative;">
						精选模版
						<view class="current-tag"></view>
					</view>

					<image src="http://img.yiqitogether.com/static/img/template-close.png" mode="" class="template-close"
						@click="closePopup"></image>
				</view>
				<view class="normalActivity-list">
					<view class="normalActivity-item" v-for="(item, index) in templateList" :key="item.appointmentNo" @click="previewTemplate(item)">
						<image class="normalActivity-item-bgImg" :src="item.pic[0]" mode="aspectFill" />
						<view class="normalActivity-item-content">
							<view class="item-content-top flex-0">
								<view class="content-top-left">
									<image class="top-left-img" :src="item.pic[0]" mode="aspectFill" />
									<view class="top-left-text">
										<view class="top-left-title ellipsis-single">{{ item.name }}</view>
										<view class="top-left-intro ellipsis-single">{{ item.description }}</view>
									</view>
								</view>
								<view class="content-top-right">
									<view class="content-top-right-content">
										<view class="right-content">
											<view class="right-content-item flex-0">
												<image class="right-content-icon" src="@/static/images/shijian2.png" mode="scaleToFill" />
												<view class="right-content-text">{{ $u.timeFormat(item.appointDateTimestamp, '周E hh:MM') }}
												</view>
											</view>
											<view class="right-content-item flex-0">
												<image class="right-content-icon" src="@/static/images/weizhi2.png" mode="scaleToFill" />
												<view class="right-content-text ellipsis-single">{{ item.address.city }}</view>
											</view>
											<view class="right-content-item flex-0">
												<image class="right-content-icon" src="@/static/images/weizhi1.png" mode="scaleToFill" />
												<view class="right-content-text ellipsis-single">{{ item.place }}</view>
											</view>
											<view class="right-content-item flex-0">
												<image class="right-content-icon" src="@/static/images/maidan.png" mode="scaleToFill" />
												<view class="right-content-text">{{ item.feeType.text }}</view>
											</view>
											<view class="right-content-item flex-0">
												<image class="right-content-icon" src="@/static/images/renyuan.png" mode="scaleToFill" />
												<view class="right-content-text">
													{{ item.currentCount?item.currentCount:0 }}/{{ item.appointmentCount }}</view>
											</view>
										</view>
									</view>
									<view class="right-content-time">
										{{ $u.timeFormat(item.appointDateTimestamp, 'yyyy-mm-dd') }}
									</view>
								</view>
							</view>
							<view class="item-content-bottom flex-1">
								<view class="icontent-bottom-left flex-0">
									<view class="bottom-left-img">
										<image @click.stop="$u.throttle(() => { goHomePage(item.userId) }, 500)" class="userImg" :src="item.userLogo" mode="scaleToFill" />
										<image v-if="item.sex == '女'" class="gender"
											src="https://img.yiqitogether.com/static/local/index/nv_s@2x.png" mode="scaleToFill" />
										<image v-if="item.sex == '男'" class="gender"
											src="https://img.yiqitogether.com/static/local/index/nan_s@2x.png" mode="scaleToFill" />
									</view>
									<view class="bottom-left-name ellipsis-single">{{ item.userName }}</view>
								</view>
								<view class="icontent-bottom-right">
									使用
								</view>
							</view>
						</view>
					</view>
				</view>

				<!-- 加载状态 -->
				<view class="">
					<u-loadmore fontSize="20" v-if="requestFlag && hasNextPage" status="loadmore" />
					<u-loadmore fontSize="20" v-if="!requestFlag" status="loading" />
					<u-loadmore fontSize="20" v-if="!hasNextPage" status="nomore" />
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	// 导入接口
	import findModel from '@/model/find.js'


	export default {
		name: "publish-activity-template",
		data() {
			return {
				pageNo: 1,
				pageSize: 3,
				templateList: [],
				requestFlag: true,
				hasNextPage: true,

			};
		},
		created() {
			this.getTemplateList('refresh')
		},
		methods: {
			/**
			 * @param {Object} type 请求类型
			 * 'nextPage' 获取更多，数据追加
			 * 'refresh'  重新获取第一页，数据替换
			 */
			getTemplateList(type) {
				if (!this.requestFlag) {
					return
				}
				this.requestFlag = false

				if (type === 'nextPage') {
					if (!this.hasNextPage) {
						return this.requestFlag = true
					}
					this.pageNo++
				} else if (type === 'refresh') {
					this.pageNo = 1
				}

				let params = {
					pageNo: this.pageNo,
					pageSize: this.pageSize
				}
				findModel.getActivityTemplateData(params)
					.then((res) => {
						if (type === 'nextPage') {
							this.templateList = [...this.templateList, ...res.data.templateList]
						} else if (type === 'refresh') {
							this.templateList = res.data.templateList
						}
						this.hasNextPage = res.data.hasNextPage
						this.requestFlag = true
					})
					.catch((err => {
						this.requestFlag = true
					}))
			},
			// 关闭模版弹窗
			closePopup() {
				this.$emit('closePopup', false)
			},
			/**
			 * @param {Object} item 模版对象
			 * @function useTemplate 在详情页调用使用模版事件
			 */
			previewTemplate(item) {
				let self = this
				uni.navigateTo({
					url: `/pagesCommon/details/details?appointmentNo=${item.appointmentNo}&from=activityTemplate`,
					events: {
						useTemplate: function(appointmentNo) {
							self.useTemplate(item)
						}
					}
				})
			},
			// 去个人主页
			goHomePage(item) {
			  uni.navigateTo({
			    url: '/pagesMy/my/myHomePages/index?userId=' + item + '&checkedTab=2'
			  })
			},
			/**
			 * 使用模版填充
			 */
			useTemplate() {
				this.$emit('useTemplate','useTemplate')
				this.$emit('closePopup')
			}
		}
	}
</script>

<style scoped lang="scss">
	.flex-0 {
		display: flex;
		align-items: center;
	}

	.flex-1 {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.flex-2 {
		display: flex;
		justify-content: space-between;
	}

	.flex-3 {
		display: flex;
		justify-content: space-around;
		align-items: center;
	}

	.flex-4 {
		display: flex;
		align-items: flex-end;
	}

	.flex-5 {
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.template-box {
		position: fixed;
		top: var(--status-bar-height);
		left: 0;
		width: 100vw;
		height: calc(100vh - var(--status-bar-height));
		background-color: rgba(0, 0, 0, 0.5);
		overflow: hidden;
		z-index: 999;

		.scroll-template-box {
			width: 100%;
			height: 100%;

			.white-fill-box {
				width: 100%;
				height: 40%;
			}

			.template-list-box {
				width: 100%;
				min-height: 60%;
				padding: 0 0 40rpx;
				box-sizing: border-box;
				background-color: #fff;
				border-radius: 40rpx 40rpx 0 0;
				position: relative;
				z-index: 2;
				
				.title-box {
					position: sticky;
					top: 0;
					width: 100%;
					padding: 40rpx;
					box-sizing: border-box;
					background-color: #fff;
					font-size: 32rpx;
					font-weight: 600;
					text-align: left;
					color: #2a343e;
					z-index: 1;
					border-radius: 40rpx 40rpx 0 0;

					.template-close {
						width: 48rpx;
						height: 48rpx;
						display: block;
					}

					.current-tag {
						position: absolute;
						left: 50%;
						bottom: 0;
						width: 40rpx;
						height: 8rpx;
						background: #2a343e;
						border-radius: 6rpx;
						transform: translate(-50%, 10rpx);
					}
				}

				.cart-box {
					width: 100%;
					height: 300rpx;
					margin-bottom: 30rpx;
					background-color: green;
					color: #fff;
				}
			}
		}
	}

	.normalActivity-list {
		padding: 0 40rpx;

		.normalActivity-item {
			position: relative;
			height: 460rpx;
			margin-bottom: 44rpx;

			.normalActivity-item-bgImg {
				width: 100%;
				height: 372rpx;
				filter: blur(5rpx) brightness(0.9);
				border-radius: 30rpx 30rpx 0 0;
			}

			.normalActivity-item-content {
				top: 0;
				position: absolute;
				width: 100%;

				.item-content-top {
					.content-top-left {
						position: relative;
						color: #ffffff;

						.top-left-img {
							width: 372rpx;
							height: 372rpx;
							border-radius: 20rpx 20rpx 20rpx 0;
							display: block;
						}

						.top-left-text {
							position: absolute;
							background: url('@/static/images/beijingshadow.png');
							background-size: 100% 100%;
							bottom: 0;
							width: 100%;
							box-sizing: border-box;
							padding: 0 0 28rpx 20rpx;
							border-radius: 20rpx 20rpx 20rpx 0;
							background: linear-gradient(180deg, rgba(255, 252, 252, 0) 4%, rgba(47, 47, 47, 0.3) 50%, rgba(0, 0, 0, 0.8) 100%);

							.top-left-title {
								width: 300rpx;
								height: 44rpx;
								font-size: 32rpx;
								line-height: 44rpx;
								margin-bottom: 4rpx;
							}

							.top-left-intro {
								width: 318rpx;
								height: 28rpx;
								font-size: 20rpx;
								line-height: 28rpx;
							}
						}
					}

					.content-top-right {
						margin-left: 38rpx;
						background: url('@/static/images/beijingshadow2.png');
						background-size: 100% 100%;
						width: 228rpx;
						height: 290rpx;
						position: relative;

						.content-top-right-content {
							width: 178rpx;
							padding: 22rpx 0 32rpx;
							margin: auto;

							.right-content {
								.right-content-item {
									margin-bottom: 12rpx;

									.right-content-icon {
										flex-shrink: 0;
										width: 20rpx;
										height: 20rpx;
										margin-right: 8rpx;
									}

									.right-content-text {
										flex-grow: 1;
										font-size: 24rpx;
										color: #2a343e;
									}
								}
							}
						}

						.right-content-time {
							left: 18%;
							font-size: 26rpx;
							color: #ffffff;
							position: absolute;
							bottom: 3%;
						}
					}
				}

				.item-content-bottom {
					padding: 20rpx;
					width: 670rpx;
					background: #ffffff;
					border-radius: 0 0 20rpx 20rpx;
					box-sizing: border-box;
					width: 100%;

					.icontent-bottom-left {
						.bottom-left-img {
							width: 40rpx;
							height: 40rpx;
							position: relative;

							.userImg {
								width: 40rpx;
								height: 40rpx;
								border-radius: 50%;
							}

							.gender {
								position: absolute;
								bottom: 0;
								right: 0;
								width: 14rpx;
								height: 14rpx;
							}
						}

						.bottom-left-name {
							max-width: 174rpx;
							font-size: 22rpx;
							color: #4e4e4e;
							margin-left: 12rpx;
						}
					}

					.icontent-bottom-right {
						width: 60rpx;
						height: 28rpx;
						border: 1rpx solid #1c1c1c;
						border-radius: 4rpx;
						font-size: 18rpx;
						text-align: center;
						color: #1c1c1c;
						line-height: 28rpx;
					}
				}
			}
		}

		.normalActivity-item:last-child {
			margin: 0;
		}
	}
</style>