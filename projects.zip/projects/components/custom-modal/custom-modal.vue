<template>
  <u-popup class="custom-modal-container" :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onCancel" @open="onOpen" :safeAreaInsetBottom="false" @touchmove.native.stop.prevent>
    <!-- 关闭按钮 -->
    <image class="close-icon" v-if="showClose" :style="{ 'border-top-right-radius': round + 'rpx' }" src="@/static/images/myImgs/bjzl_zybj_delete@2x.png" mode="aspectFill" @click="onClose" />
    <!-- alert弹框 -->
    <view class="alert-wrap" v-if="type == 'alert'">
      <view class="alert-wrap-title">{{ title }}</view>
      <!-- 内容自定义 -->
      <slot></slot>
      <!-- 底部按钮 -->
      <view class="alert-wrap-btn" :style="{ background: themeColor }" @click="onConfirm">{{ confirmText }}</view>
    </view>

    <!-- 说明弹框 -->
    <view class="tipsconfirm-wrap-new des-wrap" v-if="type == 'description'">
      <view class="alert-wrap-title">{{ title }}</view>
      <!-- 内容自定义 -->
      <slot></slot>
      <!-- 底部按钮 -->
      <view class="alert-wrap-btn des-wrap-btn" :style="{ color: themeColor }" @click="onConfirm">{{ confirmText }}</view>
    </view>

    <!-- tipsConfirm弹框 -->
    <view class="tipsconfirm-wrap" v-if="type == 'tipsConfirm'">
      <view class="tipsconfirm-wrap-title">{{ title }}</view>
      <view class="tipsconfirm-wrap-content">{{ content }}</view>
      <slot></slot>
      <!-- 底部按钮 -->
      <view class="tipsconfirm-wrap-btns">
        <u-button :style="{ color: themeColor }" type="error" :text="cancelText" color="#f6f7f8" :throttleTime="throttleTime" @click="onCancel"></u-button>
        <u-button type="error" :text="confirmText" :color="themeColor" :throttleTime="throttleTime" @click="onConfirm"></u-button>
      </view>
    </view>

    <!-- confirm弹框 -->
    <view class="confirm-wrap" v-if="type == 'confirm'">
      <view class="confirm-wrap-content">{{ content }}</view>
      <!-- 底部按钮 -->
      <view class="confirm-wrap-btns">
        <u-button style="color: #333333" :text="cancelText" :throttleTime="throttleTime" @click="onCancel"></u-button>
        <u-button :style="{ color: themeColor }" :text="confirmText" :throttleTime="throttleTime" @click="onConfirm"></u-button>
      </view>
    </view>
    <!-- know弹框 -->
    <view class="tipsconfirm-wrap-new" v-if="type == 'know'">
      <view class="tipsconfirm-wrap-content-new">
        {{ content }}
      </view>
      <slot></slot>
      <view class="tipsconfirm-wrap-btns-new" @click="onConfirm">{{ confirmText }}</view>
    </view>
  </u-popup>
</template>

<script>
export default {
  name: 'CustomModal',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    /**
     * 弹框类型：
     * · alert-提示弹框
     * · confirm-确认弹框
     * · tipsConfirm-带提示语的确认弹框
     */
    type: {
      type: String,
      default: 'alert'
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 24
    },
    // 遮罩打开或收起的动画过渡时间，单位ms
    duration: {
      type: [Number, String],
      default: 300
    },
    // 节流，一定时间内只能触发一次，单位毫秒
    throttleTime: {
      type: [Number, String],
      default: 500
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: false
    },
    // 是否展示关闭按钮
    showClose: {
      type: Boolean,
      default: false
    },
    // 主题色，旧版主题色#ff466d，新版主题色#FE5E10
    themeColor: {
      type: String,
      default: '#FE5E10'
    },
    // 弹框标题，type=confirm时此参数无效
    title: {
      type: String,
      default: ''
    },
    // 弹框内容
    content: {
      type: String,
      default: ''
    },
    // 取消按钮的文字，type=alert时此参数无效
    cancelText: {
      type: String,
      default: '取消'
    },
    // 确认按钮的文字
    confirmText: {
      type: String,
      default: '确定'
    }
  },
  data() {
    return {}
  },
  methods: {
    onOpen() {
      this.$emit('open')
    },
    onClose() {
      this.$emit('close')
    },
    onCancel() {
      this.$emit('cancel')
    },
    onConfirm() {
      this.$emit('confirm')
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-modal-container {
  .close-icon {
    width: 24rpx;
    height: 24rpx;
    position: absolute;
    padding: 30rpx;
    top: 0;
    right: 0;
  }
  // alert弹框
  .alert-wrap {
    text-align: center;
    // 标题
    &-title {
      font-size: 32rpx;
      font-weight: 700;
      text-align: center;
      color: #333333;
      line-height: 50rpx;
      padding: 30rpx 0;
    }
    // 底部按钮
    &-btn {
      width: 386rpx;
      height: 72rpx;
      border-radius: 40rpx;
      font-size: 28rpx;
      font-weight: 700;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 30rpx 54rpx 40rpx;
    }
  }

  // tipsConfirm弹框
  .tipsconfirm-wrap {
    width: 578rpx;
    padding: 60rpx 0 50rpx;
    // 标题
    &-title {
      font-size: 28rpx;
      font-weight: 700;
      text-align: center;
      color: #333333;
      line-height: 44rpx;
      padding-bottom: 20rpx;
    }
    // 内容
    &-content {
      font-size: 24rpx;
      text-align: center;
      color: #333333;
      line-height: 46rpx;
      padding: 0 50rpx;
      box-sizing: border-box;
      white-space: pre-wrap;
    }
    // 底部按钮
    .tipsconfirm-wrap-btns {
      display: flex;
      justify-content: center;
      margin-top: 30rpx;
      /deep/ .u-button {
        width: 220rpx;
        height: 72rpx;
        font-size: 24rpx;
        border-radius: 40rpx;
        margin: 0;
      }
      /deep/ .u-button + .u-button {
        margin-left: 50rpx;
      }
    }
  }

  // confirm弹框
  .confirm-wrap {
    width: 560rpx;
    // 内容
    &-content {
      width: 560rpx;
      height: 196rpx;
      padding: 0 50rpx 4rpx;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: center;
      font-size: 32rpx;
      text-align: center;
      color: #333333;
      line-height: 48rpx;
      overflow: hidden;
    }
    // 底部按钮
    &-btns {
      width: 100%;
      height: 100rpx;
      display: flex;
      align-items: center;
      border-top: 2rpx solid #e5e5e5;
      box-sizing: border-box;

      /deep/ .u-button {
        flex: 1;
        height: 100rpx;
        border-radius: 0;
        margin: 0;
        border: none;
        background: transparent;
      }
      /deep/ .u-button + .u-button {
        border-left: 2rpx solid #e5e5e5;
      }
      /deep/.u-button__text {
        font-size: 32rpx !important;
      }
    }
  }
}

.tipsconfirm-wrap-new {
  width: 560rpx;
  // height: 248rpx;
  background: #ffffff;
  border-radius: 20rpx;
  padding: 0 29rpx;
  box-sizing: border-box;
}

.tipsconfirm-wrap-content-new {
  width: 100%;
  text-align: center;
  font-size: 34rpx;
  color: #484848;
  word-break: break-all;
  margin-top: 62rpx;
}

.tipsconfirm-wrap-btns-new {
  width: 100%;
  height: 82rpx;
  line-height: 82rpx;
  text-align: center;
  font-size: 28rpx;
  color: #fe5e10;
  margin-top: 54rpx;
  border-top: 2rpx solid #f7f7f7;
}

.des-wrap-btn {
  width: 100% !important;
  height: 84rpx !important;
  border-radius: 42rpx !important;
  background: #f6f6f8;
  font-weight: 400 !important;
  margin: 50rpx 0 !important;
}

.des-wrap {
  width: 630rpx !important;
  height: auto !important;
  padding: 0 50rpx;
}
</style>
