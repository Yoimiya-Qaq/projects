<template>
  <view :class="isApp ? 'bottom-tab' : 'bottom-tab istab'" :style="{ 'z-index': hidden ? '0' : '' }">
    <view :class="item.center == true ? 'bottom-tab-item-center' : 'bottom-tab-item-sider'" @click="changeTap(item)" v-for="(item, index) in tabList" :key="index">
      <image v-if="tabIndex == item.id" class="first-img" :src="item.imgOn"></image>
      <image v-if="tabIndex != item.id" class="first-img" :src="item.imgOff"></image>
      <text :class="tabIndex == item.id ? 'text-position text-on' : 'text-position'">{{ item.name }}</text>
      <text v-if="item.id == 4 && msgNum > 0" class="msg-num">{{ msgNum }}</text>
    </view>
  </view>
</template>

<script>
export default {
  name: 'bottomTab',
  props: {
    hidden: {
      // 是否隐藏tab
      type: Boolean,
      default: false
    },
    tabIndex: {
      //图片的尺寸
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      curTab: 1,
      // id == 3 不再使用，1.0版本tabbar中间的加号
      tabList: [
        {
          id: 1,
          name: '首页',
          imgOff: '/static/tab-icon/index-f.png',
          imgOn: '/static/tab-icon/index-t.png',
          url: 'pages/index/index'
        },
        // {
        // 	id: 6,
        // 	name: '优选',
        // 	imgOff: '/static/tab-icon/shop-f.png',
        // 	imgOn: '/static/tab-icon/shop-t.png',
        // 	url: 'pages/shop/shop',
        // },
        {
          id: 2,
          name: '发现',
          imgOff: '/static/tab-icon/find-f.png',
          imgOn: '/static/tab-icon/find-t.png',
          url: 'pages/find/index'
        },
        // {
        // 	id: 3,
        // 	name: "",
        // 	imgOff: "https://img.yiqitogether.com/static/local/leo/fabuhuodong@2x.png",
        // 	imgOn: "https://img.yiqitogether.com/static/local/leo/fabuhuodong@2x.png",
        // 	"url": "",
        // 	center:true
        // },
        // #ifndef MP-WEIXIN
        {
          id: 4,
          name: '消息',
          imgOff: '/static/tab-icon/message-f.png',
          imgOn: '/static/tab-icon/message-t.png',
          url: 'pages/message/index'
        },
        // #endif
        {
          id: 5,
          name: '我的',
          imgOff: '/static/tab-icon/my-f.png',
          imgOn: '/static/tab-icon/my-t.png',
          url: 'pages/my/index'
        }
      ],
      isApp: true,
      msgNum: 0
    }
  },
  mounted(e) {
    let that = this
    uni.onNativeEventReceive((event, data) => {
      if (event == 'androidSwitchTab' && this.tabIndex != data + 1) {
        that.changeTap(that.tabList[data])
      }
      if (event == 'unReadMsgCount') {
        that.msgNum = data
        uni.setStorage({
          key: 'msgNum',
          data: that.msgNum //
        })
      }
    })
    if (that.msgNum == 0 && uni.getStorageSync('msgNum')) {
      that.msgNum = uni.getStorageSync('msgNum')
    }
  },
  methods: {
    changeTap(e) {
      console.log(`当前跳转页面：${e.name},id:${e.id}`)
      if (e.id == 4) {
        // #ifdef  APP-PLUS
        let testModule = uni.requireNativePlugin('TestModule')
        testModule.goAndroidMsg({}, ret => {})
        // #endif
      } else if (this.tabIndex != e.id) {
        uni.reLaunch({
          url: '/' + e.url
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.bottom-tab {
  position: fixed;
  background: url('https://img.yiqitogether.com/static/local/leo/daohang_bg@2x.png') no-repeat;
  background-size: 100% 100%;
  bottom: 0%;
  left: 0%;
  width: 100%;
  height: 140rpx;
  z-index: 99999;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  border: 2rpx solid #f0f0f0;
  .bottom-tab-item-center {
    width: 20%;
    height: 110rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;

    .first-img {
      width: 82rpx;
      height: 82rpx;
      // margin-top: -0.8rem;
      border-radius: 50%;
      margin-bottom: 6rpx;
    }
  }

  .bottom-tab-item-sider {
    width: 20%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 110rpx;
    position: relative;

    .first-img {
      width: 52rpx;
      height: 52rpx;
      margin-bottom: 6rpx;
    }

    .text-position {
      margin-top: 0rem;
      font-size: 24rpx;
      color: #aaaaaa;
    }

    .text-on {
      color: #ff466d;
    }
  }
}

.istab {
  justify-content: space-around;
}

.msg-num {
  width: 28rpx;
  height: 28rpx;
  background: #ff466d;
  border: 2rpx solid #ffffff;
  font-size: 20rpx;
  font-weight: 400;
  text-align: center;
  color: #ffffff;
  line-height: 28rpx;
  border-radius: 50%;
  position: absolute;
  top: 8rpx;
  right: 24%;
}
</style>
