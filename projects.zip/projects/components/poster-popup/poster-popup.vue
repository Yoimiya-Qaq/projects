<template>
  <u-overlay :show="show" @close="closePopup">
    <view>
      <view class="share_box" v-if="shareUrl">
        <view class="share" style="height: 350rpx">
          <view class="h-flex-center h-flex-sb" style="margin-bottom: 56rpx">
            <view
              class="share-list share-list-gray"
              @click.stop="
                $u.throttle(() => {
                  shareImageText('WXSceneSession')
                }, 500)
              "
            >
              <image src="https://img.yiqitogether.com/static/local/myImagesV2/wx%402x.png" mode=""></image>
              微信好友
            </view>
            <view
              class="share-list share-list-gray"
              @click.stop="
                $u.throttle(() => {
                  shareImageText('WXSceneTimeline')
                }, 500)
              "
            >
              <image src="https://img.yiqitogether.com/static/local/myImagesV2/pyq%402x.png" mode=""></image>
              朋友圈
            </view>
            <view v-if="pageType == 'face' || pageType == 'topicsPage' || pageType == 'luckDraw'" @click.stop="copy" class="share-list share-list-gray">
              <image src="@/static/images/recruitImgs/fx_lj@2x.png" mode=""></image>
              复制链接
            </view>
            <view v-else-if="pageType == 'faceVote'" hidden></view>
            <view v-else class="share-list share-list-gray" @click.stop="$u.throttle(showPoster, 500)">
              <image src="../../static/images/lj@2x.png" mode=""></image>
              生成海报
            </view>
          </view>
          <view class="cancle" @click.stop="showUrl">取消</view>
        </view>
      </view>
      <view class="share_box" v-if="sharePictrue">
        <view class="share_nav" @click.stop="showUrl">
          <image class="back_img" src="https://img.yiqitogether.com/static/local/index/back_02@2x.png" mode=""></image>
          <text>分享至</text>
          <view class="back_img"></view>
        </view>
        <view class="share_m">
          <view class="title">APP内扫一扫查看活动</view>
          <image v-if="!isLoading" :src="path" class="img_show" mode="widthFix"></image>

          <u-loading-icon style="margin-top: 416rpx" size="40" :show="isLoading" text="海报生成中..." mode="semicircle" textSize="26" vertical color="#fff" textColor="#fff"></u-loading-icon>
        </view>
        <view class="share">
          <view class="h-flex-center h-flex-sb" style="margin-bottom: 56rpx">
            <view
              class="share-list"
              @click.stop="
                $u.throttle(() => {
                  generatePicture(0)
                }, 500)
              "
            >
              <image src="../../static/images/hd_fx_hb_bc@2x.png" mode=""></image>
              保存相册
            </view>
            <view
              class="share-list"
              @click.stop="
                $u.throttle(() => {
                  generatePicture(1)
                }, 500)
              "
            >
              <image src="https://img.yiqitogether.com/static/local/myImagesV2/wx%402x.png" mode=""></image>
              微信好友
            </view>
            <view
              class="share-list"
              @click.stop="
                $u.throttle(() => {
                  generatePicture(2)
                }, 500)
              "
            >
              <image src="https://img.yiqitogether.com/static/local/myImagesV2/pyq%402x.png" mode=""></image>
              朋友圈
            </view>
          </view>
        </view>

        <view class="bgc" v-if="list.length != 0" :style="'backgroundImage:url(' + list[0] + ')'"></view>
        <view class="bgc" v-else style="background-image: url('http://img.yiqitogether.com/yqyq-app/images/default_img.png')"></view>
        <l-painter ref="painter" @success="successEvent" isCanvasToTempFilePath hidden>
          <l-painter-view css="width: 570rpx; height: 872rpx;background: #fff; padding-top: 30rpx;margin:auto;box-sizing: border-box;border-radius: 8rpx;">
            <l-painter-image :src="list[0] ? list[0] : 'http://img.yiqitogether.com/yqyq-app/images/default_img.png'" css="background: #d9d9d9; width: 510rpx; height: 510rpx; objectFit: cover;margin:auto;border-radius: 16rpx;"></l-painter-image>
            <l-painter-text
              :text="activityDetails.name"
              css="width: 98%;padding: 30rpx 0 0 30rpx;box-sizing: border-box;font-size: 40rpx; color: #333333;display: -webkit-box;overflow: hidden; text-overflow: ellipsis;-webkit-line-clamp: 2;line-clamp: 2;-webkit-box-orient: vertical;word-break: break-all;"
            />
            <l-painter-text :text="`${activityDetails.userName} ${appointDate} ${activityDetails.appointmentCount}人`" css="padding: 12rpx 0 0 30rpx; font-size: 28rpx; color: #ADB3BA;display: block;" />
            <l-painter-view css="display: flex;align-items: center;justify-content: space-between;padding:30rpx 30rpx 0 30rpx;">
              <l-painter-view>
                <l-painter-text text="一起一起" css="font-size: 28rpx; color: #333333;display: block;" />
                <l-painter-text text="长按识别活动详情" css="font-size: 22rpx; color: #ADB3BA;display: block;padding-top: 8rpx;" />
              </l-painter-view>
              <l-painter-qrcode :text="`${BASEURL}/pagesCommon/details/details?appointmentNo=${activityDetails.appointmentNo}&invitationCode=${activityDetails.invitationCode}`" css="width: 80rpx; height: 80rpx" />
            </l-painter-view>
          </l-painter-view>
        </l-painter>
      </view>
    </view>
  </u-overlay>
</template>

<script>
import { yiqiPordH5BaseUrl,LOGIN_NICKNAME } from '../../utils/cacheKey.js'
import { uploadFile } from '../../utils/tools.js'
import IndexModel from '@/model/index'
import { load } from '../../utils/store'
export default {
  name: 'poster-popup',
  props: ['source', 'show', 'list', 'activityDetails', 'appointDate', 'pageType', 'code', 'myname', 'faceVoteImg'],
  data() {
    return {
      path: '',
      BASEURL: '',
      isLoading: true,
      downloadUrl: '',
      sharePictrue: false,
      shareUrl: true,
			myName:load(LOGIN_NICKNAME) || ''
    }
  },
  created() {
    this.BASEURL = yiqiPordH5BaseUrl
  },
  methods: {
    copy() {
			let that = this
      let content = ''
			let pageType = this.$props.pageType
      if (pageType == 'topicsPage') {
        content = `${this.BASEURL}/pagesFind/find/topics?topicName=${this.activityDetails.name}&twitterType=${this.activityDetails.twitterType}`
      } else if (pageType == 'luckDraw') {
				content = `邀您加入实名认证新玩法,奖励升级,有机会中500元大奖${this.BASEURL}/pagesCommon/authentication/authentication`
			} else {
        content = `邀您加入颜值圈推广计划百元现金等你领，收益上不封顶!${this.BASEURL}/pagesMy/my/bonusActivity?invitationCode=${this.code}`
      }
      uni.setClipboardData({
        data: content,
        success: function () {
          uni.showToast({
            title: '已复制',
            icon: 'none'
          })
					if (pageType == 'luckDraw') {
						that.$emit('close')
					}
        }
      })
    },
    /**
     * 图文分享
     */
    shareImageText(type) {
      let self = this
      let hrefData
      let titleData
      let imageData
      let summaryData

      // 活动详情单独分享小程序
      if (this.source == 'activityDetailsPage' && type == 'WXSceneSession') {
        imageData = `https://img.yiqitogether.com/yyqc/20240205/upload_sv9tpz2hmi5mnjdzeu5rlnros7oars5g.png`
        titleData = this.activityDetails.name
        let path = `/packageCommon/details/details?appointmentNo=${this.activityDetails.appointmentNo}`
        uni.share({
          provider: 'weixin',
          scene: 'WXSceneSession',
          type: 5,
          imageUrl: imageData,
          title: titleData,
          miniProgram: {
            id: 'gh_7c94761fe0a4',
            path: path,
            type: 0,
            webUrl: `${this.BASEURL}/pagesCommon/details/details?appointmentNo=${this.activityDetails.appointmentNo}&invitationCode=${this.activityDetails.invitationCode}`
          },
          success: ret => {
            self.addIntegral()
          }
        })
        return
      } else if (this.$props.pageType == 'topicsPage' && type == 'WXSceneSession') {
        // 动态/话题分享小程序
        imageData = `https://img.yiqitogether.com/yyqc/20240205/upload_sv9tpz2hmi5mnjdzeu5rlnros7oars5g.png`
        titleData = this.activityDetails.name
        let path = ''
        if (this.activityDetails.twitterType == 'TWITTER') {
          path = `/packageFind/find/dynamicTag?topicName=${this.activityDetails.name}`
        } else {
          path = `/packageFind/find/topic?topicName=${this.activityDetails.name}`
        }

        uni.share({
          provider: 'weixin',
          scene: 'WXSceneSession',
          type: 5,
          imageUrl: imageData,
          title: titleData,
          miniProgram: {
            id: 'gh_7c94761fe0a4',
            path: path,
            type: 0,
            webUrl: `${this.BASEURL}${path}&invitationCode=${this.activityDetails.invitationCode}`
          },
          success: ret => {
            self.addIntegral()
          }
        })
        return
      }
      // 其他类型分享
      if (this.$props.pageType == 'face') {
        console.log('🚀 ~ shareUrlEvent ~ this.$props.pageType:', this.$props.pageType)
        titleData = '邀您加入颜值圈推广计划百元现金等你领，收益上不封顶!'
        hrefData = `${this.BASEURL}/pagesMy/my/bonusActivity?invitationCode=${this.code}`
        imageData = 'https://img.yiqitogether.com/yyqc/20240205/upload_mcczdjmw61q6tllr1h3gltot9zsckldg.png'
        summaryData = `来自 ${this.myname} 的一起一起`
        console.log(hrefData)
      } else if (this.$props.pageType == 'faceVote') {
        console.log('🚀 ~ shareUrlEvent ~ this.$props.pageType:', this.$props.pageType)
        titleData = '发现了一位颜值达人，快来看看吧~'
        hrefData = `${this.BASEURL}/pagesMy/my/facialSearch?targetId=${this.code}`
        imageData = this.faceVoteImg
        summaryData = '点击参与助力投票'
        console.log(hrefData, '1444')
      }else if (this.$props.pageType == 'luckDraw') {
        console.log('luckDraw', this.$props.pageType)
        titleData = '邀您加入实名认证新玩法,奖励升级,有机会中500元大奖'
        hrefData = `${this.BASEURL}/pagesCommon/authentication/authentication`
        imageData = 'https://img.yiqitogether.com/yqyq-app/images/luck-draw-weixin.png'
        summaryData = `来自 ${this.myName} 的一起一起`
      } else if (this.$props.pageType == 'topicsPage' && type == 'WXSceneTimeline') {
        titleData = this.activityDetails.name
        imageData = 'https://img.yiqitogether.com/yyqc/20240205/upload_sv9tpz2hmi5mnjdzeu5rlnros7oars5g.png'
        summaryData = `来自 ${this.activityDetails.userName} 的分享`
        hrefData = `${this.BASEURL}/pagesFind/find/topics?topicName=${this.activityDetails.name}&twitterType=${this.activityDetails.twitterType}`
      } else {
        titleData = this.activityDetails.name
        hrefData = `${this.BASEURL}/pagesCommon/details/details?appointmentNo=${this.activityDetails.appointmentNo}&invitationCode=${this.activityDetails.invitationCode}`
        imageData = 'https://img.yiqitogether.com/yyqc/20240205/upload_sv9tpz2hmi5mnjdzeu5rlnros7oars5g.png'
        summaryData = `来自 ${this.activityDetails.userName} 的活动`
      }
      uni.share({
        provider: 'weixin',
        scene: type,
        type: 0,
        href: hrefData,
        title: titleData,
        summary: summaryData,
        imageUrl: imageData,
        success: function (res) {
          console.log('success:' + JSON.stringify(res))
          // 活动分享成功加积分
          self.addIntegral()
					if (self.pageType == 'luckDraw') {
						self.$emit('close')
					}
        },
        fail: function (err) {
          console.log('fail:' + JSON.stringify(err))
        }
      })
    },
    /**
     * 分享后完成任务，增加积分
     */
    addIntegral() {
      if (this.$props.pageType != 'face') {
        let data = {
          taskConditionType: 'T6'
        }
        IndexModel.addIntegral({ ...data })
          .then(res => {})
          .catch(err => {})
      }
    },
    /**
     * 链接分享事件
     */
    shareUrlEvent(type) {
      let hrefData
      if (this.$props.pageType == 'face') {
        console.log('🚀 ~ shareUrlEvent ~ this.$props.pageType:', this.$props.pageType)
        hrefData = `一起加入校园颜值圈推广计划获百元现金红包，推广奖励上不封顶！${this.BASEURL}/pagesMy/my/bonusActivity?invitationCode=${this.code}`
        console.log(hrefData)
      } else {
        hrefData = `${this.activityDetails.name}，一起来吧：${this.BASEURL}/pagesCommon/details/details?appointmentNo=${this.activityDetails.appointmentNo}&invitationCode=${this.activityDetails.invitationCode}`
      }
      uni.share({
        provider: 'weixin',
        scene: type == 1 ? 'WXSceneSession' : 'WXSceneTimeline',
        type: 1,
        summary: hrefData,
        success: function (res) {
          console.log('success:' + JSON.stringify(res))
        },
        fail: function (err) {
          console.log('fail:' + JSON.stringify(err))
        }
      })
    },
    /**
     * 显示链接分享
     */
    showUrl() {
      this.sharePictrue = false
      this.shareUrl = true
      this.$emit('close')
    },
    /**
     * 显示海报
     */
    showPoster() {
      this.sharePictrue = true
      this.shareUrl = false
    },
    successEvent(e) {
      this.path = e
      this.isLoading = false
    },
    /**
     * 生成临时地址
     */
    generatePicture(type) {
      let that = this
      if (!that.downloadUrl) {
        this.$refs.painter.canvasToTempFilePathSync({
          fileType: 'jpg',
          // 如果返回的是base64是无法使用 saveImageToPhotosAlbum，需要设置 pathType为url
          pathType: 'url',
          quality: 1,
          success: async res => {
            that.downloadUrl = await uploadFile(res.tempFilePath)
            console.log(that.downloadUrl, 'that.downloadUrl')
            that.share(type)
            // 活动分享成功加积分
            if (that.$props.pageType != 'face') {
              let data = {
                taskConditionType: 'T6'
              }
              IndexModel.addIntegral({ ...data })
                .then(res => {
                  console.log('🚀 ~ shareImageText ~ res:', res)
                })
                .catch(err => {})
            }
          }
        })
      } else {
        that.share(type)
      }
    },
    /**
     * 分享活动
     */
    share(type) {
      console.log(`${this.BASEURL}/pagesCommon/details/details?appointmentNo=${this.activityDetails.appointmentNo}&invitationCode=${this.activityDetails.invitationCode}`)
      let that = this
      if (type == 0) {
        // 非H5 保存到相册
        // H5 提示用户长按图另存
        uni.saveImageToPhotosAlbum({
          filePath: that.downloadUrl,
          success: function () {
            that.myShowToast('保存成功!')
          }
        })
      } else {
        uni.share({
          provider: 'weixin',
          scene: type == 1 ? 'WXSceneSession' : 'WXSceneTimeline',
          type: 2,
          imageUrl: that.downloadUrl,
          success: function (res) {
            console.log('success:' + JSON.stringify(res))
          },
          fail: function (err) {
            console.log('fail:' + JSON.stringify(err))
          }
        })
      }
    },
    myShowToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    },
    closePopup() {
      this.sharePictrue = false
      this.shareUrl = true
      this.$emit('close')
      // this.show = false
    }
  }
}
</script>

<style lang="scss" scoped>
.share_box {
  position: relative;
  width: 100%;
  height: 100vh;
}

.bgc {
  position: absolute;
  width: 100%;
  height: 100vh;
  // background-image: url("https://img.yiqitogether.com/yyqc/20231121/upload_gt4rtvcpayphctxm3gkhtyia1ozu8aqv.jpg");
  background-size: contain;
  /* 设置背景图片 */
  filter: blur(8px);
  /* 添加模糊效果 */
  z-index: -1;
}

.share_nav {
  width: 100%;
  padding: 88rpx 24rpx 64rpx;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: absolute;
  top: 0;

  text {
    font-size: 36rpx;
    font-family: OPPOSans, OPPOSans-Medium;
    color: #ffffff;
  }
}

.back_img {
  width: 44rpx;
  height: 44rpx;
}

.share {
  width: 750rpx;
  height: 304rpx;
  box-sizing: border-box;
  background: #ffffff;
  border-radius: 16rpx 16rpx 0rpx 0rpx;
  position: absolute;
  left: 0;
  bottom: 0;
  padding: 40rpx 110rpx;
}

.share-list {
  text-align: center;
  font-size: 24rpx;
  // font-family: OPPOSans, OPPOSans-Medium;
  font-weight: 500;
  color: #333333;
}

.share-list-gray {
  color: #adb3ba;
}

.share-list image {
  width: 100rpx;
  height: 100rpx;
  display: block;
  margin: 0 auto 20rpx;
}

.cancle {
  width: 100%;
  font-size: 28rpx;
  // font-family: OPPOSans, OPPOSans-Medium;
  font-weight: 500;
  text-align: center;
  color: #adb3ba;
  line-height: 80rpx;
}

.share_m {
  width: 100%;
  position: absolute;
  left: 50%;
  top: 15%;
  transform: translateX(-50%);
}

.title {
  width: 100%;
  font-size: 28rpx;
  text-align: center;
  color: #ffffff;
  margin-bottom: 46rpx;
}

.share_img {
  width: 570rpx;
  height: 832rpx;
  border-radius: 10rpx;
}

.img_show {
  width: 100%;
}
</style>
