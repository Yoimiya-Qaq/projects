<template>
  <view class="join-group-container">
    <u-popup :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onClose">
      <view class="modal-wrap">
        <view class="modal-wrap-title">加入群组</view>
        <view class="modal-wrap-content">请输入群号</view>
        <view class="modal-wrap-input" @click="setInputFocus">
          <input class="code-input" :focus="inputFocus" :selection-start="6" :selection-end="6" v-model="codeNumber" type="tel" adjust-position="false" auto-blur="true" maxlength="6" @input="handleInputClick" />
          <view class="code-list">
            <block v-for="(item, index) in 6" :key="index">
              <view :class="['code-list-item', codeNumber.length == index ? 'active-item' : '', codeNumber.length == 6 && index == 5 && inputFocus ? 'active-item' : '']">{{ codeNumber[index] }}</view>
            </block>
          </view>
        </view>
        <view class="modal-wrap-group" v-show="!disabled">
          <image class="group-img" src="https://img.yiqitogether.com/yyqc/20231108/upload_5cylf2qo97egms2o6vuazgwxell0hugo.png" mode="aspectFill" />
          <view class="group-info">
            <view class="flex-box">
              <view class="eclipse">{{ groupInfo.groupName || '' }}</view>
              <view class="name">({{ groupInfo.userCount || 0 }}人)</view>
            </view>
            <view class="group-number">群号 {{ groupInfo.groupCode || '' }}</view>
          </view>
        </view>
        <view :class="['modal-wrap-btn', disabled ? 'disabled' : '']" @click="onConfirm">加入</view>
      </view>
    </u-popup>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import rongYun from '@/model/rongyun.js'
export default {
  name: 'JoinGroupModal',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 32
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      codeNumber: '',
      disabled: true,
      groupNo: '',
      groupInfo: {},
      inputFocus: false,
      // 加入的时候防抖
      joinDebounce: false
    }
  },
  watch: {
    show: {
      handler(val) {
        if (!val) {
          this.codeNumber = ''
          this.groupInfo = {}
          this.disabled = true
        }
      }
    }
  },
  mounted() {
    uni.onKeyboardHeightChange(res => {
      if (res.height == 0) {
        this.inputFocus = false
      }
    })
  },
  methods: {
    setInputFocus() {
      console.log(this.inputFocus)
      this.inputFocus = true
    },
    // 输入群号
    handleInputClick(e) {
      let val = e.detail.value
      this.codeNumber = val
      if (val && val.length == 6) {
        this.getInfo()
        uni.hideKeyboard()
        this.inputFocus = false
      } else {
        this.disabled = true
      }
    },
    // 获取群组信息
    getInfo() {
      rongYun
        .getGroup({
          groupCode: this.codeNumber
        })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.groupInfo = res.data.group || {}
            this.groupNo = res.data.group.groupNo || ''
            this.disabled = false
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
            // this.$refs.uToast.show({
            //     ...res
            // })
          }
        })
    },
    // 加入
    onConfirm() {
      let that = this
      if (this.joinDebounce) {
        return
      }
      this.joinDebounce = true
      if (!this.disabled) {
        this.$emit('confirm', this.groupNo)
      }
      setTimeout(() => {
        that.joinDebounce = false
      }, 1000)
    },
    // 关闭弹窗
    onClose() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
.join-group-container {
  .modal-wrap {
    width: 560rpx;
    padding: 40rpx 24rpx;
    text-align: center;

    // 标题
    &-title {
      font-size: 32rpx;
      font-family: OPPOSans, OPPOSans-Regular;
      color: #000000;
      line-height: 34rpx;
      margin-bottom: 24rpx;
    }
    // 提示
    &-content {
      font-size: 24rpx;
      font-family: OPPOSans, OPPOSans-Regular;
      color: #97999f;
      line-height: 24rpx;
      margin-bottom: 48rpx;
    }
    &-input {
      position: relative;
      height: 72rpx;

      .code-input {
        position: absolute;
        left: -750rpx;
        top: 0;
        height: 72rpx;
        width: 100%;
        opacity: 0;
        z-index: 99;
        outline: none;
        color: transparent;
        caret-color: transparent;
      }
      .code-list {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 72rpx;
        display: flex;
        justify-content: space-between;
        .code-list-item {
          width: 72rpx;
          height: 72rpx;
          background: #f0f0f0;
          border-radius: 16rpx;
          font-size: 32rpx;
          font-family: OPPOSans, OPPOSans-Regular;
          color: #000000;
          line-height: 72rpx;
          margin-right: 16rpx;
          z-index: 5;
          box-sizing: border-box;
        }
        .code-list-item:last-child {
          margin-right: 0;
        }
        .active-item {
          border: 2rpx solid #fe5e10;
        }
      }
    }
    &-group {
      display: flex;
      align-items: center;
      padding: 16rpx;
      background: #f0f0f0;
      border-radius: 16rpx;
      margin-top: 32rpx;

      .group-img {
        width: 92rpx;
        height: 92rpx;
        margin-right: 24rpx;
        flex-shrink: 0;
      }
      .group-info {
        flex: 1;
        text-align: left;
        min-width: 0;

        .flex-box {
          display: flex;
          margin-bottom: 8rpx;

          .eclipse {
            // flex: 1;
            font-size: 28rpx;
            font-family: OPPOSans, OPPOSans-Medium;
            font-weight: 500;
            color: #333333;
            line-height: 36rpx;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            word-break: break-all;
          }
          .name {
            flex-shrink: 0;
            font-size: 28rpx;
            font-family: OPPOSans, OPPOSans-Medium;
            font-weight: 500;
            color: #333333;
            line-height: 36rpx;
          }
        }

        .group-number {
          font-size: 24rpx;
          font-family: OPPOSans, OPPOSans-Regular;
          color: #999999;
          line-height: 32rpx;
        }
      }
    }
    // 底部按钮
    &-btn {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 80rpx;
      box-sizing: border-box;
      color: #fff;
      background: #fe5e10;
      border-radius: 40rpx;
      margin-top: 48rpx;
      box-shadow: 0rpx 8rpx 0rpx 0rpx rgba(255, 138, 163, 0.34);
    }
    .disabled {
      opacity: 0.5;
    }
  }
}
</style>
