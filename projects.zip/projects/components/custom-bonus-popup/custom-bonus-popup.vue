<template>
  <view class="custom-bonus-popup">
    <u-popup :show="show" mode="bottom" :closeOnClickOverlay="true" @close="onClose" :overlay="false" customStyle="background-color: transparent;" @touchmove.native.stop.prevent>
      <view class="tip-wrap">
        <view class="tip-box" @click="goMyIntegral">
          <image class="tip-icon" src="@/static/images/jifen.png" mode="aspectFill" />
          <text class="tip-desc">积分+{{ score }} ></text>
        </view>
      </view>
    </u-popup>
  </view>
</template>

<script>
export default {
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 分值
    score: {
      type: [Number, String],
      default: 1
    },
    // 自定义样式
    customStyle: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {}
  },
  methods: {
    // 我的积分
    goMyIntegral() {
      uni.$u.throttle(() => {
        uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
      }, 500)
    },
    // 关闭弹窗
    onClose() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-bonus-popup {
  .tip-wrap {
    display: flex;
    flex-direction: row;
    justify-content: center;
  }
  .tip-box {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    width: 198rpx;
    height: 68rpx;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 34rpx;
    margin-bottom: 220rpx;
    .tip-icon {
      width: 28rpx;
      height: 28rpx;
      margin-right: 8rpx;
    }
    .tip-desc {
      font-size: 24rpx;
      color: #ffffff;
      margin-bottom: 4rpx;
    }
  }
}
</style>
