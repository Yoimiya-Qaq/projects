<template>
  <view class="evaluate-box">
    <view class="top-bg">
      <!-- 未评价 -->
      <view class="no-evaluate" v-if="isSend == false && userId !== targetNumberId && isMember == true">
        <view class="left">
          <image class="text-img" src="https://img.yiqitogether.com/static/images/wenzi.png" mode="aspectFill"></image>
          <text class="text">你觉得本次同行体验如何?</text>
        </view>
        <u-button class="go-evaluate-btn" @click="openEvaluatePopup()" :hairline="false">去评价</u-button>
      </view>
      <!-- 已评价展示标签内容 -->
      <view class="label-box" v-else>
        <view class="label-list flex-1">
          <view class="label-item flex-0" v-for="(firstitem, firstindex) in firstFive" :key="firstindex">
            <image class="item-img" :src="firstitem.url" mode="scaleToFill" />
            <view class="item-text">
              {{ firstitem.text }}
              <text v-if="firstitem.count > 0">{{ '+' + firstitem.count }}</text>
            </view>
          </view>
        </view>
        <view class="label-list flex-1 label-list-pad">
          <view class="label-item flex-0" v-for="(lastitem, lastindex) in lastFive" :key="lastindex">
            <image class="item-img" :src="lastitem.url" mode="scaleToFill" />
            <view class="item-text">
              {{ lastitem.text }}
              <text v-if="lastitem.count > 0">{{ '+' + lastitem.count }}</text>
            </view>
          </view>
        </view>
      </view>
      <view class="evaluate-all">
        全部评价
        <text v-if="activityScoreDTOList.length > 0">({{ total }}条)</text>
      </view>
    </view>
    <view class="evaluate-list">
      <view class="evaluate-list-item" v-for="(item, index) in activityScoreDTOList" :key="index">
        <view class="userinfo">
          <view
            class="userinfo-left"
            @click="
              $u.throttle(() => {
                goMyPage(item.numberId)
              })
            "
          >
            <image :src="item.headUrl" class="head-img" mode="aspectFill"></image>
            <view class="userinfo-detail">
              <text class="username">{{ item.nikeName }}</text>
              <text class="createtime">{{ item.createTime }}</text>
            </view>
          </view>
          <image src="https://img.yiqitogether.com/static/images/more.png" mode="" class="more-img" @click="openMorePopup(item.activityScoreId, index)" v-if="userId == item.numberId"></image>
        </view>
        <view class="rate-box">
          <u-rate readonly active-color="#F5D865" :value="item.score" inactive-color="#b2b2b2" gutter="5" size="45" :allowHalf="true" inactiveIcon="star-fill" inactiveColor="#f4f5f6"></u-rate>
          {{ item.score ? item.score : '' }}
        </view>
        <!-- <u-rate readonly active-color="#F5D865" :value="item.score" inactive-color="#b2b2b2" gutter="5" size="45" :allowHalf="true" inactiveIcon="star-fill" inactiveColor="#f4f5f6"></u-rate> -->
        <!-- 评价内容 -->
        <view class="evaluate-con">{{ item.content ? item.content : '' }}</view>
        <view class="impressionList" v-if="item.label.length > 1">
          <text class="impression-item" v-for="(labelItem, labelIndex) in item.label" :key="labelIndex">{{ labelItem }}</text>
        </view>
      </view>
    </view>
    <!-- 暂无数据 -->
    <view class="evaluate-empty-box" v-if="activityScoreDTOList.length == 0">
      <image class="evaluate-empty-img" src="https://img.yiqitogether.com/static/images/zanwupingjia@2x.png" mode=" "></image>
      <text class="evaluate-empty-text">暂无评价</text>
    </view>
  </view>
</template>

<script>
import { save, load } from '@/utils/store.js'
import { LOGIN_USERID } from '@/utils/cacheKey.js'

export default {
  props: {
    // 回显选中的标签 如果返回false则这个用户没有评价过
    isSend: {
      type: Boolean,
      default: false
    },
    // 评价列表
    activityScoreDTOList: {
      type: Array,
      default: []
    },
    // 头部标签列表
    labelDTOS: {
      type: Array,
      default: []
    },
    // 发布人id
    targetNumberId: {
      type: Number,
      default: ''
    },
    // 评价总数
    total: {
      type: Number,
      default: ''
    },
    //是否是活动成员
    isMember: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      evaluateList: [],
      // 评价弹窗
      evaluatePopupShow: false,
      tagList: [],
      score: '',
      selectedLabel: [],
      userId: load(LOGIN_USERID)
    }
  },
  computed: {
    // 使用计算属性来截取数组
    firstFive() {
      return this.labelDTOS.slice(0, 5)
    },
    lastFive() {
      return this.labelDTOS.slice(6, 11)
    }
  },
  methods: {
    // 打开评分弹窗
    openEvaluatePopup() {
      this.$emit('openEvaluatePopup')
    },
    // 打开删除弹窗
    openMorePopup(activityScoreId, delIndex) {
      this.$emit('openMorePopup', activityScoreId, delIndex)
    },
    // 去个人主页
    goMyPage(numberId) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + numberId })
    }
  }
}
</script>

<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.evaluate-box {
  // width: 100vw;
  // height: 100%;
  position: relative;
  .top-bg {
    width: 100%;
    height: 458rpx;
    background-image: url('https://img.yiqitogether.com/static/images/pingjiabijing@2x.png');
    background-size: 100% 100%;
    padding: 36rpx;
    box-sizing: border-box;
    .no-evaluate {
      width: 100%;
      background-image: url('https://img.yiqitogether.com/static/images/qupingjia_bj@2x.png');
      background-size: 100% 100%;
      box-sizing: border-box;
      display: flex;
      padding: 44rpx 42rpx;

      justify-content: space-between;
      align-items: center;
      .left {
        display: flex;
        flex-direction: column;
        .text-img {
          width: 374rpx;
          height: 44rpx;
        }
        .text {
          font-size: 24rpx;
          color: #4e4e4e;
        }
      }
      .go-evaluate-btn {
        width: 144rpx;
        height: 54rpx;
        background: #fe5e10;
        border-radius: 28rpx;
        font-size: 28rpx;
        color: #ffffff;
        margin: 0;
        line-height: 54rpx;
        text-align: center;
      }
    }
    .evaluate-all {
      font-size: 28rpx;
      color: #4e4e4e;
      position: absolute;
      top: 240rpx;
    }
    .label-box {
      overflow: hidden;
      .label-list {
        margin-bottom: 22rpx;
      }
      .label-list-pad {
        margin-left: 80rpx;
      }
      .label-item {
        display: flex;
        margin-right: 65rpx;
        flex-shrink: 0;
        animation: label 10s linear infinite;
        animation-fill-mode: forwards;
        opacity: 0.7;
        background: #ffffff;
        border-radius: 34rpx;
        padding: 12rpx 32rpx;
        box-sizing: border-box;
        .item-img {
          width: 54rpx;
          height: 54rpx;
          margin-right: 9rpx;
        }
        .item-text {
          font-size: 26rpx;
          color: #2a343e;
        }
      }
      /* 文字滚动 */
      @keyframes label {
        0% {
          transform: translate3d(50px, 0, 0);
        }

        100% {
          transform: translate3d(-500px, 0, 0);
        }
      }
    }
  }
  .evaluate-list {
    padding: 0 36rpx;
    box-sizing: border-box;
    margin-top: -180rpx;
    // margin-bottom: 180rpx;
    .evaluate-list-item {
      padding: 30rpx 0;
      border-bottom: 2rpx solid #f0f1f3;
      .userinfo {
        display: flex;
        justify-content: space-between;
        align-items: center;
        .userinfo-left {
          height: 98rpx;
          display: flex;
          align-items: center;
          margin-bottom: 13rpx;
          .head-img {
            width: 72rpx;
            height: 72rpx;
            margin-right: 11rpx;
            border-radius: 50%;
          }
          .userinfo-detail {
            display: flex;
            flex-direction: column;
            justify-content: center;
            .username {
              font-size: 28rpx;
            }
            .createtime {
              font-size: 20rpx;
            }
          }
        }
        .more-img {
          width: 36rpx;
          height: 36rpx;
        }
      }
      .rate-box {
        display: flex;
        align-items: center;
        font-size: 28rpx;
        color: #9fa7b4;
      }
      /deep/.u-rate__content {
        margin-right: 16rpx;
      }
      /deep/.u-rate__content__item__icon-wrap--half {
        width: 24rpx !important;
      }
      .evaluate-con {
        margin: 12rpx 0 20rpx 0;
        font-size: 28rpx;
        color: #2a343e;
        line-height: 40rpx;
        white-space: pre-wrap;
      }
      .impressionList {
        width: 100%;
        display: flex;
        align-items: center;
        overflow-x: scroll;
        .impression-item {
          min-width: 144rpx;
          padding: 8rpx;
          text-align: center;
          box-sizing: border-box;
          background: #f4f5f6;
          border-radius: 26rpx;
          font-size: 24rpx;
          color: #64696f;
          line-height: 34rpx;
          margin-right: 12rpx;
        }
      }
    }
  }
  .evaluate-empty-box {
    margin-top: 20%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .evaluate-empty-img {
      width: 212rpx;
      height: 212rpx;
    }
    .evaluate-empty-text {
      font-size: 24rpx;
      color: #9fa7b4;
    }
  }
}
</style>
