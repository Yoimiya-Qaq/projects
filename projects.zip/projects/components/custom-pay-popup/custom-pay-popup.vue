<template>
  <view class="custom-pay-popup">
    <!-- 立即付款弹出层 -->
    <u-popup :show="showPayPopup" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="showPayPopup = false" @open="onOpen">
      <view class="popup-header">
        <view class="header-title">付款方式</view>
        <image class="close-icon" src="@/static/images/myImgs/bjzl_zybj_delete@2x.png" mode="aspectFill" @click="showPayPopup = false" />
      </view>
      <!-- vip年卡特有 -->
      <view class="vip-box flex1" v-if="sourcePage == 'enterpriseVip'">
        <view class="vip-price">
          <text>￥</text>
          {{ Number(payMoney).toFixed(2) }}
        </view>
        <view class="vip-introduce">
          {{ activityInfo.description }}
        </view>
      </view>
      <!-- 勾选项 -->
      <view class="popup-content" v-for="(item, index) in payTypeList" :key="index" @click="selectPayType(item.type)">
        <view class="list-item">
          <image class="list-item-icon" :src="item.icon" mode=""></image>
          <view class="list-item-name">
            {{ item.name }}
            <text v-if="item.name == '余额'">（{{ Number(balance).toFixed(2) }}）</text>
          </view>
          <radio v-show="item.type == payType" :value="item.type" :checked="true" :color="themeColor" />
        </view>
      </view>
      <!-- 按钮 -->
      <view class="popup-btn">
        <u-button shape="circle" :color="themeColor" type="primary" @click="onConfirm">
          立即支付
          <text style="margin-left: 8rpx" v-show="payMoney">￥{{ payMoney }}</text>
        </u-button>
      </view>
    </u-popup>

    <!-- 余额支付密码弹窗 -->
    <u-popup :show="showPwdPopup" :round="40" @close="showPwdPopup = false" :closeOnClickOverlay="false">
      <cc-defineKeyboard ref="CodeKeyboard" passwrdType="pay" :price="payMoney + ''" @back="showPwdPopup = false" @close="showPwdPopup = false" @passWord="getPassword" @forget="$u.throttle(forgetBtn, 500)"></cc-defineKeyboard>
    </u-popup>

    <!-- 继续支付提示弹窗 -->
    <custom-modal type="tipsConfirm" :show="showContinue" :round="24" themeColor="#FE5E10" title="支付提示" content="已经存在一笔待支付的订单，是否继续支付" cancelText="取消" confirmText="继续支付" @cancel="showContinue = false" @confirm="handlePrePay" />

    <!-- 支付提示弹窗 -->
    <custom-modal type="tipsConfirm" :show="showTips" :round="24" themeColor="#FE5E10" title="支付提示" content="是否支付成功？" cancelText="未完成支付" confirmText="我已完成支付" @cancel="goOrderPage('F1')" @confirm="goOrderPage('F2')" />

    <!-- loading弹窗 -->
    <yue-loading :loadTxet="loadTxet" v-if="payLoading"></yue-loading>
  </view>
</template>

<script>
import Base64 from '@/utils/base64.js'
import shopModel from '@/model/shop.js'
import IndexModel from '@/model/index'
import RecruitModal from '@/model/recruit.js'
import AnswerModel from '@/model/answer.js'

// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { LOGIN_USERID, RECRUIT_INFO } from '@/utils/cacheKey.js'

export default {
  name: 'CustomPayPopup',
  props: {
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 24
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    /**
     * 页面来源:
     * · activityDetailPay-活动详情-加入活动支付定金
     * · activityOrderPay-待付订单支付
     * · activitySignInPay-活动签到支付
     * · signInToDetailPay-活动签到支付进活动详情-加入活动支付定金
     * · enterpriseVip 购买企业会员年卡支付
     * · unlockReportPay 查看答题报告支付
     * · redPacketPay 聊天红包
     */
    sourcePage: {
      type: String,
      default: ''
    },
    // 主题色
    themeColor: {
      type: String,
      default: '#FE5E10'
    },
    // 商品详情
    activityInfo: {
      type: Object,
      default: () => {}
    },
    // 需要支付的金额
    payMoney: {
      type: [String, Number],
      default: 0
    },
    // 是否已有订单号
    hasSystemNo: {
      type: Boolean,
      default: false
    },
    // 答题标题及答案id
    answerInfo: {
      type: Object,
      default: () => {}
    },
    // 公司详细信息 （年卡支付）
    companyInfoDTO: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      // 支付Loading
      payLoading: false,
      // 立即支付弹窗
      showPayPopup: false,
      // 余额支付密码弹窗
      showPwdPopup: false,
      // 继续支付提示弹窗
      showContinue: false,
      // 支付提示弹窗
      showTips: false,
      // 默认余额
      payType: 'balance',
      balance: 0,
      systemNo: '', // 订单号
      // 密码
      password: '',
      // 支付方式
      payTypeList: [
        {
          icon: 'https://img.yiqitogether.com/static/local/myImagesV2/lq@2x.png',
          name: '余额',
          type: 'balance'
        },
        {
          icon: 'https://img.yiqitogether.com/static/local/myImagesV2/wx@2x.png',
          name: '微信',
          type: 'wxpay'
        },
        {
          icon: '../../static/images/pay_zfb@2x.png',
          name: '支付宝',
          type: 'alipay'
        }
      ], // 业务类型(通用支付需传参 COMPANY_VIP：企业年卡 ANSWER_BOOK： 答题卡)
      businessType: '',
      numberId: load(LOGIN_USERID) || '',
      loadTxet: '支付中...'
    }
  },
  mounted() {
    this.getUserBalance()
  },
  methods: {
    // 打开立即支付弹窗
    onOpen() {
      if (this.sourcePage == 'enterpriseVip') {
        this.$emit('openPay')
      }
      this.showPayPopup = true
    },
    // 获取用户余额
    getUserBalance() {
      shopModel
        .userBalance()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.balance = res.data.amount
            let payChannel = res.data.payChannel
            this.payTypeList = this.payTypeList.filter(item => payChannel.includes(item.type))
            this.payType = this.payTypeList[0].type
          }
        })
        .catch(err => {})
    },
    // 选择支付方式
    selectPayType(e) {
      this.payType = e
    },
    // 立即支付
    onConfirm() {
      if (this.payType == 'balance') {
        if (Number(this.balance) < 0 || Number(this.balance) < Number(this.payMoney)) {
          uni.showToast({
            title: '您的余额不足,请更换支付方式',
            icon: 'none'
          })
          return
        }
        this.showPwdPopup = true
      } else if (this.payType == 'wxpay') {
        let obj
        if (this.sourcePage == 'enterpriseVip') {
          // 购买企业年卡所需参数
          obj = {
            name: '上海尚潮电子商务有限公司',
            title: this.activityInfo.description,
            price: this.payMoney,
            userId: load(LOGIN_USERID),
            orderType: 'recruitPay',
            productId: this.activityInfo.id,
            companyId: load(RECRUIT_INFO).companyId,
            detailTitle: this.companyInfoDTO.companyName,
            detailImg: this.companyInfoDTO.companyLogo
          }
        } else if (this.sourcePage == 'unlockReportPay') {
          let businessParams = null
          if (this.companyInfoDTO) {
            let businessObj = {
              detailTitle: this.companyInfoDTO.companyName,
              detailImg: this.companyInfoDTO.companyLogo
            }
            businessParams = JSON.stringify(businessObj)
          }
          this.businessType = 'ANSWER_BOOK'
          // 查看报告所需参数
          obj = {
            businessId: this.answerInfo.answerNo,
            price: this.payMoney,
            userId: load(LOGIN_USERID),
            name: '上海尚潮电子商务有限公司',
            title: this.answerInfo.title,
            orderType: 'unlockReportPay',
            businessType: this.businessType,
            businessParams
          }
        } else if (this.sourcePage == 'redPacketPay') {
          // 聊天发红包所需参数
          let redPacketObj = {
            groupNo: this.activityInfo.groupNo || null, // 群号，群红包必传
            targetUserId: this.activityInfo.targetId || null, // 目标用户Id，私聊红包必传
            title: this.activityInfo.title, // 红包标题
            amount: this.activityInfo.amount, // 金额，单位：分；普通红包传单个红包金额
            count: this.activityInfo.count, // 红包数量，群红包必传
            sendName: this.activityInfo.sendName // 发送者昵称
          }
          obj = {
            businessId: this.activityInfo.businessId, // 红包预定义产品
            businessType: 'RED_PACKET',
            businessParams: JSON.stringify(redPacketObj),
            name: '一起一起',
            title: '一起红包',
            price: this.activityInfo.calculatedAmount,
            userId: load(LOGIN_USERID)
          }
        } else {
          // app携带参数： 用户id  产品名称，价格，活动信息
          obj = {
            appointmentNo: this.activityInfo.appointmentNo,
            type: 'wechat',
            userId: load(LOGIN_USERID),
            name: this.activityInfo.userName,
            orderType: 'deposit',
            price: this.payMoney,
            title: this.activityInfo.name
          }
        }
        this.showPayPopup = false
				// console.log('0011',JSON.stringify(obj));
        this.goWxPay(JSON.stringify(obj))
        this.$emit('loading', true)
      } else if (this.payType == 'alipay') {
        if (this.sourcePage == 'unlockReportPay') {
          // 答题支付
          this.businessType = 'ANSWER_BOOK'
          this.payOrder()
        } else {
          this.payBill()
        }
      }
    },
    // 用余额支付获取密码
    getPassword(e) {
      this.password = e
      if (this.sourcePage == 'enterpriseVip') {
        this.balancePayVip()
      } else if (this.sourcePage == 'unlockReportPay') {
        // 答题支付
        this.businessType = 'ANSWER_BOOK'
        this.payOrder()
      } else if (this.sourcePage == 'redPacketPay') {
        // 发红包
        this.businessType = 'RED_PACKET'
        this.handleSendRedPacket()
      } else {
        this.payBill()
      }
    },
    // 忘记密码
    forgetBtn() {
      shopModel
        .forgetPassword()
        .then(res => {
          if (res.code == 'SUCCESS') {
            let urlStr = res.data.url || ''
            let index = res.data.url.indexOf('.com')
            let obj = {
              type: '2',
              openUrl: urlStr.slice(index + 4),
              token: res.data.toke
            }
            getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
            this.$nextTick(() => {
              uni.navigateTo({
                url: '/pages/my/webView'
              })
            })
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    // 买单请求
    payBill() {
      if (this.hasSystemNo) {
        // 已生成了待支付订单，直接付款
        this.systemNo = this.activityInfo.systemNo
        this.handlePrePay()
      } else {
        // 订单还未生成
        let params = {
          appointmentNo: this.activityInfo.appointmentNo,
          payType: this.payType,
          payPassWord: this.password
        }
        this.payLoading = true
        shopModel
          .payment(params)
          .then(res => {
            if (res.code == 'SUCCESS') {
              if (res.data.payData.success) {
                // 支付成功
                this.showPayPopup = false
                this.showPwdPopup = false
                if (this.payType == 'balance') {
                  // 余额
                  if (this.sourcePage == 'activityOrderPay') {
                    uni.navigateTo({ url: '/pagesCommon/details/paymentSuccess?appointmentNo=' + this.activityInfo.appointmentNo + '&sourcePage=' + this.sourcePage })
                  } else {
                    uni.redirectTo({ url: '/pagesCommon/details/paymentSuccess?appointmentNo=' + this.activityInfo.appointmentNo + '&sourcePage=' + this.sourcePage })
                  }
                } else if (this.payType == 'alipay') {
                  // 支付宝
                  this.goAlipay(res.data.payData.data)
                }
                this.payLoading = false
              } else {
                // 支付失败
                this.payLoading = false
                uni.showToast({
                  title: res.data.payData.message,
                  icon: 'none',
                  duration: 2000
                })
              }
            } else if (res.code == 'AP001') {
              // 已存在相同活动的待支付订单，弹窗提示是否继续支付原待支付订单，而不是生成新订单
              this.showPayPopup = false
              this.showPwdPopup = false
              this.systemNo = res.data
              this.payLoading = false
              this.$nextTick(() => {
                this.showContinue = true
              })
            } else {
              this.payLoading = false
              uni.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
          .catch(err => {
            this.payLoading = false
          })
      }
    },
    // 发红包 余额支付
    handleSendRedPacket() {
      let businessParams = {
        targetUserId: this.activityInfo.targetId || null,
        groupNo: this.activityInfo.groupNo || null,
        title: this.activityInfo.title,
        amount: this.activityInfo.amount,
        count: this.activityInfo.count || null,
        sendName: this.activityInfo.sendName
      }
      let params = {
        businessId: this.activityInfo.businessId,
        businessType: 'RED_PACKET',
        payType: 'balance',
        payParams: JSON.stringify({ payPassWord: this.password }),
        businessParams: JSON.stringify(businessParams)
      }
      console.log('🚀 ~ handleSendRedPacket ~ params:', params)
      AnswerModel.createOrder(params).then(res => {
        console.log(res, 'res')
        if (res.code == 'SUCCESS') {
          if (res.data.payData.success) {
            // 支付成功
            this.showPayPopup = false
            this.showPwdPopup = false
            if (this.payType == 'balance') {
              uni.navigateBack()
            }
            this.payLoading = false
          }
        } else {
          // 支付失败
          this.payLoading = false
          uni.showToast({
            title: res.message,
            icon: 'none',
            duration: 2000
          })
        }
      })
    },
    // 通用支付
    payOrder() {
      let businessParams = null
      if (this.companyInfoDTO) {
        let businessObj = {
          detailTitle: this.companyInfoDTO.companyName,
          detailImg: this.companyInfoDTO.companyLogo
        }
        businessParams = JSON.stringify(businessObj)
      }
      let params = {
        businessType: this.businessType,
        payType: this.payType,
        payParams: { payPassWord: this.password },
        businessId: this.answerInfo.answerNo,
        businessParams
      }
      console.log(params, 'params')
      AnswerModel.createOrder(params)
        .then(res => {
          console.log(res, 'res')
          if (res.code == 'SUCCESS') {
            this.showPwdPopup = false
            if (this.payType == 'balance') {
              // 余额
              if (res.data.payData.success) {
                setTimeout(() => {
                  this.loadTxet = '正在解锁'
                  this.payLoading = true
                }, 500)
                let pages = getCurrentPages()
                let prevPage = pages[pages.length - 2]
                console.log(prevPage.route, 'pre')
                if (prevPage.route == 'pagesCommon/answers/answerRecord') {
                  setTimeout(() => {
                    prevPage.$vm.pageNumber = 0
                    prevPage.$vm.recordList = []
                    prevPage.$vm.getAnswerList()
                    uni.navigateBack({ delta: 1 })
                  }, 3000)
                } else {
                  setTimeout(() => {
                    uni.redirectTo({
                      url: `/pagesCommon/answers/answerRecord`
                    })
                    this.payLoading = false
                  }, 3000)
                }
              } else {
                uni.showToast({
                  title: res.data.payData.message,
                  icon: 'none'
                })
              }
            } else if (this.payType == 'alipay') {
              // 支付宝
              this.goAlipay(res.data.payData.data)
            }
            this.payLoading = false
          } else {
            this.payLoading = false
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.payLoading = false
        })
      this.payLoading = true
    },

    /**
     * 余额购买企业年卡
     */
    balancePayVip() {
      let params = {
        productId: this.activityInfo.id,
        companyId: load(RECRUIT_INFO).companyId,
        payPassWord: this.password,
        detailTitle: this.companyInfoDTO.companyName,
        detailImg: this.companyInfoDTO.companyLogo
      }
      this.payLoading = true
      RecruitModal.createOrderBalance(params)
        .then(res => {
          this.payLoading = false
          if (res.data.payData.success) {
            uni.showToast({
              title: '开通成功！',
              icon: 'none'
            })
            this.showPwdPopup = false
            this.showPayPopup = false
            this.$emit('balancePayVipSuccess')
          } else {
            uni.showToast({
              title: res.data.payData.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.payLoading = false
        })
    },
    // 微信支付
    goWxPay(payDataWx) {
      setTimeout(() => {
        this.showTips = true
      }, 1500)
      // #ifdef APP-PLUS
      plus.share.getServices(
        s => {
          let shares = {}
          for (let i = 0; i < s.length; i++) {
            let t = s[i]
            shares[t.id] = t
          }
          let sweixin = shares['weixin']
          sweixin
            ? sweixin.launchMiniProgram({
                path: 'pagesPay/pay/pay?payDataWx=' + payDataWx,
                type: 0, // 可取值： 0-正式版； 1-测试版； 2-体验版。 默认值为0。
                id: 'gh_1396a27d3f75'
              })
            : plus.nativeUI.alert('当前环境不支持微信操作')
        },
        function (e) {
          console.log('获取分享服务列表失败:' + e.message)
        }
      )
      // #endif
    },
    // 支付宝支付
    goAlipay(data) {
      let base64 = new Base64()
      let orderInfo = base64.decode(data).toString('utf8')
      uni.requestPayment({
        provider: 'alipay',
        orderInfo, // 微信、支付宝订单数据 【注意微信的订单信息，键值应该全部是小写，不能采用驼峰命名】
        success: function (res) {
          console.log('success:' + JSON.stringify(res))
        },
        fail: function (err) {
          console.log('fail:' + JSON.stringify(err))
        }
      })
    },
    // 继续支付
    handlePrePay() {
      let params = {
        systemNo: this.systemNo,
        payType: this.payType,
        payPassWord: this.password,
        openId: ''
      }
      this.payLoading = true
      IndexModel.continuePay(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.showContinue = false
            if (res.data.payData.success) {
              if (this.sourcePage == 'activityOrderPay') {
                uni.navigateTo({ url: '/pagesCommon/details/paymentSuccess?appointmentNo=' + this.activityInfo.appointmentNo + '&sourcePage=' + this.sourcePage })
              } else {
                uni.redirectTo({ url: '/pagesCommon/details/paymentSuccess?appointmentNo=' + this.activityInfo.appointmentNo + '&sourcePage=' + this.sourcePage })
              }
              this.payLoading = false
            } else {
              // 支付失败
              this.payLoading = false
              uni.showToast({
                title: res.data.payData.message,
                icon: 'none',
                duration: 2000
              })
            }
          } else {
            this.payLoading = false
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.payLoading = false
        })
    },
    // 未完成支付/我已完成支付
    goOrderPage(type) {
      this.showTips = false
      this.$emit('wechatPayTips', type)
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-pay-popup {
  padding-bottom: 72rpx;
  .popup-header {
    position: relative;
    .header-title {
      font-size: 32rpx;
      text-align: center;
      padding: 44rpx 0;
      color: #2a343e;
      line-height: 42rpx;
    }
    .close-icon {
      width: 24rpx;
      height: 24rpx;
      position: absolute;
      top: 50%;
      right: 30rpx;
      transform: translateY(-50%);
    }
  }
  .popup-content {
    .list-item {
      display: flex;
      align-items: center;
      padding: 22rpx 24rpx 22rpx 36rpx;

      &-icon {
        width: 50rpx;
        height: 50rpx;
        margin-right: 20rpx;
      }
      &-name {
        flex: 1;
        font-size: 28rpx;
        color: #2a343e;
        line-height: 40rpx;
        margin-right: 16rpx;
      }
      &-check {
        width: 40rpx;
        height: 40rpx;
      }
    }
  }
  /deep/ .uni-radio-input {
    margin: 0;
    width: 40rpx;
    height: 40rpx;
    border: none;
  }
  .popup-btn {
    padding: 28rpx 24rpx 50rpx;

    /deep/.u-button {
      margin: 0;
      height: 84rpx;
      line-height: 84rpx;
      border-radius: 42rpx;
      font-size: 32rpx;
    }
  }
}

.vip-box {
  height: 190rpx;
  flex-direction: column;
  justify-content: center;
}

.vip-price {
  font-size: 60rpx;
  font-weight: 500;
  color: #484848;
  line-height: 84rpx;
  text {
    font-size: 32rpx;
  }
}

.vip-introduce {
  width: 690rpx;
  text-align: center;
  padding-bottom: 40rpx;
  border-bottom: 2rpx solid #f5f5f8;
}
</style>
