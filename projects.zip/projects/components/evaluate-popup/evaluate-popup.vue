<template>
  <view>
    <view class="popup" v-if="evaluatePopupShow" @touchmove.stop.prevent="handleTouchMove">
      <u-popup round="30" :show="evaluatePopupShow">
        <view class="popup-box">
          <view class="nav-box">
            <view></view>
            <image class="close-img" src="https://img.yiqitogether.com/static/images/close-btn.png" @click="closePopup"></image>
          </view>
          <scroll-view scroll-y="true" class="scroll-box">
            <view class="popup-con">
              <view class="text-title">对发起人评价</view>
              <view class="userinfo" v-if="userInfoDTO">
                <image
                  :src="userInfoDTO.headUrl ? userInfoDTO.headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'"
                  mode=""
                  class="head-img"
                  @click="
                    $u.throttle(() => {
                      goMyPage(userInfoDTO.numberId)
                    })
                  "
                ></image>
                <text
                  class="username"
                  @click="
                    $u.throttle(() => {
                      goMyPage(userInfoDTO.numberId)
                    })
                  "
                >
                  {{ userInfoDTO.nickName }}
                </text>
              </view>
              <view class="rate-box">
                总体
                <u-rate active-color="#F5D865" v-model="scoreValue" inactive-color="#b2b2b2" gutter="15" size="45" :allowHalf="true" inactiveIcon="star-fill" inactiveColor="#f4f5f6"></u-rate>
                {{ scoreValue > 0 ? scoreValue : '' }}
              </view>
              <view class="text-title">“活动太棒了, 夸夸发起人”</view>
              <view class="tagBox">
                <view class="smallBox" v-for="(item, index) in tagList" :key="index">
                  <u-tag :text="item.name" plain :color="item.checked ? '#FE5E10' : '#A6ACB2'" :borderColor="item.checked ? '#FE5E10' : '#DFE0E1'" :style="{ background: item.checked ? '#FFEAEB' : 'none' }" shape="circle" :name="index" @click="checkboxClick(item)"></u-tag>
                </view>
              </view>
              <u--textarea :cursorSpacing="400" count autoHeight :confirmType="null" v-model.trim="evaluateValue" placeholder="说说你的同行体验吧~" maxlength="500" border="none" placeholderStyle="color:#ADB3BA"></u--textarea>
            </view>
            <view class="popup-foot">
              <u-button text="发布评价" class="release-btn" :disabled="computeDisabled" @click="addScore" :throttleTime="500"></u-button>
            </view>
          </scroll-view>
        </view>
      </u-popup>
    </view>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
export default {
  name: 'evaluate-popup',
  props: {
    // 是否显示弹窗
    evaluatePopupShow: {
      type: Boolean,
      default: false
    },
    // 标签列表
    tagList: {
      type: Array,
      default: []
    },
    // 发布人信息
    userInfoDTO: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {
      checkedTag: [],
      evaluateValue: '',
      scoreValue: 0
    }
  },
  computed: {
    computeDisabled() {
      if (this.scoreValue > 0) {
        return false
      } else {
        return true
      }
    }
  },
  methods: {
    // 解决弹窗滚动穿透问题
    handleTouchMove(e) {
      e.stopPropagation()
    },
    closePopup() {
      this.evaluateValue = ''
      this.checkedTag = []
      this.scoreValue = ''
      this.tagList.forEach(item => {
        item.checked = false
      })
      this.$emit('closePopup')
    },
    // 标签选择
    checkboxClick(item) {
      // if (!this.isShow) {
      //   return
      // }
      item.checked = !item.checked
      this.$nextTick(() => {
        this.checkedTag = this.tagList.filter(item => item.checked)
      })
    },
    addScore() {
      let label = ''
      if (this.checkedTag) {
        label = this.checkedTag
          .map(item => {
            return item.name
          })
          .join('&&')
      }
      let datas = {
        score: this.scoreValue,
        label: label,
        content: this.evaluateValue,
        beNumberId: this.userInfoDTO.numberId
      }
      this.$emit('addScore', datas)
      // 发布完数据清空
    },

    // 去个人主页
    goMyPage(numberId) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + numberId })
    },
    // 发布评价成功后清空数据
    clearData() {
      this.evaluateValue = ''
      this.checkedTag = []
      this.scoreValue = ''
      this.tagList.forEach(item => {
        item.checked = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/.u-popup__content {
  background-color: transparent !important;
}
.popup-box {
  width: 100%;
  height: 90vh;
  border-radius: 40rpx 40rpx 0 0;
  position: relative;
  padding-top: 174rpx;
  box-sizing: border-box;
  background: #fff;
  .nav-box {
    width: 100%;
    height: 332rpx;
    background-image: url('https://img.yiqitogether.com/static/images/pingjia_top_news.png');
    background-size: 100% 100%;
    display: flex;
    justify-content: space-between;
    position: absolute;
    top: -44rpx;
    .close-img {
      width: 52rpx;
      height: 52rpx;
      margin: 48rpx 20rpx 0 0;
      box-sizing: border-box;
    }
  }
  .popup-con {
    width: 100%;
    padding: 0 36rpx;
    box-sizing: border-box;
    background-color: #fff;
    padding-bottom: 50rpx;
    .text-title {
      padding: 26rpx 0;
      font-size: 32rpx;
      color: #0c0c0c;
    }
    .userinfo {
      height: 98rpx;
      display: flex;
      align-items: center;
      margin-bottom: 13rpx;
      .head-img {
        width: 72rpx;
        height: 72rpx;
        margin-right: 11rpx;
        border-radius: 50%;
      }
      .username {
        font-size: 28rpx;
      }
    }
    .rate-box {
      font-size: 28rpx;
      color: #0c0c0c;
      display: flex;
      align-items: center;
      padding-bottom: 36rpx;
      border-bottom: 2rpx solid #f0f1f3;

      /deep/.u-rate__content {
        margin: 0 32rpx;
      }
      /deep/.u-rate__content__item__icon-wrap--half {
        width: 30rpx !important;
      }
    }
    .tagBox {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 10rpx;
      .smallBox {
        height: 52rpx;
        border-radius: 26rpx;
        font-size: 28rpx;
        font-weight: 400;
        text-align: left;
        line-height: 52rpx;
        margin-bottom: 40rpx;
        margin-right: 20rpx;
        /deep/.u-fade-enter-active {
          border-radius: 200rpx !important;
        }
      }
    }
    /deep/.u-textarea {
      background: #f7f7f7;
      border-radius: 20rpx;
      min-height: 300rpx;
      padding-bottom: 55rpx;
    }
    /deep/.uni-textarea-wrapper {
      min-height: 300rpx;
    }
    /deep/.u-textarea__count {
      background-color: #f7f7f7 !important;
    }
  }
  .popup-foot {
    width: 100%;
    height: 130rpx;
    background-color: #fff;
    padding-top: 80rpx;
    border-top: 1rpx solid #f2f5f8;
    padding-top: 20rpx;
  }
  .release-btn {
    width: 456rpx;
    height: 88rpx;
    background-color: #fe5e10 !important;
    color: #fff;
    font-size: 36rpx;
    border-radius: 44rpx;
  }
}
.scroll-box {
  height: calc(90vh - 208rpx);
  /* #ifdef APP */
  // height: calc(80vh - 17vh - 42rpx);
  /* #endif */
}
</style>
