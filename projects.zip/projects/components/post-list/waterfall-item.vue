<template>
  <view class="waterfall-item-container" :style="params.id == 0 && !myPersonal ? 'height: 240rpx' : ''">
    <view class="waterfall-item" @tap="onTap('goDetail')">
      <view v-if="params.id == 0 && !myPersonal" @tap.stop="onTap('goDraftBox')">
        <view class="top" style="height: 240rpx">
          <view class="imgurl1"></view>
          <!-- <image class="" style="position: absolute" lazy-load src="./transparent.png" mode="widthFix"></image> -->
          <image lazy-load style="height: 240rpx" :src="params.url" class="draftsimg" mode="top" @load="emitHeight" @error="emitHeight" />
          <view class="drafts">
            <view class="imgtitle">草稿箱</view>
            <view class="tip">{{ params.total }}篇笔记待发布</view>
          </view>
        </view>
      </view>
      <view v-else>
        <view class="top">
          <!-- 置顶标识 -->
          <view class="top-box flex-0">
            <view class="top-icon" v-if="params.twitterInfo.topOrder == 1 && sourcePage == 'my'">置顶</view>
            <view class="peddingbox flex-0" v-if="params.userinfo.numberId == numberId && params.twitterInfo.checkState == 1" @tap.stop="onTap('hint')">
              <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
              <view class="paddingbox-text">待审核</view>
            </view>
          </view>
          <view class="image-box" :style="{ height: imageBox.height + 'rpx' }" v-if="params.twitterInfo.imageUrls.split('&&')[0]">
            <image class="" style="width: 1rpx; height: 1rpx; position: absolute; top: 20rpx" lazy-load src="./transparent.png" mode="widthFix" @load="emitHeight" @error="emitHeight"></image>
            <image v-if="imageBox.type === 'wideGraph'" :style="{ height: imageBox.height + 'rpx' }" class="image-item" :src="params.twitterInfo.imageUrls.split('&&')[0]" mode="heightFix" />
            <image v-else-if="imageBox.type === 'longGraph'" class="image-item image-item-long" :src="params.twitterInfo.imageUrls.split('&&')[0]" mode="widthFix" />
            <image v-else class="image-item image-item-long" :src="params.twitterInfo.imageUrls.split('&&')[0]" mode="widthFix"></image>
            <view class="bg-color"></view>
            <!-- 笔记视频 -->
            <view v-if="params.twitterInfo.videoUrl" style="z-index: 2" class="video-img" @tap.stop="onTap('playVideo')">
              <image v-if="sourcePage != 'my'" style="z-index: 2" lazy-load class="video" src="@/static/images/fx_gc_sp.png" mode="scaleToFill" />
              <image v-else lazy-load class="video" src="@/static/images/fx_gc_sp.png" mode="scaleToFill" />
            </view>
            <!-- 短剧视频 -->
            <view v-if="params.twitterInfo.findType && params.twitterInfo.findType.label == 'SD'" style="z-index: 2" class="video-img">
              <image v-if="sourcePage != 'my'" style="z-index: 2" lazy-load class="video" src="@/static/images/fx_gc_sp.png" mode="scaleToFill" />
              <image v-else lazy-load class="video" src="@/static/images/fx_gc_sp.png" mode="scaleToFill" />
            </view>
          </view>
        </view>
        <view class="content">
          <block v-if="sourcePage != 'draftBox'">
            <view class="title" v-if="params.twitterInfo">
              {{ params.twitterInfo.title || params.twitterInfo.content || '' }}
            </view>
            <view class="bottom">
              <view class="left">
                <view class="img">
                  <image class="imgurl" lazy-load :src="params.userinfo.headUrl" mode="scaleToFill" />
                </view>
                <view class="name ellipsis-single" v-if="params.userinfo.nickName">{{ params.userinfo.nickName }}</view>
              </view>
              <!-- 短视频点赞 -->
              <view class="right" v-if="params.twitterInfo.findType && params.twitterInfo.findType.label == 'SD'">
                <image @tap.stop="onTap('collectPlaylet')" :src="params.isZan ? require('@/static/images/fx_dz_love-t.png') : require('@/static/images/fx_dz_love-f.png')" mode="scaleToFill" @click="collect(params, index)" />
                <view class="text">{{ params.zanCount }}</view>
              </view>
              <!-- 笔记点赞 -->
              <view class="right" v-else>
                <image @tap.stop="onTap('collect')" :src="params.isZan ? require('@/static/images/fx_dz_love-t.png') : require('@/static/images/fx_dz_love-f.png')" mode="scaleToFill" @click="collect(params, index)" />
                <view class="text">{{ params.zanCount }}</view>
              </view>
            </view>
          </block>
          <!-- 草稿箱底部 -->
          <block v-else>
            <view class="draft-bottom flex-1">
              <view class="bottom-left">
                {{ params.twitterInfo.createTime | timeFormat }}
              </view>
              <view class="bottom-right">
                <image class="bottom-rightImg" src="@/static/images/cg_sc.png" mode="" @tap.stop="onTap('openDelShow')"></image>
              </view>
            </view>
          </block>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { dateTimeFormat } from '@/static/common/formatTime.js'
import { load } from '@/utils/store.js'
import { LOGIN_USERID } from '@/utils/cacheKey.js'
export default {
  name: 'helangWaterfallItem',
  options: {
    virtualHost: true
  },
  props: {
    params: {
      type: Object,
      default() {
        return {}
      }
    },
    tag: {
      type: String | Number,
      default: ''
    },
    index: {
      type: Number,
      default: -1
    },
    myPersonal: {
      type: Boolean,
      default: false
    },
    sourcePage: {
      type: String,
      default: 'my'
    }
  },
  data() {
    return {
      imageBox: {},
      numberId: load(LOGIN_USERID) || '' // 用户id
    }
  },
  created() {
    let imageObj =
      this.$props.params.twitterInfo && this.$props.params.twitterInfo.imgSize
        ? JSON.parse(this.$props.params.twitterInfo.imgSize)
        : {
            width: 360,
            height: 480
          }
    let w = imageObj.width || 360
    let h = imageObj.height || 480
    let rate = w / h
    let imageBox = {}
    if (rate > 4 / 3) {
      // 视为宽图  高度重设为270，宽度的4分之3，乐哥要求的。
      imageBox.type = 'wideGraph'
      imageBox.height = 270
    } else if (rate < 3 / 4) {
      // 视为长图  宽度设置为360，高度等比设置，截取中间部分。最终结果 ：宽度展示完，高度被上下截掉一部分。
      imageBox.type = 'longGraph'
      imageBox.height = 480
    } else {
      imageBox.type = 'normal'
      imageBox.height = 360 / rate
    }
    this.imageBox = imageBox
  },
  filters: {
    timeFormat: function (value) {
      let date = ''
      let date2 = ''
      let date3 = ''
      let date4 = ''
      let lastYear = ''
      if (value) {
        date = dateTimeFormat(value, 'yyyy-MM-dd')
        date2 = dateTimeFormat(value, 'MM-dd')
        date3 = dateTimeFormat(value, 'HH:mm')
        date4 = dateTimeFormat(value, 'MM-dd HH:mm')
        lastYear = dateTimeFormat(value, 'yyyy')
      }
      let year = new Date().getFullYear()

      let createTime = new Date(date).getTime()
      let currentTime = new Date().getTime()
      let countdown = currentTime - createTime

      // 当天晚上十二点之前的时间戳
      let timeEnd = new Date(new Date(new Date().toLocaleDateString()).getTime()).getTime()
      let timeEnd2 = new Date(new Date(new Date().toLocaleDateString()).getTime() - 24 * 60 * 60 * 1000).getTime()
      // let timeEnd2 = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1).getTime()

      if (createTime > timeEnd) {
        return '今天'
      } else if (createTime < timeEnd && createTime > timeEnd2) {
        return '昨天'
      } else if (year != lastYear) {
        return date
      } else {
        return date2
      }
    }
  },
  methods: {
    // 点击播放视频
    playVideo() {
      this.$emit('playVideos')
    },
    // 1*1的占位图片加载成功，触发更新
    emitHeight(e) {
      const query = uni.createSelectorQuery().in(this)
      query
        .select('.waterfall-item-container')
        .boundingClientRect(data => {
          let height = Math.floor(data.height)
          this.$emit('height', height, this.$props.tag)
        })
        .exec()
      // if (e == '1') {
      // 	const query = uni.createSelectorQuery().in(this)
      // 	query
      // 		.select('.waterfall-item-container')
      // 		.boundingClientRect(data => {
      // 			this.$emit('height', 120, this.$props.tag)
      // 		})
      // 		.exec()
      // } else {
      // 	const query = uni.createSelectorQuery().in(this)
      // 	query
      // 		.select('.waterfall-item-container')
      // 		.boundingClientRect(data => {
      // 			let height = Math.floor(data.height)
      // 			this.$emit('height', height, this.$props.tag)
      // 		})
      // 		.exec()
      // }
    },
    onTap(type) {
      this.$emit('click', this.$props.index, this.$props.tag, type)
    },
    // 到草稿箱
    godraftBox() {
      this.$emit('goDraftBox')
    },
    // 视频详情/笔记详情
    goDetail() {
      this.$emit('goDetail', this.$props.params.twitterInfo.twitterId)
    },
    // 点赞
    collect(data, index) {
      this.$emit('collect', {
        data,
        index
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

image {
  display: block;
  font-size: 0;
}

.waterfall-item-container {
  width: 360rpx;
}

.waterfall-item {
  // padding: 16rpx;

  width: 360rpx;
  background-color: #fff;
  border-radius: 16rpx;
  font-size: 28rpx;
  color: #666;
  box-sizing: border-box;

  .top {
    // width: 342rpx;
    position: relative;
    color: #ffffff;

    .image-box {
      width: 360rpx;
      max-width: 360rpx;
      max-height: 480rpx;

      position: relative;
      border-radius: 20rpx;
      overflow: hidden;
      background-color: #fff;

      .image-item {
        width: 360rpx;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        // border-radius: 17rpx;
        z-index: 1;
      }
      .image-item-long {
        width: 360rpx;
        // border-radius: 17rpx;
        // background-color: #fff;
      }
      .bg-color {
        width: 100%;
        height: 99%;
        background-color: #000;
        position: absolute;
        top: 2rpx;
        border-radius: 20rpx;
        // z-index: -1;
      }
    }

    .draftsimg {
      width: 100%;
      border-radius: 16rpx;
    }

    .drafts {
      border-radius: 16rpx;
      // z-index: 999999;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      position: absolute;
      top: 0;
      text-align: center;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: center;

      .imgtitle {
        font-size: 28rpx;
        font-family: PingFang SC, PingFang SC-Medium;
        font-weight: Medium;
        text-align: center;
        line-height: 40rpx;
        margin-bottom: 6rpx;
      }

      .tip {
        font-size: 22rpx;
        font-family: PingFang SC, PingFang SC-Regular;
        font-weight: Regular;
        text-align: center;
        line-height: 32rpx;
      }
    }

    .img {
      border-radius: 16rpx;
      max-height: 456rpx;
      min-height: 256rpx;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f9fafc; // 默认设置一个图片的大约值
      // height: 350rpx;
      width: 100%;
      position: relative;

      .imgurl1 {
        display: block !important;
        width: 100%;
      }
    }
    .video-img {
      position: absolute;
      top: 0;
      right: 0;
      width: 100%;
      height: 100%;
      .video {
        transform: translate(50%, 0%);
        width: 52rpx;
        height: 52rpx;
        position: absolute;
        top: 45%;
        right: 50%;
      }
    }
  }

  .content {
    margin-top: 16rpx;
    padding: 0 20rpx 15rpx;

    .title {
      line-break: anywhere;
      font-size: 28rpx;
      text-align: left;
      color: #2a343e;
      line-height: 44rpx;
      overflow: hidden;
      display: -webkit-box;
      font-weight: 400;
      -webkit-line-clamp: 2;
      /* 设置最大显示行数 */
      -webkit-box-orient: vertical;
      text-overflow: ellipsis;
      word-break: break-all;
    }

    .bottom {
      margin: 20rpx 0 10rpx 0;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .left {
        flex-grow: 1;
        display: flex;
        align-items: center;
        text-align: center;

        .img {
          width: 40rpx;
          height: 40rpx;
          margin-right: 10rpx;

          image {
            text-align: center;
            width: 100%;
            height: 100%;
            border-radius: 50%;
          }
        }

        .name {
          width: 150rpx;
          font-size: 24rpx;
          text-align: left;
          color: #838e9a;
          line-height: 40rpx;
          overflow: hidden;
        }
      }

      .right {
        display: flex;
        align-items: center;

        image {
          width: 44rpx;
          height: 44rpx;
          margin-right: 8rpx;
        }

        .text {
          font-size: 24rpx;
          font-family: PingFang SC, PingFang SC-Medium;
          font-weight: Medium;
          text-align: left;
          color: #9fa7b4;
          line-height: 34rpx;
        }
      }
    }

    .draft-bottom {
      .bottom-left {
      }

      .bottom-right {
        .bottom-rightImg {
          width: 36rpx;
          height: 36rpx;
        }
      }
    }
  }
}
.top-box {
  position: absolute;
  left: 20rpx;
  top: 20rpx;
  z-index: 3;
  .top-icon {
    width: 68rpx;
    height: 38rpx;
    background: #fd5e0f;
    border-radius: 22rpx;
    line-height: 38rpx;
    text-align: center;
    font-size: 22rpx;
  }
  .peddingbox {
    background: #ffefe7;
    border-radius: 28rpx;
    padding: 6rpx 12rpx;
    margin-left: 8rpx;

    .peddingbox-img {
      width: 28rpx;
      height: 28rpx;
      margin-right: 6rpx;
      display: block;
      margin-top: 2rpx;
    }
    .paddingbox-text {
      font-size: 24rpx;
      color: #fd5e0f;
      line-height: 30rpx;
    }
  }
}
</style>
