<template>
  <view>
    <view v-if="list.length > 0 && !showLoading">
      <view class="waterfall-box h-flex-x h-flex-2">
        <view>
          <view v-for="(item, index) in leftList" :key="item._render_id" class="list-item" :class="{ show: showPage > item._current_page }">
            <helang-waterfall-item :sourcePage="sourcePage" tag="left" :myPersonal="myPersonal" :params="item" :index="index" @height="onHeight" @click="onClick"></helang-waterfall-item>
          </view>
        </view>
        <view>
          <view v-for="(item, index) in rightList" :key="item._render_id" class="list-item" :class="{ show: showPage > item._current_page }">
            <helang-waterfall-item :sourcePage="sourcePage" tag="right" :index="index" :params="item" @height="onHeight" @click="onClick"></helang-waterfall-item>
          </view>
        </view>
      </view>
      <slot v-if="leftList.length !== 0 || rightList.length !== 0"></slot>
    </view>
    <!-- 缺省图 -->
    <view class="normalActivity-empty" v-if="!showLoading && (list.length == 0 || (leftList.length == 0 && rightList.length == 0 && awaitRenderList.length == 0 && status == 'success'))">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
      <text class="empty-text">暂无内容</text>
    </view>
    <!-- 删除草稿提示框 -->
    <custom-modal type="tipsConfirm" :show="isShowDelete" :round="24" title="提示" content="是否删除草稿？" themeColor="#FE5E10" cancelText="取消" confirmText="确认" @cancel="closedDelShow" @confirm="delData" />
  </view>
</template>

<script>
// 导入组件
import helangWaterfallItem from './waterfall-item.vue'
//导入接口
import FindModel from '@/model/find'

export default {
  name: 'helangWaterfallList',
  options: {
    virtualHost: true
  },
  components: {
    'helang-waterfall-item': helangWaterfallItem
  },
  props: {
    status: {
      type: String,
      default: 'success'
    },
    // 待渲染的数据
    list: {
      type: Array,
      default() {
        return []
      }
    },
    // 重置列表，设置为 true 时，瀑布流会自动重新渲染列表
    // reset: {
    //   type: Boolean,
    //   default: false
    // },
    myPersonal: {
      type: Boolean,
      default: false
    },
    showLoading: {
      type: Boolean,
      default: false
    },
    // 当前页面
    sourcePage: {
      type: String,
      default: 'find'
    }
  },
  computed: {},
  data() {
    return {
      // 左侧列表高度
      leftHeight: 0,
      // 右侧列表高度
      rightHeight: 0,
      // 左侧列表数据
      leftList: [],
      // 右侧列表数据
      rightList: [],
      // 待渲染列表
      awaitRenderList: [],
      // 当前展示页码数据
      showPage: 1,
      jiazai: false,
      startTime: null,
      endtime: null,
      loadingTime: 0,
      type: '', // 图文/视频
      isShowDelete: false, // 删除弹框
      index: '', // inde索引
      checkedItem: {}, // 选中的item
      tag: '' // 左边、右边
    }
  },
  watch: {
    status: function (newValue, oldValue) {
      // 状态变更为 加载成功 时，执行瀑布流数据渲染
      if (newValue == 'success') {
        this.startRender()
      } else if (newValue == 'reset') {
        this.resetData()
      }
    }
  },
  methods: {
    /**
     * 播放视频事件，暂时跳转详情页
     */
    playVideo(item) {
      // this.$emit('playVideo', item.twitterInfo)
      // #ifdef H5
      this.$emit('playVideo', item.twitterInfo)
      // #endif
      // #ifndef H5
      if (item.twitterInfo.videoUrl) {
        let obj = {
          _id: item.twitterInfo.twitterId, //每一个视频独有 id （自定义）
          userNumberId: item.twitterInfo.userNumberId, //作者numberId
          nickName: item.userinfo.nickName, //作者昵称
          href: item.userinfo.headUrl, //作者头像
          title: item.twitterInfo.title || '', //第一行标题
          msg: item.twitterInfo.content || '', //第二行内容
          state: 'pause', //初始状态标志（不改）
          isZan: item.isZan, //是否点赞了
          isCollect: item.isCollect, //是否收藏了
          zanCount: item.zanCount ? Number(item.zanCount) : 0, //点赞数量
          collectCount: item.collectCount ? Number(item.collectCount) : 0, //收藏数量
          commentCount: item.commentCount ? Number(item.commentCount) : 0, //评论数量
          src: item.twitterInfo.videoUrl, //视频链接
          videoImgUrl: item.twitterInfo.imageUrls || '', //视频封面
          pinlun: [], //评论
          playIng: false, //播放（默认这个即可）
          isShowimage: false, //是否显示封面（默认这个即可）
          isShowProgressBarTime: false, //是否显示进度条（默认这个即可）
          isplay: true, //是否播放音频（默认这个即可）
          showPauseIcon: false //是否显示暂停播放图标（默认这个即可）
        }
        uni.navigateTo({
          url: '/pages/index/appPlay?videoData=' + encodeURIComponent(JSON.stringify(obj)) + '&pageType=2',
          events: {
            setFullscreen() {
              plus.navigator.setStatusBarStyle('dark')
            },
            // 刷新点赞/收藏数量
            refreshFindDetailsCount(data) {
              let { countField, flagField, type } = data
              if (type == 'sub') {
                item[countField] = Number(item[countField]) - 1
                item[flagField] = false
              } else {
                item[countField] = Number(item[countField]) + 1
                item[flagField] = true
              }
            },
            // 刷新评论数量
            refreshCommentCount(num) {
              item.commentCount = num
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    /**
     * 去往详情页
     */
    goDetail(item, tag, index) {
      let self = this
      // 前往短视频详情页
      if (item.twitterInfo.findType && item.twitterInfo.findType.label == 'SD') {
        uni.navigateTo({ url: `/pages/my/webView?destination=3&openUrl=https://applet-h5.yiqitogether.com/pages/playlet/index/videoPlay&sharePage=h5&playCode=${item.twitterInfo.findType.playCode}&sdId=${item.twitterInfo.twitterId}` })
      } else if (this.sourcePage !== 'draftBox') {
        uni.navigateTo({
          url: '/pages/find/findDetails?twitterId=' + item.twitterInfo.twitterId + '&pageType=2',
          events: {
            /**
             * 点赞
             *  sub / add
             */
            zanCountChange: function (type) {
              if (tag === 'left') {
                if (type == 'sub') {
                  self.leftList[index].isZan = false
                } else {
                  self.leftList[index].isZan = true
                }
                self.changeItemZan(self.leftList[index])
              } else {
                if (type == 'sub') {
                  self.rightList[index].isZan = false
                } else {
                  self.rightList[index].isZan = true
                }
                self.changeItemZan(self.rightList[index])
              }
              self.$forceUpdate()
            },
            /**
             * 公共回调事件，处理特殊回调
             */
            publicChange: function (data) {
              self.$emit(data.functionName, data)
            }
          }
        })
      } else {
        if (item.twitterInfo.twitterType.text == '图文') {
          this.type = 'pic'
        }
        if (item.twitterInfo.twitterType.text == '视频') {
          this.type = 'video'
        }
        if (item.twitterInfo.fwb) {
          // 如果是富文本，跳到发文章列表；如果不是，则跳到编辑笔记列表
          uni.navigateTo({
            url: `/pagesFind/find/releaseArticle?chooseType=s3&type=${this.type}&twitterId=${item.twitterInfo.twitterId}`
          })
        } else {
          uni.navigateTo({
            url: `/pagesFind/find/release?chooseType=s3&type=${this.type}&twitterId=${item.twitterInfo.twitterId}`
          })
        }
      }
    },
    /**
     * 去往草稿箱
     */
    goDraftBox() {
      // 个人主页进要传pagetype=my
      uni.navigateTo({
        url: '/pagesFind/find/draftBox?pagetype=my'
      })
    },
    /**
     * 点赞
     */
    collect(item, tag, index) {
      let params = {
        twitterId: item.twitterInfo.twitterId
      }
      FindModel.isTwitter(item.isZan, params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            if (tag === 'left') {
              this.leftList[index].isZan = !this.leftList[index].isZan
              this.changeItemZan(this.leftList[index])
            } else if (tag === 'right') {
              this.rightList[index].isZan = !this.rightList[index].isZan
              this.changeItemZan(this.rightList[index])
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 3000
            })
          }
        })
        .catch(err => {
          console.log('🚀 ~ collect ~ err:', err)
        })
    },
    /**
     * 短剧点赞
     */
    collectPlaylet(item, tag, index) {
      let params = {
        sdId: item.twitterInfo.twitterId
      }
      FindModel.zanSd(item.isZan, params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            if (tag === 'left') {
              this.leftList[index].isZan = !this.leftList[index].isZan
              this.changeItemZan(this.leftList[index])
            } else if (tag === 'right') {
              this.rightList[index].isZan = !this.rightList[index].isZan
              this.changeItemZan(this.rightList[index])
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 3000
            })
          }
        })
        .catch(err => {
          console.log('🚀 ~ collectPlaylet ~ err:', err)
        })
    },
    /**
     *  打开删除弹框
     */

    openDelShow(item, tag, index) {
      this.isShowDelete = true
      this.delIndex = item.twitterId
    },
    closedDelShow() {
      this.isShowDelete = false
    },
    /**
     * 调用删除接口
     */
    delData(type) {
      let params = {
        twitterId: this.checkedItem.twitterInfo.twitterId
      }
      FindModel.twitterDel({ ...params })
        .then(res => {
          this.isShowDelete = false
          if (res.code == 'SUCCESS') {
            if (type != 'draftRelease') {
              setTimeout(() => {
                uni.showToast({
                  title: '删除成功',
                  icon: 'none',
                  mask: true
                })
              }, 500)
            }
            this.delePostListItem()
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 3000
            })
          }
        })
        .catch(err => {
          console.log('🚀 ~ delData ~ err:', err)
        })
    },
    /**
     * 删除某条数据
     */
    delePostListItem() {
      this.checkedItem = {}
      if (this.tag === 'left') {
        this.leftList.splice(this.index, 1)
      } else if (this.tag === 'right') {
        this.rightList.splice(this.index, 1)
      }
    },
    /**
     * 赞数更改
     */
    changeItemZan(data) {
      if (data.isZan) {
        // 修改合集总赞数
        this.$emit('changeZan', 'add')
        data.zanCount = parseInt(data.zanCount) + 1
      } else {
        // 修改合集总赞数
        this.$emit('changeZan', 'sub')
        data.zanCount = parseInt(data.zanCount) - 1
      }
    },
    /**
     * 待审核提示
     */
    hint() {
      uni.showToast({
        title: '由于发布的内容存在涉及色情、暴力等敏感信息，需等待系统审核后公开',
        icon: 'none',
        class: 'hint-toast'
      })
    },
    /**
     * @param {Object} index 当前点击的索引
     * @param {Object} tag left/right，左边数组还是右边数组
     * @param {Object} type 点击事件的类型  goDetail/去详情页  collect/收藏或取消收藏  playVideo/播放视频  goDraftBox/去草稿箱
     */
    onClick(index, tag, type) {
      // console.log(`当前点击事件为：${type},触发卡片为：${tag},${index}`)
      // console.log(`卡片数据为：`, this.leftList[index])
      // uni.showToast({
      //   title: `当前点击事件为：${type},触发卡片为：${tag},${index}`,
      //   icon: 'none',
      //   duration: 2500
      // })
      let item = {}
      if (tag === 'left') {
        item = this.leftList[index]
      } else if (tag === 'right') {
        item = this.rightList[index]
      }
      this.checkedItem = item
      this.tag = tag
      this.index = index

      switch (type) {
        case 'goDetail':
          // if (tag == 'left') {
          //   this.leftList.splice(index, 1)
          // }
          this.goDetail(item, tag, index)
          break
        case 'goDraftBox':
          this.goDraftBox()
          break
        case 'playVideo':
          this.playVideo(item)
          break
        case 'collect':
          this.collect(item, tag, index)
          break
        case 'openDelShow':
          this.openDelShow(item, tag, index)
          break
        case 'hint':
          this.hint(item, tag, index)
          break
        case 'collectPlaylet':
          this.collectPlaylet(item, tag, index)
          break
        default:
          console.log(`未定义type:${type}`)
          break
      }
    },
    // 监听高度变化
    onHeight(height, tag) {
      /**
       * 这个为实际渲染后 CSS 中 margin-buttom 的值，本示例默认为20rpx
       * 用于解决实际渲染后因为数据条数关系，高度差计算偏差的问题
       * */
      let marginBottom = uni.upx2px(20)
      if (tag == 'left') {
        this.leftHeight += height + marginBottom
      } else {
        this.rightHeight += height + marginBottom
      }
      this.renderList()
    },
    // 渲染列表，这里实现瀑布流的左右分栏
    renderList() {
      // 待渲染长度为 0 时表示已渲染完成
      if (this.awaitRenderList.length <= this.$props.list.length && this.awaitRenderList.length != 0) {
        this.jiazai = true
      } else {
        this.jiazai = false
      }
      if (this.awaitRenderList.length < 1) {
        this.showPage++
        this.endtime = Date.now()
        this.loadingTime = (this.endtime - this.startTime) / 1000
        this.$emit('done')
        // 为防止 js 数值类型最大值溢出，当高度值大于 1亿时重置高度
        if (this.leftHeight > 100000000) {
          if (this.leftHeight > this.rightHeight) {
            this.leftHeight = 2
            this.rightHeight = 1
          } else {
            this.leftHeight = 1
            this.rightHeight = 2
          }
        }
        return
      }
      let item = {
        ...this.awaitRenderList.splice(0, 1)[0],
        // 当前数据添加当前页面标识
        _current_page: this.showPage,
        // 当前数据添加一个渲染id，解决 v-for 重复会出现不执行 load 的 BUG
        _render_id: new Date().getTime()
      }
      if (this.leftHeight > this.rightHeight) {
        this.rightList.push(item)
      } else {
        this.leftList.push(item)
      }
    },
    // 重置数据
    resetData() {
      this.leftHeight = 0
      this.rightHeight = 0
      this.leftList = []
      this.rightList = []
      this.awaitRenderList = []
      // 当前展示页码数据
      this.showPage = 1
      this.$forceUpdate()
    },
    // 启动渲染
    startRender() {
      this.startTime = Date.now()
      if (!this.$props.list || this.$props.list.length < 1) {
        console.log('河浪瀑布流插件提示：当前数据为空，不会触发列表渲染')
        return
      }
      this.awaitRenderList = [...this.$props.list]
      this.renderList()
    }
  }
}
</script>

<style lang="scss" scoped>
.waterfall-box {
  margin: 20rpx 0;
  box-sizing: border-box;
  > view {
    padding-left: 10rpx;
    text-align: center;
  }

  .list-item {
    width: 360rpx;
    margin-bottom: 0;
    // 设置透明，默认是可视的
    opacity: 0;
    // 默认超出隐藏，不影响加载中的文字显示效果
    overflow: hidden;
    height: 0;

    &.show {
      margin-bottom: 12rpx;
      opacity: 1;
      overflow: auto;
      height: auto;
    }
  }
}

.h-flex-x {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  align-items: flex-start;
  align-content: flex-start;

  &.h-flex-2 {
    > view {
      // width: 50%;
    }
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    display: block;
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
