<template>
  <u-popup class="custom-more-operate-popup" :show="show" :closeOnClickOverlay="closeOnClickOverlay" @close="onClose" :duration="200" customStyle="background-color: transparent;margin: 0 20rpx 60rpx;">
    <view class="popup-btns-wrap">
      <view :class="['normal-text', index === list.length - 1 ? '' : 'line']" v-for="(item, index) in list" :key="index" @click="onClick(index, item)">
        <!-- 兼容nvue页面样式，谨慎改动 -->
        <text style="font-size: 28rpx; text-align: center" :style="{ color: item == '取消精选评论' || item == '退出活动' || item == '取消置顶' ? '#fb5c4e' : '#484848' }">{{ item }}</text>
      </view>
    </view>
    <view class="popup-btns-cancel" @click="onClose">
      <text style="font-size: 32rpx; color: #838e9a; text-align: center">{{ cancelText }}</text>
    </view>
  </u-popup>
</template>

<script>
export default {
  name: 'CustomMoreOperatePopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // 弹框内容
    list: {
      type: Array,
      default: () => []
    },
    // 取消按钮的文字
    cancelText: {
      type: String,
      default: '取消'
    }
  },
  data() {
    return {}
  },
  methods: {
    onClose() {
      this.$emit('close')
    },
    onClick(index, item) {
      // #ifndef APP-NVUE
      uni.$u.throttle(() => {
        this.handleClick(index, item)
      }, 1000)
      // #endif

      // #ifdef APP-NVUE
      this.handleClick(index, item)
      // #endif
    },
    handleClick(index, item) {
      this.$emit('click', index, item)
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-more-operate-popup {
  .popup-btns-wrap {
    background: #ffffff;
    border-radius: 24rpx;
    .normal-text {
      font-size: 28rpx;
      color: #484848;
      line-height: 40rpx;
      text-align: center;
      padding: 30rpx 0;
    }
  }
  .popup-btns-cancel {
    background: #ffffff;
    border-radius: 24rpx;
    margin-top: 20rpx;
    line-height: 44rpx;
    padding: 30rpx 0;
    text-align: center;
  }
  .line {
    border-bottom: 2rpx solid #f7f7f7;
  }
}
</style>
