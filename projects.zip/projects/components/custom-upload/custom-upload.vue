<template>
  <view class="custom-upload">
    <view class="upload-list">
      <block v-for="(item, index) in listData" :key="index">
        <view class="upload-box" v-if="item.photoType == 'IMGS'">
          <!-- 上传的图片 -->
          <image class="upload-img" :src="item.localUrl" mode="aspectFill" @click="handlePreviewImg(index)" />
          <image class="del-icon" v-if="item.percentage == 100 || item.showFail" src="@/static/images/upload_delete.png" mode="" @click.stop="deleteImgOrVideo('IMGS', index)" />
          <block v-else>
            <!-- 图片上传状态 —— 上传失败/取消上传 -->
            <view class="upload-bottom flex-center" v-if="!item.percentage && item.showFail">
              <image class="warn-icon" src="@/static/images/warn.png" mode="aspectFill" />
              <view class="warn-text">上传失败</view>
            </view>
            <!-- 图片上传状态 —— 上传中 -->
            <view class="upload-bottom" v-else>
              <view class="txt">{{ item.percentage || 0 }}%</view>
              <u-line-progress class="progress" :style="{ width: index == currIndex ? '152rpx' : '186rpx' }" :percentage="item.percentage" height="10" :showText="false" inactiveColor="#b8b6b9" activeColor="#fff"></u-line-progress>
              <image v-show="index == currIndex" class="close-icon" src="@/static/images/close_white.png" mode="aspectFill" @click.stop="cancelUpload(index)" />
            </view>
          </block>
        </view>

        <view class="upload-box" v-if="item.photoType == 'VIDEO'">
          <!-- 上传的视频 -->
          <image class="upload-img" :src="item.imgUrl" mode="aspectFill" @click="handlePlayVideo" />
          <image class="play-icon" src="@/static/images/fx_gc_sp.png" mode="aspectFill" @click.stop="handlePlayVideo" />
          <image class="del-icon" v-if="item.percentage == 100 || item.showFail" src="@/static/images/upload_delete.png" alt="" mode="" @click.stop="deleteImgOrVideo('VIDEO', index)" />
          <block v-else>
            <!-- 视频上传状态 —— 上传失败/取消上传 -->
            <view class="upload-bottom flex-center" v-if="!item.percentage && item.showFail">
              <image class="warn-icon" src="@/static/images/warn.png" mode="aspectFill" />
              <view class="warn-text">上传失败</view>
            </view>
            <!-- 视频上传状态 —— 上传中 -->
            <view class="upload-bottom" v-else>
              <view class="txt">{{ item.percentage || 0 }}%</view>
              <u-line-progress class="progress" :style="{ width: index == currIndex ? '152rpx' : '186rpx' }" :percentage="item.percentage" height="10" :showText="false" inactiveColor="#b8b6b9" activeColor="#fff"></u-line-progress>
              <image v-show="index == currIndex" class="close-icon" src="@/static/images/close_white.png" mode="aspectFill" @click.stop="cancelUpload(index)" />
            </view>
          </block>
        </view>
      </block>
      <view class="add-box" @click="judgeAlbumAuth">
        <image class="add-img" src="@/static/images/photo.png" mode="widthFix" />
        <view class="add-text">添加照片/视频</view>
      </view>
    </view>

    <!-- 相册权限弹窗 -->
    <accredit-popup ref="accreditRef" systemTitle="“一起一起”想访问您的相册" systemContent="用于使用上传照片/视频功能" permisionID="android.permission.READ_EXTERNAL_STORAGE" cacheId="externalStorage" @successAccredit="showUploadType = true" />
    <!-- 选择上传类型弹窗 -->
    <custom-more-operate-popup :show="showUploadType" :list="btnList" @close="showUploadType = false" @click="handleBtnClick" />
    <!-- 重新上传弹窗 -->
    <custom-more-operate-popup :show="showReUpload" :list="reloadBtnList" @close="showReUpload = false" @click="handleReUpload" />
    <!-- 确认删除图片/视频弹窗 -->
    <custom-modal type="tipsConfirm" :show="showDel" :round="24" title="确认删除" :content="delContent" cancelText="取消" confirmText="确认" @cancel="cancelDel" @confirm="confirmDel" />
  </view>
</template>

<script>
import { uploadFile } from '@/utils/tools.js'

export default {
  name: 'CustomUpload',
  data() {
    return {
      uploadType: '', // 上传类型
      listData: [], // 图片视频数组
      showDel: false,
      indexNumber: null,
      delContent: '是否删除此照片？',
      showUploadType: false, // 上传类型弹窗
      btnList: ['图片', '视频'],
      showReUpload: false,
      reloadBtnList: ['重新上传'],
      downloadTask: null, // 上传对象
      currIndex: 0
    }
  },
  watch: {
    listData: {
      handler(val) {
        this.$emit('success', this.listData)
      }
    }
  },
  methods: {
    // 判断相册权限
    judgeAlbumAuth() {
      if (this.listData.length) {
        let arr = this.listData.filter(item => item.percentage != 100 && !item.showFail)
        if (arr && arr.length) {
          uni.showToast({
            title: '请等待当前图片/视频上传完成',
            icon: 'none',
            mask: true
          })
          return
        }
      }
      this.$refs.accreditRef.triggerEvent()
    },
    // 选择上传类型
    handleBtnClick(index) {
      switch (index) {
        case 0:
          // 图片
          this.uploadType = 'IMGS'
          this.handleUpload()
          break
        case 1:
          // 视频
          this.uploadType = 'VIDEO'
          this.handleUpload()
          break
        default:
          break
      }
    },
    handleFail(index) {
      if (this.listData.length) {
        let arr = this.listData.filter(item => item.percentage != 100 && !item.showFail)
        if (arr && arr.length) {
          uni.showToast({
            title: '请等待当前图片/视频上传完成',
            icon: 'none',
            mask: true
          })
          return
        }
      }
      this.indexNumber = index
      this.showReUpload = true
    },
    // 重新上传
    handleReUpload() {
      let type = this.listData[this.indexNumber].photoType
      let currUrl = this.listData[this.indexNumber].localUrl
      if (type == 'VIDEO') {
        let obj = {
          tempFilePath: currUrl
        }
        this.afterReadVideo(obj)
      } else {
        let obj = {
          file: [{ url: currUrl }]
        }
        this.afterReadImg(obj)
      }
    },
    // 上传
    handleUpload() {
      this.showUploadType = false
      let self = this
      if (this.uploadType == 'VIDEO') {
        // 选择视频
        uni.chooseVideo({
          sourceType: ['album'],
          compressed: false,
          success: function (res) {
            self.afterReadVideo(res)
          }
        })
      } else {
        // 选择图片
        uni.chooseImage({
          sourceType: ['album'],
          success: res => {
            let arr = res.tempFilePaths || []
            let imageSrcList = []
            for (let i = 0; i < arr.length; i++) {
              imageSrcList.push({ url: arr[i] })
            }
            let obj = {
              file: imageSrcList
            }
            self.afterReadImg(obj)
          }
        })
      }
    },
    // 上传图片
    async afterReadImg(e) {
      let self = this
      let len = this.listData.length
      let list = e.file || []
      let arr = list.filter(item => item.url.toLowerCase().includes('heic'))
      if (arr.length > 0) {
        uni.showToast({
          title: '暂不支持上传HEIC格式的文件',
          icon: 'none',
          duration: 2000
        })
      }
      list = list.filter(item => !item.url.includes('heic'))
      for (let i = 0; i < list.length; i++) {
        this.listData.push({ photoType: 'IMGS', imgUrl: '', videoUrl: '', localUrl: list[i].url, percentage: 0, showFail: false })
      }
      for (let i = 0; i < list.length; i++) {
        this.currIndex = i + len
        try {
          let imgUrl = await uploadFile(list[i].url, self.processingProgress)
          this.listData[this.currIndex].imgUrl = imgUrl
        } catch (error) {
          this.listData[this.currIndex].percentage = 0
          this.listData[this.currIndex].showFail = true
        }
      }
    },
    // 上传视频
    async afterReadVideo(e) {
      if (JSON.stringify(e) === '{}' || !e) {
        return
      }
      let self = this
      let len = this.listData.length
      let sizeMb = Number(e.size) / 1024 / 1024
      if (sizeMb > 1536) {
        return uni.showToast({
          title: '视频过大，不得超过1.5G',
          icon: 'none',
          duration: 1500
        })
      }
      let obj = {
        photoType: 'VIDEO',
        imgUrl: '',
        videoUrl: '',
        localUrl: e.tempFilePath,
        percentage: 0,
        showFail: false
      }
      this.listData.push(obj)
      this.currIndex = len
      try {
        // 上传视频
        let videoUrl = await uploadFile(e.tempFilePath, self.processingProgress)
        this.listData[this.currIndex].imgUrl = videoUrl + '!/snapshot/point/00:00:00/format/png'
        this.listData[this.currIndex].videoUrl = videoUrl
      } catch (err) {
        // 上传失败
        this.listData[this.currIndex].percentage = 0
        this.listData[this.currIndex].showFail = true
      }
    },
    // 删除图片/视频
    deleteImgOrVideo(type, index) {
      this.indexNumber = index || 0
      this.delContent = type == 'VIDEO' ? '是否删除此视频？' : '是否删除此照片？'
      this.showDel = true
    },
    // 删除-取消
    cancelDel() {
      this.showDel = false
      this.indexNumber = null
    },
    // 删除-确认
    confirmDel() {
      if (this.listData.length) {
        this.listData.splice(this.indexNumber, 1)
      }
      this.indexNumber = null
      this.showDel = false
    },
    // 处理上传进度   downloadTask为上传对象
    processingProgress(res, downloadTask) {
      this.listData[this.currIndex].percentage = res.progress
      if (!this.downloadTask) {
        this.downloadTask = downloadTask
      }
      this.$forceUpdate()
    },
    // 取消上传
    cancelUpload(index) {
      this.downloadTask.abort()
      this.downloadTask = null
      this.listData[index].percentage = 0
      this.listData[index].showFail = true
      this.$forceUpdate()
    },
    // 预览图片
    handlePreviewImg(e) {
      let list = this.listData.filter(item => item.photoType == 'IMGS').map(item => item.imgUrl)
      uni.previewImage({
        urls: list,
        current: e
      })
    },
    // 播放视频
    handlePlayVideo(item) {
      this.$emit('play', item.imgUrl, item.videoUrl)
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-upload {
  box-sizing: border-box;
  white-space: nowrap;
  font-size: 0;

  .flex-center {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .upload-list {
    width: 100%;
    padding: 0 12rpx 0 24rpx;
    box-sizing: border-box;
    display: flex;
    flex-wrap: wrap;
  }
  .upload-box {
    width: 226rpx;
    height: 226rpx;
    position: relative;
    font-size: 0;
    margin-right: 12rpx;
    margin-bottom: 12rpx;

    .upload-img {
      width: 100%;
      height: 100%;
      border-radius: 16rpx;
    }
    .del-icon {
      width: 40rpx;
      height: 40rpx;
      position: absolute;
      top: 0;
      right: 0;
    }
    .play-icon {
      width: 46rpx;
      height: 46rpx;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }

    .upload-bottom {
      width: 226rpx;
      height: 80rpx;
      background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.5));
      border-radius: 0 0 16rpx 16rpx;
      position: absolute;
      left: 0;
      bottom: 0;
      .txt {
        font-size: 24rpx;
        text-align: center;
        color: #ffffff;
        line-height: 34rpx;
        margin-top: 16rpx;
      }
      .progress {
        position: absolute;
        bottom: 16rpx;
        left: 20rpx;
      }
      .close-icon {
        width: 24rpx;
        height: 24rpx;
        position: absolute;
        padding: 0 20rpx 10rpx 10rpx;
        right: 0;
        bottom: 0;
      }
      .warn-icon {
        width: 24rpx;
        height: 24rpx;
        margin-right: 6rpx;
      }
      .warn-text {
        font-size: 24rpx;
        text-align: center;
        color: #ffffff;
        line-height: 36rpx;
      }
    }
  }
  .add-box {
    width: 226rpx;
    height: 226rpx;
    background: #f5f8fb;
    border-radius: 16rpx;
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    vertical-align: top; // 解决相邻inline-block盒子会下移的问题
    margin-right: 12rpx;
    margin-bottom: 12rpx;
    .add-img {
      width: 42rpx;
      height: 36rpx;
    }
    .add-text {
      font-size: 20rpx;
      text-align: center;
      color: #adb3ba;
      line-height: 28rpx;
      margin-top: 12rpx;
    }
  }
}
</style>
