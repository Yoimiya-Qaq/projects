<template>
  <view class="custom-emoji-wrap">
    <!-- 以下样式为了兼容nvue页面，谨慎改动 -->
    <swiper :current="swiperIndex" :style="'width: ' + emojiWidth + widthUnit + ';height: 410rpx'" @change="swiperChange" :indicator-dots="true">
      <swiper-item v-for="(items, index) in emojData" :key="index">
        <view class="emoji-box" :style="'width: ' + emojiWidth + widthUnit">
          <view :style="'width:' + singleEmojiWidth + widthUnit + ';display: flex;flex-direction: row;align-items:center;justify-content: center'" v-for="(item, i) in items" :key="i" hover-class="active-bg" hover-stay-time="100" @click="tuchEmoj(item)">
            <text style="margin-bottom: 10rpx; font-size: 56rpx">{{ item }}</text>
          </view>
        </view>
      </swiper-item>
    </swiper>
  </view>
</template>

<script>
export default {
  props: {
    // 以下参数主要是为了兼容nvue页面，正常vue页面直接宽度100%就好，默认100%
    // 表情盒子宽度
    emojiWidth: {
      type: Number,
      default: 100
    },
    // 表情盒子宽度单位
    widthUnit: {
      type: String,
      default: '%'
    }
  },
  data() {
    return {
      emojData: [
        ['😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '😉', '😌', '😍', '🥰', '😘', '😗', '😚', '😋', '😛', '😝', '😜', '🤪', '🧐', '😮', '😲', '😦', '😑', '😶', '🤥', '🤗', '😴', '🤓'],
        ['😎', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '👍', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '🤑', '😥', '😓', '😻'],
        ['🥴', '😵', '😪', '👏', '🤝', '👍', '👎', '✊', '👊', '🙏', '🦶', '🦵', '💄', '👽', '👊', '👻', '💩', '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🚗', '🚲', '🚆', '🚦', '🚀', '🛸', '⛽', '🚤', '🏠']
      ],
      swiperIndex: 0, // 初始 swiper 索引
      selectedEmoji: null // 用于保存用户选择的表情
    }
  },
  created() {
    if (this.widthUnit != '%') {
      this.singleEmojiWidth = Math.floor(this.emojiWidth / 8)
    } else {
      this.singleEmojiWidth = Math.floor((this.emojiWidth / 8) * 100) / 100
    }
  },
  methods: {
    tuchEmoj(item) {
      this.selectedEmoji = item
      this.$emit('swiperChange', item)
    },
    swiperChange(e) {
      this.swiperIndex = e.detail.current
    }
  }
}
</script>

<style scoped lang="scss">
.custom-emoji-wrap {
  height: 410rpx;
  padding: 20rpx 0;

  .emoji-box {
    width: 100%;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    // display: grid;
    // grid-template-columns: repeat(8, 12.5%);
    // row-gap: 4rpx;
  }
  .active-bg {
    background-color: #e8e8e8 !important;
  }
}
</style>
