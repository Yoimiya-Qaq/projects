<template>
  <!-- 下载app弹窗 -->
  <view class="download-box" v-if="downloadShow">
    <u-overlay :show="downloadShow">
      <image :src="baseImgUrl + '/guanbiblack.png'" mode="" class="guanbi-img" @click="closeDownload"></image>
      <image :src="baseImgUrl + '/xiazaiapp.png'" mode="" class="download-img"></image>
      <!-- #ifndef H5 -->
      <div class="save-box">
        <image :src="baseImgUrl + '/xiazaipic.png'" mode="aspectFill" class="save-img"></image>
        <text class="text" @click="saveImg">保存图片</text>
      </div>
      <!-- #endif -->
    </u-overlay>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
  </view>
</template>

<script>
export default {
  name: 'download-popup',
  props: {
    // 是否展示弹框
    downloadShow: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      baseImgUrl: 'https://img.yiqitogether.com/yyq-wx',
      internalDownloadShow: this.downloadShow, // 初始化内部数据属性
      showLoading: false
    }
  },
  onMounted() {
    console.log(this.downloadShow)
  },
  methods: {
    saveImg() {
      const fileUrl = 'https://img.yiqitogether.com/yyq-wx/xiazaiapp.png'
      this.showLoading = true
      let that = this
      uni.getImageInfo({
        src: fileUrl,
        success: function (image) {
          uni.saveImageToPhotosAlbum({
            filePath: image.path,
            success: () => {
              console.log(this.showLoading, 'this.showLoading')
              uni.showToast({
                title: '保存到相册成功',
                icon: 'none'
              })
              that.closeDownload()
            },
            fail: err => {
              uni.showToast({
                title: '保存到相册失败',
                icon: 'none'
              })
              console.log(err, 'err')
            }
          })
          that.showLoading = false
        }
      })
    },
    closeDownload() {
      this.$emit('update:downloadShow', !this.downloadShow) // 触发自定义事件
    }
  }
}
</script>

<style lang="scss" scoped>
.download-box {
  top: 0;
  width: 100%;
  height: 100vh;
  z-index: 999;
  /deep/.u-transition {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .guanbi-img {
    width: 52rpx;
    height: 52rpx;
    position: absolute;
    right: 36rpx;
    top: 200rpx;
  }
  .download-img {
    width: 598rpx;
    height: 986rpx;
    // 小程序监听不到深度选择器 选择用margin: auto;
    margin: auto;
  }
  .save-box {
    width: 296rpx;
    height: 88rpx;
    opacity: 0.5;
    background: #000000;
    border-radius: 44rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    bottom: 50rpx;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 999;
    .save-img {
      width: 36rpx;
      height: 36rpx;
    }
    .text {
      font-size: 32rpx;
      margin-left: 8rpx;
      color: #ffffff;
    }
  }
}
</style>
