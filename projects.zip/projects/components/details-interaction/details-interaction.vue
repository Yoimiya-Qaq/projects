<template>
  <!-- @touchend="handleTouchEnd" -->
  <view class="">
    <u-popup key="interaction" mode="bottom" closeOnClickOverlay :show="show" @close="close" :round="20">
      <!-- @touchmove.stop.prevent="handleTouchMove" -->
      <view class="popup_box">
        <view class="interaction_t flex1">
          互动
          <image class="interaction_t_close" src="@/static/images/details_completed_close.png" mode="" @click="close"></image>
        </view>
        <block v-if="commentList.length > 0">
          <scroll-view class="interaction_w" scroll-y="true" :class="emojiShow ? 'interaction_emoji_show' : ''" @scrolltolower="scrollToLower">
            <block v-for="(item, i) in commentList" :key="i">
              <!-- 一级评论 -->
              <view class="user_box" @click="replyUser(item, i, 2)">
                <zero-lazy-load class="user_box_l" borderRadius="36" :image="item.userinfo.headUrl" :height="72" imgMode="aspectFill" @click="nextPage(`/pagesMy/my/myHomePages/index?userId=${item.userinfo.numberId}`)"></zero-lazy-load>
                <!-- @longpress.stop="longPressList(item,i,1)" -->
                <view class="user_box_r" @touchstart="touchStart" @touchend="touchEnd($event, item, i, 1)">
                  <view class="user_name flex1" @click="nextPage(`/pagesMy/my/myHomePages/index?userId=${item.userinfo.numberId}`)">
                    {{ item.userinfo.nickName }}
                    <block v-if="item.userinfo.numberId == activityDetails.userId"><text>作者</text></block>
                    <text v-if="item.topOrder == 1" class="top_icon">置顶</text>
                  </view>
                  <!-- <view class="user_comment">{{ item.content }}</view> -->
                  <view class="user_comment">
                    <block v-for="(obj, k) in item.content" :key="k">
                      <text v-if="obj.type == 'text'">{{ obj.text }}</text>
                      <text v-if="obj.type == 'name'" style="color: #fe5e10" @click="nextPage(`/pagesMy/my/myHomePages/index?userId=${obj.id}`)">{{ obj.text }}{{ ` ` }}</text>
                    </block>
                  </view>
                  <view class="user_address">{{ $u.timeFormat(item.createTime, 'sendMsgFormat') }} {{ item.city }}</view>
                  <!-- <view class="user_address">{{ item.createTime.slice(5, 10) }} {{ item.city }}</view> -->
                  <view class="launch_comment" v-if="Number(item.commentCount) > 0 && item.isShow !== 'true'" @click.stop="launchComment(item, i)">
                    展开{{ item.commentCount }}条回复
                    <image src="@/static/images/details_launch.png" mode=""></image>
                  </view>
                </view>
              </view>
              <!--二,三级评论 -->
              <view class="user_box2" v-if="item.isShow == 'true'">
                <view class="user_box" v-for="(itemTwo, j) in item.twoList" :key="j" @click="replyUser(itemTwo, i, 3)">
                  <zero-lazy-load class="user_box_l" borderRadius="36" :image="itemTwo.userinfo.headUrl" :height="72" imgMode="aspectFill" @click="nextPage(`/pagesMy/my/myHomePages/index?userId=${itemTwo.userinfo.numberId}`)"></zero-lazy-load>
                  <!-- @longpress.stop="longPressList(itemTwo,i,2,j)" -->
                  <view class="user_box_r" @touchstart="touchStart" @touchend="touchEnd($event, itemTwo, i, 2, j)">
                    <view class="user_name flex1" @click="nextPage(`/pagesMy/my/myHomePages/index?userId=${itemTwo.userinfo.numberId}`)">
                      <block v-if="itemTwo.targetUserNickName == null">
                        {{ itemTwo.userinfo.nickName }}
                        <block v-if="itemTwo.userinfo.numberId == activityDetails.userId"><text>作者</text></block>
                      </block>
                      <block v-else>
                        {{ itemTwo.userinfo.nickName }}
                        <block v-if="itemTwo.userinfo.numberId == activityDetails.userId"><text>作者</text></block>
                        <view class="triangle"></view>
                        {{ itemTwo.targetUserNickName }}
                        <block v-if="itemTwo.targetUserNickName == activityDetails.userName"><text>作者</text></block>
                      </block>
                    </view>
                    <view class="user_comment">
                      <block v-for="(objTwo, indexTwo) in itemTwo.content" :key="indexTwo">
                        <text v-if="objTwo.type == 'text'">{{ objTwo.text }}</text>
                        <text v-if="objTwo.type == 'name'" style="color: #fe5e10" @click.stop="nextPage(`/pagesMy/my/myHomePages/index?userId=${objTwo.id}`)">{{ objTwo.text }}{{ ` ` }}</text>
                      </block>
                    </view>
                    <view class="user_address">{{ itemTwo.createTime.slice(5, 10) }} {{ itemTwo.city }}</view>
                  </view>
                </view>
                <view class="flex1 bottom_more">
                  <view class="launch_comment comment_bottom" v-if="item.twoData && !item.twoData.lastPage" @click="expandMore(item, i)">
                    展开更多
                    <image src="@/static/images/details_launch.png" mode=""></image>
                  </view>
                  <view class="launch_comment comment_bottom" v-if="item.twoList.length !== 0" @click="packUpComment(item, i)">
                    收起
                    <image class="rotate_180" src="@/static/images/details_launch.png" mode=""></image>
                  </view>
                </view>
              </view>
            </block>
          </scroll-view>
        </block>
        <block v-if="commentList.length == 0">
          <view class="user_none flex1">
            <zero-lazy-load class="user_none_img" image="http://img.yiqitogether.com/yqyq-app/images/details_user_none.png" height="202" imgMode="aspectFill"></zero-lazy-load>
            暂无内容
          </view>
        </block>
        <!-- 遮罩层 -->
        <!-- <view class="popup_box_mask" @click="closeMask" v-if="isMask"></view> -->
        <view class="bottom_box">
          <view class="flex1">
            <view class="input_box flex1">
              <view style="position: relative; flex: 1">
                <!--富文本编辑器-->
                <editor ref="editor" id="editor" @ready="onEditorReady" @input="handleInput" class="textarea_box" @blur="handleBlur" @focus="handleFocus" :placeholder="placeholderText"></editor>
                <!--用于生成@图片 用css隐藏即可   这里的高度设置成富文本内的行高-->
                <canvas canvas-id="at-canvas" :style="{ height: `${cHeight}px` }" class="canvas_box"></canvas>
                <!-- <textarea
							      v-model="inputText"
							      type="text"
							      class="textarea_box"
							      :placeholder="placeholderText"
							      placeholder-style="color:#C8C8C8;font-size:24rpx;"
								  confirm-type="send"
								  maxlength="200"
							      :focus="focusState"
							      @blur="focusState = false"
							      :hold-keyboard="holdKeyboard"
							      @touchend="handleNoHideKeyboard"
							      @input="inputEvent"
								  @confirm="sendMsg"
							    ></textarea> -->
                <!-- <view class="textarea_show" v-html="inputText2"></view> -->
              </view>
              <!-- 表情和@ -->
              <view class="input_box_r flex1">
                <image src="@/static/images/details_emoji.png" mode="" @click="showEmojiBox"></image>
                <image src="@/static/images/details_at.png" mode="" @click="addAt"></image>
              </view>
              <!-- 艾特好友列表 -->
              <view class="friend_List" v-if="showFriend">
                <scroll-view scroll-x="true" @scrolltolower="scrollToRight">
                  <view class="friend_box flex1">
                    <view class="friend_item flex1" v-for="(item, i) in atentionList" :key="i" @click="selectUser(item)">
                      <zero-lazy-load class="friend_img" borderRadius="44" :image="item.userinfo.headUrl" :height="88" imgMode="aspectFill"></zero-lazy-load>
                      <text class="u-line-1">{{ item.userinfo.nickName }}</text>
                    </view>
                  </view>
                </scroll-view>
              </view>
            </view>
            <!-- 发送 -->
            <view class="send_box" @click="sendMsg">发送</view>
          </view>
          <!-- 表情 -->
          <view class="emoji-container" v-if="emojiShow">
            <emoji @swiperChange="changedEmoji"></emoji>
          </view>
        </view>
      </view>
    </u-popup>
    <!-- 长按列表 -->
    <!-- #ifdef H5 -->
    <u-popup key="longpress" class="longpress-popup" mode="bottom" :mask-click="true" :show="showLongList" :round="20">
      <view class="option_box">
        <view class="option_list">
          <view class="option_item" v-for="(item, i) in optionList" :key="i" @click="clickOption(item.text)">
            {{ item.text }}
          </view>
        </view>
        <view class="option_line"></view>
        <view class="option_item" @click="closeMask">取消</view>
      </view>
    </u-popup>
    <!-- #endif -->
    <!-- #ifndef H5 -->
    <u-popup key="longpress" class="longpress-popup" mode="bottom" :mask-click="true" :show="showLongList" :round="20" @close="closeMask">
      <view class="option_box">
        <view class="option_list">
          <view class="option_item" v-for="(item, i) in optionList" :key="i" @click="clickOption(item.text)">
            {{ item.text }}
          </view>
        </view>
        <view class="option_line"></view>
        <view class="option_item" @click="closeMask">取消</view>
      </view>
    </u-popup>
    <!-- #endif -->
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import MyInfo from '@/model/my'
import IndexModel from '@/model/index.js'
import { save, load } from '@/utils/store.js'
import { LOGIN_USERID, POSITION } from '../../utils/cacheKey'
// import { forEach } from 'lodash'
let tm = null
export default {
  name: 'details-interaction',
  props: [
    'show',
    // 作者id
    'activityDetails',
    // 消息id
    'businessNo'
  ],
  data() {
    return {
      // 互动列表
      commentList: [],
      // 二级评论分页查询关键词
      lastKeyWord: '',
      // 绑定输入
      inputText: '',
      // 输入框默认输入
      placeholderText: '留下你想了解的内容吧~',
      // 当前选择一级评论的id(父评论id)
      commentId: 0,
      // 当前选择一级评论的index
      commentIndex: 0,
      // 当前选择二级评论的index
      commentTwoIndex: 0,
      // 当前选择评论内容
      commentContent: [],
      // 定时器
      timer: 0,
      // 获取焦点状态
      focusState: false,
      // focus时，点击页面的时候不收起键盘
      holdKeyboard: false,
      // 是否在键盘弹出，点击界面时关闭键盘
      holdKeyboardFlag: true,
      // @好友列表显示
      showFriend: false,
      // 关注好友的列表
      atentionList: [],
      // 评论级别
      commentLevel: 1,
      // 是否显示emoji
      emojiShow: false,
      // 选中的 @ 好友id列表
      selectUserId: [],
      // 选中的 @ 好友昵称列表
      selectNickName: [],
      // inputText2: '',
      //富文本context对象
      editorCtx: null,
      //@插入位置下标
      cursorIndex: '',
      //CanvasContext对象
      canvasCtx: null,
      //初始化需要带上p标签，如果为空的话后面比对会有bug
      message: '<p></p>',
      //canvas高度
      cHeight: 16,
      showLongList: false,
      // 长按列表内容
      optionList: [],
      // 滑动开始的y坐标
      clientY: 0,
      // 滑动开始时间
      addStartTime: 0,
      // 滑动结束时间
      addEndTime: 0,
      // 遮罩层
      isMask: false,
      // 当前置顶评论数
      topNumber: 0,
      // 从互动消息列表过来的一级列表评论id
      messageCommentId: '',
      // 一级评论数据
      oneComment: {},
      // 二级分页查询关键词
      twoLastKeyWord: '',
      // 关注列表数据
      atentionData: {}
    }
  },
  destroyed() {
    // clearTimeout(tm)
    // tm = null
    this.clearEditorContent()
    uni.offKeyboardHeightChange(this.onKeyboardHeightChange)
  },
  created() {
    //页面加载完获取CanvasContext对象
    this.canvasCtx = uni.createCanvasContext('at-canvas')
    uni.onKeyboardHeightChange(this.onKeyboardHeightChange)
  },
  methods: {
    onKeyboardHeightChange(res) {
      const { height, duration } = res
      // 键盘弹起
      if (height > 0) {
        // console.log('键盘弹起');
        this.isMask = true
      }
      // 键盘收回
      else {
        // console.log('键盘收回');
        this.isMask = false
      }
    },
    /**
     * 触摸移动限制
     */
    // handleTouchMove(e) {
    //   e.stopPropagation()
    // },
    /**
     * 触动屏幕开始
     */
    touchStart(e) {
      this.clientY = e.changedTouches[0].clientY
      this.addStartTime = new Date().getTime()
      // console.log('开始');
    },
    /**
     * 触动屏幕结束
     */
    touchEnd(e, userItem, oneIndex, level, twoIndex) {
      // console.log('结束');
      this.addEndTime = new Date().getTime()
      const subY = e.changedTouches[0].clientY - this.clientY
      let sub = parseInt(subY)
      if (sub < 10 && sub > -10) {
        if (this.addEndTime - this.addStartTime < 200) {
          // console.log('小于200')
          return
        }
        this.longPressList(userItem, oneIndex, level, twoIndex)
        // console.log('滑动太小')
      } else {
        // console.log('只是滑动而已')
      }
    },
    /**
     * 长按弹出列表
     */
    longPressList(userItem, oneIndex, level, twoIndex) {
      let type = 0
      let optionArr = []
      if (this.activityDetails.userId == load(LOGIN_USERID)) {
        type = 1
      } else if (userItem.userinfo.numberId == load(LOGIN_USERID)) {
        type = 2
      } else {
        type = 3
      }
      // return
      switch (type) {
        // 发起人  置顶、复制、删除、举报
        case 1:
          optionArr = [
            {
              text: userItem.topOrder == 1 ? '取消置顶' : '置顶'
            },
            {
              text: '复制'
            },
            {
              text: '删除'
            }
          ]
          // 二级不支持置顶
          if (level == 2) {
            optionArr.splice(0, 1)
          }
          break
        // 参与人 自己评论 -复制、删除
        case 2:
          optionArr = [
            {
              text: '复制'
            },
            {
              text: '删除'
            }
          ]
          break
        // 游客 -复制、举报
        case 3:
          optionArr = [
            {
              text: '复制'
            },
            {
              text: '举报'
            }
          ]
          break
        default:
          return
      }
      // 评论id
      this.commentId = userItem.commentId
      // 一级索引
      this.commentIndex = oneIndex
      // 二级索引
      this.commentTwoIndex = twoIndex
      // 当前选中的评论信息
      this.commentUserData = userItem
      // 当前选中的等级
      this.commentLevel = level
      // 选项列表
      this.optionList = optionArr
      // 表情弹窗
      this.emojiShow = false
      // 好友弹窗
      this.showFriend = false
      // 选项弹窗
      this.showLongList = true
      // 遮罩层
      this.isMask = true
    },
    /**
     * 关闭遮罩层 && 关闭 长按列表
     */
    closeMask() {
      this.isMask = false
      this.showLongList = false
      this.emojiShow = false
      this.showFriend = false
    },
    /**
     * 点击长按列表
     */
    clickOption(type) {
      let that = this
      switch (type) {
        case '置顶':
          this.topComment()
          break
        case '取消置顶':
          this.unCommentTop()
          break
        case '复制':
          let commentArr = that.commentUserData.content
          let contentStr = ''
          commentArr.forEach(item => {
            contentStr += item.text
          })
          if (contentStr.endsWith('\n')) {
            contentStr = contentStr.replace('\n', '')
          }
          uni.setClipboardData({
            data: String(contentStr).trim(),
            showToast: false,
            success: function () {
              // console.log(contentStr,'contentStr----');
              that.myShowToast('已复制', 1000)
              that.showLongList = false
              that.isMask = false
            }
          })
          break
        case '删除':
          this.deleteComment()
          break
        case '举报':
          let userId = that.commentUserData.userinfo.numberId
          that.showLongList = false
          that.isMask = false
          that.nextPage(`/pagesCommon/message/report?userId=${userId}`)
          break
        default:
          return
      }
    },
    /**
     * 取消评论置顶
     */
    unCommentTop() {
      let datas = {
        commentId: this.commentId
      }
      IndexModel.unCommentTop(datas).then(res => {
        if (res.success) {
          this.commentList = []
          this.oneComment = {}
          this.getCommentListOne()
          this.$nextTick(() => {
            this.myShowToast('已取消置顶')
            this.showLongList = false
            this.isMask = false
            this.topNumber--
          })
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * 置顶评论处理
     */
    topComment() {
      let datas = {
        commentId: this.commentId
      }
      IndexModel.topComment(datas).then(res => {
        // console.log(res);
        if (res.success) {
          let isOneComment = this.commentList[this.commentIndex]
          this.commentList.splice(this.commentIndex, 1)
          this.$nextTick(() => {
            this.commentList.unshift(isOneComment)
            this.commentList[0].topOrder = 1
            this.topNumber++
          })
          this.myShowToast('置顶成功')
          this.showLongList = false
          this.isMask = false
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * 删除评论处理
     */
    deleteComment() {
      let datas = {
        commentId: this.commentId
      }
      IndexModel.uncomment(datas).then(res => {
        console.log(res)
        if (res.code == 'SUCCESS') {
          this.myShowToast('删除成功')
          this.showLongList = false
          this.isMask = false
          // console.log('1222222156');
          if (this.commentLevel == 1) {
            this.commentList.splice(this.commentIndex, 1)
            if (this.commentList[this.commentIndex].topOrder == 1) {
              this.topNumber--
            }
          } else {
            let isCommentList = this.commentList[this.commentIndex]
            isCommentList.twoList.splice(this.commentTwoIndex, 1)
            isCommentList.commentCount = Number(isCommentList.commentCount) - 1
          }
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * 富文本编辑器初始化完成
     */
    onEditorReady() {
      uni
        .createSelectorQuery()
        .select('#editor')
        .context(res => {
          this.editorCtx = res.context
        })
        .exec()
    },
    /**
     * 富文本input事件
     */
    handleInput({ detail }) {
      let str = detail.html || ''
      //旧字符串数组
      const oldArr = this.message.split('')
      //新字符串数组
      const newArr = str.split('')
      //找出当前输入的内容
      //如果this.message初始值为空
      //第一次输入@时oldArr将会是空数组，而str为<p>@</p>
      //最终contentStr的值为<p>@</p>，不会进入下一个判断
      let contentStr = str
      oldArr.forEach(str => {
        contentStr = contentStr.replace(str, '')
      })
      // 输入是@时
      if (contentStr === '@') {
        //打开@选择用户弹窗
        // 请求好友列表数据 搜索处理是否显示
        this.attentionList()
        // 比对算法,找出当前光标的位置,找到当前输入的位置
        newArr.some((now, index) => {
          if (str.substring(0, index) !== this.message.substring(0, index)) {
            this.cursorIndex = index
            return true
          }
        })
      } else {
        this.showFriend = false
      }
      this.message = str
    },
    /**
     * 编辑器聚焦时触发
     */
    handleFocus() {
      this.showFriend = false
      this.isMask = true
    },
    /**
     * 编辑器失去焦点时触发
     */
    handleBlur(e) {
      let str = e.detail.html
      tm = setTimeout(() => {
        this.emojiShow = false
        this.showFriend = false
        this.placeholderText = '留下你想了解的内容吧~'
        if (str.endsWith('<p><br></p>')) {
          str = str.replace('<p><br></p>', '')
        }
        // 评论框为空 或者被清空
        if (str == '<p></p>') {
          this.commentLevel = 1
        }
        this.message = str
      }, 200)
    },
    /**
     * @选择用户,item为选择的用户数据
     */
    async selectUser(item) {
      let html = this.message
      let flag = await this.selectUserDeduplicate(item)
      if (flag) {
        // console.log(html,'输入框内容');
        //生成图片，返回图片路径
        let res = await this.createATImg(item.userinfo.nickName)
        let img = `<img src="${res.src}" width="${res.width}px" height="${res.height}px" data-custom="id=${item.userinfo.numberId};name=${item.userinfo.nickName}">`
        //把图片替换掉@字符
        // console.log(this.cursorIndex, '字符位置')
        html = html.substr(0, this.cursorIndex - 1) + img + html.substr(this.cursorIndex, html.length)
        // //塞进富文本内
        this.editorCtx.setContents({
          html: html
        })
        // //更新message内容
        this.editorCtx.getContents({
          success: ({ html }) => {
            this.message = html
          }
        })
        this.showFriend = false
      }
    },
    /**
     * 创建@用户文本的图片
     */
    createATImg(name) {
      // console.log(name)
      let that = this
      return new Promise(resolve => {
        // console.log(that.canvasCtx)
        // 设置文字颜色
        that.canvasCtx.fillStyle = '#FE5E10'
        //设置字体大小
        that.canvasCtx.setFontSize(16)
        //设置文本水平居中
        that.canvasCtx.setTextAlign('center')
        //设置文本垂直居中
        that.canvasCtx.setTextBaseline('middle')
        //获取at文本宽度
        let at = that.canvasCtx.measureText(`@${name}`)
        //填充文本
        that.canvasCtx.fillText(`@${name}`, at.width / 2, that.cHeight / 2)
        that.canvasCtx.draw(false, () => {
          //canvas转图片
          uni.canvasToTempFilePath({
            x: 0,
            y: 0,
            width: at.width,
            canvasId: 'at-canvas',
            quality: 1,
            success: async res => {
              //返回图片链接 图片显示宽度，高度
              resolve({
                src: res.tempFilePath,
                width: at.width,
                height: that.cHeight
              })
            },
            fail: err => {
              console.log(err)
            }
          })
        })
      })
    },
    /**
     * 发送
     */
    getMsg() {
      return new Promise((resolve, reject) => {
        this.editorCtx.getContents({
          success: res => {
            // console.log('结果执行');
            let arr = []
            let userList = []
            let content = ''
            //res.delta.ops是返回的节点信息
            for (let op of res.delta.ops) {
              if (op.attributes) {
                let nameObj = {
                  type: 'name'
                }
                for (let a of op.attributes['data-custom'].split(';')) {
                  let list = a.split('=')
                  // if (list[0] === 'id') userList.push(list[1])
                  // if (list[0] === 'name') content += '@' + list[1]
                  if (list[0] === 'id') {
                    nameObj.id = list[1]
                    userList.push(list[1])
                  }
                  if (list[0] === 'name') {
                    nameObj.text = '@' + list[1]
                    content += '@' + list[1]
                  }
                }
                arr.push(nameObj)
              } else {
                let textObj = {
                  type: 'text',
                  text: op.insert
                }
                arr.push(textObj)
                content += op.insert
              }
            }
            // console.log(arr);
            resolve({
              userList,
              content,
              arr
            })
          }
        })
      })
    },
    /**
     * 发送消息
     */
    async sendMsg() {
      let inputData = await this.getMsg()
      let numberStr = inputData.userList.join(',')
      let inputText = JSON.stringify(inputData.arr)
      // return
      let datas = {
        content: inputText,
        position: load(POSITION) || '{"lat":31.23,"lon":121.38}',
        commentType: 'APPOINTMENT',
        taNumberIds: numberStr
      }
      if (inputData.arr[0].text !== '\n') {
        if (this.commentLevel == 1) {
          this.createOne(datas)
        } else if (this.commentLevel == 2) {
          this.createTwo(datas)
        } else if (this.commentLevel == 3) {
          // 是否回复
          datas.reply = true
          // @他的NumberID，用逗号隔开
          // datas.taNumberIds =
          this.createTwo(datas)
        }
        setTimeout(() => {
          this.isMask = false
          this.emojiShow = false
        }, 150)
      } else {
        this.myShowToast('发送内容不能为空')
      }
    },
    /**
     * 获取互动消息列表 跳转过来的置顶信息
     */
    async getMessageListTop() {
      let datas = {
        businessNo: this.businessNo
      }
      IndexModel.listTopOne(datas).then(res => {
        // console.log(res.data)
        if (res.code == 'SUCCESS') {
          let oneObj = res.data.twitterCommentDTO
          if (oneObj !== '') {
            let twoArr = []
            let falgOne = this.isJsonString(String(oneObj.content))
            if (falgOne) {
              oneObj.content = JSON.parse(oneObj.content)
            } else {
              oneObj.content = [{ type: 'text', text: oneObj.content }]
            }
            // 互动过来的评论id
            this.messageCommentId = oneObj.commentId
            this.commentList.push(oneObj)
            res.data.listChild.list.forEach((obj, index) => {
              let falg = this.isJsonString(String(obj.content))
              if (falg) {
                obj.content = JSON.parse(obj.content)
              } else {
                obj.content = [{ type: 'text', text: obj.content }]
              }
              twoArr.push(obj)
            })
            this.commentList[0].twoData = res.data.listChild
            // 没有twoList 非更多
            if (!this.commentList[0].twoList || !item.more) {
              this.commentList[0].twoList = twoArr
              // console.log(twoArr)
            } else {
              this.commentList[0].twoList.push(...twoArr)
            }
            this.commentList[0].isShow = 'true'
          }

          console.log('00')
          this.getCommentListOne()
          // console.log(this.commentList)
          // this.$forceUpdate()
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * 滚动到底部触发分页
     */
    scrollToLower() {
      if (!this.oneComment.lastPage) {
        this.getCommentListOne()
      }
    },
    /**
     * 滚动到右边触发分页
     */
    scrollToRight() {
      if (!this.atentionData.lastPage) {
        this.attentionList()
      }
    },
    /**
     * 获取互动列表数据 一级
     */
    getCommentListOne() {
      let datas = {
        twitterId: this.activityDetails.appointmentNo,
        lastKeyWord: this.oneComment.lastKeyWord || '',
        // pageNo: this.oneComment.pageNumber + 1 || 1,
        commentType: 'APPOINTMENT'
      }
      IndexModel.commentListOne(datas).then(async res => {
        // console.log(res.data.commentList,"一级列表");
        if (res.code == 'SUCCESS') {
          let arr = []
          this.oneComment = res.data.commentList
          res.data.commentList.list.forEach((obj, index) => {
            let falg = this.isJsonString(String(obj.content))
            if (falg) {
              obj.content = JSON.parse(obj.content)
            } else {
              obj.content = [{ type: 'text', text: obj.content }]
            }
            arr.push(obj)
          })
          this.commentList.push(...arr)
          this.topNumber = 0
          this.$nextTick(() => {
            this.commentList.forEach((item, i) => {
              if (item.topOrder == 1) {
                this.topNumber++
              } else if (this.messageCommentId == item.commentId && i !== 0) {
                // 不是第一条且评论id相等
                this.commentList.splice(i, 1)
              }
            })
          })
        } else {
          this.myShowToast(res.message)
        }
        this.$forceUpdate()
        // console.log(this.commentList)
      })
    },
    /**
     * 判断是否是json字符串
     */
    isJsonString(str) {
      if (typeof str === 'string') {
        try {
          const result = JSON.parse(str)
          const type = Object.prototype.toString.call(result)

          // 验证result是Object或者Array（这两种类型都是JSON合法的解析结果）
          return type === '[object Object]' || type === '[object Array]'
        } catch (e) {
          return false
        }
      } else {
        return false
      }
    },
    /**
     * 展开查看二级评论
     */
    launchComment(item, i) {
      this.commentList[i].more = false
      this.commentList[i].isShow = 'true'
      this.lastKeyWord = ''
      this.getCommentListTwo(item, i)
    },
    /**
     * 收起所有评论
     */
    packUpComment(item, i) {
      this.commentList[i].isShow = 'false'
      this.$forceUpdate()
    },
    /**
     * 展开更多
     */
    expandMore(item, i) {
      this.commentList[i].more = true
      this.twoLastKeyWord = item.twoData.lastKeyWord
      this.getCommentListTwo(item, i)
    },
    /**
     * 获取互动列表数据 二级
     */
    getCommentListTwo(item, i) {
      let datas = {
        commentId: item.commentId,
        lastKeyWord: this.twoLastKeyWord || '',
        commentType: 'APPOINTMENT'
      }
      IndexModel.commentListTwo(datas).then(async res => {
        // console.log(res.data.commentList,"二级列表");
        if (res.code == 'SUCCESS') {
          let arr = []
          res.data.commentList.list.forEach((obj, index) => {
            let falg = this.isJsonString(String(obj.content))
            if (falg) {
              obj.content = JSON.parse(obj.content)
            } else {
              obj.content = [{ type: 'text', text: obj.content }]
            }
            arr.push(obj)
          })

          this.commentList[i].twoData = res.data.commentList
          // 没有twoList 非更多
          if (!this.commentList[i].twoList || !item.more) {
            this.commentList[i].twoList = arr
            // console.log(arr)
          } else {
            this.commentList[i].twoList.push(...arr)
          }
          // console.log(this.commentList)
          this.$forceUpdate()
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * input输入
     */
    inputEvent(e) {
      let text = e.detail.value.slice(-1)
      if (text == '@') {
        // 请求好友列表数据 搜索处理是否显示
        this.attentionList()
      } else {
        this.showFriend = false
      }
    },
    /**
     * 选择用户去重
     */
    async selectUserDeduplicate(item) {
      let inputData = await this.getMsg()
      let flag = false
      let numberIndex = inputData.userList.indexOf(String(item.userinfo.numberId))
      if (numberIndex == -1) {
        flag = true
      } else {
        this.myShowToast('用户已存在')
        flag = false
      }
      return flag
    },
    /**
     * 回复 一 二级评论
     */
    replyUser(item, i, level) {
      // 与上次回复得评论id对比不一致 清空输入框
      if (item.commentId !== this.commentId) {
        this.clearEditorContent()
      }
      this.placeholderText = `回复：${item.userinfo.nickName} `
      this.commentId = item.commentId
      this.focusState = true
      this.commentIndex = i
      this.commentLevel = level
      this.handleNoHideKeyboard()
    },
    /**
     * 互动 一级评论
     */
    createOne(datas) {
      datas.twitterId = this.activityDetails.appointmentNo
      IndexModel.createOne(datas).then(async res => {
        // console.log(res,"一级评论");
        if (res.success) {
          this.commentLevel = 1
          this.commentEcho(res.data.comment)
        }
        this.myShowToast(res.message)
      })
    },
    /**
     * 互动 二级评论
     */
    createTwo(datas) {
      // 父评论id
      datas.commentId = this.commentId
      // 有评论数 但没请求二级的
      if (!this.commentList[this.commentIndex].twoList) {
        this.launchComment(this.commentList[this.commentIndex], this.commentIndex)
      }
      IndexModel.createTwo(datas).then(async res => {
        // console.log(res,"二级评论");
        if (res.success) {
          let commentObj = res.data.comment
          this.commentEcho(commentObj)
        }
        this.myShowToast(res.message)
      })
    },
    /**
     *  评论成功 信息回显
     */
    commentEcho(data) {
      data.content = JSON.parse(data.content)
      switch (this.commentLevel) {
        // 一级评论
        case 1:
          let num = this.topNumber
          if (num == 0) {
            // 无置顶
            this.commentList.unshift(data)
          } else {
            this.commentList.splice(num, 0, data)
          }
          break
        // 二，三级评论
        default:
          // 没有评论数的
          let commentCount = this.commentList[this.commentIndex].commentCount
          if (Number(commentCount) == 0) {
            let arr = []
            arr.push(data)
            this.commentList[this.commentIndex].twoList = arr
          } else {
            // 有评论数 且请求二级的
            this.commentList[this.commentIndex].twoList.push(data)
          }
          // 展开
          this.commentList[this.commentIndex].isShow = 'true'
          commentCount = Number(commentCount) + 1
      }
      this.placeholderText = '留下你想了解的内容吧~'
      this.clearEditorContent()
      this.commentLevel = 1
      this.$forceUpdate()
    },
    /**
     * 清除editor输入框内容
     */
    clearEditorContent() {
      if (tm) {
        clearTimeout(tm)
      }
      if (this.editorCtx) {
        this.editorCtx.clear()
      }
      this.message = '<p></p>'
    },
    /**
     * 关注列表
     */
    attentionList() {
      let that = this
      let data = {
        pageNo: that.atentionData.pageNumber + 1 || 1
      }
      MyInfo.getAttentionList(data).then(res => {
        if (res.code == 'SUCCESS' && res.data) {
          that.atentionData = res.data.atentionList
          this.atentionList = [...this.atentionList, ...res.data.atentionList.list]
          if (this.atentionList.length == 0) {
            this.myShowToast('目前没有可@人员')
          } else {
            this.showFriend = true
          }
          // console.log(this.atentionList)
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    /**
     * 点击添加 @时，不收键盘
     */
    handleNoHideKeyboard() {
      this.holdKeyboardFlag = false
    },
    /**
     * 点击非弹键盘 收起键盘
     */
    handleTouchEnd() {
      clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        // 键盘弹出时点击界面则关闭键盘
        if (this.holdKeyboardFlag) {
          uni.hideKeyboard()
          this.commentLevel = 1
          this.placeholderText = '留下你想了解的内容吧~'
        }
        this.holdKeyboardFlag = true
      }, 50)
    },
    /**
     * 添加 @ 不收起键盘
     */
    addAt() {
      if (tm) {
        clearTimeout(tm)
        tm = null
      }
      this.emojiShow = false
      this.isMask = true
      if (!this.atentionData.lastPage) {
        this.attentionList()
      } else {
        this.showFriend = true
      }
      // this.changedEmoji('@')
      // this.message = this.message + '@'
      // // 请求好友列表数据 搜索处理是否显示
      // this.showFriend = true
      // this.handleNoHideKeyboard()
    },
    /**
     * 显示表情列表
     */
    showEmojiBox() {
      if (tm) {
        clearTimeout(tm)
        tm = null
      }
      this.emojiShow = true
      this.isMask = true
      this.showFriend = false
    },
    /**
     * 选中表情
     */
    changedEmoji(item) {
      let html = this.message
      html = html.substr(0, html.length - 4) + item + html.substr(html.length - 4, html.length)
      //塞进富文本内
      this.editorCtx.setContents({
        html: html
      })
      //更新message内容
      this.editorCtx.getContents({
        success: ({ html }) => {
          this.message = html
        }
      })
    },
    /**
     * 关闭弹窗
     */
    close() {
      this.$emit('close')
      this.commentList = []
      this.oneComment = []
      this.atentionData = {}
      this.atentionList = []
      this.placeholderText = '留下你想了解的内容吧~'
      this.clearEditorContent()
      this.commentLevel = 1
      this.showFriend = false
      this.emojiShow = false
      this.isMask = false
    },
    // 提示
    myShowToast(title, duration) {
      uni.showToast({
        title,
        duration: duration || 1500,
        icon: 'none'
      })
    },
    nextPage(url) {
      uni.navigateTo({
        url
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.popup_box {
  position: relative;
  width: 100%;
  height: 80vh;
  padding: 2vh 5% 11vh;
  box-sizing: border-box;
}

.popup_box_mask {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 80vh;
  border-radius: 20rpx 20rpx 0 0;
  background-color: rgba(0, 0, 0, 0.2);
  z-index: 2;
}

.interaction_t {
  font-size: 32rpx;
  color: #0c0c0c;
  justify-content: space-between;
}

.interaction_t_close {
  width: 32rpx;
  height: 32rpx;
}

.user_none {
  flex-direction: column;
  font-size: 24rpx;
  color: #f8c1ca;
}

.user_none_img {
  width: 256rpx;
  height: 202rpx;
  margin: 20vh auto 24rpx;
}

.interaction_w {
  /* width: 90%; */
  margin: 3vh auto 0;
  height: calc(80vh - 17vh - 32rpx);
  /* #ifdef APP */
  height: calc(80vh - 17vh - 42rpx);
  /* #endif */
}

.interaction_emoji_show {
  height: calc(80vh - 15vh - 32rpx - 446rpx);
}

.user_box {
  display: flex;
  margin-bottom: 30rpx;
  // background-color: pink;
}

.user_box2 {
  margin-left: 96rpx;
}

.user_box_l {
  width: 72rpx;
  height: 72rpx;
}

.user_box_r {
  flex: 1;
  // background-color: #FB5C4E;
  margin-left: 24rpx;
}

.user_name {
  font-size: 24rpx;
  color: #adadad;
  line-height: 34rpx;

  text {
    padding: 0 10rpx;
    font-size: 16rpx;
    background: #fff2f4;
    border-radius: 12rpx;
    color: #fb5c4e;
    margin-left: 12rpx;
  }
}

.top_icon {
  background: #f7f7f7 !important;
  color: #adadad !important;
}

.user_comment {
  font-size: 28rpx;
  color: #484848;
  line-height: 40rpx;
  margin-top: 8rpx;
  white-space: pre-line;
  word-wrap: break-word;
  word-break: break-all;
}

.user_address {
  font-size: 18rpx;
  color: #a6acb2;
  margin-top: 8rpx;
}

.user_box_2 {
  margin-left: 96rpx;
}

.bottom_box {
  position: fixed;
  bottom: 0;
  width: 100%;
  border-radius: 20rpx 20rpx 0 0;
  padding: 10rpx 5% 30rpx;
  box-sizing: border-box;
  left: 50%;
  transform: translateX(-50%);
  background-color: #fff;
  z-index: 3;
}

.input_box {
  // max-height: 144rpx;
  height: 72rpx;
  flex: 1;
  padding: 16rpx 26rpx 16rpx 36rpx;
  background: #f7f7f7;
  border-radius: 36rpx;
  margin-top: 8rpx;
  justify-content: space-between;
  color: #c8c8c8;
  // overflow: hidden;
}

.emoji-container {
  width: 100%;
}

.textarea_box {
  flex: 1;
  width: 100%;
  // margin-top: 28rpx;
  height: 80rpx;
  min-height: 80rpx !important;
  font-size: 28rpx;
  color: #2a343e;
  // background-color: pink;
  line-height: 42rpx;
  white-space: pre-line;
  word-wrap: break-word;
  word-break: break-all;
}

.canvas_box {
  position: absolute;
  top: 0;
  z-index: -1;
}

.textarea_show {
  width: 100%;
  height: 72rpx;
  line-height: 72rpx;
  font-size: 28rpx;
  color: #2a343e;
  // background-color: #ffff7f;
}

.input_box_r {
  image {
    width: 40rpx;
    height: 40rpx;
    margin-left: 26rpx;
  }
}

.friend_List {
  position: absolute;
  top: -180rpx;
  left: 0;
  width: 100vw;
  height: 192rpx;
  background-color: #ffffff;
  border-radius: 20rpx 20rpx 0 0;
  // overflow-x: auto;
  // padding-left: 5vw;
  // box-sizing: border-box;
  // background-color: #ffaa7f;
}

.friend_box {
  width: 100%;
  height: 192rpx;
  padding-left: 3%;
  box-sizing: border-box;
}

.friend_item {
  width: 120rpx;
  flex-direction: column;
  // font-weight: Bold;
  color: #2a343e;
  font-size: 20rpx;
  margin-right: 20rpx;
  flex-shrink: 0;
}

.friend_img {
  width: 88rpx;
  height: 88rpx;
  margin-bottom: 12rpx;
}

.input-content {
  outline: none;
  margin: 16px 0 15px;
  height: 9.2em;
  width: 100%;
  line-height: 1.2em;
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  font-size: 14px;
  padding: 0;
}

.launch_comment {
  font-size: 18rpx;
  color: #a6acb2;
  margin-top: 24rpx;
  image {
    width: 20rpx;
    height: 20rpx;
    margin-left: 10rpx !important;
  }
}

.comment_bottom {
  margin-top: 0;
  margin-bottom: 30rpx;
}

.bottom_more :first-child {
  margin-right: 34rpx;
}

.rotate_180 {
  transform: rotate(180deg);
  margin-bottom: -4rpx;
}

.triangle {
  width: 0;
  height: 0;
  border-top: 10rpx solid transparent;
  border-bottom: 10rpx solid transparent;
  border-left: 18rpx solid #d8d8d8;
  margin: 0 12rpx 4rpx;
}

.send_box {
  width: 112rpx;
  height: 72rpx;
  background: #fe5e10;
  border-radius: 44rpx;
  font-size: 28rpx;
  color: #ffffff;
  line-height: 72rpx;
  text-align: center;
  margin-left: 20rpx;
}

/deep/ .ql-editor p {
  text-align: justify;
  white-space: pre-wrap;
}

/deep/ .ql-editor p img {
  vertical-align: middle !important;
  max-width: 100%;
}

.option_box {
  width: 100vw;
  // height: 680rpx;
  background: #ffffff;
  border-radius: 20rpx 20rpx 0rpx 0rpx;
  box-shadow: 0 -10px 10px rgba(0, 0, 0, 0.1);
}

.option_list {
  padding: 30rpx 0;
}

.option_line {
  height: 12rpx;
  width: 100%;
  background-color: #f7f7f7;
}

.option_item {
  height: 104rpx;
  width: 100%;
  line-height: 104rpx;
  text-align: center;
  font-size: 32rpx;
  // font-weight: Bold;
  color: #2a343e;
}

/deep/.ql-editor.ql-blank:before {
  color: #c8c8c8;
  font-style: normal !important;
  font-family: OPPOSans-Medium !important; //PingFang-M
  // line-height: 72rpx;
}

.longpress-popup {
  /deep/.u-transition {
    z-index: 10080 !important;
  }
}
</style>
