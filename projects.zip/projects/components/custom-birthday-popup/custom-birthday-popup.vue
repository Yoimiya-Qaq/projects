<template>
  <u-popup class="custom-birthday-popup" :show="show" :duration="0" mode="bottom" :closeOnClickOverlay="true" @close="onClose" @touchmove.native.stop.prevent>
    <view class="popup-header">
      <image class="close-icon" src="http://img.yiqitogether.com/static/images/index/icon_birthday_close.png" mode="aspectFill" @click="onClose" />
    </view>
    <view @click="$u.throttle(goBirthday, 500)">
      <image class="cake-img" src="http://img.yiqitogether.com/static/images/index/birthday_cake.png" mode="aspectFill" />
      <view class="cake-btn">查看详情</view>
    </view>
  </u-popup>
</template>

<script>
export default {
  name: 'CustomBirthdayPopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onClose() {
      this.$emit('close')
    },
    goBirthday() {
      uni.navigateTo({ url: '/pagesCommon/message/birthdayMessage?sourcePage=index' })
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-birthday-popup {
  /deep/.u-popup__content {
    background-color: transparent;
    padding-bottom: 120rpx;
  }
  .popup-header {
    font-size: 0;
    text-align: right;

    .close-icon {
      width: 44rpx;
      height: 44rpx;
      padding: 24rpx 36rpx;
    }
  }
  .cake-img {
    width: 750rpx;
    height: 960rpx;
    display: block;
    margin: 0 auto;
  }
  .cake-btn {
    width: 288rpx;
    height: 76rpx;
    font-size: 32rpx;
    text-align: center;
    color: #ffffff;
    line-height: 76rpx;
    background-image: url(http://img.yiqitogether.com/static/images/index/birthday_cake_btn.png);
    background-size: cover;
    margin: -36rpx auto 0;
  }
}
</style>
