<template>
  <!-- 如果officialTarget不为空则展示，没有不展示 -->
  <view class="custom-tag-card">
    <view
      @click.stop="
        $u.throttle(() => {
          goJumpUrl(twitterInfo.quoteInfoDTO.quoteJumpUrl)
        })
      "
    >
      <view class="card-box" v-if="twitterInfo.quoteInfoDTO.officialTarget[0].label == 'GOOD_PHOTO' || twitterInfo.quoteInfoDTO.officialTarget[0].label == 'APPOINTMENT'">
        <!-- 颜值票选、关联活动 -->
        <image class="card-left" :src="twitterInfo.quoteInfoDTO.quoteHeadImg" mode="aspectFill" />
        <!-- 颜值票选 -->
        <view class="card-right" v-if="twitterInfo.quoteInfoDTO.officialTarget[0].label == 'GOOD_PHOTO'">
          <view class="title ellipsis-single">{{ twitterInfo.quoteInfoDTO.quoteTitle }}</view>
          <view class="subtitle">{{ twitterInfo.quoteInfoDTO.quoteContent }}</view>
        </view>
        <!-- 关联活动 -->
        <view class="card-right" v-if="twitterInfo.quoteInfoDTO.officialTarget[0].label == 'APPOINTMENT'">
          <view class="title ellipsis-single">{{ twitterInfo.quoteInfoDTO.quoteTitle }}</view>
          <view class="flex-box" style="margin-bottom: 6rpx">
            <image class="icon" src="@/static/images/shijian2.png" mode="aspectFill" />
            <view class="subtitle">{{ twitterInfo.quoteInfoDTO.quoteContent.appointDate ? $u.timeFormat(twitterInfo.quoteInfoDTO.quoteContent.appointDate, 'yyyy-mm-dd') : '' }}</view>
          </view>
          <view class="flex-box">
            <image class="icon" src="@/static/images/weizhi2.png" mode="aspectFill" />
            <view class="subtitle ellipsis-single">{{ twitterInfo.quoteInfoDTO.quoteContent.cityName ? twitterInfo.quoteInfoDTO.quoteContent.cityName + ' · ' : '' }}{{ twitterInfo.quoteInfoDTO.quoteContent.place || '' }}</view>
          </view>
        </view>
      </view>
      <!-- 转发动态 -->
      <view class="card-box" v-if="twitterInfo.quoteInfoDTO.officialTarget[0].label == 'TWITTER_FORWARD' || twitterInfo.quoteInfoDTO.officialTarget[0].label == 'NOTES_FORWARD_TWITTER'">
        <view class="dynamic-card">
          <view class="dynamic-content">
            <text class="em">{{ nickName ? '@' + nickName : twitterInfo.quoteInfoDTO.quoteTitle }}：</text>
            {{ twitterInfo.quoteInfoDTO.quoteContent.content }}
          </view>
          <view class="dynamic-file" v-if="twitterInfo.quoteInfoDTO.quoteHeadImg">
            <view class="dynamic-video-item">
              <image class="video-img" :src="twitterInfo.quoteInfoDTO.quoteContent.imageUrls" mode="aspectFill" />
              <image class="video-icon" src="@/static/images/findVideo.png" alt="" mode="aspectFill" />
            </view>
          </view>
          <view class="dynamic-file" v-if="!twitterInfo.quoteInfoDTO.quoteHeadImg && twitterInfo.quoteInfoDTO.quoteContent.imageUrls && twitterInfo.quoteInfoDTO.quoteContent.imageUrls.length">
            <block v-for="(item, index) in twitterInfo.quoteInfoDTO.quoteContent.imageUrls" :key="index">
              <view class="dynamic-photo-item" v-if="index < 3">
                <image class="photo-img" :src="item" mode="aspectFill" />
                <view v-if="index == 2 && twitterInfo.quoteInfoDTO.quoteContent.imageUrls.length > 3" class="photo-num">+{{ twitterInfo.quoteInfoDTO.quoteContent.imageUrls.length - 3 }}</view>
              </view>
            </block>
          </view>
          <view class="dynamic-tag em" v-if="twitterInfo.quoteInfoDTO.dynamicType">#{{ twitterInfo.quoteInfoDTO.dynamicType }}</view>
        </view>
      </view>

      <!-- 生日动态 -->
      <view class="birthday-card" v-if="twitterInfo.quoteInfoDTO.officialTarget[0].label == 'BIRTHDAY'">
        <view class="birthday-box" :style="{ 'background-image': `url(${twitterInfo.quoteInfoDTO.officialTarget[0].backgroundUrl || defaultBirthdayBg})` }">
          <view class="birthday-person">
            <image class="birthday-avatar" :src="twitterInfo.quoteInfoDTO.quoteHeadImg" mode="aspectFill" />
            <image class="birthday-hat" src="http://img.yiqitogether.com/static/images/messageGray/birthday_hat.png" mode="aspectFill" />
          </view>
          <image class="birthday-ribbon" src="http://img.yiqitogether.com/static/images/find_birthday_ribbon.png" mode="aspectFill" />
          <view class="birthday-desc">今天是我的生日{{ twitterInfo.quoteInfoDTO.quoteTitle }}</view>
          <view class="birthday-desc">送上祝福 ></view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    /**
     * 源数据
     */
    twitterInfo: {
      type: Object,
      default: () => {}
    },
    nickName: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      defaultBirthdayBg: 'http://img.yiqitogether.com/static/images/find_birthday_bg.png'
    }
  },
  methods: {
    // 跳转对应的链接
    goJumpUrl(url) {
      if (url == '/pages/my/webView') {
        // #ifdef H5
        uni.showToast({
          title: '该操作需要在APP内进行',
          icon: 'none'
        })
        return
        // #endif
        try {
          let paramsData = this.twitterInfo.quoteInfoDTO.quoteContent || {}
          let str = `/pages/my/webView?destination=${paramsData.type}`
          for (let key in paramsData) {
            if (key != 'type') {
              str += `&${key}=${paramsData[key]}`
            }
          }
          uni.navigateTo({ url: str })
        } catch (error) {}
      } else {
        uni.navigateTo({ url: url })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-tag-card {
  .flex-box {
    display: flex;
  }
  // 颜值票选、关联活动
  .card-box {
    display: flex;
    align-items: center;
    padding: 30rpx;
    background: #f8f9f9;
    border-radius: 20rpx;
    box-sizing: border-box;

    .card-left {
      flex-shrink: 0;
      width: 176rpx;
      height: 132rpx;
      border-radius: 20rpx;
    }

    .card-right {
      flex: 1;
      margin-left: 20rpx;

      .title {
        font-size: 32rpx;
        color: #333333;
        line-height: 44rpx;
        margin-bottom: 12rpx;
        font-weight: bold;
      }
      .subtitle {
        font-size: 24rpx;
        color: #333333;
        line-height: 34rpx;
      }

      .icon {
        width: 20rpx;
        height: 20rpx;
        flex-shrink: 0;
        margin-right: 10rpx;
        margin-top: 8rpx;
      }
    }
  }
  // 转发动态
  .dynamic-card {
    flex: 1;
    .em {
      display: inline-block;
      font-size: 28rpx;
      color: #fe5e10;
      line-height: 40rpx;
      color: #fe5e10;
    }
    .dynamic-content {
      font-size: 28rpx;
      color: #333333;
      line-height: 40rpx;
      display: -webkit-box;
      line-clamp: 2;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      word-break: break-all;
      text-overflow: ellipsis;
      overflow: hidden;
      line-break: anywhere;
      white-space: pre-wrap;
    }

    .dynamic-file {
      display: flex;
      align-items: center;
      margin-top: 16rpx;
      .dynamic-video-item {
        position: relative;
        font-size: 0;
        .video-img {
          width: 206rpx;
          height: 206rpx;
          border-radius: 8rpx;
        }
        .video-icon {
          width: 52rpx;
          height: 52rpx;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
      }
      .dynamic-photo-item {
        position: relative;
        margin-right: 6rpx;
        .photo-img {
          width: 206rpx;
          height: 206rpx;
          border-radius: 8rpx;
        }
        .photo-num {
          width: 206rpx;
          height: 206rpx;
          border-radius: 8rpx;
          background: rgba(0, 0, 0, 0.5);
          font-size: 28rpx;
          color: #ffffff;
          text-align: center;
          line-height: 206rpx;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
      .dynamic-photo-item:nth-child(3n) {
        margin-right: 0;
      }
    }
    .dynamic-tag {
      margin-top: 8rpx;
    }
  }
  // 生日动态
  .birthday-card {
    margin: 0 auto;

    .birthday-box {
      width: 678rpx;
      height: 404rpx;
      // background-image: url(http://img.yiqitogether.com/static/images/find_birthday_bg.png);
      background-size: cover;
      text-align: center;
      font-size: 0;
      .birthday-person {
        position: relative;
        padding-top: 104rpx;
        text-align: center;
        font-size: 0;
        .birthday-avatar {
          width: 144rpx;
          height: 144rpx;
          background: #d8d8d8;
          border-radius: 50%;
        }
        .birthday-hat {
          width: 88rpx;
          height: 88rpx;
          position: absolute;
          top: 52rpx;
          left: 322rpx;
        }
      }
      .birthday-ribbon {
        width: 230rpx;
        height: 60rpx;
        margin-top: -16rpx;
        margin-bottom: 16rpx;
      }
      .birthday-desc {
        font-size: 22rpx;
        text-align: center;
        color: #fe5e10;
        line-height: 32rpx;
      }
    }
  }
}
</style>
