<template>
  <view class="share-pages" @click="close">
    <view class="share-box">
      <view class="share-box-title">分享至</view>
      <!-- 粉丝 -->
      <block v-if="fansList.length">
        <view class="friend-list">
          <scroll-view class="scroll-box" :scroll-x="true" @scrolltolower="loadNextPage">
            <view class="friend-box">
              <view
                class="friend-item"
                v-for="(item, index) in fansList"
                :key="index"
                @click="
                  $u.throttle(() => {
                    handleShare(item)
                  }, 1000)
                "
              >
                <zero-lazy-load class="friend-item-img" :borderRadius="80" :image="item.userinfo.headUrl" :height="80" imgMode="aspectFill"></zero-lazy-load>
                <view class="friend-item-text u-line-1">{{ item.userinfo.nickName }}</view>
              </view>
            </view>
          </scroll-view>
        </view>
        <view class="split-line"></view>
      </block>

      <view class="h-flex-center share-slide-box">
        <view class="share-list" v-if="shareData.isShowRecommend" @click="recommendEvent">
          <image class="share-icon" src="https://img.yiqitogether.com/yqyq-app/images/dt-share-likeit.png" mode=""></image>
          推荐
        </view>

        <view class="share-list" v-if="shareData.isShowForward" @click="forwardEvent">
          <image class="share-icon" src="https://img.yiqitogether.com/yqyq-app/images/dt_share-collect.png" mode=""></image>
          转发至动态
        </view>

        <!-- #ifdef APP -->
        <view class="share-list" @click.stop="shareClick('WXSceneSession')">
          <image class="share-icon" src="https://img.yiqitogether.com/static/local/myImagesV2/wx%402x.png" mode=""></image>
          微信好友
        </view>

        <view class="share-list" @click.stop="shareClick('WXSceneTimeline')">
          <image class="share-icon" src="https://img.yiqitogether.com/static/local/myImagesV2/pyq%402x.png" mode=""></image>
          朋友圈
        </view>
        <!-- #endif -->

        <view @click="copyLink" class="share-list">
          <image class="share-icon" src="@/static/images/recruitImgs/fx_lj@2x.png" mode=""></image>
          复制链接
        </view>
      </view>
      <view class="share-box-close">取消</view>
    </view>
  </view>
</template>

<script>
/**
 * shareData		分享的数据对象
 *
 * 必填
 * - type 				0 图文   5小程序
 * - title				标题
 * - imageUrl 		分享出去的图片
 * - href					h5跳转链接  无需加域名
 *
 * 选填
 * - path							分享为小程序时必填
 * - isShowRecommend 	是否展示推荐	 默认false
 * - isShowForward 		是否展示转发 默认false
 * - targetId					推荐/转发的id
 */
import { yiqiPordH5BaseUrl,wechatMiniProgramType } from '../../utils/cacheKey.js'
import IndexModel from '@/model/index'
import MyInfo from '@/model/my'
import rongYun from '@/model/rongyun.js'

export default {
  name: 'common-sharing-module',
  props: ['shareData'],
  data() {
    return {
      baseURL: yiqiPordH5BaseUrl,
      pages: 0,
      pageNumber: 0,
      pageSize: 10,
      loadStatus: 'loadmore',
      fansList: []
    }
  },
  created() {
    this.pageNumber = 0
    this.fansList = []
    this.getFansList()
  },
  methods: {
    // 获取粉丝列表
    getFansList() {
      let params = {
        pageNo: this.pageNumber + 1,
        pageSize: this.pageSize
      }
      MyInfo.getFansList(params).then(res => {
        if (res.code == 'SUCCESS' && res.data) {
          this.pages = res.data.fansList.pages
          this.pageNumber = res.data.fansList.pageNumber

          let list = res.data.fansList.list || []
          this.fansList = [...this.fansList, ...list]
          if (res.data.fansList.total == 0) {
            this.loadStatus = 'none'
          } else {
            if (res.data.fansList.pages <= res.data.fansList.pageNumber) {
              this.loadStatus = 'nomore'
            } else {
              this.loadStatus = 'loadmore'
            }
          }
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 关注列表加载下一页
    loadNextPage() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.getFansList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    // 分享
    handleShare(item) {
      let obj = {
        id: this.shareData.targetId,
        title: this.shareData.title,
        content: this.shareData.content,
        imageUrl: this.shareData.imageUrl,
        href: this.shareData.href,
        messageType: 1,
        identifier: 'share'
      }
      let params = {
        content: '[分享]',
        messageType: 'Share',
        extraMsg: JSON.stringify(obj),
        targetNumberId: item.userinfo.numberId
      }
      rongYun.sendShareMessage(params).then(res => {
        if (res.code == 'SUCCESS') {
          uni.showToast({
            title: '分享成功',
            icon: 'none'
          })
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    /**
     * 推荐
     */
    recommendEvent() {
      let data = {
        twitterId: this.shareData.targetId
      }
      IndexModel.recommendScore(data).then(res => {
        if (res.code == 'SUCCESS') {
          uni.showToast({
            title: '推荐成功',
            icon: 'none'
          })
        }
      })
    },
    /**
     * 转发至动态
     */
    forwardEvent() {
      this.$emit('handleForward')
    },
    close() {
      this.$emit('closePopup')
    },
    shareClick(scene) {
      let shareObj = {
        provider: 'weixin',
        scene: scene,
        type: this.shareData.type,
        title: this.shareData.title,
        imageUrl: this.shareData.imageUrl,
        href: this.baseURL + this.shareData.href
      }
      // 分享为小程序时 需要携带小程序信息
      if (this.shareData.type == 5) {
        shareObj.miniProgram = {
          id: 'gh_7c94761fe0a4',
          path: this.shareData.path,
          type: wechatMiniProgramType,
          webUrl: this.baseURL + this.shareData.href
        }
      }
      // 分享到微信朋友圈，强制为图文
      if (scene == 'WXSceneTimeline') {
        shareObj.type = 0
      }
      uni.share({
        ...shareObj,
        success: res => {
          console.log('success:' + JSON.stringify(res))
        },
        fail: err => {
          console.log('fail:' + JSON.stringify(err))
        },
        complete: () => {
          this.$emit('closePopup')
        }
      })
    },
    copyLink() {
      uni.setClipboardData({
        data: this.baseURL + this.shareData.href,
        success: function () {
          uni.showToast({
            title: '已复制',
            icon: 'none'
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.share-pages {
  width: 750rpx;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999999999;

  .share-box {
    width: 750rpx;
    box-sizing: border-box;
    position: absolute;
    left: 0;
    bottom: 0;
    background: #ffffff;
    border-radius: 16rpx 16rpx 0rpx 0rpx;

    .share-box-title {
      font-size: 28rpx;
      text-align: center;
      color: #373d44;
      line-height: 40rpx;
      padding: 30rpx 0 25rpx;
    }
    .friend-list {
      width: 100%;
      padding: 15rpx 0;
      box-sizing: border-box;
      background-color: #ffffff;
      .scroll-box {
        height: 122rpx;

        .friend-box {
          display: flex;
          flex-wrap: nowrap;
          height: 100%;
        }
        .friend-item {
          flex-shrink: 0;
          width: 110rpx;
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-right: 30rpx;

          .friend-item-img {
            width: 80rpx;
            height: 80rpx;
            border-radius: 50%;
            margin-bottom: 10rpx;
          }
          .friend-item-text {
            font-size: 22rpx;
            color: #484848;
            line-height: 32rpx;
          }
        }
        .friend-item:first-child {
          margin-left: 44rpx;
        }
        .friend-item:last-child {
          padding-right: 44rpx;
          margin-right: 0;
        }
      }
    }
  }

  .split-line {
    height: 2rpx;
    background-color: #f6f6f8;
    margin: 15rpx 30rpx;
  }

  .share-slide-box {
    overflow-x: auto;
    padding: 15rpx 0;

    .share-list {
      text-align: center;
      font-size: 20rpx;
      font-weight: 500;
      color: #adb3ba;

      .share-icon {
        width: 100rpx;
        height: 100rpx;
        display: block;
        margin: 0 30rpx 20rpx;
      }
    }
    .share-list:first-child {
      margin-left: 14rpx;
    }
    .share-list:last-child {
      margin-right: 14rpx;
    }
  }

  .share-box-close {
    // position: fixed;
    // bottom: 0;
    width: 100%;
    font-size: 28rpx;
    text-align: center;
    color: #adb3ba;
    line-height: 36rpx;
    padding: 40rpx 0;
  }
}
</style>
