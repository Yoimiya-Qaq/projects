<template>
  <u-popup class="custom-topic-popup" :show="show" :round="round" :customStyle="customStyle" :closeOnClickOverlay="true" @open="onOpen" @close="onClose">
    <view class="popup-header">
      <view class="header-title">添加话题</view>
      <image class="close-icon" src="@/static/images/bjzl_zybj_delete.png" mode="" @click="onClose"></image>
    </view>
    <view class="popup-content">
      <view class="input-wrap">
        <image class="input-icon" src="@/static/images/tagColor.png" mode=""></image>
        <input
          class="input-field"
          v-model.trim="searchValue"
          placeholder="输入想要添加的话题"
          :maxlength="maxlength"
          border="none"
          placeholderStyle="color:#c1c7d2;font-size: 28rpx;"
          @input="
            $u.throttle(() => {
              onSearch($event)
            }, 50)
          "
        />
        <view class="input-limit">{{ valuelength ? valuelength : 0 }}/10</view>
      </view>
      <view class="list-wrap" v-for="(item, index) in tempList" :key="index">
        <view class="left ellipsis-single" v-html="'#' + highlightText(item.topicName)" @click="onAdd(item)"></view>
        <view class="right" v-if="!topicList.length && item.topicName === searchValue" @click="$u.throttle(onConfirm, 500)">创建话题</view>
        <view class="right" v-else>{{ item.viewNumber > 10000 ? (item.viewNumber / 10000).toFixed(2) + '万' : item.viewNumber }}人阅读</view>
      </view>
    </view>
  </u-popup>
</template>

<script>
import FindModel from '@/model/find.js'

export default {
  name: 'CustomTopicPopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 24
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // 自定义样式
    customStyle: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      searchValue: '',
      tempList: [], // 列表显示的话题
      topicList: [], // 全匹配话题
      maxlength: 20,
      valuelength: 0
    }
  },
  methods: {
    getTopicList() {
      FindModel.topicList({ keyword: this.searchValue }).then(res => {
        if (res.code == 'SUCCESS') {
          if (res.data.list.length > 0) {
            let list = res.data.list.slice(0, 10) || []
            this.tempList = list
            if (this.searchValue) {
              let arr = []
              arr = list.filter(item => item.topicName === this.searchValue)
              if (arr.length) {
                this.topicList = arr
              } else {
                this.topicList = []
                this.tempList = this.tempList.slice(0, 9)
                this.tempList.unshift({ topicName: this.searchValue })
              }
            } else {
              this.topicList = list
            }
          } else {
            this.tempList = this.searchValue ? [{ topicName: this.searchValue }] : []
            this.topicList = []
          }
        }
      })
    },
    onOpen() {
      this.searchValue = ''
      this.getTopicList()
      this.$emit('open')
    },
    onClose() {
      this.$emit('close')
    },
    // 模糊搜索话题
    onSearch(e) {
      this.maxlength = 20
      this.valuelength = 0
      let length = 0
      let input = e.detail.value.trim()
      const split = input.split('')
      // 计算已输入的长度(英文字母和数字为1，中文字符为2)
      const map = split.map((s, i) => (input.charCodeAt(i) >= 0 && input.charCodeAt(i) <= 128 ? 1 : 2))
      let n = 0
      // 输入的长度
      const charLength =
        map.length > 0 &&
        map.reduce((accumulator, currentValue, index) => {
          if (accumulator === this.maxlength || accumulator === this.maxlength - 1) {
            n = index
          }
          return accumulator + currentValue
        })
      this.$nextTick(() => {
        if (charLength > this.maxlength) {
          split.slice(0, n).forEach((item, index) => {
            // 如果输入中文字符，将限制长度-1,这样解决当长度为19时，还能输入中文字符的问题
            if (map[index] == 2) {
              this.maxlength -= 1
            }
            length += map[index]
            this.valuelength = Math.ceil(length / 2)
          })
          input = split.slice(0, n).join('')
          this.searchValue = input
        } else {
          this.valuelength = charLength ? Math.ceil(charLength / 2) : 0
          this.searchValue = input
          map.forEach(item => {
            if (item == 2) {
              this.maxlength -= 1
            }
          })
        }
        this.getTopicList()
      })
    },
    onAdd(item) {
      if (!this.topicList.length && item.topicName === this.searchValue) {
        this.$emit('confirm', this.searchValue)
      } else {
        this.$emit('add', item)
      }
    },
    onConfirm() {
      this.$emit('confirm', this.searchValue)
    },
    // 处理高亮
    highlightText(text) {
      let highlightStr = `<text style="color:#FE5E10">${this.searchValue}</text>`
      // new 出来一个正则表达式reg根据动态数据变量来创建
      // 参数一 将 this.searchValue的值解析成字符串,并根据这个创建正则表达式,
      // 参数二 匹配模式  "gi"
      let reg = new RegExp(this.searchValue, 'gi')
      // 返回替换后的心字符串
      return text.replace(reg, highlightStr)
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-topic-popup {
  .popup-header {
    position: relative;
    .header-title {
      font-size: 32rpx;
      text-align: center;
      padding: 30rpx 0;
      color: #2a343e;
      line-height: 44rpx;
    }
    .close-icon {
      width: 24rpx;
      height: 24rpx;
      position: absolute;
      top: 50%;
      right: 30rpx;
      transform: translateY(-50%);
    }
  }
  .popup-content {
    height: 1000rpx;
    background: #ffffff;
    overflow-y: scroll;
    width: 100%;
    box-sizing: border-box;
    border-radius: 24rpx;
    position: relative;
    z-index: 3 !important;

    .input-wrap {
      display: flex;
      align-items: center;
      padding: 10rpx 0 30rpx;
      margin: 0 30rpx;
      box-sizing: border-box;
      position: relative;
      border-bottom: 2rpx solid #f6f7fa;
      .input-icon {
        width: 24rpx;
        height: 24rpx;
        margin-right: 8rpx;
        flex-shrink: 0;
      }
      .input-field {
        width: 400rpx;
      }

      /deep/.uni-input-input {
        font-size: 28rpx;
        color: #2a343e;
      }
      .input-limit {
        color: #cccbcb;
        font-size: 24rpx;
        padding: 0 20rpx;
        box-sizing: border-box;
        position: absolute;
        right: 0rpx;
      }
    }
    .list-wrap {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20rpx 24rpx;
      margin-top: 10rpx;

      .left {
        flex: 1;
        font-size: 28rpx;
        color: #2a343e;
        line-height: 40rpx;
      }
      .right {
        flex-shrink: 0;
        font-size: 24rpx;
        color: #838e9a;
        line-height: 34rpx;
        margin-left: 24rpx;
      }
    }
  }
}
</style>
