<template>
  <view class="custom-publish-popup">
    <!-- 发布弹窗 -->
    <u-popup :show="showPublish" :round="20" :closeOnClickOverlay="closeOnClickOverlay" @open="onOpen" @close="onClose" @touchmove.native.stop.prevent>
      <image class="bg-img" src="http://img.yiqitogether.com/static/images/index/publish_bg.png" mode="widthFix" />
      <view class="main">
        <view
          class="card-box"
          @click="
            $u.throttle(() => {
              onClick('dynamic')
            }, 500)
          "
        >
          <image class="card-box-img" src="http://img.yiqitogether.com/static/images/index/publish_dynamic.png" mode="aspectFill" />
          <view class="card-box-content">
            <view class="title">发动态</view>
            <view class="subtitle">晒一晒你此刻的想法</view>
          </view>
          <image class="card-box-icon" src="http://img.yiqitogether.com/static/images/index/arrow_right_black.png" mode="" />
        </view>

        <view
          class="card-box"
          @click="
            $u.throttle(() => {
              onClick('note')
            }, 500)
          "
        >
          <image class="card-box-img" src="http://img.yiqitogether.com/static/images/index/publish_note.png" mode="aspectFill" />
          <view class="card-box-content">
            <view class="title">发笔记</view>
            <view class="subtitle">高质量内容吸引高质量人群</view>
          </view>
          <image class="card-box-icon" src="http://img.yiqitogether.com/static/images/index/arrow_right_black.png" mode="" />
        </view>

        <view
          class="card-box"
          @click="
            $u.throttle(() => {
              onClick('activity')
            }, 500)
          "
        >
          <image class="card-box-img" src="http://img.yiqitogether.com/static/images/index/publish_activity.png" mode="aspectFill" />
          <view class="card-box-content">
            <view class="title">发活动</view>
            <view class="subtitle">寻找与你一拍即合De伙伴</view>
          </view>
          <image class="card-box-icon" src="http://img.yiqitogether.com/static/images/index/arrow_right_black.png" mode="" />
        </view>
      </view>
      <image class="close-icon" src="@/static/tab-icon/publish-f.png" mode="" @click.stop="onClose" />
    </u-popup>
    <!-- 实名认证弹窗 -->
    <yue-realname-auth-modal ref="realnameAuthRef" />
  </view>
</template>

<script>
import MyInfo from '@/model/my.js'

export default {
  name: 'CustomPublishPopup',
  props: {
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      showPublish: false,
      authSimple: '' // 是否认证
    }
  },
  methods: {
    onOpen() {
      uni.hideTabBar()
      this.showPublish = true
      this.getRealnameAuthStatus()
    },
    onClose() {
      this.showPublish = false
      setTimeout(() => {
        uni.showTabBar()
      }, 200)
    },
    // 去发布
    onClick(type) {
      switch (type) {
        case 'dynamic':
          uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s1' })
          this.onClose()
          break
        case 'note':
          uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s3' })
          this.onClose()
          break
        case 'activity':
          this.goInitateActivity()
          break
        default:
          break
      }
    },
    // 获取实名认证状态
    async getRealnameAuthStatus() {
      let res = await MyInfo.userInfoStatusV2()
      if (res.code == 'SUCCESS') {
        this.authSimple = res.data.authSimple == 'SUCCESS' ? 'SUCCESS' : 'FAIL'
      }
    },
    // 发布活动
    async goInitateActivity() {
      await this.getRealnameAuthStatus()

      if (this.authSimple == 'SUCCESS') {
        uni.navigateTo({ url: '/pagesInitiateActivity/initiateActivity/initiateActivity' })
        this.onClose()
      } else {
        this.onClose()
        this.$refs.realnameAuthRef.onOpen()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-publish-popup {
  .bg-img {
    width: 100%;
    height: 492rpx;
  }
  .main {
    padding: 0 36rpx;
    .card-box {
      width: 100%;
      height: 144rpx;
      background: #ffeee5;
      border-radius: 20rpx;
      margin-top: 24rpx;
      display: flex;
      align-items: center;
      padding: 16rpx 24rpx 16rpx 16rpx;
      box-sizing: border-box;

      &-img {
        width: 112rpx;
        height: 112rpx;
        flex-shrink: 0;
      }
      &-content {
        flex: 1;
        margin: 0 20rpx;
        color: #2a343e;

        .title {
          font-size: 36rpx;
          line-height: 50rpx;
          font-weight: bold;
        }
        .subtitle {
          font-size: 24rpx;
          line-height: 34rpx;
        }
      }
      &-icon {
        width: 20rpx;
        height: 20rpx;
        flex-shrink: 0;
      }
    }
    .card-box:last-of-type {
      background: #ffc1a2;
    }
  }
  .close-icon {
    width: 64px;
    height: 64px;
    margin: 40px auto 6px;
  }
}
</style>
