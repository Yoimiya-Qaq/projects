<template>
  <u-popup class="custom-at-popup" v-if="show" :show="show" mode="right" @open="onOpen">
    <view class="status-bar-box"></view>
    <view class="nav-container">
      <image @click="onClose" class="nav-back" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" />
      <view class="nav-title">@好友</view>
    </view>
    <view class="top-wrap">已选择 {{ checkedList.length || 0 }} 位联系人</view>
    <scroll-view class="list-container" v-if="attentionList.length" :scroll-y="true" @scrolltolower="loadNextPage">
      <u-checkbox-group placement="column">
        <block v-for="(item, index) in attentionList" :key="index">
          <view class="list-item" @click="checkboxGroupChange(item)">
            <u-checkbox class="list-item-checkbox" :checked="item.isChecked" :value="item.userinfo.numberId" shape="circle" size="32" iconSize="20" activeColor="#FE5E10" @change="onCheck(index)"></u-checkbox>
            <zero-lazy-load class="list-item-avatar" :borderRadius="70" :image="item.userinfo.headUrl" :height="70" imgMode="aspectFill"></zero-lazy-load>
            <view class="list-item-name">{{ item.userinfo.nickName || '' }}</view>
          </view>
        </block>
      </u-checkbox-group>
      <view class="tips-box">
        <u-loadmore :status="loadStatus" :fontSize="20" nomore-text="没有更多了~" />
      </view>
    </scroll-view>
    <view v-else class="empty-wrap">
      <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/details_user_none.png" alt="" mode="aspectFill" />
      <view class="empty-text">暂无可@人员</view>
    </view>
    <!-- 底部固定盒子 -->
    <view class="bottom-container" @click="$u.throttle(onConfirm, 500)">
      <view class="btn">确认选择</view>
    </view>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-if="showLoading"></yue-loading>
  </u-popup>
</template>

<script>
import MyInfo from '@/model/my'

export default {
  name: 'CustomAtPopup',
  props: {
    show: {
      type: Boolean,
      default: false
    },
    checked: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      showLoading: false,
      pageNumber: 1,
      pageSize: 20,
      attentionList: [],
      checkedList: [],
      loadStatus: 'loadmore'
    }
  },
  methods: {
    // 打开弹出框
    onOpen() {
      this.pageNumber = 1
      this.attentionList = []
      this.showLoading = true
      this.getAtList()
      this.$emit('open')
    },
    // 关闭弹出框
    onClose() {
      this.pageNumber = 1
      this.attentionList = []
      this.$emit('close', false)
    },
    // 获取关注列表
    getAtList() {
      let params = {
        pageNo: this.pageNumber,
        pageSize: this.pageSize
      }
      MyInfo.getAttentionList(params)
        .then(res => {
          if (res.code == 'SUCCESS' && res.data) {
            this.loadStatus = !res.data.atentionList.hasNextPage ? 'nomore' : 'loadmore'
            let list = res.data.atentionList.list || []
            list.map(item => {
              item.isChecked = false
              if (this.checked.length) {
                this.checked.map(v => {
                  if (item.userinfo.numberId == v.userinfo.numberId) {
                    item.isChecked = true
                  }
                })
              }
            })
            this.attentionList = [...this.attentionList, ...list]
            this.checkedList = []
            let arr = []
            arr = this.attentionList.filter(item => !!item.isChecked)
            this.checkedList = arr
            this.showLoading = false
          } else {
            this.showLoading = false
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 关注列表加载下一页
    loadNextPage() {
      if (this.loadStatus !== 'nomore') {
        this.loadStatus = 'loading'
        this.pageNumber++
        this.getAtList()
      }
    },
    // 切换列表单个复选框状态
    onCheck(index) {
      this.attentionList[index].isChecked = !this.attentionList[index].isChecked
      this.checkedList = this.attentionList.filter(item => !!item.isChecked)
    },
    // 获取选中数组
    checkboxGroupChange(item) {
      this.attentionList.map(v => {
        if (v.userinfo.numberId == item.userinfo.numberId) {
          v.isChecked = !v.isChecked
        }
      })
      this.checkedList = this.attentionList.filter(item => !!item.isChecked)
    },
    // 确认选择
    onConfirm() {
      if (!this.checkedList.length) {
        uni.showToast({
          title: '请先选择要@的好友',
          icon: 'none'
        })
        return
      }
      this.$emit('confirm', this.checkedList, 'mul')
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-at-popup {
  width: 100%;
  height: 100vh;

  /deep/.u-transition {
    width: 100%;
  }

  .status-bar-box {
    width: 100%;
    height: var(--status-bar-height);
    background-color: #fff;
  }

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    position: relative;
    z-index: 999;
    .nav-back {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-title {
      flex: 1;
      font-size: 36rpx;
      line-height: 48rpx;
      color: #333333;
    }
  }
  .top-wrap {
    font-size: 24rpx;
    color: #2a343e;
    line-height: 34rpx;
    padding: 20rpx 30rpx 10rpx;
  }
  .list-container {
    height: calc(100vh - var(--status-bar-height) - 276rpx);
    .list-item {
      display: flex;
      align-items: center;
      padding: 20rpx 30rpx;

      &-checkbox {
        margin-right: 20rpx;
        flex-shrink: 0;

        /deep/.u-checkbox__icon-wrap {
          margin: 0;
        }
      }

      &-avatar {
        flex-shrink: 0;
        width: 70rpx;
        height: 70rpx;
        margin-right: 20rpx;
      }
      &-name {
        flex: 1;
        font-size: 28rpx;
        color: #484848;
        line-height: 40rpx;
      }
    }
    .tips-box {
      padding-bottom: 30rpx;
    }
  }
  .empty-wrap {
    margin: 240rpx auto;
    text-align: center;
    .empty-img {
      width: 312rpx;
      height: 244rpx;
    }
    .empty-text {
      font-size: 24rpx;
      color: #f8c1ca;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
  .bottom-container {
    padding: 24rpx 30rpx;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    box-sizing: border-box;
    background-color: #fff;

    .btn {
      width: 100%;
      font-size: 32rpx;
      color: #ffffff;
      line-height: 44rpx;
      text-align: center;
      padding: 16rpx 0;
      background-color: #fe5e10;
      border-radius: 44rpx;
    }
  }
}
</style>
