<template>
  <view class="custom-drag-list">
    <template v-if="viewWidth">
      <movable-area class="area" :style="{ height: areaHeight }" @mouseenter="mouseenter" @mouseleave="mouseleave">
        <!-- 列表 -->
        <movable-view
          v-for="(item, index) in listData"
          :key="item.id"
          class="view"
          direction="all"
          :y="item.y"
          :x="item.x"
          :damping="40"
          :animation="false"
          :disabled="item.disable"
          @change="
            $u.throttle(() => {
              onChange($event, item)
            }, 100)
          "
          @touchstart="touchstart(item)"
          @mousedown="touchstart(item)"
          @touchend="touchend(item)"
          @mouseup="touchend(item)"
          @longpress="longPress(item)"
          :style="{
            width: viewWidth + 'px',
            height: viewWidth + 'px',
            'z-index': item.zIndex,
            opacity: item.opacity
          }"
        >
          <!-- 上传的视频 -->
          <view v-if="item.photoType == 'VIDEO'" class="upload-box" :style="{ width: childWidth, height: childWidth, borderRadius: borderRadius + 'rpx', transform: 'scale(' + item.scale + ')' }">
            <image class="upload-img" :src="item.imgUrl" mode="aspectFill" @click.stop="handlePlayVideo(item)" />
            <image class="play-icon" src="@/static/images/fx_gc_sp.png" mode="aspectFill" @click.stop="handlePlayVideo(item)" />
            <!-- 视频 —— 删除按钮 -->
            <image
              v-if="item.percentage == 100 || item.showFail"
              class="del-icon"
              src="@/static/images/upload_delete.png"
              mode=""
              @click.stop="deleteImgOrVideo('VIDEO', item, index)"
              @touchstart.stop="delImageMp('VIDEO', item, index)"
              @touchend.stop="nothing()"
              @mousedown.stop="nothing()"
              @mouseup.stop="nothing()"
            />
            <!-- 视频上传状态 —— 上传失败/取消上传 -->
            <view v-if="item.showFail" class="upload-fail flex-center" :style="{ width: childWidth, borderBottomLeftRadius: borderRadius + 'rpx', borderBottomRightRadius: borderRadius + 'rpx' }" @click.stop="handleFail(index)" @touchstart.stop @touchend.stop @mousedown.stop @mouseup.stop>
              <image class="warn-icon" src="@/static/images/warn.png" mode="aspectFill" />
              <view class="warn-text">上传失败</view>
            </view>
            <!-- 视频上传状态 —— 上传中 -->
            <view v-if="item.percentage != 100 && !item.showFail" class="upload-bottom" :style="{ width: childWidth, borderBottomLeftRadius: borderRadius + 'rpx', borderBottomRightRadius: borderRadius + 'rpx' }">
              <view class="txt">{{ item.percentage || 0 }}%</view>
              <u-line-progress class="progress" :style="{ width: index == currIndex ? '152rpx' : '186rpx' }" :percentage="item.percentage" height="10" :showText="false" inactiveColor="#b8b6b9" activeColor="#fff"></u-line-progress>
              <image v-show="index == currIndex" class="close-icon" src="@/static/images/close_white.png" mode="aspectFill" @click.stop="cancelUpload(index)" @touchstart.stop @touchend.stop @mousedown.stop @mouseup.stop />
            </view>
          </view>

          <!-- 上传的图片 -->
          <view v-else class="upload-box" :style="{ width: childWidth, height: childWidth, borderRadius: borderRadius + 'rpx', transform: 'scale(' + item.scale + ')' }">
            <image class="upload-img" :src="item.src" mode="aspectFill" @click.stop="handlePreviewImg(item)"></image>
            <!-- 图片 —— 删除按钮 -->
            <image
              v-if="item.percentage == 100 || item.showFail"
              class="del-icon"
              src="@/static/images/upload_delete.png"
              mode=""
              @click.stop="deleteImgOrVideo('IMGS', item, index)"
              @touchstart.stop="delImageMp('IMGS', item, index)"
              @touchend.stop="nothing()"
              @mousedown.stop="nothing()"
              @mouseup.stop="nothing()"
            />
            <!-- 图片上传状态 —— 上传失败/取消上传 -->
            <view v-if="item.showFail" class="upload-fail flex-center" :style="{ width: childWidth, borderBottomLeftRadius: borderRadius + 'rpx', borderBottomRightRadius: borderRadius + 'rpx' }" @click.stop="handleFail(index)" @touchstart.stop @touchend.stop @mousedown.stop @mouseup.stop>
              <image class="warn-icon" src="@/static/images/warn.png" mode="aspectFill" />
              <view class="warn-text">上传失败</view>
            </view>
            <!-- 图片上传状态 —— 上传中 -->
            <view v-if="item.percentage != 100 && !item.showFail" class="upload-bottom" :style="{ width: childWidth, borderBottomLeftRadius: borderRadius + 'rpx', borderBottomRightRadius: borderRadius + 'rpx' }">
              <view class="txt">{{ item.percentage || 0 }}%</view>
              <u-line-progress class="progress" :style="{ width: index == currIndex ? '152rpx' : '186rpx' }" :percentage="item.percentage" height="10" :showText="false" inactiveColor="#b8b6b9" activeColor="#fff"></u-line-progress>
              <image v-show="index == currIndex" class="close-icon" src="@/static/images/close_white.png" mode="aspectFill" @click.stop="cancelUpload(index)" @touchstart.stop @touchend.stop @mousedown.stop @mouseup.stop />
            </view>
          </view>
        </movable-view>

        <!-- 添加照片/视频 -->
        <view class="add-wrap" v-if="!limit || listData.length < limit" :style="{ top: add.y, left: add.x, width: viewWidth + 'px', height: viewWidth + 'px' }" @click="judgeAlbumAuth">
          <view class="add-box" :style="{ width: childWidth, height: childWidth, borderRadius: borderRadius + 'rpx' }">
            <image class="add-img" src="@/static/images/photo.png" mode="widthFix" />
            <view class="add-text">添加照片/视频</view>
          </view>
        </view>
      </movable-area>
    </template>

    <!-- 相册权限弹窗 -->
    <accredit-popup ref="accreditRef" systemTitle="“一起一起”想访问您的相册" systemContent="用于使用上传照片/视频功能" permisionID="android.permission.READ_EXTERNAL_STORAGE" cacheId="externalStorage" @successAccredit="showUploadType = true" />
    <!-- 选择上传类型弹窗 -->
    <custom-more-operate-popup :show="showUploadType" :list="btnList" @close="showUploadType = false" @click="handleBtnClick" />
    <!-- 重新上传弹窗 -->
    <custom-more-operate-popup :show="showReUpload" :list="reloadBtnList" @close="showReUpload = false" @click="handleReUpload" />
    <!-- 确认删除图片/视频弹窗 -->
    <custom-modal type="tipsConfirm" :show="showDel" :round="24" title="确认删除" :content="delContent" cancelText="取消" confirmText="确认" @cancel="cancelDel" @confirm="confirmDel" />
  </view>
</template>

<script>
import { rpxTopx, uploadFile, getFileInfo } from '@/utils/tools'

export default {
  emits: ['input', 'update:modelValue'],
  props: {
    // 排序图片，VUE2
    value: {
      type: Array,
      default: function () {
        return []
      }
    },
    // 排序图片，VUE3
    modelValue: {
      type: Array,
      default: function () {
        return []
      }
    },
    // 从 list 元素对象中读取的键名
    keyName: {
      type: String,
      default: 'imgUrl'
    },
    // 选择图片数量限制
    limit: {
      type: Number,
      default: 18
    },
    // 图片父容器宽度（实际显示的图片宽度为 imageWidth / 1.1 ），单位 rpx
    // imageWidth > 0 则 cols 无效
    imageWidth: {
      type: Number,
      default: 0
    },
    // 图片列数
    cols: {
      type: Number,
      default: 3
    },
    // 图片圆角，单位 rpx
    borderRadius: {
      type: Number,
      default: 16
    },
    // 图片周围空白填充，单位 rpx
    padding: {
      type: Number,
      default: 6
    },
    // 拖动图片时放大倍数 [0, ∞)
    scale: {
      type: Number,
      default: 1
    },
    // 拖动图片时不透明度
    opacity: {
      type: Number,
      default: 0.7
    },
    // 自定义添加
    addImage: {
      type: Function,
      default: null
    },
    // 删除确认
    delImage: {
      type: Function,
      default: null
    }
  },
  data() {
    return {
      listData: [], // 图片视频数组
      windowWidth: 0, // 屏幕宽度
      add: {
        x: 0,
        y: 0
      },
      colsValue: 0, // 列数
      viewWidth: 0, // 图片加左右间距的大小
      timer: null,
      changeStatus: true, // 拖动状态
      preStatus: true, // 预览状态
      first: true,

      uploadType: '', // 上传类型
      currIndex: 0, // 当前上传中索引
      currItem: null, // 当前选中项数据

      delIndex: null, // 当前需要删除项索引
      delItem: null, // 当前需要删除项
      delContent: '是否删除此照片？',
      showDel: false,

      showUploadType: false, // 上传类型弹窗
      btnList: ['图片', '视频'],
      showReUpload: false,
      reloadBtnList: ['重新上传'],
      isReupload: false // 是否是重新上传
    }
  },
  computed: {
    areaHeight() {
      let height = ''
      if (this.limit && this.listData.length >= this.limit) {
        height = (Math.ceil(this.listData.length / this.colsValue) * this.viewWidth).toFixed() + 'px'
      } else {
        height = (Math.ceil((this.listData.length + 1) / this.colsValue) * this.viewWidth).toFixed() + 'px'
      }
      return height
    },
    childWidth() {
      return this.viewWidth - rpxTopx(this.padding) * 2 + 'px'
    }
  },
  watch: {
    listData: {
      handler(val) {
        this.$emit('input', val)
        this.$emit('update:modelValue', val)
      },
      deep: true
    }
  },
  created() {
    this.windowWidth = uni.getSystemInfoSync().windowWidth
  },
  mounted() {
    const query = uni.createSelectorQuery().in(this)
    query.select('.custom-drag-list').boundingClientRect(res => {
      this.colsValue = this.cols
      this.viewWidth = res.width / this.cols
      if (this.imageWidth > 0) {
        this.viewWidth = rpxTopx(this.imageWidth)
        this.colsValue = Math.floor(res.width / this.viewWidth)
      }
      let list = this.value
      // #ifdef VUE3
      list = this.modelValue
      // #endif
      for (let item of list) {
        this.addProperties(this.getSrc(item), { percentage: 100 })
      }
      this.first = false
    })
    query.exec()
  },
  methods: {
    // 获取图片路径
    getSrc(item) {
      return item[this.keyName]
    },
    // 拖动过程中触发的事件
    onChange(e, item) {
      if (!item) return
      item.oldX = e.detail.x
      item.oldY = e.detail.y
      if (e.detail.source === 'touch') {
        if (item.moveEnd) {
          item.offset = Math.sqrt(Math.pow(item.oldX - item.absX * this.viewWidth, 2) + Math.pow(item.oldY - item.absY * this.viewWidth, 2))
        }
        let x = Math.floor((e.detail.x + this.viewWidth / 2) / this.viewWidth)
        if (x >= this.colsValue) return
        let y = Math.floor((e.detail.y + this.viewWidth / 2) / this.viewWidth)
        let index = this.colsValue * y + x
        if (item.index != index && index < this.listData.length) {
          this.changeStatus = false
          for (let obj of this.listData) {
            if (item.index > index && obj.index >= index && obj.index < item.index) {
              this.change(obj, 1)
            } else if (item.index < index && obj.index <= index && obj.index > item.index) {
              this.change(obj, -1)
            } else if (obj.id != item.id) {
              obj.offset = 0
              obj.x = obj.oldX
              obj.y = obj.oldY
              this.$nextTick(() => {
                obj.x = obj.absX * this.viewWidth
                obj.y = obj.absY * this.viewWidth
              })
            }
          }
          item.index = index
          item.absX = x
          item.absY = y
          if (!item.moveEnd) {
            this.$nextTick(() => {
              item.x = item.absX * this.viewWidth
              item.y = item.absY * this.viewWidth
            })
          }
          this.sortList()
        }
      }
    },
    change(obj, i) {
      obj.index += i
      obj.offset = 0
      obj.x = obj.oldX
      obj.y = obj.oldY
      obj.absX = obj.index % this.colsValue
      obj.absY = Math.floor(obj.index / this.colsValue)
      this.$nextTick(() => {
        obj.x = obj.absX * this.viewWidth
        obj.y = obj.absY * this.viewWidth
      })
    },
    touchstart(item) {
      this.listData.forEach(v => {
        v.disable = true
      })
      // this.listData.forEach(v => {
      //   v.zIndex = v.index + 9
      // })
      // item.zIndex = 99
      // item.moveEnd = true
      // this.currItem = item
      // this.timer = setTimeout(() => {
      //   item.scale = this.scale
      //   item.opacity = this.opacity
      //   clearTimeout(this.timer)
      //   this.timer = null
      // }, 200)
    },
    longPress(item) {
      let arr = this.listData.filter(item => item.percentage != 100 && !item.showFail)
      if (arr && arr.length) {
        return
      }
      this.listData.forEach(v => {
        v.zIndex = v.index + 9
        v.disable = false
      })
      item.zIndex = 99
      item.moveEnd = true
      this.currItem = item
      this.timer = setTimeout(() => {
        item.scale = this.scale
        item.opacity = this.opacity
        clearTimeout(this.timer)
        this.timer = null
      }, 200)
    },
    touchend(item) {
      this.listData.forEach(v => {
        v.disable = true
      })
      // if (item.photoType == 'VIDEO') {
      //   this.handlePlayVideo(item)
      // } else {
      //   this.handlePreviewImg(item)
      // }
      item.scale = 1
      item.opacity = 1
      item.x = item.oldX
      item.y = item.oldY
      item.offset = 0
      item.moveEnd = false
      setTimeout(() => {
        item.x = item.absX * this.viewWidth
        item.y = item.absY * this.viewWidth
        this.currItem = null
        this.changeStatus = true
      }, 100)
    },
    mouseenter() {
      //#ifdef H5
      this.listData.forEach(v => {
        v.disable = true
      })
      //#endif
    },
    mouseleave() {
      //#ifdef H5
      if (this.currItem) {
        this.listData.forEach(v => {
          v.disable = true
          v.zIndex = v.index + 9
          v.offset = 0
          v.moveEnd = false
          if (v.id == this.currItem.id) {
            if (this.timer) {
              clearTimeout(this.timer)
              this.timer = null
            }
            v.scale = 1
            v.opacity = 1
            v.x = v.oldX
            v.y = v.oldY
            this.$nextTick(() => {
              v.x = v.absX * this.viewWidth
              v.y = v.absY * this.viewWidth
              this.currItem = null
            })
          }
        })
        this.changeStatus = true
      }
      //#endif
    },
    // 判断相册权限
    judgeAlbumAuth() {
      if (this.listData.length) {
        let arr = this.listData.filter(item => item.percentage != 100 && !item.showFail)
        if (arr && arr.length) {
          uni.showToast({
            title: '请等待当前图片/视频上传完成',
            icon: 'none',
            mask: true
          })
          return
        }
      }
      this.isReupload = false
      this.$refs.accreditRef.triggerEvent()
    },
    // 选择上传类型
    handleBtnClick(index) {
      switch (index) {
        case 0:
          // 图片
          this.uploadType = 'IMGS'
          this.handleUpload()
          break
        case 1:
          // 视频
          this.uploadType = 'VIDEO'
          this.handleUpload()
          break
        default:
          break
      }
    },
    // 上传
    handleUpload() {
      if (typeof this.addImage === 'function') {
        this.addImage.bind(this.$parent)()
      } else {
        this.showUploadType = false
        let self = this
        if (this.uploadType == 'VIDEO') {
          // 选择视频
          uni.chooseVideo({
            sourceType: ['album'],
            compressed: false,
            success: function (res) {
              self.afterReadVideo(res)
            }
          })
        } else {
          // 选择图片
          uni.chooseImage({
            count: this.isReupload ? 1 : this.limit - this.listData.length,
            // sizeType: ['original'],
            sourceType: ['album'],
            success: res => {
              self.afterReadImg(res)
            }
          })
        }
      }
    },
    // 上传图片
    async afterReadImg(e) {
      let self = this
      let len = this.listData.length
      let list = e.tempFilePaths || []
      let arr = list.filter(item => item.toLowerCase().includes('heic'))
      if (arr.length > 0) {
        uni.showToast({
          title: '暂不支持上传HEIC格式的文件',
          icon: 'none',
          duration: 2000
        })
      }
      list = list.filter(item => !item.includes('heic'))
      if (this.isReupload) {
        // 重新上传，只能选择一张，替换当前
        list = list.splice(0, 1)
        this.listData[this.currIndex].src = list[0]
        this.listData[this.currIndex].photoType = 'IMGS'
        this.listData[this.currIndex].imgUrl = ''
        this.listData[this.currIndex].videoUrl = ''
        this.listData[this.currIndex].showFail = false
      } else {
        // 添加照片
        for (let i = 0; i < list.length; i++) {
          let obj = { photoType: 'IMGS', imgUrl: '', videoUrl: '', percentage: 0 }
          this.addProperties(list[i], obj)
        }
      }
      for (let i = 0; i < list.length; i++) {
        this.currIndex = this.isReupload ? this.currIndex : i + len
        try {
          let imgUrl = await uploadFile(list[i], self.processingProgress)
          this.listData[this.currIndex].imgUrl = imgUrl
        } catch (error) {
          this.listData[this.currIndex].percentage = 0
          this.listData[this.currIndex].showFail = true
        }
      }
      this.sortList()
    },
    // 上传视频
    async afterReadVideo(e) {
      if (JSON.stringify(e) === '{}' || !e) {
        return
      }
      let self = this
      let len = this.listData.length
      let sizeMb = Number(e.size) / 1024 / 1024
      if (sizeMb > 1536) {
        return uni.showToast({
          title: '视频过大，不得超过1.5G',
          icon: 'none',
          duration: 1500
        })
      }
      if (this.isReupload) {
        this.listData[this.currIndex].src = e.tempFilePath
        this.listData[this.currIndex].photoType = 'VIDEO'
        this.listData[this.currIndex].imgUrl = ''
        this.listData[this.currIndex].videoUrl = ''
        this.listData[this.currIndex].showFail = false
        this.listData[this.currIndex].videoMd5 = null
      } else {
        let obj = { photoType: 'VIDEO', imgUrl: '', videoUrl: '', percentage: 0, videoMd5: null }
        this.addProperties(e.tempFilePath, obj)
        this.currIndex = len
      }
      try {
        // 上传视频
        let videoUrl = await uploadFile(e.tempFilePath, self.processingProgress)
        let fileInfo = await getFileInfo(e)
        this.listData[this.currIndex].imgUrl = videoUrl + '!/snapshot/point/00:00:00/format/png'
        this.listData[this.currIndex].videoUrl = videoUrl
        this.listData[this.currIndex].videoMd5 = fileInfo.digest
      } catch (err) {
        // 上传失败
        this.listData[this.currIndex].percentage = 0
        this.listData[this.currIndex].showFail = true
        this.listData[this.currIndex].videoMd5 = null
      }
      this.sortList()
    },
    // 处理上传进度   downloadTask为上传对象
    processingProgress(res, downloadTask) {
      this.listData[this.currIndex].downloadTask = downloadTask
      this.listData[this.currIndex].percentage = res.progress
      this.$forceUpdate()
    },
    // 取消上传
    cancelUpload(index) {
      try {
        this.listData[index].downloadTask.abort()
        this.listData[index].downloadTask = null
      } catch (error) {}
      this.listData[index].percentage = 0
      this.listData[index].showFail = true
      this.$forceUpdate()
    },
    // 点击上传失败弹窗重新上传
    handleFail(index) {
      if (this.listData.length) {
        let arr = this.listData.filter(item => item.percentage != 100 && !item.showFail)
        if (arr && arr.length) {
          uni.showToast({
            title: '请等待当前图片/视频上传完成',
            icon: 'none',
            mask: true
          })
          return
        }
      }
      this.currIndex = index
      this.showReUpload = true
    },
    // 重新上传
    handleReUpload() {
      this.showReUpload = false
      this.showUploadType = true
      this.isReupload = true
    },
    // 删除图片/视频
    deleteImgOrVideo(type, item, index) {
      if (typeof this.delImage === 'function') {
        this.delImage.bind(this.$parent)(() => {
          this.delImageHandle(item, index)
        })
      } else {
        this.delIndex = index
        this.delItem = item
        this.delContent = type == 'VIDEO' ? '是否删除此视频？' : '是否删除此照片？'
        this.showDel = true
      }
    },
    // 删除-取消
    cancelDel() {
      this.showDel = false
      this.delIndex = null
      this.delItem = null
    },
    // 删除-确认
    confirmDel() {
      this.showDel = false
      this.delImageHandle(this.delItem, this.delIndex)
    },
    // 删除方法
    delImageHandle(item, index) {
      this.listData.splice(index, 1)
      for (let obj of this.listData) {
        if (obj.index > item.index) {
          obj.index -= 1
          obj.x = obj.oldX
          obj.y = obj.oldY
          obj.absX = obj.index % this.colsValue
          obj.absY = Math.floor(obj.index / this.colsValue)
          obj.x = obj.absX * this.viewWidth
          obj.y = obj.absY * this.viewWidth
        }
      }
      this.add.x = (this.listData.length % this.colsValue) * this.viewWidth + 'px'
      this.add.y = Math.floor(this.listData.length / this.colsValue) * this.viewWidth + 'px'
      this.sortList()
    },
    delImageMp(type, item, index) {
      //#ifdef MP
      this.deleteImgOrVideo(type, item, index)
      //#endif
    },
    sortList() {
      let list = this.listData.slice()
      list.sort((a, b) => {
        return a.index - b.index
      })
      this.listData = list
      this.$forceUpdate()
    },
    // 给每一项添加其他需要用到的属性
    addProperties(url, item) {
      let absX = this.listData.length % this.colsValue
      let absY = Math.floor(this.listData.length / this.colsValue)
      let x = absX * this.viewWidth
      let y = absY * this.viewWidth
      this.listData.push({
        ...item,
        src: url,
        x,
        y,
        oldX: x,
        oldY: y,
        absX,
        absY,
        scale: 1,
        zIndex: 9,
        opacity: 1,
        index: this.listData.length,
        id: this.guid(16),
        disable: true,
        offset: 0,
        moveEnd: false,
        showFail: false,
        downloadTask: null
      })
      this.add.x = (this.listData.length % this.colsValue) * this.viewWidth + 'px'
      this.add.y = Math.floor(this.listData.length / this.colsValue) * this.viewWidth + 'px'
    },
    guid(len = 32) {
      const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('')
      const uuid = []
      const radix = chars.length
      for (let i = 0; i < len; i++) uuid[i] = chars[0 | (Math.random() * radix)]
      uuid.shift()
      return `u${uuid.join('')}`
    },
    nothing() {},
    // 预览图片
    handlePreviewImg(item) {
      if (item.percentage == 100 && !this.showFail) {
        // if (item.percentage == 100 && this.timer && this.preStatus && this.changeStatus && item.offset < 28.28) {
        clearTimeout(this.timer)
        this.timer = null
        const list = this.value || this.modelValue
        let srcList = list.filter(item => item.photoType == 'IMGS' && item.percentage == 100).map(v => this.getSrc(v))
        uni.previewImage({
          urls: srcList,
          current: item.imgUrl,
          success: () => {
            this.preStatus = false
            setTimeout(() => {
              this.preStatus = true
            }, 600)
          }
        })
      } else if (this.timer) {
        clearTimeout(this.timer)
        this.timer = null
      }
    },
    // 播放视频
    handlePlayVideo(item) {
      if (item.percentage == 100 && !this.showFail) {
        // if (item.percentage == 100 && this.timer && this.preStatus && this.changeStatus && item.offset < 28.28) {
        clearTimeout(this.timer)
        this.timer = null
        // 预览图片
        this.$emit('play', item.imgUrl, item.videoUrl)
        this.preStatus = false
        setTimeout(() => {
          this.preStatus = true
        }, 600)
      } else if (this.timer) {
        clearTimeout(this.timer)
        this.timer = null
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.custom-drag-list {
  .flex-center {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .area {
    width: 100%;

    .view {
      display: flex;
      justify-content: center;
      align-items: center;

      .upload-box {
        position: relative;
        font-size: 0;
        overflow: hidden;

        .upload-img {
          width: 100%;
          height: 100%;
        }
        .del-icon {
          width: 40rpx;
          height: 40rpx;
          position: absolute;
          top: 0;
          right: 0;
        }
        .play-icon {
          width: 46rpx;
          height: 46rpx;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
        .upload-bottom {
          height: 80rpx;
          background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.5));
          position: absolute;
          left: 0;
          bottom: 0;
          z-index: 999;
          .txt {
            font-size: 24rpx;
            text-align: center;
            color: #ffffff;
            line-height: 34rpx;
            margin-top: 16rpx;
          }
          .progress {
            position: absolute;
            bottom: 16rpx;
            left: 20rpx;
          }
          .close-icon {
            width: 24rpx;
            height: 24rpx;
            position: absolute;
            padding: 0 20rpx 10rpx 10rpx;
            right: 0;
            bottom: 0;
          }
        }
        .upload-fail {
          height: 56rpx;
          background: rgba(0, 0, 0, 0.54);
          position: absolute;
          left: 0;
          bottom: 0;
          z-index: 999;

          .warn-icon {
            width: 24rpx;
            height: 24rpx;
            margin-right: 6rpx;
          }
          .warn-text {
            font-size: 24rpx;
            text-align: center;
            color: #ffffff;
            line-height: 36rpx;
          }
        }
      }
    }

    .add-wrap {
      position: absolute;
      display: flex;
      align-items: center;
      justify-content: center;
      .add-box {
        display: inline-flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: #f5f8fb;
        vertical-align: top; // 解决相邻inline-block盒子会下移的问题

        .add-img {
          width: 42rpx;
          height: 36rpx;
        }
        .add-text {
          font-size: 20rpx;
          text-align: center;
          color: #adb3ba;
          line-height: 28rpx;
          margin-top: 12rpx;
        }
      }
    }
  }
}
</style>
