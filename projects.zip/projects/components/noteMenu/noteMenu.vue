<template>
  <view>
    <view class="note-note flex1">
      <scroll-view class="scroll-box" scroll-x :scroll-into-view="currentLabel">
        <view class="nav-box">
          <view
            class="nav-item flex1"
            :id="item.label"
            :class="currentLabel == item.label ? 'nav-item-active' : ''"
            v-for="(item, i) in navList"
            :key="i"
            @touchmove.stop
            @click="
              $u.throttle(() => {
                switchNav(item.label, i)
              }, 500)
            "
          >
            {{ item.text }}
            <view class="nav-item-line" v-show="currentLabel == item.label"></view>
          </view>
        </view>
      </scroll-view>
      <view class="arrow-box flex1" @click="$u.throttle(showNavPop, 500)">
        <image class="nav-arrow" :class="showPopup ? 'nav-arrow-active' : ''" src="http://img.yiqitogether.com/static/images/index/down_arrow.png" mode=""></image>
      </view>
    </view>
    <view v-if="showPopup" class="pop-box" @click="close">
      <scroll-view scroll-y="true" class="scroll-pop-box">
        <view class="channel-box flex1" @click.stop>
          <view class="channel-title flex1">
            我的频道
            <view class="channel-title-r" v-show="!editState" @click.stop="openEdit">编辑频道</view>
            <view class="channel-title-r" v-show="editState">
              <text class="cancel" @click.stop="cancelEdit">取消</text>
              <text @click.stop="$u.throttle(editChannelRquest, 500)">保存</text>
            </view>
          </view>
          <view class="drag-lable-box flex1">
            <basic-drag v-model="myChannelList" :column="4" itemKey="text" itemHeight="42px" :dragState="editState">
              <template #item="{ element }">
                <view class="lable-item drag-item">
                  {{ element.text }}
                  <image class="edit_icon" v-show="editState && !(element.label == 'RECOMMEND' || element.label == 'ATENTION')" src="http://img.yiqitogether.com/static/images/delete-channel.png" mode="" @click.stop="editChannelEvent('delete', element, element.label)"></image>
                </view>
              </template>
            </basic-drag>
          </view>
          <!-- <view class="lable-box">
            <view class="lable-item" v-for="(item, i) in myChannelList" :key="i" @click="chooseMyChannel(item, i)">
              {{ item.text }}
              <image class="edit_icon" v-show="editState && !(item.label == 'RECOMMEND' || item.label == 'ATENTION')" src="http://img.yiqitogether.com/static/images/delete-channel.png" mode="" @click.stop="editChannelEvent('delete', item, i)"></image>
            </view>
          </view> -->
          <view class="channel-title flex1">添加频道</view>
          <view class="lable-box">
            <view class="lable-item" v-for="(item, i) in allChannerList" :key="i">
              {{ item.text }}
              <image class="edit_icon" v-show="editState" src="http://img.yiqitogether.com/static/images/add-channel.png" mode="" @click="editChannelEvent('add', item, item.label)"></image>
            </view>
          </view>
        </view>
      </scroll-view>
    </view>
  </view>
</template>

<script>
import findModel from '@/model/find.js'
import BasicDrag from '@/components/basic-drag/index.vue'
export default {
  components: { BasicDrag },
  name: 'noteMenu',
  props: [
    // 频道列表数据
    'channelData',
    'navList',
    'currentLabel'
  ],
  data() {
    return {
      // 展开状态
      showPopup: false,
      // 编辑状态
      editState: false,
      // 添加频道列表
      allChannerList: [],
      // 我的频道列表
      myChannelList: []
    }
  },
  methods: {
    /**
     * 选择我的频道
     */
    chooseMyChannel(item) {
      // 非编辑状态下
      if (!this.editState) {
        this.switchNav(item.label)
      }
    },
    /**
     * 取消编辑
     */
    cancelEdit() {
      this.editState = false
      this.handlePopData()
    },
    /**
     * 打开编辑
     */
    openEdit() {
      this.editState = true
    },
    open() {
      // this.showPopup = false
    },
    close() {
      this.showPopup = false
      this.$emit('showChannelBox', this.showPopup)
    },
    /**
     * 编辑频道
     */
    editChannelEvent(type, item, label) {
      // console.log(type, item, index);
      // return
      let arrList = []
      if (type == 'add') {
        arrList = this.allChannerList
        this.myChannelList.push(item)
      } else if (type == 'delete') {
        arrList = this.myChannelList
        this.allChannerList.push(item)
      }
      arrList.map((element, index) => {
        if (element.label === label) {
          arrList.splice(index, 1)
        }
      })
    },
    /**
     * 处理频道数据回传
     */
    handleChannelData() {
      let myList = []
      let myListStr = ''
      for (let i = 0; i < this.myChannelList.length; i++) {
        myList.push(this.myChannelList[i].label)
      }
      if (myList.length !== 0) {
        myListStr = myList.join(',')
      }
      return myListStr
    },
    /**
     * 编辑频道请求
     */
    editChannelRquest() {
      let datas = {
        twitterChannel: this.handleChannelData()
      }
      findModel
        .editChannel(datas)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.resetCreate()
            this.$emit('saveMyLabel')
            this.showMyToast('保存成功')
          } else {
            this.showMyToast(res.message)
          }
        })
        .catch(err => {
          this.showMyToast(err)
        })
    },
    /**
     * 显示弹窗
     */
    showNavPop() {
      this.showPopup = !this.showPopup
      this.$emit('showChannelBox', this.showPopup)
      if (this.showPopup) {
        this.handlePopData()
      }
    },
    /**
     * 处理弹窗数据
     */
    handlePopData() {
      let channelDataCopy = JSON.parse(JSON.stringify(this.channelData))
      this.myChannelList = JSON.parse(JSON.stringify(this.navList))
      this.allChannerList = channelDataCopy.taList || []
    },
    /**
     * 切换nav
     * 全部时，将请求label置空，请求全部
     */
    switchNav(label, index) {
      if (this.currentLabel === label) return
      this.resetCreate()
      // if (label === 'ATENTION' || label === 'RECOMMEND') {
      //   // 调用笔记 推荐 || 关注接口
      //   this.$emit('getNoteAtentionOrRecommend', label)
      // } else {
      //   this.$emit('check', label)
      // }
      this.$emit('check', index)
    },
    /**
     * 恢复初始状态
     */
    resetCreate() {
      this.showPopup = false
      this.editState = false
      this.$emit('showChannelBox', this.showPopup)
    },
    /**
     * 提示
     */
    showMyToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.note-note {
  width: 100%;
  height: 84rpx;
  box-sizing: border-box;
  background: #fff;
  padding-left: 14rpx;

  .scroll-box {
    max-width: 670rpx;
    width: 670rpx;
    white-space: nowrap;
    touch-action: none;
  }

  .nav-box {
    display: flex;
    box-sizing: border-box;
  }

  .nav-item {
    flex-direction: column;
    font-size: 28rpx;
    color: #bdc1c5;
    padding: 0 20rpx;
  }

  .nav-item-active {
    color: #2a343e;
    font-weight: bold;
  }

  .nav-item-line {
    width: 20rpx;
    height: 6rpx;
    background: #2a343e;
    border-radius: 2rpx;
    margin-top: 4rpx;
  }

  .arrow-box {
    height: 84rpx;
    width: 80rpx;
    justify-content: center;
    background: #fff;
  }

  .nav-arrow {
    width: 24rpx;
    height: 24rpx;
    margin-bottom: 6px;
    transition: transform 0.5s linear;
  }
}

.nav-arrow-active {
  transform: rotate(180deg);
}

.scroll-pop-box {
  width: 100%;
  // max-height: 750rpx;
  background-color: #fff;
  border-radius: 0 0 40rpx 40rpx;
  padding: 30rpx 0 50rpx;
}

.pop-box {
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  .channel-box {
    flex-direction: column;
    box-sizing: border-box;
  }

  .channel-title {
    width: 100%;
    padding: 0 30rpx;
    box-sizing: border-box;
    font-size: 24rpx;
    justify-content: space-between;
  }

  .channel-title-r {
    color: #fe5e10;
  }

  .cancel {
    color: #adb3ba;
    margin-right: 38rpx;
  }

  .lable-box {
    width: 100%;
    display: grid;
    grid-template-columns: repeat(auto-fill, 164rpx);
    grid-gap: 12rpx;
    justify-content: center;
    padding: 24rpx 0;
  }

  .lable-item {
    position: relative;
    width: 164rpx;
    height: 72rpx;
    line-height: 72rpx;
    text-align: center;
    border: 2rpx solid #f6f6f8;
    border-radius: 8rpx;
    font-size: 28rpx;
  }

  .edit_icon {
    position: absolute;
    top: -6rpx;
    right: -8rpx;
    width: 32rpx;
    height: 32rpx;
    background: #dfe2e7;
    border-radius: 50%;
  }
}

.drag-lable-box {
  width: 100%;
  touch-action: none;
  padding: 24rpx 0;
  justify-content: center;
}
</style>
