<template>
  <view v-if="isShow">
    <u-popup :show="isShow" mode="bottom" :round="24" duration="0" bgColor="#FFF" customStyle="">
      <view class="login_box">
        <image class="close_icon" src="@/static/images/myImgs/bjzl_zybj_delete@2x.png" mode="" @click="closeBtn"></image>
        <block v-if="!successStatus">
          <image class="login_icon" src="@/static/images/login_logo.png" mode=""></image>
          <text class="text-title">登录发现精彩活动</text>
          <view class="input_box">
            <view class="input_box_l" @click="onShowAreaCode(true)">
              +{{ areaCode }}
              <image class="down_arrow" src="@/static/images/myImgs/arrow_down@2x.png" mode=""></image>
            </view>
            <input class="phone_input_box" v-model="phoneNumber" type="number" maxlength="11" placeholder="请输入手机号码" @input="changePhone" placeholder-style="font-size:28rpx;" />
          </view>
          <view class="input_box space_b">
            <input class="phone_input_box" v-model="codeNumber" type="number" maxlength="6" placeholder-style="font-size:28rpx;" placeholder="输入验证码" @input="changeCode" />
            <view class="tips" :class="!isSending ? 'no_tap' : ''" @tap="getCode">
              {{ tips }}
            </view>
            <u-toast ref="uToast"></u-toast>
            <u-code :seconds="seconds" @end="end" @start="start" ref="uCode" changeText="重新发送(Xs)" endText="重新发送" @change="codeChange"></u-code>
          </view>
          <view class="code_text">
            <text>邀请码</text>
            {{ code }}
          </view>

          <view class="btn_wrap">
            <u-button type="error" color="#ff466d" text="登录" :disabled="!isPhoneValid" @click="handleLogin"></u-button>
          </view>

          <view class="bottom-container">
            <view class="img-wrap" @click="changeCheck">
              <image class="radio-img" v-if="isChecked" src="@/static/images/myImgs/gouxuan@2x.png" alt=""></image>
              <image class="radio-img" v-else src="@/static/images/myImgs/weixuan@2x.png" alt=""></image>
            </view>
            <view class="others-wrap">
              若手机号未注册将进入注册流程，注册即为已阅读并同意
              <text class="emphasize" @click="goDetail(1)">《用户服务协议》</text>
              和
              <text class="emphasize" @click="goDetail(2)">《隐私政策》</text>
            </view>
          </view>
        </block>
        <block v-if="successStatus">
          <image class="success_img" src="http://img.yiqitogether.com/yqyq-app/images/successImg.png" mode=""></image>
          <view class="texe_t">{{ content }}</view>
          <view class="texe_b">可前往APP参加活动</view>
          <view class="downloads_btn" @click="downloadBtn">下载APP</view>
        </block>
      </view>
    </u-popup>
    <!-- 区号选择弹出框 -->
    <yue-areacode-picker :show="showAreaCode" @show="onShowAreaCode" @select="selectAreacode" />
  </view>
</template>

<script>
import loginModel from '@/model/login.js'
import { LOGIN_USERID, LOGIN_TOKEN, USER_INFO, PHONE_NUM, AUTH_SIMPLE, AUTH_COMPLEX, LOGIN_NICKNAME, COUNTRY_CODE } from '@/utils/cacheKey'

import { save } from '../../utils/store'

export default {
  name: 'login-popup',
  props: {
    isShow: {
      type: Boolean,
      default: false
    },
    code: {
      type: String,
      default: ''
    },
    content: {
      type: String,
      default: '助力成功'
    }
  },
  data() {
    return {
      phoneNumber: '',
      isPhoneValid: false,
      isCodeValid: false,
      isChecked: false,
      showAreaCode: false, // 国家区号弹窗显隐
      isSending: true, // 验证码是否可点击
      tips: '',
      areaCode: '86',
      // 倒数60秒
      seconds: 60,
      codeNumber: '',
      successStatus: false
    }
  },
  methods: {
    closeBtn() {
      this.$emit('close')
    },
    downloadBtn() {
      uni.navigateTo({
        url: '/pagesMy/my/download'
      })
    },
    codeChange(text) {
      this.tips = text
    },
    end() {
      // uni.$u.toast('倒计时结束');
      this.isSending = true
    },
    start() {
      // uni.$u.toast('倒计时开始');
      this.isSending = false
    },
    // 国家区号弹出框显隐
    onShowAreaCode(flag) {
      this.showAreaCode = flag
    },
    // 切换所选区号
    selectAreacode(item) {
      this.showAreaCode = false
      this.areaCode = item.phoneCode
    },
    // 输入手机号
    changePhone(e) {
      if (e.detail.value && e.detail.value.length === 11) {
        this.isPhoneValid = true
      } else {
        this.isPhoneValid = false
      }
    },
    // 输入验证码
    changeCode(e) {
      if (e.detail.value && e.detail.value.length === 6) {
        this.isCodeValid = true
      } else {
        this.isCodeValid = false
      }
    },
    // 切换单选框
    changeCheck() {
      this.isChecked = !this.isChecked
    },
    // 跳转用户服务协议或隐私政策
    goDetail(type) {
      if (type == 2) {
        uni.navigateTo({
          url: '/pages/login/privacyPolicy'
        })
      } else {
        uni.navigateTo({
          url: '/pages/login/userService'
        })
      }
    },
    // 重新发送
    handleResend() {
      this.codeNumber = ''
      this.sendSmsCode()
    },
    // 获取验证码
    getCode() {
      // 判断手机号格式是否符合要求
      // if (!/^1[3456789]\d{9}$/.test(this.phoneNumber)) {
      //   this.myShowToast('手机号格式不正确')
      //   return false
      // }
      let params = {
        mobile: this.phoneNumber,
        countryCode: '+' + this.areaCode,
        smsType: 'REGISTER_LOGIN_VERIFY'
      }
      // 调用接口
      loginModel
        .sendMsg(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.myShowToast('发送成功')
            this.$refs.uCode.start()
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {})
    },

    // 登录/注册
    handleLogin() {
      if (!this.isCodeValid) {
        return this.myShowToast('请输入正确的验证码')
      }
      // 判断复选框
      if (!this.isChecked) {
        return this.myShowToast('请阅读并勾选用户服务协议和隐私政策')
      }
      // 调用接口
      let params = {
        mobile: this.phoneNumber,
        code: this.codeNumber,
        countryCode: '+' + this.areaCode,
        invitationCode: this.code
      }
      loginModel.mobileLogin(params).then(res => {
        if (res.code == 'SUCCESS') {
          this.myShowToast('登录成功')

          let { numberId, token, authSimple, authComplex, nickName, mobile, countryCode } = res.data.userDto
          uni.setStorageSync(LOGIN_USERID, numberId)
          uni.setStorageSync(LOGIN_NICKNAME, nickName)
          uni.setStorageSync(LOGIN_TOKEN, token)
          uni.setStorageSync(PHONE_NUM, mobile)
          uni.setStorageSync(AUTH_SIMPLE, authSimple)
          uni.setStorageSync(AUTH_COMPLEX, authComplex)
          uni.setStorageSync(USER_INFO, JSON.stringify(res.data.userDto))
          uni.setStorageSync(COUNTRY_CODE, countryCode)
          setTimeout(() => {
            this.successStatus = true
          }, 1500)
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },

    myShowToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.login_box {
  position: relative;
  width: 100%;
  min-height: 1100rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.close_icon {
  position: absolute;
  right: 24rpx;
  top: 24rpx;
  width: 32rpx;
  height: 32rpx;
}

.login_icon {
  width: 124rpx;
  height: 122rpx;
  margin-top: 134rpx;
}

.text-title {
  font-size: 28rpx;
  font-family: PingFang SC, PingFang SC-Regular;
  font-weight: 400;
  color: #2a2a2a;
  margin-top: 24rpx;
}

.input_box {
  width: 76%;
  height: 60rpx;
  padding: 0 18rpx 0 20rpx;
  // background-color: aliceblue;
  margin-top: 40rpx;
  display: flex;
  align-items: center;
  border-bottom: 2rpx solid #f2f2f2;
}

.input_box_l {
  height: 40rpx;
  border-right: 2rpx solid #eee;
  display: flex;
  align-items: center;
  font-size: 24rpx;
  color: #4b4b4b;
  padding-right: 22rpx;
  margin-right: 22rpx;
}

.down_arrow {
  width: 20rpx;
  height: 12rpx;
  margin-left: 10rpx;
}

.phone-input-box {
  flex: 1;
  margin-left: 20rpx;
  height: 96rpx;
  color: #282828 !important;
  font-size: 28rpx !important;
  background-color: aqua;
}

.space_b {
  justify-content: space-between;
}

.tips {
  width: 200rpx;
  height: 40rpx;
  line-height: 40rpx;
  color: #eb566f;
  font-size: 24rpx;
  border-left: 2rpx solid #eeeeee;
  padding-left: 20rpx;
  box-sizing: border-box;
  white-space: nowrap;
}

.no_tap {
  opacity: 0.5;
}

.code_text {
  width: 78%;
  padding-left: 20rpx;
  font-size: 28rpx;
  color: #a7acb6;
  margin-top: 44rpx;

  // background-color: #F2F2F2;
  text {
    font-size: 24rpx;
    margin-right: 30rpx;
  }
}

.btn_wrap {
  width: 82%;
  height: 76rpx;
  box-sizing: border-box;
  margin-top: 118rpx;

  /deep/.u-button {
    height: 76rpx;
    border-radius: 48rpx;
    margin: 0;
    border: none !important;
    background-color: #ff466d;
    color: #fff;
  }

  /deep/.u-button--disabled {
    background-color: #ffe2e8 !important;
    color: #fff !important;
    border: none !important;
    opacity: 1 !important;
  }

  /deep/ .u-button__text {
    font-size: 32rpx !important;
  }

  /deep/.u-loading-icon__spinner {
    width: 24rpx !important;
    height: 24rpx !important;
  }
}

.bottom-container {
  width: 82%;
  margin-top: 30rpx;
  display: flex;
  color: #a7acb6;

  .img-wrap {
    flex-shrink: 0;
    padding-right: 12rpx;
    font-size: 0;

    .radio-img {
      width: 24rpx;
      height: 24rpx;
    }
  }

  .others-wrap {
    font-size: 20rpx;
    font-weight: 500;
    line-height: 26rpx;
  }
}

.modal-content {
  font-size: 24rpx;
  font-weight: 500;
  text-align: center;
  color: #a7acb6;
  line-height: 46rpx;
}

.emphasize {
  color: #ff466d !important;
}

.success_img {
  width: 388rpx;
  height: 384rpx;
  margin-top: 36rpx;
}

.texe_t {
  font-size: 36rpx;
  font-weight: 500;
  color: #2a2a2a;
  margin-top: -30rpx;
}

.texe_b {
  font-size: 28rpx;
  color: #a4a4a4;
  margin-top: 4rpx;
}

.downloads_btn {
  width: 360rpx;
  height: 76rpx;
  background: #eb566f;
  border-radius: 38rpx;
  font-size: 36rpx;
  font-weight: 500;
  text-align: center;
  color: #ffffff;
  line-height: 76rpx;
  margin-top: 148rpx;
}
</style>
