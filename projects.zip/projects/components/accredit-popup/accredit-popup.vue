<template>
  <view>
    <!-- class="popupSystem" -->
    <view>
      <u-popup :show="showAccredit" mode="center" :round="24" duration="0" bgColor="#FFF" customStyle="width: 542rpx;">
        <view class="popup_box flex1">
          <image v-if="isImg" src="http://img.yiqitogether.com/static/images/index/icon_dingwei.png" class="img_style" mode=""></image>
          <view class="tishi">{{ systemTitle }}</view>
          <view class="change">{{ systemContent }}</view>
          <view class="btn2">
            <u-button :style="{ color: themeColor }" shape="circle" text="拒绝" class="quxiao" customStyle="width: 190rpx;height: 72rpx;" @click="cancels"></u-button>
            <u-button :color="themeColor" type="error" shape="circle" :text="isImg ? '使用时允许' : '允许'" customStyle="width: 190rpx;height: 72rpx;" @click="requestAndroidPermission"></u-button>
          </view>
        </view>
      </u-popup>
    </view>
    <u-notify ref="uNotify"></u-notify>
  </view>
</template>

<script>
import permision from '@/js_sdk/wa-permission/permission.js'
import { save, load } from '@/utils/store.js'
import { EXTERNAL_STORAGE, TIPS_SHOW, CAMERA_ACCREDIT, LOGIN_USERID } from '@/utils/cacheKey.js'
export default {
  name: 'system-popup',
  props: {
    // 标题
    systemTitle: {
      type: String,
      default: ''
    },
    // 内容
    systemContent: {
      type: String,
      default: ''
    },
    // 授权ID
    permisionID: {
      type: String,
      default: ''
    },
    // 缓存ID
    cacheId: {
      type: String,
      default: ''
    },
    // 是否包含图片
    isImg: {
      type: Boolean,
      default: false
    },
    // 是否是onShow里调用 如onShow调用拒绝将不再弹出
    isOnShow: {
      type: Boolean,
      default: false
    },
    // 主题色，旧版主题色#ff466d，新版主题色#FE5E10
    themeColor: {
      type: String,
      default: '#FE5E10'
    }
  },
  data() {
    return {
      showAccredit: false,
      accreditTop: false
    }
  },
  methods: {
    /**
     * 触发获取授权状态
     */
    triggerEvent() {
      // #ifdef APP
      let that = this
      let localCache = uni.getStorageSync(this.cacheId) !== '' ? Number(uni.getStorageSync(this.cacheId)) : 2
      console.log(this.cacheId, localCache, uni.getStorageSync(this.cacheId))
      let isIos = plus.os.name == 'iOS'
      if (!isIos) {
        if (localCache == 1) {
          //成功获取权限调用事件
          that.$emit('successAccredit')
        } else if (localCache == 0 || localCache == -1) {
          if (!this.isOnShow) {
            this.showAccredit = true
          }
        } else {
          this.showAccredit = true
        }
      } else {
        //成功获取权限调用事件
        that.$emit('successAccredit')
      }
      // #endif
      // #ifdef H5
      this.$emit('successAccredit')
      // #endif
    },
    /**
     *  获取授权状态
     */
    async requestAndroidPermission() {
      let that = this
      let permisionID = this.permisionID
      this.$refs.uNotify.show({
        top: 20,
        type: 'error',
        color: '#000',
        bgColor: '#e8e8e8',
        message: that.systemTitle + ':' + that.systemContent,
        duration: 1000 * 6,
        fontSize: 26,
        safeAreaInsetTop: true
      })
      // 拿到结果
			try{
				let result = await permision.requestAndroidPermission(permisionID)
				console.log(result, 'result1')
				that.showAccredit = false
				if (result == 1) {
				  //成功获取权限调用事件
				  that.$emit('successAccredit')
				} else if (result == -1) {
				  that.myShowToast('权限被禁用，请前往应用设置授权')
				}
				// 2 默认  1 以获取权限  0 拒绝本次权限 -1 永久拒绝权限
				uni.setStorageSync(this.cacheId, result)
			}catch(e){
				console.log(e);
				//TODO handle the exception
			}
      this.$refs.uNotify.close()
    },
    // 关闭弹框
    cancels() {
      if (this.isOnShow) {
        uni.setStorageSync(this.cacheId, 0)
      }
      this.showAccredit = false
    },
    // 提示
    myShowToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    }
  }
}
</script>

<style scoped lang="scss">
.allheaders {
  //   width: 100%;
  //   height: 100vh;
  z-index: 99999999;
  overflow: hidden;
}

.popup_box {
  flex-direction: column;
}

.img_style {
  width: 102rpx;
  height: 144rpx;
  margin-bottom: -56rpx;
  padding-top: 46rpx;
}

.popupSystem {
  text-align: center;
  background-color: red;
  z-index: 99999999;
}

.tishi {
  font-size: 28rpx;
  font-family: OPPOSans, OPPOSans-Bold;
  font-weight: 500;
  text-align: center;
  color: #333333;
  line-height: 44rpx;
  margin-top: 60rpx;
}

.change {
  font-size: 24rpx;
  font-family: OPPOSans, OPPOSans-Regular;
  font-weight: 400;
  text-align: center;
  color: #333333;
  line-height: 46rpx;
  margin-top: 20rpx;
  padding: 0 30rpx;
}

.btn2 {
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin-top: 40rpx;
  /* #ifdef APP-NVUE */
  flex-direction: row;
  width: 542rpx;
  padding: 0 40rpx 30rpx;
  /* #endif */

  .quxiao {
    background-color: #f6f6f6;
    border: #f6f6f6;
    font-weight: 400;
    color: #fe5e10;
  }
}

/* #ifndef APP-NVUE */
/deep/ .u-button__text {
  font-size: 24rpx !important;
}
/* #endif */
</style>
