<template>
  <view class="page">
    <!-- 页面固定背景 -->
    <image src="http://img.yiqitogether.com/yqyq-app/images/shop_index_bgi.png" mode="" class="page-img" v-show="!scrollShow"></image>

    <!-- 状态栏 -->
    <view class="status_bar" :style="scrollShow ? 'background: #fff;' : ''"></view>

    <!-- 顶部导航栏 -->
    <view class="status-top-bar" :style="scrollShow ? 'background: #fff;' : ''">
      <image class="back-image" src="@/static/images/back_black.png" mode="" @click="goBack()"></image>
      <view class="top-input-box" @tap.stop="$u.throttle(goSearch, 500)" :style="scrollShow ? 'background: #F7F7F7;' : ''">
        <image class="search-icon" src="@/static/images/sousuo.png" mode="aspectFill" />
        <view class="top-input">搜索</view>
      </view>
      <image src="@/static/images/details_more.png" alt="" class="shop-order" @click="morePopupFlag = true"></image>
    </view>

    <!-- banner-->
    <image src="http://img.yiqitogether.com/yqyq-app/images/shop_banner.png" mode="" class="shop-banner" @click="$u.throttle(goStore, 500)"></image>

    <!-- 分类入口 -->
    <view class="grid-box" v-if="list.length !== 0">
      <view class="slide-box">
        <view
          class="grid-item"
          v-for="(listItem, listIndex) in list"
          :key="listIndex"
          @click="
            $u.throttle(() => {
              changeCategory(listItem)
            }, 500)
          "
        >
          <image :src="listItem.url" alt="" class="grid-img-item" />
          <view class="grid-text">
            {{ listItem.text }}
          </view>
        </view>
      </view>
    </view>

    <!-- tab切换 -->
    <view class="screen-box" :style="scrollShow ? 'background: #fff;' : ''">
      <view class="screen-bgc">
        <view :class="['tab-item', currentCode === item.code ? 'current-item' : '']" v-for="(item, index) in tabList" :key="index" @click="changeTab(item.code)">
          {{ item.name }}
          <image v-if="currentCode === item.code" src="@/static/images/shop_tab_current.png" alt="" class="current-line"></image>
        </view>
      </view>
    </view>

    <block v-if="goodsListData.length && !showLoading">
      <!-- 商品列表 -->
      <shop-list :goodsListData="goodsListData"></shop-list>

      <!-- 加载更多 -->
      <view class="status-text">
        <u-loadmore :status="status" :fontSize="22" nomore-text="到底了~" :marginTop="0" />
      </view>
    </block>

    <!-- 列表无数据 -->
    <view class="empty-box" v-if="!goodsListData.length && !showLoading">
      <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/details_user_none.png" alt="" mode="" />
      <view class="empty-text">暂无数据</view>
    </view>

    <!-- 更多操作弹窗 -->
    <view class="more-popup" v-show="morePopupFlag" @click="morePopupFlag = false">
      <view class="more-popup-box">
        <image class="more-image" src="@/static/images/details_more_corners.png" mode=""></image>
        <view class="more-popup-content">
          <view
            :class="['popup-info', 'flex1', i == 0 && showTextList.length == 2 ? 'border_bottom' : '']"
            :style="{ opacity: item.state ? '1' : '0.5' }"
            v-for="(item, i) in showTextList"
            :key="i"
            @click="
              $u.throttle(() => {
                handleMoreClick(item)
              }, 500)
            "
          >
            <image class="more-popup-icon" :src="item.img" mode=""></image>
            <text>{{ item.text }}</text>
          </view>
        </view>
      </view>
    </view>
    <!-- 加载中 -->
    <yue-loading loadTxet="加载中..." v-show="showLoading" />
  </view>
</template>

<script>
// 接口导入
import shopModel from '@/model/shop.js'
import toolsModel from '@/model/tools.js'
import MyInfo from '@/model/my.js'
import { getLocation } from '@/utils/tools.js'
export default {
  watch: {
    currentAddress: 'handleCityName'
  },
  data() {
    return {
      showLoading: true,
      storeStatus: 1, // 1-接口还未请求完 2-非商户审核成功 3-商户审核成功
      errMessage: '',
      merchantToKen: '',
      morePopupFlag: false,
      // 数据加载状态
      status: 'loadmore',
      // 当前经纬度
      latlon: {},
      scrollTop: 0,
      currentAddress: '北京市',
      background: ``,
      // 当前选中的tab项code
      currentCode: 1,
      // tab数据
      tabList: [
        {
          name: '热门商户',
          code: 1,
          type: 'RECOMMEND'
        },
        {
          name: '附近商户',
          code: 2,
          type: 'NEARBY'
        }
      ],
      showTextList: [
        {
          id: 'order',
          img: '../../static/images/shop_index_order.png',
          text: '订单管理',
          state: true,
          path: '/pagesShop/orderManage/index'
        }
      ],
      // 当前页数
      pageNo: 1,
      // 总页数
      pages: 0,
      // 分类数据
      list: [],
      //商品列表数据
      goodsListData: [],
      // 轮播图数据
      swiperList: [],
      scrollShow: false,
      shop: {} //店铺信息
    }
  },
  onLoad() {
    // 获取位置信息
    // this.getLatlon()
    this.getCityLatLon()
    // 获取页面数据
    this.getShopInfo()
    this.getStoreStatus()
  },
  onBackPress({ from }) {
    if (from == 'navigateBack') {
      return false
    } else {
      this.goBack()
      return true
    }
  },
  onPageScroll(e) {
    this.scrollPage(e)
  },
  // 在scroll-view中使用onReachBottom是无效的，用@scrolltolower这个事件来监听
  onReachBottom() {
    // this.$noMultipleClicks()
    this.pullUpEvent()
  },
  methods: {
    /**
     * 退出
     */
    goBack() {
      uni.switchTab({ url: '/pages/find/index' })
    },
    handleMoreClick(item) {
      uni.navigateTo({ url: item.path })
    },
    /**
     * 去除城市中多余的市
     */
    handleCityName() {
      let str = this.currentAddress
      let char = '市'
      const regex = new RegExp(`${char}+`, 'g')
      this.currentAddress = str.replace(regex, char)
    },
    changeAddress(url) {
      let that = this
      uni.navigateTo({
        url,
        events: {
          getNewList: function (data) {
            console.log(`页面shop,之前地址：${that.currentAddress},更新后地址${data}`)
            that.currentAddress = data
            uni.setStorageSync('city', data)
            that.getCityLatLon()
          }
        }
      })
    },
    goSearch() {
      uni.navigateTo({ url: '/pagesShop/shop/shopSearch' })
    },
    // 切换分类
    changeCategory(item) {
      uni.navigateTo({ url: `/pagesShop/shop/shop-class?id=${item.code}&name=${item.text}` })
    },
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      if (this.isApp) {
        winHeight = winHeight - 200
      } else {
        winHeight = winHeight - 210
      }
      return winHeight
    },
    // 获取当前城市的经纬度
    getCityLatLon() {
      let that = this
      let datas = {
        city: uni.getStorageSync('city') || this.currentAddress
      }
      this.currentAddress = datas.city
      toolsModel
        .getCityLocation(datas)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let location = res.data.location
            let latlon1 = {
              lat: location.lat,
              lon: location.lon
            }
            that.latlon = latlon1
            uni.setStorageSync('position', JSON.stringify(latlon1))
            that.pageNo = 1
            that.goodsListData = []
            that.getShopLable(that.tabList[that.currentCode - 1].type)
          } else {
            this.showLoading = false
            that.showToast1(res.message)
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    //轮播图跳转
    toSwiper(e) {
      let obj = {
        type: '1',
        openUrl: '/home/yiqi'
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    getLatlon() {
      this.latlon = uni.getStorageSync('position')
      // #ifdef APP
      getLocation().then(res => {
        this.latlon = res
      })
      // #endif
      toolsModel
        .getAddressInfo({
          position: this.latlon
        })
        .then(res => {
          this.currentAddress = res.data.city
        })
    },
    // 监听滚动，动态修改tab背景色
    scrollPage(e) {
      if (e.scrollTop > 0) {
        this.scrollShow = true
      } else {
        this.scrollShow = false
      }
    },
    // 获取列表数据
    getShopInfo() {
      shopModel
        .getShopBanner()
        .then(res => {
          this.list = res.data.shopType
          this.swiperList = res.data.indexBanner
          this.shop = res.data.shop ? res.data.shop : {}
          if (this.shop.merchantNo) {
            let dataInfo = {
              merchantNo: this.shop.merchantNo,
              shopId: this.shop.shopId
            }
            this.showTextList.push({
              id: 'shop',
              img: '../../static/images/shop_index_shop.png',
              text: '商品管理',
              state: true,
              path: '/pagesShop/productManage/index?dataInfo=' + JSON.stringify(dataInfo)
            })
          }
        })
        .catch(err => {})
    },
    // 提示弹窗
    showToast1(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    },
    //获取Tab数据
    getShopLable(type) {
      let position = uni.getStorageSync('position')
      let pageNo = this.pageNo
      var datas = {
        type,
        position,
        pageNo
      }
      shopModel
        .getShopTab(datas)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.goodsListData = this.goodsListData.concat(res.data.page.list)
            this.pages = res.data.page.pages
            let listLength = res.data.page.list.length
            let limit = res.data.page.limit
            if (res.data.page.total == 0) {
              this.status = 'none'
            } else {
              if (listLength < limit) {
                this.status = 'nomore'
              } else {
                this.status = 'loadmore'
                this.pageNo++
              }
            }
            this.showLoading = false
          } else {
            this.showLoading = false
            this.status = 'none'
            this.showToast1(res.message)
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 上拉触底事件
    pullUpEvent() {
      if (this.status !== 'nomore') {
        if (this.pageNo <= this.pages) {
          this.status = 'loading'
          setTimeout(() => {
            this.getShopLable(this.tabList[this.currentCode - 1].type)
          }, 100)
        } else {
          this.status = 'nomore'
        }
      }
    },
    // 切换tab事件
    changeTab(code) {
      if (this.currentCode == code) {
        return
      }
      this.currentCode = code
      this.pageNo = 1
      this.goodsListData = []
      this.showLoading = true
      this.getShopLable(this.tabList[code - 1].type)
    },
    // 获取商户入驻状态
    getStoreStatus() {
      MyInfo.getMerchantInfo().then(res => {
        if (res.code == 'SUCCESS') {
          let info = res.data.applyMerchantInfo || {}
          if (res.data.applied && info.merchantState && info.merchantState.label == 'APPLYPASSYES') {
            this.getToken()
          } else {
            this.storeStatus = 2
          }
        }
      })
    },
    // 获取商户token
    getToken() {
      MyInfo.getMerchantToKen()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.merchantToKen = res.data.merchantToKen || ''
          } else {
            this.errMessage = res.message
          }
          this.storeStatus = 3
        })
        .catch(err => {
          this.storeStatus = 3
        })
    },
    // 跳转商户资金页面
    goMerchant() {
      if (this.merchantToKen) {
        let token = load(LOGIN_TOKEN)
        let obj = {
          type: '2',
          openUrl: '/business',
          token: token || '',
          MerToken: this.merchantToKen
        }
        getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
        this.$nextTick(() => {
          uni.navigateTo({ url: '/pages/my/webView' })
        })
      } else {
        uni.showToast({
          title: this.errMessage || '获取商户信息失败',
          icon: 'none',
          duration: 2000
        })
      }
    },
    // 跳转商家入驻
    goStore() {
      if (this.storeStatus == 3) {
        this.goMerchant()
      } else if (this.storeStatus == 2) {
        uni.navigateTo({
          url: '/pagesMy/my/Mybrand'
        })
      } else {
        uni.showToast({
          title: '商家信息获取中，请稍后再试',
          icon: 'none'
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.page {
  width: 100vw;
  min-height: 100vh;
  // overflow: hidden;
}

.status_bar {
  height: calc(var(--status-bar-height) + 20rpx);
  width: 100%;
  position: sticky;
  top: 0;
  z-index: 99;
}

.page-img {
  position: fixed;
  top: 0;
  left: 0;
  z-index: -1;
  display: block;
  width: 750rpx;
  height: 812rpx;
}

.shop-banner {
  display: block;
  width: 678rpx;
  height: 144rpx;
  margin: 32rpx auto 49rpx;
}

.status-top-bar {
  position: sticky;
  top: calc(var(--status-bar-height) + 20rpx);
  left: 0;
  z-index: 99;
  box-sizing: border-box;
  width: 750rpx;
  height: 88rpx;
  margin: 0 auto;
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.top-input-box {
  flex: 1;
  height: 72rpx;
  display: flex;
  align-items: center;
  background-color: #fff;
  border-radius: 36rpx;
  color: #c8c8c8;
  font-size: 24rpx;

  .search-icon {
    flex-shrink: 0;
    width: 40rpx;
    height: 40rpx;
    margin-right: 14rpx;
    margin-left: 22rpx;
  }
}

.placeholder {
  font-size: 24rpx;
  // font-family: Source Han Sans CN, Source Han Sans CN-Regular;
  font-weight: 400;
  text-align: left;
  color: #a6acb2;
}

.shop-order {
  width: 44rpx;
  height: 44rpx;
  display: block;
  padding: 22rpx 36rpx 22rpx 30rpx;
  flex-shrink: 0;
}

.swipt-box {
  width: 702rpx;
  height: 220rpx;
  // background: linear-gradient(90deg, #008bfc, #6ed7ff 98%);
  border-radius: 20rpx;
  margin: 0 auto 20rpx;
  margin-top: calc(var(--status-bar-height) + 20rpx);
}

.swipt-img {
  width: 100%;
  height: 100%;
  border-radius: 24rpx;
}

.body-box {
  position: relative;
  z-index: 1;
  width: 750rpx;
  background-color: #fff;
  border-radius: 36rpx 36rpx 0px 0px;
  overflow: hidden;
}

.grid-box {
  width: 750rpx;
  box-sizing: border-box;
  padding: 0rpx 60rpx;
  overflow: hidden;
}

.slide-box {
  width: 100%;
  overflow-x: auto;
  white-space: nowrap;
}

.grid-item {
  width: 72rpx;
  display: inline-block;
  margin-right: 80rpx;
}

.grid-img-item {
  display: block;
  width: 72rpx;
  height: 72rpx;
  margin: 0 auto 20rpx;
}

.grid-text {
  font-size: 24rpx;
  padding-bottom: 30rpx;
  text-align: center;
}

.screen-box {
  width: 100%;
  height: 84rpx;
  position: -webkit-sticky;
  position: sticky;
  top: calc(var(--status-bar-height) + 106rpx);
  z-index: 9;
  font-size: 28rpx;
  font-weight: 400;
  color: #adb3ba;
  margin: 0 auto 20rpx;
}

.screen-bgc {
  width: 100%;
  height: 84rpx;
  display: flex;
  align-items: center;
  padding: 18rpx 30rpx 36rpx;
  box-sizing: border-box;
  border-radius: 36rpx 36rpx 0 0;
  z-index: 2;
}

.tab-item {
  position: relative;
  padding: 14rpx 0;
  margin-right: 56rpx;
  font-size: 28rpx;
}

.current-item {
  font-size: 32rpx;
  font-weight: 400;
  text-align: left;
  color: #2a343e;
}

.current-line {
  position: absolute;
  width: 132rpx;
  height: 20rpx;
  display: block;
  bottom: 10rpx;
  left: 50%;
  transform: translateX(-50%);
  z-index: -1;
}

.scrollHeight {
  /* #ifdef APP-PLUS */
  height: calc(100vh - 104rpx);
  /* #endif */
  /* #ifdef H5 */
  height: calc(100vh - 216rpx);
  /* #endif */
  position: relative;
  margin-bottom: 88rpx;
}

.status-text {
  padding-bottom: 40rpx;
}

.top-input {
  color: #c8c8c8;
  font-size: 24rpx;
}

.goods-title {
  font-size: 32rpx !important;
}

.user-box-text {
  flex: 1;
  overflow: hidden !important;
}

.back-image {
  width: 44rpx;
  height: 44rpx;
  padding: 22rpx 24rpx;
  flex-shrink: 0;
}

.more-popup {
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999;
}

.more-popup-box {
  position: absolute;
  top: calc(var(--status-bar-height) + 108rpx);
  right: 22rpx;
  width: 242rpx;
  background-size: cover;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}

.more-image {
  position: absolute;
  top: -14rpx;
  right: 14rpx;
  width: 30rpx;
  height: 14rpx;
}

.more-popup-content {
  padding: 8rpx 14rpx;
  background-color: #fff;
  border-radius: 12rpx;
}

.popup-content {
  font-size: 24rpx;
  text-align: center;
  color: #333333;
  line-height: 46rpx;
  padding: 0 50rpx;
  box-sizing: border-box;
}

.popup-info {
  width: 200rpx;
  padding: 30rpx 0;
  font-size: 32rpx;
  font-weight: 500;
  color: #2a343e;
  justify-content: center;
}

.border_bottom {
  border-bottom: 2rpx solid #f7f7f7;
}

.more-popup-icon {
  width: 32rpx;
  height: 32rpx;
  margin-right: 20rpx;
  margin-left: 6rpx;
}

.empty-box {
  padding-top: 120rpx;
  text-align: center;
  font-size: 0;
  .empty-img {
    width: 256rpx;
    height: 202rpx;
  }
  .empty-text {
    font-size: 24rpx;
    color: #f8c1ca;
    line-height: 34rpx;
    margin-top: 24rpx;
  }
}
</style>
