<template>
  <view :class="['goplay-page', screenPopupFlag ? 'fixed-page' : '']">
    <!-- 顶部导航 start -->
    <view class="header flex-1">
      <view class="location flex-1" @click="changeAddress('/pagesCommon/cityList/cityList?typeOfOperation=saveStorage')">
        <view class="header-location ellipsis-single">{{ address.cityName ? address.cityName : '选择定位' }}</view>
        <view><image class="header-arrowImg" src="http://img.yiqitogether.com/yqyq-app/images/sanjiao.png" mode="aspectFill" /></view>
      </view>
      <view class="header-right-box flex-1">
        <image @click="$u.throttle(goSearchPages, 500)" class="search-icon" src="http://img.yiqitogether.com/yqyq-app/images/sousuo.png" mode="aspectFill" />
      </view>
    </view>
    <!-- 顶部导航 end -->
    <view class="page-body">
      <!-- 官方推荐 -->
      <view class="officia-recommend" v-if="officiaRecommendList.length > 0">
        <view class="officia-recommend-content" v-if="checkOfficiaRecommendItem">
          <image class="officia-recommend-bgimg" :src="checkOfficiaRecommendItem.pic[0]" mode="aspectFill" />
          <view
            class="officia-recommend-box flex-2"
            @click="
              $u.throttle(() => {
                goActivityDetail(checkOfficiaRecommendItem)
              }, 500)
            "
            v-if="checkOfficiaRecommendItem"
          >
            <view class="recommend-box-left">
              <view class="left-title">官方推荐</view>
              <view class="left-bottom">
                <view class="bottom-name flex-0">
                  {{ checkOfficiaRecommendItem.name }}
                  <view class="name-text" style="margin: 0 14rpx">|</view>
                  <view class="name-text" v-if="checkOfficiaRecommendItem.address">{{ checkOfficiaRecommendItem.address.city }}</view>
                </view>
                <view class="bottom-time">活动时间 : {{ $u.timeFormat(checkOfficiaRecommendItem.appointDateTimestamp, 'mm-dd hh:MM') }}</view>
              </view>
            </view>
            <image v-if="officiaRecommendList.length == 1" class="one-img" src="http://img.yiqitogether.com/yqyq-app/images/chakan_da.png" mode="scaleToFill" />
            <scroll-view v-if="officiaRecommendList.length > 1" class="recommend-scroll" scroll-y :scroll-into-view="checkOfficiaRecommendItem.appointmentNo">
              <view @click.stop="changeCheckOfficiaRecommend(item)" :id="item.name" class="scroll-box" v-for="(item, index) in officiaRecommendList" :key="index">
                <view class="scroll-box-item flex-6">
                  <image :class="checkOfficiaRecommendItem.appointmentNo == item.appointmentNo ? 'active-box-swiper-img' : 'box-swiper-img'" :src="item.pic[0]" mode="aspectFill" />
                </view>
              </view>
            </scroll-view>
          </view>
        </view>
      </view>
      <view class="body-content">
        <!-- 活动tab  start -->
        <view class="content-tab">
          <view>
            <view class="content-tab-list flex-1">
              <view :class="[checkFirstTab == activityTabFlag.name ? 'active-content-tab-item' : 'content-tab-item', 'flex-5']" style="z-index: 2" @click="changeFirstTab(activityTabFlag.name)">
                <image v-if="activityTabFlag.name == '精选'" class="tab-item-hotimg" src="http://img.yiqitogether.com/yqyq-app/images/huomiao.png" mode="aspectFill" />

                {{ activityTabFlag.name }}
                <image v-if="showAlltab" class="tab-item-arrowImg" src="http://img.yiqitogether.com/yqyq-app/images/sanjiao-top.png" mode="aspectFill" />
                <image v-else class="tab-item-arrowImg" src="http://img.yiqitogether.com/yqyq-app/images/sanjiao-bottom.png" mode="aspectFill" />
              </view>
              <view :class="[checkFirstTab == '官方' ? 'active-content-tab-item' : 'content-tab-item', 'flex-5']" @click="changeFirstTab('官方')">官方</view>
              <view :class="[checkFirstTab == '周边' ? 'active-content-tab-item' : 'content-tab-item', 'flex-5']" @click="changeFirstTab('周边')">周边</view>
              <view style="width: 60rpx; margin: 0" class="content-tab-item flex-5" @click="openFilterPopup">
                <image class="tab-item-shaixuan" src="http://img.yiqitogether.com/yqyq-app/images/saixuan.png" mode="aspectFill" />
              </view>
            </view>
          </view>
          <view v-if="showAlltab" class="content-tab-all flex-1">
            <view
              @click="
                $u.throttle(() => {
                  toggleTabItem(item)
                }, 500)
              "
              :class="item.type == activityTabFlag.type ? 'active-all-item' : ' all-item '"
              v-for="item in activityTabArr"
              :key="item.type"
              :style="item.type == 'G3' ? 'margin:0rpx;' : ''"
            >
              {{ item.name }}
            </view>
          </view>
          <!-- 用于点击其他区域 精选下拉不展示 -->
          <u-overlay :show="allCheckShow" @click="closeAllCheckShow" :z-index="1" :opacity="0"></u-overlay>
        </view>
        <!-- 活动tab  end -->
        <!-- 活动列表  start -->
        <goplay-activity :activityList="activityList" :showLoading="showLoading" :activityloadStatus="activityloadStatus" :checkFirstTab="checkFirstTab"></goplay-activity>
        <view v-if="!showLoading && checkFirstTab == '官方'">
          <view class="guessed-box-title">往期活动</view>
          <goplay-activity :activityList="oldActivityList" :showLoading="showLoading" :activityloadStatus="activityloadStatus" checkFirstTab="往期活动"></goplay-activity>
        </view>
        <view v-if="activityList.length > 0" class="tips-box" @click="$u.throttle(activityListLoadMore, 500)">
          <u-loadmore :status="activityloadStatus" :fontSize="23" nomore-text="到底了~" />
        </view>
        <!-- 猜你喜欢 -->
        <view v-if="activityList.length == 0 && !showLoading && checkFirstTab == '周边'" class="guessed-box">
          <view class="guessed-box-title">热门推荐</view>
          <goplay-activity :activityList="oldActivityList" :showLoading="showLoading" :activityloadStatus="activityloadStatus">
            <view v-if="oldActivityList.length > 0" class="tips-box">
              <u-loadmore status="nomore" :fontSize="23" nomore-text="到底了~" />
            </view>
          </goplay-activity>
        </view>
        <!-- 活动列表  end -->
      </view>
    </view>

    <!-- 筛选弹窗 -->
    <yue-screen-popup ref="screenPopup" v-show="screenPopupFlag" :cityName="address.cityName" @closePopup="closeFilterPopup" @startScreen="startScreen" :radiovalue4="activityTypeChecked" :activityType="activityType"></yue-screen-popup>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
    <!-- 获取定位弹框 -->
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于显示附近的人和活动" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="setAddress" isImg isOnShow></accredit-popup>
  </view>
</template>
<script>
// 导入接口
import IndexModal from '@/model/index'
import toolsModel from '@/model/tools.js'

// 导入缓存工具 及 缓存字典
import { save, load, clear } from '@/utils/store.js'
import { POSITION, CITY_NAME, IP_ADDRESS, SCREENDATA } from '@/utils/cacheKey.js'
import { determineActivityStatus, getLocation } from '@/utils/tools.js'

// 导入组件
import goplayActivity from './components/goplay-activity.vue'
export default {
  components: { goplayActivity },
  data() {
    return {
      // 在当前页点击tabbar，刷新开关。默认关闭，在onshow里先关闭，2s以后再开启
      clickCurrentTabbarFlag: false,
      // 定位相关
      address: {
        cityName: '',
        lat: '',
        lon: '',
        position: ''
      },
      officiaRecommendList: [], //官方推荐活动
      checkOfficiaRecommendItem: {}, //选中官方推荐item
      officiaRecommendTime: '', //更换选中官方推荐item定时器
      showLoading: true,
      activityList: [],
      oldActivityList: [], //往期活动 || 猜你喜欢
      pages: 0,
      pageNumber: 0,
      activityloadStatus: 'loadmore',
      allCheckShow: false,
      activityTabFlag: {
        name: '精选',
        type: 'G1'
      }, // 活动切换flag
      activityTabArr: [
        {
          name: '精选',
          type: 'G1'
        },
        {
          name: '成团活动',
          type: 'G2'
        },
        {
          name: '历史活动',
          type: 'G3'
        }
      ],
      showAlltab: false, //活动点击精选tab展示
      checkFirstTab: '精选',
      screenPopupFlag: false, //筛选弹框
      activityType: [], //活动类型
      activityTypeStr: '', //选择的活动类型
      activityTypeChecked: [], //选择的活动类型
      screenDate: load(SCREENDATA) ? JSON.parse(load(SCREENDATA)) : ''
    }
  },
  watch: {
    'address.cityName': 'handleCityName'
  },
  onTabItemTap(e) {
    if (this.clickCurrentTabbarFlag) {
      uni.$u.debounce(this.refreshList, 1000)
    }
  },
  onLoad() {
    // 获取定位的经纬度再调接口
    this.$nextTick(() => {
      this.getActivityList()
    })
    this.appointmentType()
    this.getOfficialAptRecommend()
    uni.$on('openFindPopup', () => {
      this.$refs.publishPopupRef.onOpen()
    })
  },
  onReachBottom() {
    this.activityListLoadMore()
  },
  onShow() {
    uni.showTabBar()
    this.clickCurrentTabbarFlag = false
    setTimeout(() => {
      this.clickCurrentTabbarFlag = true
    }, 1000)
    // 如果当前没有定位信息，重新获取定位，如果有，直接读取
    let latLonStr = load(POSITION) || ''
    let city = load(CITY_NAME) || ''
    this.address.position = latLonStr
    this.address.cityName = city
    // if (!latLonStr || !city) {
    //   this.$nextTick(() => {
    //     this.$refs.accredit.triggerEvent()
    //   })
    // } else {
    //   this.address.position = latLonStr
    //   this.address.cityName = city
    // }
    // 更换选中官方推荐item
    setTimeout(() => {
      console.log('官方推荐自动播放')
      if (this.officiaRecommendList.length > 0) {
        this.officiaRecommendTime = setInterval(() => {
          let index = this.officiaRecommendList.findIndex(item => {
            return item.name == this.checkOfficiaRecommendItem.name
          })
          if (this.checkOfficiaRecommendItem.name == this.officiaRecommendList[this.officiaRecommendList.length - 1].name) {
            index = 0
          } else {
            index += 1
          }
          this.checkOfficiaRecommendItem = this.officiaRecommendList[index]
        }, 2500)
      }
    }, 100)
  },
  onHide() {
    this.clearOfficiaRecommendTime()
    this.$refs.publishPopupRef.onClose()
    this.closeFilterPopup()
  },
  onPullDownRefresh() {
    if (this.isMask) return uni.stopPullDownRefresh()
    // 下拉时刷新活动列表 重置分页
    this.refreshList()
  },
  methods: {
    /**
     * 刷新官方推荐 && 活动列表
     */
    refreshList() {
      this.getOfficialAptRecommend()
      this.clearActivity()
      if (this.checkFirstTab == '官方') {
        this.getOfficialListV2()
      } else {
        this.getActivityList()
      }
    },
    /**
     * 清除官方推荐swiper定时器
     */
    clearOfficiaRecommendTime() {
      if (this.officiaRecommendTime) {
        clearInterval(this.officiaRecommendTime)
        this.officiaRecommendTime = ''
      }
    },
    /**
     * 更改选中的官方推荐item
     * @param item
     */
    changeCheckOfficiaRecommend(item) {
      this.checkOfficiaRecommendItem = item
    },
    /**
     * 切换活动选项
     * @param type
     */
    toggleTabItem(newType) {
      // if (this.activityTabFlag.type == newType.type) {
      //   return
      // }
      this.activityTabFlag = newType
      this.checkFirstTab = newType.name
      this.clearActivity()
      this.closeAlltab()
      this.getActivityList()
    },
    /**
     * 删除活动相关数据
     */
    clearActivity() {
      this.pages = 0
      this.pageNumber = 0
      this.activityList = []
      this.oldActivityList = []
      this.activityTypeStr = ''
      this.activityloadStatus = 'loadmore'
      this.showLoading = true
    },
    /**
     * 获取活动列表数据
     */
    getActivityList(data) {
      let position = ''
      let group = this.activityTabFlag.type
      if (this.checkFirstTab == '周边') {
        position = this.address.position
        group = 'G1'
      }
      if (this.screenDate.isDistance) {
        position = this.address.position
      }
      let queryData = {
        position: position,
        group: group,
        ...this.screenDate,
        pageNo: this.pageNumber + 1,
        pageSize: 10
      }
      IndexModal.activityQuery(queryData)
        .then(res => {
          uni.stopPullDownRefresh()
          if (res.code == 'SUCCESS') {
            let activityObj = {}
            let list = []
            let t2 = new Date().getTime()
            let timeDifference = 0
            res.data.page.list.forEach(item => {
              timeDifference = Number(item.applyDeadlineDate) - Number(t2)
              item.appointDate = item.appointDateTimestamp
              activityObj = determineActivityStatus(item)
              if (activityObj.status == 'end') {
                activityObj.btnText = '已完成'
              } else if (activityObj.status == 'underWay' || (activityObj.status == 'notStart' && timeDifference <= 0)) {
                activityObj.btnText = '已截止'
              } else if (activityObj.isReachMaximum) {
                activityObj.btnText = '已满'
              } else if (activityObj.status == 'notStart') {
                activityObj.btnText = '招募中'
              }

              item.activityObj = { ...activityObj }
              list.push(item)
            })
            this.activityList.push(...list)
            if (this.activityList.length == 0 && this.checkFirstTab == '周边') {
              this.getGuessYouLike()
            }
            this.pages = res.data.page.pages
            this.pageNumber = res.data.page.pageNumber
            if (res.data.page.total == 0) {
              this.activityloadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.activityloadStatus = 'nomore'
              } else {
                this.activityloadStatus = 'loadmore'
              }
            }
          } else {
          }
          this.showLoading = false
        })
        .catch(err => {
          uni.stopPullDownRefresh()
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    /**
     * 活动加载更多
     */
    activityListLoadMore() {
      if (this.pages > this.pageNumber) {
        this.activityloadStatus = 'loadmore'
        if (this.checkFirstTab == '官方') {
          this.getOfficialListV2()
        } else {
          this.getActivityList()
        }
      }
    },
    // 获取官方活动列表信息
    getOfficialListV2() {
      let position = ''
      if (this.screenDate.distanceEnd) {
        position = this.address.position
      }
      let data = {
        pageNo: this.pageNumber + 1,
        pageSize: 10,
        position: position,
        ...this.screenDate
      }
      // console.log('🚀 ~ getOfficialListV2 ~ data:', data)
      IndexModal.officialAppointmentV2(data)
        .then(res => {
          uni.stopPullDownRefresh()
          if (res.code == 'SUCCESS') {
            let activityObj = {}
            let list = []
            // 往期活动
            let oldList = []
            let t2 = new Date().getTime()
            let timeDifference = 0
            res.data.page.list.forEach(item => {
              timeDifference = Number(item.applyDeadlineDate) - Number(t2)
              item.appointDate = item.appointDateTimestamp
              activityObj = determineActivityStatus(item)
              if (activityObj.status == 'end') {
                activityObj.btnText = '已完成'
              } else if (activityObj.status == 'underWay' || (activityObj.status == 'notStart' && timeDifference <= 0)) {
                activityObj.btnText = '已截止'
              } else if (activityObj.isReachMaximum) {
                activityObj.btnText = '已满'
              } else if (activityObj.status == 'notStart') {
                activityObj.btnText = '招募中'
              }
              item.activityObj = { ...activityObj }
              if (item.activityObj.status == 'end') {
                oldList.push(item)
              } else {
                list.push(item)
              }
            })
            this.activityList.push(...list)
            this.oldActivityList.push(...oldList)
            this.pages = res.data.page.pages
            this.pageNumber = res.data.page.pageNumber
            if (res.data.page.total == 0) {
              this.activityloadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.activityloadStatus = 'nomore'
              } else {
                this.activityloadStatus = 'loadmore'
              }
            }
          } else {
          }
          this.showLoading = false
        })
        .catch(err => {
          uni.stopPullDownRefresh()
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    /**
     * 官方推荐
     */
    getOfficialAptRecommend() {
      let data = {
        pageNo: 1,
        pageSize: 10
      }
      IndexModal.getOfficialAptRecommend(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.officiaRecommendList = res.data.page.list
            this.checkOfficiaRecommendItem = this.officiaRecommendList[0]
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    /**
     * 猜你喜欢
     */
    getGuessYouLike() {
      let data = {
        pageNo: 1,
        pageSize: 10
      }
      IndexModal.getGuessYouLike(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let activityObj = {}
            let list = []
            let t2 = new Date().getTime()
            let timeDifference = 0
            res.data.list.forEach(item => {
              timeDifference = Number(item.applyDeadlineDate) - Number(t2)
              item.appointDate = item.appointDateTimestamp
              activityObj = determineActivityStatus(item)
              if (activityObj.status == 'end') {
                activityObj.btnText = '已完成'
              } else if (activityObj.status == 'underWay' || (activityObj.status == 'notStart' && timeDifference <= 0)) {
                activityObj.btnText = '已截止'
              } else if (activityObj.status == 'notStart') {
                activityObj.btnText = '招募中'
              } else if (activityObj.isReachMaximum) {
                activityObj.btnText = '已满'
              }
              item.activityObj = { ...activityObj }

              list.push(item)
            })

            this.oldActivityList = list
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    /**
     * 活动类型
     */
    appointmentType() {
      IndexModal.getActivityTypeV().then(res => {
        if (res.code == 'SUCCESS') {
          this.activityType = res.data.appointmentType
        }
      })
    },
    /**
     * 关闭点击精选选择弹窗
     */
    closeAlltab() {
      this.showAlltab = false
      this.allCheckShow = false
    },
    /**
     * 切换活动类型（精选、官方、周边）
     * @param item
     */
    changeFirstTab(item) {
      // 第一次点击不显示多选框，第二次重复点击显示（精选、成团活动、历史活动）弹框
      if (this.checkFirstTab != this.activityTabFlag.name && item == this.activityTabFlag.name) {
        this.checkFirstTab = item
        return this.toggleTabItem(this.activityTabFlag)
      }

      this.checkFirstTab = item
      if (this.checkFirstTab == this.activityTabFlag.name) {
        if (this.showAlltab == false) {
          this.allCheckShow = true
        } else {
          this.allCheckShow = false
        }
        this.showAlltab = !this.showAlltab
      } else if (this.checkFirstTab == '官方') {
        this.clearActivity()
        this.getOfficialListV2()
      } else if (this.checkFirstTab == '周边') {
        this.clearActivity()
        if (this.address.position == '') {
          this.showLoading = false
          this.getGuessYouLike()
          return
        }
        this.getActivityList()
      }
    },
    /**
     *
     * @param {Object} queryData 筛选的结果
     * 筛选完成，获取数据
     */
    startScreen(queryData) {
      this.clearActivity()
      this.activityTypeStr = queryData.appointmentType
      this.screenDate = queryData
      this.activityTypeChecked = queryData.appointmentType ? queryData.appointmentType.split(',') : []
      this.screenPopupFlag = false
      uni.showTabBar()
      if (this.checkFirstTab == '官方') {
        this.getOfficialListV2()
      } else {
        this.getActivityList()
      }
    },
    // 打开筛选弹窗
    openFilterPopup() {
      uni.hideTabBar()
      if (this.$refs.screenPopup.$refs.regionSlider) {
        this.$refs.screenPopup.$refs.regionSlider.getSlider()
      }
      this.screenPopupFlag = true
    },
    // 关闭筛选弹窗
    closeFilterPopup() {
      this.screenPopupFlag = false
      uni.showTabBar()
    },
    /**
     * 去除城市中多余的市
     */
    handleCityName() {
      let str = this.address.cityName
      let char = '市'
      const regex = new RegExp(`${char}+`, 'g')
      this.address.cityName = str.replace(regex, char)
      if (this.checkFirstTab == '周边') {
        if (this.address.cityName != '选择定位') {
          setTimeout(() => this.changeFirstTab('周边'), 50)
        }
      }
    },
    /**
     * 关闭精选下拉弹窗
     */
    closeAllCheckShow() {
      this.allCheckShow = false
      this.showAlltab = false
    },
    /**
     * 前往查看活动页面
     * @param item
     */
    goActivityDetail(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo
      })
    },
    /**
     * top 选择地址跳转后返回页面选择的地址
     */
    changeAddress(url) {
      let that = this
      uni.navigateTo({
        url,
        events: {
          getCityName: function (data) {
            console.log(`页面index,之前地址：${that.address.cityName},更新后地址${data}`)
            that.address.cityName = data
          }
        }
      })
    },
    /**
     * 去个人主页
     * @param item
     */
    goHomePage(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item.userId + '&checkedTab=2'
      })
    },
    /**
     * 去往搜索页面
     */
    goSearchPages() {
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/indexSearch?tabType=APPOINTMENT'
      })
    },
    /**
     * 同意获取定位授权
     */
    async setAddress() {
      let latLonStr = await getLocation()
      if (!latLonStr) {
        this.address.position = ''
        this.address.cityName = '选择定位'
        return
      }
      // 用户地址的经纬度，首页左上角可以切换
      save(POSITION, latLonStr)
      // 用户的IP地址经纬度，不可手动更改
      save(IP_ADDRESS, latLonStr)
      // 根据经纬度，获取城市名称
      toolsModel
        .getAddressInfo({
          position: latLonStr
        })
        .then(res => {
          save(CITY_NAME, res.data.city)
          console.log('当前所在城市名称：', res)
          this.address.position = latLonStr
          this.address.cityName = res.data.city
          let province = res.data.province ? res.data.province : ''
          let city = res.data.city ? res.data.city : ''
          let addressStr2 = province + '&&' + city
          uni.setStorage({
            key: 'addressStr2',
            data: latLonStr
          })
        })
        .catch(err => {})
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.goplay-page {
  .header {
    z-index: 999;
    position: fixed;
    padding: calc(var(--status-bar-height) + 28rpx) 36rpx 18rpx;
    width: 100%;
    box-sizing: border-box;
    top: 0;
    left: 0;
    background: #ffffff;
    .location {
      .header-location {
        font-size: 36rpx;
        text-align: left;
        line-height: 56rpx;
        color: #484848;
      }
      .header-arrowImg {
        margin-left: 12rpx;
        width: 20rpx;
        height: 20rpx;
      }
    }
    .search-icon {
      width: 44rpx;
      height: 44rpx;
      display: block;
      margin-right: 22rpx;
    }
  }
  .page-body {
    margin: calc(var(--status-bar-height) + 108rpx) 0 0;
    .officia-recommend {
      margin: 0 36rpx;
      .officia-recommend-content {
        position: relative;

        .officia-recommend-bgimg {
          width: 678rpx;
          height: 356rpx;
          border-radius: 20rpx;
        }
        .officia-recommend-box {
          position: absolute;
          top: 0;
          width: 100%;
          height: 350rpx;
          padding: 24rpx;

          box-sizing: border-box;
          .recommend-box-left {
            flex: 1;
            .left-title {
              width: 156rpx;
              height: 50rpx;
              background: rgba($color: #000000, $alpha: 0.5);
              border-radius: 12rpx;
              font-size: 28rpx;
              text-align: center;
              color: #ffffff;
              line-height: 50rpx;
            }
            .left-bottom {
              position: absolute;
              bottom: 24rpx;
              .bottom-name {
                font-size: 28rpx;
                color: #ffffff;
                .name-text {
                  font-size: 20rpx;
                }
              }

              .bottom-time {
                font-size: 20rpx;
                color: #ffffff;
                margin-top: 4rpx;
              }
            }
          }
          .one-img {
            width: 48rpx;
            height: 48rpx;
            position: absolute;
            bottom: 36rpx;
            right: 24rpx;
          }
          .recommend-scroll {
            width: 166rpx;
            .scroll-box {
              .scroll-box-item {
                margin-bottom: 12rpx;
                .box-swiper-img {
                  width: 102rpx;
                  height: 60rpx;
                  border-radius: 12rpx;
                  display: block;
                }
                .active-box-swiper-img {
                  width: 136rpx;
                  height: 80rpx;
                  border: 2rpx solid #ffffff;
                  border-radius: 12rpx;
                  display: block;
                }
              }
            }
          }
        }
      }
    }

    .body-content {
      .content-tab {
        margin-top: 28rpx;
        position: sticky;
        top: calc(var(--status-bar-height) + 95rpx);
        z-index: 1;
        background: #ffffff;
        .content-tab-list {
          position: relative;
          background: #ffffff;
          padding: 20rpx 36rpx 40rpx;
          .content-tab-item {
            width: 192rpx;
            height: 60rpx;
            border: 2rpx solid #f0f1f3;
            border-radius: 16rpx;
            font-size: 26rpx;
            color: #484848;
            line-height: 60rpx;
            box-sizing: border-box;
            text-align: center;
            margin-right: 18rpx;
          }
          .active-content-tab-item {
            width: 192rpx;
            height: 60rpx;
            background: #ffffff;
            border: 2rpx dashed #1c1c1c;
            border-radius: 16rpx;
            font-size: 26rpx;
            text-align: center;
            color: #1c1c1c;
            line-height: 60rpx;
            margin-right: 18rpx;
            font-weight: bold;
          }

          .tab-item-arrowImg {
            width: 14rpx;
            height: 14rpx;
            margin-left: 6rpx;
          }
          .tab-item-shaixuan {
            width: 36rpx;
            height: 36rpx;
          }
          .tab-item-hotimg {
            width: 32rpx;
            height: 32rpx;
          }
        }
        .content-tab-all {
          padding: 0 36rpx 10rpx;
          width: 100%;
          box-sizing: border-box;
          position: absolute;
          top: 88rpx;
          z-index: 2;
          height: 124rpx;
          background: #ffffff;
          border-radius: 0rpx 0rpx 40rpx 40rpx;
          box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(210, 218, 225, 0.5);
          .all-item {
            width: 216rpx;
            height: 56rpx;
            line-height: 56rpx;
            background: #f5f5f5;
            border-radius: 12rpx;
            font-size: 24rpx;
            text-align: center;
            color: #838e9a;
            margin-right: 10rpx;
          }
          .active-all-item {
            width: 216rpx;
            height: 56rpx;
            line-height: 56rpx;
            background: #ffece3;
            border-radius: 12rpx;
            font-size: 24rpx;
            text-align: center;
            color: #fe5e10;
            margin-right: 10rpx;
          }
        }
      }
    }
  }
}

.guessed-box {
  // margin: 256rpx 0 0;
}
.guessed-box-title {
  margin: 0 36rpx;
  font-size: 32rpx;
  text-align: left;
  color: #484848;
  margin-bottom: 24rpx;
}
.tips-box {
  padding-bottom: 50rpx;
}
.fixed-page {
  height: 100vh !important;
  overflow: hidden !important;
}
</style>
