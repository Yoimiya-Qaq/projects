<template>
  <view class="official-activities-page">
    <image class="page-bg" src="http://img.yiqitogether.com/static/images/detailsImg/gfhd_bg.png" alt="" mode="widthFix" />
    <view :style="{ height: statusBarHeight + 'rpx' }"></view>
    <view class="nav-container">
      <view class="nav-back" @click="goBack">
        <image class="nav-back-img" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" />
      </view>
    </view>
    <view class="main-container" :style="computeContainerHeight">
      <view class="tabs-box">
        <u-tabs
          :list="list"
          :scrollable="false"
          :current="current"
          lineColor="#FE5E10"
          :lineHeight="6"
          :activeStyle="{
            color: '#333333',
            fontWeight: '600',
            transform: 'scale(1)'
          }"
          :inactiveStyle="{
            color: '#838E9A',
            fontWeight: '400',
            transform: 'scale(1)'
          }"
          @change="changeTab"
        ></u-tabs>
      </view>
      <!-- 有数据 -->
      <scroll-view class="list-wrap" scroll-y v-if="listData.length" @scrolltolower="loadMore">
        <block v-for="(item, index) in listData" :key="item.appointmentNo">
          <view class="list-item" @click="goDetail(item)">
            <view class="item-left">
              <view class="item-left-title">{{ item.name || '' }}</view>
              <view class="item-left-time">
                <image class="time-icon" src="@/static/images/myImgs/gfhd_clock@2x.png" mode="" />
                <view class="time-desc">{{ item.appointDate || '' }}</view>
              </view>
              <view class="item-left-btn">前往查看</view>
            </view>
            <zero-lazy-load class="item-right" borderRadius="24" :image="item.pic[0] ? item.pic[0] : '../../static/images/defaultGraph-001.png'" :height="196"></zero-lazy-load>
          </view>
          <view class="line" v-show="index != listData.length - 1"></view>
        </block>
        <view class="tips-box" @click="loadMore">
          <u-loadmore :status="loadStatus" :fontSize="24" nomore-text="到底了~" />
        </view>
      </scroll-view>
      <!-- 无数据 -->
      <view v-if="loadStatus == 'none'" class="empty-wrap">
        <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" alt="" mode="aspectFill" />
      </view>
    </view>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import IndexModal from '@/model/index'

export default {
  name: 'officialActivities',
  data() {
    return {
      statusBarHeight: 0,
      current: 0,
      list: [
        {
          name: '正在进行'
        },
        {
          name: '往期活动'
        }
      ],
      pages: 0,
      pageNumber: 1,
      pageSize: 10,
      loadStatus: 'loadmore',
      listData: []
    }
  },
  computed: {
    computeContainerHeight() {
      return { marginTop: `calc(312rpx - ${this.statusBarHeight}rpx)` }
    }
  },
  onLoad(e) {
    // 获取手机系统信息
    const info = uni.getSystemInfoSync()
    // 设置状态栏高度
    this.statusBarHeight = this.pxToRpx(info.statusBarHeight)
    // 正在进行/往期活动
    if (e.pageType) {
      this.current = e.pageType
    }
  },
  onShow() {
    this.pageNumber = 1
    this.listData = []
    this.$nextTick(() => {
      this.getList()
    })
  },
  methods: {
    // px转换成rpx
    pxToRpx(px) {
      let deviceWidth = uni.getSystemInfoSync().windowWidth
      let rpx = (750 / deviceWidth) * Number(px)
      return Math.floor(rpx)
    },
    // 返回上一页
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 切换排行榜
    changeTab(e) {
      this.current = e.index
      this.pageNumber = 1
      this.listData = []
      this.$nextTick(() => {
        this.getList()
      })
    },
    // 获取列表信息
    getList() {
      let data = {
        pageNo: this.pageNumber,
        pageSize: this.pageSize,
        group: this.current == 1 ? 'G2' : 'G1'
      }
      IndexModal.officialAppointment(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.pages = res.data.page.pages || 1
            let list = res.data.page.list || []
            this.listData = [...this.listData, ...list]
            if (res.data.page.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.loadStatus = 'none'
        })
    },
    // 加载更多
    loadMore() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.pageNumber++
          this.getList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    // 前往查看
    goDetail(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.official-activities-page {
  height: 100vh;
  overflow: hidden;
  background: #ffffff;
  position: relative;
  z-index: 1;

  .page-bg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 400rpx;
    background-size: cover;
    z-index: 2;
  }

  .nav-container {
    width: 100%;
    height: 88rpx;
    position: relative;
    display: flex;
    align-items: center;
    z-index: 999;

    .nav-back {
      width: 44rpx;
      height: 44rpx;
      position: absolute;
      left: 24rpx;
      top: 50%;
      transform: translateY(-50%);
      .nav-back-img {
        width: 100%;
        height: 100%;
      }
    }
  }

  .main-container {
    overflow: hidden;
    position: relative;
    z-index: 5;

    .tabs-box {
      width: 100%;
      padding: 30rpx 113rpx 10rpx;
      box-sizing: border-box;

      /deep/ .u-tabs__wrapper__nav__item {
        height: 60rpx !important;
        padding: 0;

        .u-tabs__wrapper__nav__item__text {
          font-size: 28rpx !important;
        }
      }
      /deep/.u-tabs__wrapper__nav__line {
        width: 40rpx !important;
        height: 6rpx !important;
        border-radius: 4rpx;
        bottom: 0rpx;
      }
    }
    .list-wrap {
      height: calc(100vh - 500rpx);
      padding: 0 30rpx;
      box-sizing: border-box;

      .list-item {
        display: flex;
        padding: 40rpx 20rpx 40rpx 24rpx;
        // border-bottom: 2rpx solid #f6f7f8;

        .item-left {
          flex: 1;
          position: relative;

          &-title {
            font-size: 32rpx;
            font-family: OPPOSans, OPPOSans-Medium;
            font-weight: Medium;
            text-align: left;
            color: #2a343e;
            line-height: 42rpx;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
            text-overflow: ellipsis;
            overflow: hidden;
            margin-bottom: 16rpx;
          }
          &-time {
            display: flex;
            align-items: center;
            .time-icon {
              width: 24rpx;
              height: 24rpx;
              margin-right: 4rpx;
            }
            .time-desc {
              font-size: 24rpx;
              font-family: OPPOSans, OPPOSans-Regular;
              color: #838e9a;
              line-height: 32rpx;
            }
          }
          &-btn {
            display: inline-block;
            font-size: 24rpx;
            font-family: OPPOSans, OPPOSans-Regular;
            text-align: center;
            color: #fe5e10;
            padding: 4rpx 16rpx;
            border: 2rpx solid #fe5e10;
            border-radius: 28rpx;
            box-sizing: border-box;
            position: absolute;
            bottom: 0;
            left: 0;
          }
        }

        .item-right {
          flex-shrink: 0;
          width: 196rpx;
          height: 196rpx;
          border-radius: 24rpx;
          margin-left: 36rpx;
        }
      }
      // .list-item:last-of-type {
      //   border-bottom: none;
      // }
    }
    .line {
      width: 100%;
      height: 2rpx;
      background: #f6f7f8;
    }

    .tips-box {
      text-align: center;
      padding-bottom: 30rpx;
      padding-bottom: calc(constant(safe-area-inset-bottom) + 30rpx);
      padding-bottom: calc(env(safe-area-inset-bottom) + 30rpx);
    }
    .empty-wrap {
      padding: 48rpx 0;
      text-align: center;
      font-size: 0;
      .empty-img {
        width: 310rpx;
        height: 310rpx;
        background-size: cover;
      }
    }
  }
}
</style>
