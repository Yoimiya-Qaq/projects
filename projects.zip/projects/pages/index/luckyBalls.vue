<template>
  <view class="lucky-balls-page">
    <view class="status-bar"></view>
    <!-- 导航栏 -->
    <view class="nav-container">
      <image class="nav-back" src="@/static/images/back_black.png" mode="" @click="goBack()" />
    </view>

    <image class="top-img" src="http://img.yiqitogether.com/yqyq-app/images/balls_title.png" mode="" />
    <!-- 列表有数据 -->

    <view class="main-container">
      <!-- Tab切换 -->
      <view class="tabs-wrap">
        <block v-for="item in tabList" :key="item.id">
          <view class="tabs-item" @click="changeTab(item.id)">
            <view :class="['tabs-item-name', currentTab == item.id ? 'active-tab' : 'disactive-tab']">{{ item.name }}</view>
          </view>
        </block>
      </view>

      <!-- 分页列表 -->
      <scroll-view class="list-wrap" v-if="listData.length && !showLoading" :scroll-y="true" @scrolltolower="loadMore()">
        <view
          class="list-item flex"
          v-for="item in listData"
          :key="item.activityId || item.productId"
          @click="
            $u.throttle(() => {
              goDetail(item)
            }, 500)
          "
        >
          <view class="list-item-img">
            <image class="img-bg" src="http://img.yiqitogether.com/yqyq-app/images/lottery.png" mode="" />
            <view class="img-tag" v-show="currentTab == 'ING'" :style="item.activityStatus == '进行中' ? 'background-color: #ffb7bd;' : 'background-color: #ffceb1;'">{{ item.activityStatus }}</view>
          </view>
          <view class="list-item-content">
            <view class="name-text">#{{ item.title }}</view>
            <!-- 正在进行 -->
            <block v-if="currentTab == 'ING'">
              <view class="base-text">
                抽奖名额
                <text class="h-mg-l-20">
                  <text class="em-text">{{ item.joinNumber || 0 }}</text>
                  /{{ item.winningNumber || 0 }}
                </text>
              </view>
              <!-- 进行中-截止时间 、 即将开始-开始时间 -->
              <view class="base-text">
                {{ item.activityStatus == '即将开始' ? '开始时间' : '截止时间' }}
                <text class="h-mg-l-20">{{ item.activityStatus == '即将开始' ? $u.timeFormat(item.newStartTime, 'yyyy-mm-dd hh:MM') : $u.timeFormat(item.newEndTime, 'yyyy-mm-dd hh:MM') }}</text>
              </view>
            </block>
            <!-- 往期回顾 -->
            <block v-else-if="currentTab == 'CLOSED'">
              <view class="base-text">
                中奖人数
                <text class="h-mg-l-20">
                  <text class="em-text">{{ item.giveNumber || 0 }}</text>
                  人
                </text>
              </view>
              <view class="base-text">
                开奖时间
                <text class="h-mg-l-20">{{ $u.timeFormat(item.newOpenTime, 'yyyy-mm-dd hh:MM') }}</text>
              </view>
            </block>
            <!-- 抽奖记录 -->
            <block v-else>
              <view class="flex-box">
                <view class="base-text" style="margin-right: 36rpx">
                  抽奖次数
                  <text class="h-mg-l-20">{{ item.raffleNumber || 0 }}次</text>
                </view>
                <view class="base-text" v-show="item.amount">
                  中奖金额
                  <text>
                    <text class="yellow-color">￥{{ item.amount || 0 }}</text>
                  </text>
                </view>
              </view>
              <!-- 进行中-开奖时间 、 即将开始-开始时间 -->
              <view class="base-text">
                {{ item.activityStatus == '即将开始' ? '开始时间' : '开奖时间' }}
                <text class="h-mg-l-20">{{ item.activityStatus == '即将开始' ? $u.timeFormat(item.startTimeStamp, 'yyyy-mm-dd hh:MM') : $u.timeFormat(item.openTimeStamp, 'yyyy-mm-dd hh:MM') }}</text>
              </view>
            </block>
          </view>
          <image class="list-item-icon" src="@/static/images/act_arrow_right.png" />
        </view>
        <view class="tips-box" @click="loadMore">
          <u-loadmore :status="loadStatus" :fontSize="22" marginTop="0" marginBottom="0" />
        </view>
      </scroll-view>

      <!-- 列表无数据 -->
      <view v-if="!listData.length && !showLoading" class="empty-wrap">
        <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" alt="" mode="aspectFill" />
      </view>
    </view>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import IndexModel from '@/model/index'

export default {
  name: 'luckyBalls',
  data() {
    return {
      currentTab: 'ING',
      tabList: [
        { id: 'ING', name: '正在进行' },
        { id: 'CLOSED', name: '往期回顾' },
        { id: 'RECORD', name: '抽奖记录' }
      ],
      pages: 1, // 总页数
      pageNumber: 1,
      pageSize: 20,
      loadStatus: 'loadmore',
      showLoading: true,
      listData: []
    }
  },
  onLoad(e) {
    this.currentTab = e.currentTab || 'ING'
    if (e.currentTab && e.currentTab == 'RECORD') {
      this.getRecordList()
    } else {
      this.getList()
    }
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack({ detail: 1 })
    },
    // 切换Tab
    changeTab(val) {
      if (this.currentTab === val) {
        return
      }
      this.currentTab = val
      this.showLoading = true
      this.pageNumber = 1
      this.listData = []
      if (val === 'RECORD') {
        this.getRecordList()
      } else {
        this.getList()
      }
    },
    // 获取抽奖记录列表
    getRecordList() {
      IndexModel.lotteryList()
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.list || []
            list.map(item => {
              let nowTime = new Date().getTime()
              let actTime = item.newStartTime
              item.activityStatus = actTime > nowTime ? '即将开始' : '进行中'
            })
            this.listData = list
            this.loadStatus = list.length ? 'nomore' : 'none'
            this.showLoading = false
          } else {
            this.showLoading = false
            this.loadStatus = 'none'
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    // 获取列表信息
    getList() {
      let params = {
        pageNo: this.pageNumber,
        pageSize: this.pageSize,
        activityState: this.currentTab
      }
      IndexModel.getLotteryActivityList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.pages = res.data.page.pages || 1
            let list = res.data.page.list || []
            list.map(item => {
              let nowTime = new Date().getTime()
              let actTime = item.newStartTime
              item.activityStatus = actTime > nowTime ? '即将开始' : '进行中'
            })
            this.listData = [...this.listData, ...list]
            if (res.data.page.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
            this.showLoading = false
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    // 加载更多
    loadMore() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.pageNumber++
          if (this.currentTab === 'RECORD') {
            this.getRecordList()
          } else {
            this.getList()
          }
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    // 去详情
    goDetail(item) {
      let id = this.currentTab == 'RECORD' ? item.productId : item.activityId
      uni.navigateTo({
        url: '/pages/index/luckyBallsDraw?id=' + id + '&activityStatus=' + item.activityStatus
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.lucky-balls-page {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_bg.png');
  background-size: cover;

  .status-bar {
    width: 100%;
    height: var(--status-bar-height);
  }

  .flex-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    z-index: 999;
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
  }

  .top-img {
    width: 640rpx;
    height: 218rpx;
    display: block;
    margin: 0 auto;
  }

  .main-container {
    height: calc(100vh - 440rpx - var(--status-bar-height));
    margin: 60rpx 36rpx 0;
    overflow: hidden;
    background-color: #fff;
    border-radius: 24rpx;

    .tabs-wrap {
      width: 100%;
      background: #ffffff;
      padding: 56rpx 0;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      border-radius: 24rpx 24rpx 0 0;

      .tabs-item {
        flex: 1;
        text-align: center;

        .tabs-item-name {
          font-size: 28rpx;
          padding: 4rpx 24rpx;
          display: inline-flex;
        }
        .active-tab {
          color: #2a343e;
          background: linear-gradient(90deg, #fec6e9 15%, #fefaed 43%);
          border-radius: 24rpx;
          font-weight: bold;
        }
        .disactive-tab {
          color: #64696f;
        }
      }
    }
    .list-wrap {
      box-sizing: border-box;
      background-color: #fff;
      border-radius: 0 0 24rpx 24rpx;
      height: calc(100% - 158rpx);
      overflow: auto;

      .list-item {
        display: flex;
        align-items: center;
        margin-bottom: 56rpx;
        padding: 0 36rpx;
        box-sizing: border-box;

        &-img {
          flex-shrink: 0;
          width: 144rpx;
          height: 144rpx;
          border-radius: 20rpx;
          position: relative;

          .img-bg {
            width: 100%;
            height: 100%;
            border-radius: 20rpx;
          }
          .img-tag {
            position: absolute;
            top: 0;
            left: 0;
            width: 96rpx;
            height: 32rpx;
            color: #fff;
            border-radius: 20rpx 0 20rpx 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20rpx;
          }
        }
        &-content {
          flex: 1;
          margin: 0 24rpx 0 16rpx;

          .name-text {
            font-size: 36rpx;
            color: #2a343e;
            line-height: 50rpx;
            margin-bottom: 10rp;
          }
          .base-text {
            font-size: 24rpx;
            color: #64696f;
            line-height: 34rpx;
            margin-bottom: 4rpx;
          }
          .em-text {
            font-size: 24rpx;
            color: #fe5e10;
            line-height: 34rpx;
          }
          .yellow-color {
            color: #ffb813;
            margin-left: 12rpx;
            display: inline-block;
          }
        }
        &-icon {
          flex-shrink: 0;
          width: 20rpx;
          height: 20rpx;
        }
      }
      .tips-box {
        padding-bottom: 56rpx;
      }
    }
  }

  .empty-wrap {
    margin: 48rpx auto;
    text-align: center;
    font-size: 0;
    .empty-img {
      width: 310rpx;
      height: 310rpx;
      background-size: cover;
    }
  }
}
</style>
