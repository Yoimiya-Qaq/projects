<template>
  <u-popup class="balls-fail-popup" :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onClose" @open="onOpen" @touchmove.native.stop.prevent>
    <view class="popup-wrap">
      <view class="tip">{{ content }}</view>
    </view>
    <image class="close-icon" src="@/static/images/details_participant_close.png" mode="" @click="onClose"></image>
  </u-popup>
</template>

<script>
export default {
  name: 'BallsFailPopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 40
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    content: {
      type: String,
      default: ''
    }
  },
  data() {
    return {}
  },
  methods: {
    onOpen() {
      this.$emit('open')
    },
    onClose() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
.balls-fail-popup {
  /deep/ .u-popup__content {
    background-color: transparent;
  }
  .popup-wrap {
    width: 484rpx;
    height: 548rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_fail.png');
    background-size: cover;
    position: relative;

    .tip {
      font-size: 26rpx;
      text-align: center;
      color: #fe5e10;
      line-height: 36rpx;
      margin: 0 52rpx;
      position: absolute;
      top: 356rpx;
      left: 0;
    }
  }
  .close-icon {
    width: 52rpx;
    height: 52rpx;
    margin: 60rpx auto 0;
  }
}
</style>
