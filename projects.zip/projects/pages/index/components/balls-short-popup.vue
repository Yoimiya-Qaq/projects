<template>
  <u-popup class="balls-short-popup" :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onClose" @open="onOpen" @touchmove.native.stop.prevent>
    <view class="popup-wrap">
      <image class="close-icon" src="@/static/images/balls_close.png" mode="" @click="onClose"></image>
      <view class="main-title">积分不足了</view>
      <view class="sub-title">去做任务赚取积分吧</view>
      <image class="fail-img" src="http://img.yiqitogether.com/yqyq-app/images/fail.png" mode=""></image>
      <view class="btn-wrap">
        <u-button type="error" :text="btnText" :throttleTime="500" @click="onConfirm"></u-button>
      </view>
    </view>
  </u-popup>
</template>

<script>
export default {
  name: 'BallsShortPopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 40
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // 按钮的文字
    btnText: {
      type: String,
      default: '做任务赚积分'
    }
  },
  data() {
    return {}
  },
  methods: {
    onOpen() {
      this.$emit('open')
    },
    onClose() {
      this.$emit('close')
    },
    onConfirm() {
      this.$emit('confirm')
    }
  }
}
</script>

<style lang="scss" scoped>
.balls-short-popup {
  /deep/ .u-popup__content {
    background-color: transparent;
  }
  .popup-wrap {
    width: 508rpx;
    height: 530rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_short.png');
    background-size: cover;
    position: relative;
    text-align: center;
    font-size: 0;

    .close-icon {
      width: 52rpx;
      height: 52rpx;
      position: absolute;
      top: 6rpx;
      right: 6rpx;
    }

    .main-title {
      font-size: 32rpx;
      color: #484848;
      line-height: 44rpx;
      margin-bottom: 6rpx;
      margin-top: 62rpx;
    }
    .sub-title {
      font-size: 24rpx;
      color: #838e9a;
      line-height: 34rpx;
    }
    .fail-img {
      width: 252rpx;
      height: 204rpx;
      margin-bottom: 52rpx;
      margin-top: 28rpx;
    }
    .btn-wrap {
      display: flex;
      justify-content: center;
      /deep/ .u-button {
        width: 344rpx;
        height: 60rpx;
        background: #fe5e10;
        border-radius: 38rpx;
        border: none;
        margin: 0;
      }
    }
  }
}
</style>
