<template>
  <view>
    <view class="content-list" v-if="activityList.length != 0 && !showLoading">
      <view
        class="list-item"
        v-for="(item, index) in activityList"
        :key="index"
        @click="
          $u.throttle(() => {
            goActivityDetail(item, index)
          }, 500)
        "
      >
        <!-- 活动内容 -->
        <view class="item-activity">
          <view class="activity-top flex-2">
            <view class="top-left">
              <image class="left-img" :src="item.pic[0]" mode="aspectFill" />
              <view v-if="item.activityObj.btnText == '已满'" class="all-count btn-text">{{ item.activityObj.btnText }}</view>
              <view v-if="item.activityObj.btnText == '招募中'" class="ing btn-text">{{ item.activityObj.btnText }}</view>
              <view v-if="item.activityObj.btnText == '已截止'" class="finished btn-text">
                {{ item.activityObj.btnText }}
              </view>
              <view v-if="item.activityObj.btnText == '已完成'" class="finished btn-text">{{ item.activityObj.btnText }}</view>
              <!-- <image v-if="item.appointmentState.label == 'FINISHED'" class="left-status-img" src="http://img.yiqitogether.com/yqyq-app/images/hd_yiman.png" mode="scaleToFill" />
              <image v-if="item.appointmentState.label == 'ING'" class="left-status-img" src="http://img.yiqitogether.com/yqyq-app/images/hd_zmz.png" mode="scaleToFill" />
              <image v-if="item.appointmentState.label == 'FINISHED'" class="left-status-img" src="http://img.yiqitogether.com/yqyq-app/images/hd_yijiezhi.png" mode="scaleToFill" /> -->
            </view>
            <view class="top-right">
              <view class="top-right-title">{{ item.name }}</view>
              <view class="top-right-bottom">
                <view class="bottom-content flex-1">
                  <view class="content-left flex-0">
                    <image class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/shijian.png" mode="aspectFill" />
                    {{ $u.timeFormat(item.appointDateTimestamp, 'mm-dd hh:MM') }}
                  </view>
                  <view class="content-right flex-0">
                    <image class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/maidan.png" mode="scaleToFill" />
                    {{ item.feeType.text }}
                    <text style="margin-left: 10rpx" v-if="item.feeType.label !== 'FREE' && item.feeType.label !== 'AA'">{{ item.prePayAmount }}</text>
                  </view>
                </view>
                <view class="bottom-loaction flex-1">
                  <view class="flex-0">
                    <image class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/weizhi.png" mode="scaleToFill" />
                    <view class="loaction-text ellipsis-single" v-if="item.address">{{ item.address.city }} · {{ item.place }}</view>
                  </view>
                  <image
                    @click.stop="
                      $u.throttle(() => {
                        openMap(item)
                      }, 500)
                    "
                    class="content-img"
                    src="http://img.yiqitogether.com/yqyq-app/images/daohang.png"
                    mode="scaleToFill"
                  />
                </view>
              </view>
            </view>
          </view>
          <view class="activity-bottom flex-1">
            <view
              @click.stop="
                $u.throttle(() => {
                  goHomePage(item.userId)
                }, 500)
              "
              class="bottom-left flex-0"
            >
              <image class="left-userimg" :src="item.userLogo" mode="aspectFill" />
              <view class="left-user flex-0">
                <view class="user-name">{{ item.userName }}</view>
                <view class="user-score flex-0">
                  <view style="font-size: 16rpx">{{ item.score }}</view>
                  <view style="font-size: 12rpx">分</view>
                </view>
              </view>
            </view>
            <view class="bottom-right flex-0">
              <view class="member-box flex-0">
                <block v-if="item.memberVoList">
                  <view
                    @click.stop="
                      $u.throttle(() => {
                        goHomePage(memberVoItem.numberId)
                      }, 500)
                    "
                    v-for="(memberVoItem, memberVoindex) in item.memberVoList"
                    :key="memberVoindex"
                  >
                    <view>
                      <image class="box-avatar" :src="memberVoItem.headUrl" mode="aspectFill" />
                    </view>
                  </view>
                </block>
                <block v-if="item.memberVoList && item.memberVoList.length < 3">
                  <view v-for="nullindex in (item.appointmentCount >= 3 ? 3 : 2) - item.memberVoList.length" :key="'null' + nullindex">
                    <view>
                      <image class="box-avatar" src="http://img.yiqitogether.com/yqyq-app/images/renyuan.png" mode="aspectFill" />
                    </view>
                  </view>
                </block>
              </view>
              <view class="member-num">
                <text style="color: #1c1c1c">{{ item.currentCount }}</text>
                /{{ item.appointmentCount }}&nbsp;已报名
              </view>
            </view>
          </view>
        </view>
        <!-- 搭子相册 -->
        <view class="mate-photo-box" v-if="item.goodPhotoUrl">
          <image class="photo-bg-triangle" src="http://img.yiqitogether.com/yqyq-app/images/yz_sanjiao.png" mode="scaleToFill" />
          <view class="box-title">搭子相册</view>
          <view class="photo-list flex-5">
            <image
              :key="picindex"
              v-for="(picitem, picindex) in item.goodPhotoUrl.split('&&')"
              @click="
                $u.throttle(() => {
                  clickPreview(item.goodPhotoUrl.split('&&'), picindex)
                }, 500)
              "
              class="photo-item"
              :src="picitem"
              mode="aspectFill"
            />
          </view>
        </view>
      </view>
      <slot></slot>
    </view>
    <!-- v-show 去发布样式正常展示 -->
    <view class="normalActivity-empty" v-show="activityList.length == 0 && !showLoading && checkFirstTab != '官方'">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
      <view class="empty-text">暂无活动</view>
      <view v-show="checkFirstTab != '官方' && checkFirstTab != '往期活动'" class="empty-btn flex-5" @click="$u.throttle(goInitateActivity, 500)">
        <image class="release-icon" src="http://img.yiqitogether.com/yqyq-app/images/fabu.png" mode="scaleToFill" />
        <view>去发布</view>
      </view>
    </view>

    <!-- 实名认证弹窗 -->
    <yue-realname-auth-modal ref="realnameAuthRef" />
  </view>
</template>
<script>
// 导入接口
import MyInfo from '@/model/my.js'
// 导入缓存工具 及 缓存字典
import { openMap } from '@/utils/tools'
import { load } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'

export default {
  props: {
    activityList: {
      type: Array,
      default: []
    },
    activityloadStatus: {
      type: String
    },
    showLoading: {
      type: Boolean,
      default: false
    },
    checkFirstTab: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      openMap,
      authSimple: '', // 是否认证
      userInfo: load(USER_INFO) ? JSON.parse(load(USER_INFO)) : ''
    }
  },
  methods: {
    /**
     * 前往查看活动页面
     * @param item
     * @param index
     */
    goActivityDetail(item, index) {
      let self = this
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo,
        events: {
          // 修改活动人数
          changeActivityNumber: type => {
            if (type == 'join') {
              self.activityList[index].currentCount++
              // 右下角增加自己头像
              if (self.activityList[index].memberVoList.length < 3) {
                self.activityList[index].memberVoList.push({ numberId: self.userInfo.numberId, headUrl: self.userInfo.headUrl })
              }
            } else if (type == 'quit') {
              self.activityList[index].currentCount--
              // 右下角剔除自己头像
              let list = self.activityList[index].memberVoList.filter(item => item.numberId != self.userInfo.numberId)
              self.activityList[index].memberVoList = list
            }
            this.$forceUpdate()
          }
        }
      })
    },
    /**
     * 获取实名认证状态
     */
    async getRealnameAuthStatus() {
      let res = await MyInfo.userInfoStatusV2()
      if (res.code == 'SUCCESS') {
        this.authSimple = res.data.authSimple == 'SUCCESS' ? 'SUCCESS' : 'FAIL'
      }
    },
    /**
     * 去发布活动
     */
    async goInitateActivity() {
      await this.getRealnameAuthStatus()
      if (this.authSimple == 'SUCCESS') {
        uni.navigateTo({ url: '/pagesInitiateActivity/initiateActivity/initiateActivity' })
      } else {
        this.$refs.realnameAuthRef.onOpen()
      }
    },
    /**
     * 点击预览图片
     */
    clickPreview(item, index) {
      uni.previewImage({
        urls: item,
        current: index
      })
    },

    /**
     * 去个人主页
     * @param item
     */
    goHomePage(item) {
      console.log('🚀 ~ goHomePage ~ item:', item)
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item + '&checkedTab=2'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.content-list {
  margin: 0 36rpx;
  .list-item {
    padding: 0 0 40rpx;
    .item-activity {
      .activity-top {
        .top-left {
          position: relative;
          .left-img {
            width: 180rpx;
            height: 180rpx;
            border-radius: 24rpx;
          }
          .left-status-img {
            width: 96rpx;
            height: 40rpx;
            position: absolute;
            top: 0;
            left: 0;
          }
          .all-count {
            color: #ffffff;
            background: #fb5c4e;
            border-radius: 20rpx 0rpx 20rpx 0rpx;
            width: 96rpx;
            height: 40rpx;
            position: absolute;
            top: 0;
            left: 0;
          }
          .ing {
            color: #ffffff;
            background: #ff905b;
            border-radius: 20rpx 0rpx 20rpx 0rpx;
            width: 96rpx;
            height: 40rpx;
            position: absolute;
            top: 0;
            left: 0;
          }
          .finished {
            color: #ffffff;
            background: #9fa7b4;
            border-radius: 20rpx 0rpx 20rpx 0rpx;
            width: 96rpx;
            height: 40rpx;
            position: absolute;
            top: 0;
            left: 0;
          }
          .btn-text {
            font-size: 20rpx;
            text-align: center;
            color: #ffffff;
            line-height: 40rpx;
          }
        }
        .top-right {
          flex: 1;
          margin-left: 24rpx;
          .top-right-title {
            font-size: 32rpx;
            color: #2a343e;
            margin: 24rpx 0 30rpx;
            font-weight: bold;
          }
          .top-right-bottom {
            font-size: 24rpx;
            color: #2a343e;
            .content-img {
              width: 40rpx;
              height: 40rpx;
            }
            .bottom-content {
              .content-left {
              }
              .content-right {
              }
            }
            .bottom-loaction {
              .loaction-text {
                width: 320rpx;
              }
              margin-top: 2rpx;
            }
          }
        }
      }
      .activity-bottom {
        margin-top: 8rpx;
        .bottom-left {
          .left-userimg {
            width: 48rpx;
            height: 48rpx;
            border-radius: 50%;
            margin-right: 10rpx;
          }
          .left-user {
            .user-name {
              font-size: 24rpx;
              color: #1c1c1c;
              margin-right: 8rpx;
            }
            .user-score {
              padding: 2rpx 6rpx;
              color: #fe5e10;
              background: #f7fbff;
              border-radius: 6rpx;
              text-align: center;
            }
          }
        }
        .bottom-right {
          .member-box {
            margin-right: 20rpx;
            .box-avatar {
              width: 48rpx;
              height: 48rpx;
              border-radius: 50%;
              margin-right: -10rpx;
            }
          }
          .member-num {
            font-size: 22rpx;
            color: #a6acb2;
          }
        }
      }
    }
    .mate-photo-box {
      margin-top: 22rpx;
      width: 678rpx;
      height: 236rpx;
      background: #f0f1f3;
      border-radius: 0 20rpx 20rpx;
      position: relative;
      .photo-bg-triangle {
        width: 44rpx;
        height: 18rpx;
        position: absolute;
        top: -16rpx;
      }
      .box-title {
        padding: 16rpx 54rpx;
        width: 96rpx;
        height: 34rpx;
        font-size: 24rpx;
        color: #232323;
        font-weight: bold;
      }
      .photo-list {
        // margin-left: 24rpx;
        padding: 0 33rpx;
        .photo-item {
          width: 134rpx;
          height: 134rpx;
          border-radius: 24rpx;
          margin-right: 12rpx;
        }
      }
    }
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 212rpx;
    height: 212rpx;
    background-size: cover;
  }
  .empty-text {
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
  }
  .empty-btn {
    width: 236rpx;
    height: 64rpx;
    background: #fe5e10;
    border-radius: 34rpx;
    margin: 40rpx auto 0;
    .release-icon {
      width: 36rpx;
      height: 36rpx;
      margin-right: 10rpx;
    }

    font-size: 28rpx;
    text-align: center;
    color: #ffffff;
  }
}
</style>
