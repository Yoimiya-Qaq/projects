<template>
  <u-popup class="balls-rule-popup" :show="show" mode="center" :round="round" :closeOnClickOverlay="closeOnClickOverlay" @close="onClose" @open="onOpen" @touchmove.native.stop.prevent>
    <view class="popup-wrap">
      <image class="bg-img" src="http://img.yiqitogether.com/yqyq-app/images/balls_rule_bg.png" mode="widthFix" />
     
      <view class="title">
        <image class="title-img" src="@/static/images/balls_draw_title_bg.png" mode=""></image>
        <view class="title-text">玩法说明</view>
      </view>
      <view class="content">
        <!-- 规则 -->
        <view class="serial">规则</view>
        <view class="h-mg-b-40">
          <view class="base-text">1.每期活动用户可用积分进行抽奖,不限次数;</view>
          <view class="base-text">2.抽奖成功后填写号码,提交后才可生效;如未填写或人员已满,本次抽奖将不作数;积分将会退回到积分中心;</view>
          <view class="base-text">3.抽奖失败,积分将会扣除,不予退回;</view>
          <view class="base-text">4.开奖公示后，中奖金额，用户与系统各分50%</view>
        </view>
        <!-- 玩法 -->
        <view class="serial">玩法</view>
        <view class="step-box">
          <view class="step-item">
            <view class="step-item-title">Step 1</view>
            <image class="step-item-img" src="@/static/images/balls_draw_step1.png" mode=""></image>
            <view class="step-item-tips">积分抽奖</view>
          </view>
          <view class="step-arrow">
            <image class="step-icon" src="@/static/images/balls_draw_step_one.png" mode="widthFix" />
          </view>
          <view class="step-item">
            <view class="step-item-title">Step 2</view>
            <image class="step-item-img" src="@/static/images/balls_draw_step2.png" mode=""></image>
            <view class="step-item-tips">输入号码</view>
          </view>
          <view class="step-arrow">
            <image class="step-icon" src="@/static/images/balls_draw_step_two.png" mode="widthFix" />
          </view>
          <view class="step-item">
            <view class="step-item-title">Step 3</view>
            <image class="step-item-img" src="@/static/images/balls_draw_step3.png" mode=""></image>
            <view class="step-item-tips">等待开奖</view>
          </view>
        </view>
      </view>
    </view>
    <view class="btn-wrap">
      <u-button type="error" :text="btnText" :throttleTime="500" @click="onClose"></u-button>
    </view>
  </u-popup>
</template>

<script>
export default {
  name: 'BallsRulePopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 40
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    },
    // 按钮的文字
    btnText: {
      type: String,
      default: '我知道了'
    }
  },
  data() {
    return {}
  },
  methods: {
    onOpen() {
      this.$emit('open')
    },
    onClose() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
.balls-rule-popup {
  /deep/ .u-popup__content {
    background-color: transparent;
  }
  .popup-wrap {
    width: 606rpx;
    background-color: #fff;
    border-radius: 40rpx;
    position: relative;

    .bg-img {
      position: absolute;
      top: 0;
      left: 0;
      width: 606rpx;
    }

    .close-icon {
      position: absolute;
      width: 44rpx;
      height: 44rpx;
      top: 68rpx;
      right: 16rpx;
      background-color: #fff;
      border-radius: 50%;
    }

    .title {
      position: relative;
      margin-bottom: 52rpx;
      .title-img {
        width: 340rpx;
        height: 68rpx;
        display: block;
        margin: 0 auto;
      }
      .title-text {
        position: absolute;
        font-size: 30rpx;
        color: #2a343e;
        line-height: 42rpx;
        top: 12rpx;
        left: 50%;
        transform: translateX(-50%);
      }
    }

    .content {
      position: relative;
      z-index: 2;

      .serial {
        width: 104rpx;
        height: 40rpx;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24rpx;
        color: #2a343e;
        background: linear-gradient(90deg, #fec6e9 15%, #fefaed 43%);
        border-radius: 20rpx;
        margin: 0 28rpx 18rpx;
      }
      .base-text {
        font-size: 28rpx;
        color: #2a343e;
        line-height: 52rpx;
        padding: 0 56rpx;
      }

      .step-box {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 32rpx 32rpx 50rpx;
        .step-item {
          flex-shrink: 0;
          text-align: center;
          &-title {
            font-size: 22rpx;
            color: #ff8ad3;
            line-height: 30rpx;
          }
          &-img {
            width: 102rpx;
            height: 102rpx;
            margin: 24rpx 0;
          }
          &-tips {
            font-size: 22rpx;
            color: #2a343e;
            line-height: 30rpx;
          }
        }
        .step-arrow {
          flex: 1;
          display: flex;
          justify-content: center;
          align-items: center;
          .step-icon {
            width: 108rpx;
          }
        }
      }
    }
  }
  .btn-wrap {
    text-align: center;
    /deep/ .u-button {
      width: 256rpx;
      height: 80rpx;
      border-radius: 44rpx;
      font-size: 28rpx;
      margin: 62rpx auto 0;
      background: linear-gradient(90deg, #fe8787 11%, #fe5c97 92%);
      box-shadow: 0rpx 0rpx 22rpx 4rpx rgba(255, 255, 255, 0.5) inset;
      border: none;
    }
  }
}
</style>
