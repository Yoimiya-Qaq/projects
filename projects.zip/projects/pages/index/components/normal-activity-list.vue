<template>
  <view>
    <view class="normalActivity-list" v-if="activityList.length > 0">
      <view
        class="normalActivity-item"
        @click="
          $u.throttle(() => {
            goActivityDetail(item, index)
          }, 500)
        "
        v-for="(item, index) in activityList"
        :key="index"
      >
        <image class="normalActivity-item-bgImg" :src="item.pic[0]" mode="aspectFill" />
        <view class="normalActivity-item-content">
          <view class="item-content-top flex-0">
            <view class="content-top-left">
              <image v-if="item.appointmentState.label != 'FINISHED'" class="top-left-img" :src="item.pic[0]" mode="aspectFill" />
              <view v-if="item.appointmentState.label == 'FINISHED'" class="finshed-box flex-5">
                <image class="top-left-finshedimg" src="@/static/images/huodongyiwanchneg.png" mode="aspectFill" />
              </view>
              <view class="top-left-text">
                <view class="top-left-title ellipsis-single">{{ item.name }}</view>
                <view class="top-left-intro ellipsis-single">{{ item.description }}</view>
              </view>
            </view>
            <view class="content-top-right">
              <view class="content-top-right-content">
                <view class="right-content">
                  <view class="right-content-item flex-0">
                    <image class="right-content-icon" src="@/static/images/shijian2.png" mode="scaleToFill" />
                    <!-- <view class="right-content-text">{{ item.appointDate.split(' ')[1] }} {{ item.appointDate.split(' ')[2] }}</view> -->
                    <view class="right-content-text">{{ $u.timeFormat(item.appointDateTimestamp, '周E hh:MM') }}</view>
                  </view>
                  <view class="right-content-item flex-0" v-if="item.address && item.address.city">
                    <image class="right-content-icon" src="@/static/images/weizhi2.png" mode="scaleToFill" />
                    <view class="right-content-text ellipsis-single">{{ item.address.city }}</view>
                  </view>
                  <view class="right-content-item flex-0">
                    <image class="right-content-icon" src="@/static/images/weizhi1.png" mode="scaleToFill" />
                    <view class="right-content-text ellipsis-single">{{ item.place }}</view>
                  </view>
                  <view class="right-content-item flex-0">
                    <image class="right-content-icon" src="@/static/images/maidan.png" mode="scaleToFill" />
                    <view class="right-content-text">{{ item.feeType.text }}</view>
                  </view>
                  <view class="right-content-item flex-0">
                    <image class="right-content-icon" src="@/static/images/renyuan.png" mode="scaleToFill" />
                    <view class="right-content-text">{{ item.currentCount }}/{{ item.appointmentCount }}</view>
                  </view>
                </view>
              </view>
              <view class="right-content-time">
                {{ $u.timeFormat(item.appointDateTimestamp, 'yyyy-mm-dd') }}
              </view>
            </view>
          </view>
          <view class="item-content-bottom flex-1">
            <view
              class="icontent-bottom-left flex-0"
              @click.stop="
                $u.throttle(() => {
                  goHomePage(item.userId)
                }, 500)
              "
            >
              <view class="bottom-left-img">
                <image class="userImg" :src="item.userLogo" mode="scaleToFill" />
                <!-- <image v-if="item.sex == '女'" class="gender" src="https://img.yiqitogether.com/static/local/index/nv_s@2x.png" mode="scaleToFill" />
                <image v-else class="gender" src="https://img.yiqitogether.com/static/local/index/nan_s@2x.png" mode="scaleToFill" /> -->
              </view>
              <view class="bottom-left-name ellipsis-single">{{ item.userName }}</view>
              <view class="scores_box">
                {{ item.score }}
                <text class="score">分</text>
              </view>
            </view>
            <view class="icontent-bottom-right" v-show="item.createDateTimestamp">{{ $u.timeFormat(item.createDateTimestamp, 'mm-dd hh:MM') }}发布</view>
          </view>
        </view>
      </view>
      <slot></slot>
    </view>
    <view class="normalActivity-empty" v-if="activityList.length == 0 && !showLoading">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
      <view class="empty-text">暂无内容</view>
    </view>
  </view>
</template>
<script>
import { formateDate } from '@/utils/tools'
export default {
  props: {
    activityList: {
      type: Array,
      default: []
    },
    showLoading: {
      type: Boolean
    },
    loadStatus: {
      type: String
    }
  },
  data() {
    return {
      formateDate
    }
  },
  methods: {
    // 前往查看活动页面
    goActivityDetail(item, index) {
      let self = this
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo + '&pageType=normalList',
        events: {
          // 修改活动人数
          changeActivityNumber: type => {
            if (type == 'join') {
              self.activityList[index].currentCount++
            } else if (type == 'quit') {
              self.activityList[index].currentCount--
            }
            this.$forceUpdate()
          }
        }
      })
    },
    // 去个人主页
    goHomePage(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item + '&checkedTab=2'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.normalActivity-list {
  margin-top: 36rpx;

  .normalActivity-item {
    position: relative;
    height: 460rpx;
    margin-bottom: 44rpx;
    .normalActivity-item-bgImg {
      width: 100%;
      height: 372rpx;
      filter: blur(5rpx) brightness(0.9);
      border-radius: 30rpx 30rpx 0 0;
    }
    .normalActivity-item-content {
      top: 0;
      position: absolute;
      width: 100%;
      .item-content-top {
        .content-top-left {
          position: relative;
          color: #ffffff;
          width: 372rpx;
          height: 372rpx;
          .top-left-img {
            width: 372rpx;
            height: 372rpx;
            border-radius: 20rpx 20rpx 20rpx 0;
            display: block;
          }
          .finshed-box {
            width: 372rpx;
            height: 372rpx;
            background: rgba(255, 255, 255, 0.35);
            border-radius: 20rpx 20rpx 20rpx 0;

            .top-left-finshedimg {
              margin-bottom: 40rpx;
              width: 144rpx;
              height: 144rpx;
              border-radius: 20rpx 20rpx 20rpx 0;
              display: block;
            }
          }

          .top-left-text {
            position: absolute;
            background: url('@/static/images/beijingshadow.png');
            background-size: 100% 100%;
            bottom: 0;
            width: 100%;
            box-sizing: border-box;
            padding: 0 0 28rpx 20rpx;
            border-radius: 20rpx 20rpx 20rpx 0;
            background: linear-gradient(180deg, rgba(255, 252, 252, 0) 4%, rgba(47, 47, 47, 0.3) 50%, rgba(0, 0, 0, 0.8) 100%);

            .top-left-title {
              width: 300rpx;
              height: 44rpx;
              font-size: 32rpx;
              line-height: 44rpx;
              margin-bottom: 4rpx;
            }
            .top-left-intro {
              width: 318rpx;
              height: 28rpx;
              font-size: 20rpx;
              line-height: 28rpx;
            }
          }
        }
        .content-top-right {
          margin-left: 38rpx;
          background: url('@/static/images/beijingshadow2.png');
          background-size: 100% 100%;
          width: 228rpx;
          height: 290rpx;
          position: relative;
          .content-top-right-content {
            width: 178rpx;
            padding: 22rpx 0 32rpx;
            margin: auto;

            .right-content {
              .right-content-item {
                margin-bottom: 12rpx;
                .right-content-icon {
                  flex-shrink: 0;
                  width: 20rpx;
                  height: 20rpx;
                  margin-right: 8rpx;
                }
                .right-content-text {
                  flex-grow: 1;
                  font-size: 24rpx;
                  color: #2a343e;
                }
              }
            }
          }
          .right-content-time {
            left: 18%;
            font-size: 26rpx;
            color: #ffffff;
            position: absolute;
            bottom: 3%;
          }
        }
      }
      .item-content-bottom {
        padding: 20rpx;
        width: 670rpx;
        background: #ffffff;
        border-radius: 0 0 20rpx 20rpx;
        box-sizing: border-box;
        width: 100%;
        .icontent-bottom-left {
          .bottom-left-img {
            width: 40rpx;
            height: 40rpx;
            position: relative;
            .userImg {
              width: 40rpx;
              height: 40rpx;
              border-radius: 50%;
            }
            .gender {
              position: absolute;
              bottom: 0;
              right: 0;
              width: 14rpx;
              height: 14rpx;
            }
          }
          .bottom-left-name {
            max-width: 174rpx;
            font-size: 22rpx;
            color: #4e4e4e;
            margin-left: 12rpx;
          }
          .scores_box {
            width: 48rpx;
            height: 24rpx;
            margin-right: 8rpx;
            margin-left: 12rpx;
            background: #fff2f4;
            border-radius: 12rpx;
            font-size: 16rpx;
            font-family: PingFang SC, PingFang SC-Regular;
            font-weight: Regular;
            color: #ff603d;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .score {
            font-size: 13rpx;
          }
        }
        .icontent-bottom-right {
          font-size: 18rpx;
          color: #a6acb2;
        }
      }
    }
  }
  .normalActivity-item:last-child {
    margin: 0;
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
