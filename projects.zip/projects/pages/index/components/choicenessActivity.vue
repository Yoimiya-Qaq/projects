<template>
  <view class="choicenessActivity" v-if="choicenessActivityList.length > 0">
    <view class="choicenessActivity-content">
      <view class="choicenessActivity-content-top">
        <image class="content-top-img" src="http://img.yiqitogether.com/yqyq-app/images/xinrenfuli.png" mode="scaleToFill" />
        <view class="content-top-text">参加活动,可获得5~10元现金奖励</view>
      </view>
      <scroll-view class="choicenessScroll" scroll-x @scrolltolower="$u.throttle(loadMore, 500)">
        <view
          class="choicenessScroll-item"
          @click="
            $u.throttle(() => {
              goActivityDetails(item.appointmentNo)
            }, 500)
          "
          v-for="item in choicenessActivityList"
          :key="item.appointmentNo"
        >
          <image class="choicenessScroll-item-img" :src="item.pic[0]" mode="aspectFill" />
          <view class="choicenessScroll-item-time">{{ $u.timeFormat(item.appointDateTimestamp, 'yyyy-mm-dd') }}</view>
          <view class="choicenessScroll-content">
            <view class="content-title ellipsis-single">{{ item.name }}</view>
            <view
              @click.stop="
                $u.throttle(() => {
                  goHomePage(item.userId)
                }, 500)
              "
              v-if="item.userLogo || item.userName || item.distance"
              class="content-bottom flex-1"
            >
              <view v-if="item.userLogo || item.userName" class="content-bottom-left flex-0">
                <image class="userImg" :src="item.userLogo" mode="aspectFill" />
                <view class="userName ellipsis-single">{{ item.userName }}</view>
              </view>
              <view class="content-bottom-right" v-if="item.distance">{{ item.distance | capitalize }}</view>
            </view>
          </view>
        </view>
      </scroll-view>
    </view>
  </view>
</template>
<script>
import indexModel from '@/model/index.js'
import { formateDate } from '@/utils/tools.js'
export default {
  props: {
    choicenessActivityList: {
      type: Array
    }
  },
  data() {
    return {
      formateDate
    }
  },

  filters: {
    capitalize: function (value) {
      if (value) {
        if (value >= 1000) {
          value = (value / 1000).toFixed(2) + 'km'
        } else {
          value = value.toFixed(2) + 'm'
        }
      }
      return value
    }
  },
  methods: {
    /**
     * 加载更多
     */
    loadMore() {
      this.$emit('loadMore')
    },
    goActivityDetails(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item
      })
    },
    // 去个人主页
    goHomePage(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item + '&checkedTab=2'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.choicenessActivity {
  // margin-top: 56rpx;
  padding: 20rpx 36rpx 0rpx;
  box-sizing: border-box;

  .choicenessActivity-content {
    padding: 46rpx 0 36rpx 16rpx;
    box-sizing: border-box;
    background: url('http://img.yiqitogether.com/yqyq-app/images/jingxuanbeijing.png');
    background-size: 100% 100%;
    width: 678rpx;
    // height: 546rpx;
    .choicenessActivity-content-top {
      position: relative;
      .content-top-img {
        width: 650rpx;
        height: 60rpx;
      }
      .content-top-text {
        top: 0;
        right: 2%;
        position: absolute;
        font-size: 28rpx;
        line-height: 60rpx;
        color: #fe5e10;
      }
    }
    .choicenessScroll {
      margin-top: 40rpx;
      // width: 100%;
      // height: 370rpx;
      overflow: hidden;
      .choicenessScroll-item {
        position: relative;
        width: 208rpx;
        background: #ffffff;
        border-radius: 20rpx;
        margin-right: 4rpx;
        .choicenessScroll-item-img {
          width: 208rpx;
          height: 256rpx;
          border-radius: 20rpx 20rpx 0 0;
        }
        .choicenessScroll-item-time {
          position: absolute;
          top: 12rpx;
          left: 8rpx;
          width: 120rpx;
          height: 30rpx;
          opacity: 0.5;
          background: #000000;
          border-radius: 16rpx;
          font-size: 16rpx;
          color: #ffffff;
          text-align: center;
          line-height: 30rpx;
        }
        .choicenessScroll-content {
          padding: 10rpx;
          .content-title {
            margin-bottom: 20rpx;
            font-size: 24rpx;
            color: #2a343e;
          }
          .content-bottom {
            .content-bottom-left {
              .userImg {
                width: 32rpx;
                height: 32rpx;
                border-radius: 50%;
                margin-right: 6rpx;
              }
              .userName {
                width: 64rpx;
                font-size: 16rpx;
                color: #9fa7b4;
                line-height: 32rpx;
              }
            }
            .content-bottom-right {
              font-size: 16rpx;
              color: #9fa7b4;
            }
          }
        }
      }
      /deep/.uni-scroll-view-content {
        display: flex;
      }
    }
  }
}
</style>
