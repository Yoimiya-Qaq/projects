<template>
  <view class="page-box">
    <!-- #ifdef APP -->
    <view class="status-bar"></view>
    <!-- #endif -->
    <view class="top-bar h-flex h-flex-align h-border-box">
      <image src="@/static/images/back_black.png" class="h-icon-back h-pg-r-10" mode="" @click="back"></image>
      <text>奇遇搭子</text>
    </view>
    <!-- 匹配动效模块 start -->
    <view class="queue-box" v-if="popupFlag">
      <image src="http://img.yiqitogether.com/yqyq-app/images/fortuitousMeeting-004.png" mode="" class="pop-bgi"></image>
      <view class="animation-popup-box center">
        <image :src="avatarUrl" class="avatar center" mode=""></image>
        <image src="http://img.yiqitogether.com/yqyq-app/images/fortuitousMeeting-001.png" class="avatar-circle center" mode=""></image>
        <image src="http://img.yiqitogether.com/yqyq-app/images/fortuitousMeeting-002.png" class="fan-blade" mode=""></image>
        <view class="tips" v-if="tipsFlag">当前匹配失败，请重新匹配~</view>
        <view class="start-queue-btn" v-if="requeue" @click="adventureMatch">重新匹配</view>
      </view>
    </view>
    <!-- 匹配动效模块 end -->

    <!-- 匹配结果 start -->
    <view class="matching-result" v-else>
      <swiper class="swiper" circular previous-margin="55rpx" next-margin="55rpx" @change="changCurrentIndex">
        <swiper-item class="swiper-item" v-for="(item, index) in pageData" :key="index">
          <view :class="['events-box', currentIndex == index ? 'current-swiper-item' : '']" @click="nextPage(`/pagesCommon/details/details?appointmentNo=${item.appointmentNo}&sourcePage=fortuitousMeeting`)">
            <image :src="item.pic[0]" mode="aspectFit" class="events-images"></image>

            <view class="events-info-box h-border-box">
              <view class="h-flex h-flex-align h-mg-b-20">
                <text class="h-fs-36 h-mg-r-20 u-line-1">{{ item.name }}</text>
                <view class="tag">
                  {{ item.appointmentType }}
                </view>
              </view>
              <view class="h-mg-b-20 h-flex h-flex-align h-felx-sb h-border-box">
                <image src="@/static/images/date-icon.png" mode="" class="icon h-mg-r-10"></image>
                <view class="h-flex-1">
                  {{ item.appointDate }}
                </view>
                <view class="">
                  {{ item.currentCount }}
                  <text class="h-fs-20" style="color: #b7b7b7">/ {{ item.appointmentCount }}</text>
                </view>
              </view>
              <view class="h-flex h-flex-align h-felx-sb h-border-box">
                <image src="@/static/images/address-icon.png" mode="" class="icon h-mg-r-10"></image>
                <view class="h-flex-1 u-line-1 h-mg-r-20">
                  {{ item.address.info }}
                </view>
                <view class="">
                  {{ item.feeType.text }}
                </view>
              </view>
            </view>

            <view class="organizer">
              <image class="organizer-avatar" :src="item.userLogo" mode="aspectFill" @click.stop="nextPage(`/pagesMy/my/myHomePages/index?userId=${item.userId}&sourcePage=fortuitousMeeting`)" />
              <view class="organizer-info">
                <view class="organizer-info-name">{{ item.userName }}</view>
                <view class="organizer-info-other">
                  <image class="sex-icon" v-if="item.sex == '男'" src="@/static/images/myImgs/sign_male@2x.png" mode="aspectFill" />
                  <image class="sex-icon" v-if="item.sex == '女'" src="@/static/images/myImgs/sign_female@2x.png" mode="aspectFill" />
                  <view class="gray-text">{{ item.age }} · {{ item.constellation }}</view>

                  <view class="gray-text score-box h-flex-center">
                    <image class="rate-icon" src="https://img.yiqitogether.com/static/local/myImagesV2/df02_r@2x.png" mode="aspectFill" />
                    {{ item.score !== null ? Number(item.score).toFixed(1) : '' }}
                  </view>
                </view>
              </view>
            </view>
          </view>
        </swiper-item>
      </swiper>

      <view class="add-events" @click="authSimple"></view>
    </view>
    <!-- 匹配结果 end -->

    <!-- 成功加入 start -->
    <u-popup :show="sucessPopupFlag" mode="center" @close="close">
      <image src="http://img.yiqitogether.com/yqyq-app/images/fortuitousMeeting-006.png" mode="" class="success-img" @click="nextPage(`/pagesCommon/details/myActivity?sourcePage=fortuitousMeeting&optionDatas=F2`)"></image>
      <image src="@/static/images/fortuitousMeeting-008.png" class="close-icon" mode="" @click="close"></image>
      <!-- <view class="close-icon" >x</view> -->
    </u-popup>
    <!-- 成功加入 end -->

    <!-- 前往认证窗口 start -->
    <u-popup :initiateActivity="false" mode="center" :show="authPopupFlag" :round="40" @close="authPopupFlag = false">
      <view class="authentication">
        <image @click="authPopupFlag = false" class="activity-type-delete" src="https://img.yiqitogether.com/static/local/compons/bjzl_zybj_delete@2x.png" mode=""></image>
        <image class="authentication-image" src="http://img.yiqitogether.com/static/images/myImgs/icon_shimin.png" mode=""></image>
        <view class="authentication-title">实名认证</view>
        <view class="authentication-tips">为了保障活动出行的安全</view>
        <view class="authentication-tips">需要进行实名认证噢~</view>
        <view class="authentication-button" @click="goRealNameAuthFun()">去认证</view>
      </view>
    </u-popup>
    <!-- 前往认证窗口 end -->
  </view>
</template>

<script>
import IndexModel from '@/model/index'
import myModel from '@/model/my.js'
import { load } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'
/**
 * 匹配的定时器 4s延时
 */
let tm = null
export default {
  data() {
    return {
      authPopupFlag: false,
      popupFlag: true,
      currentIndex: 0,
      pageData: [],
      sucessPopupFlag: false,
      tipsFlag: false,
      avatarUrl: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      requeue: false
    }
  },
  onLoad() {
    this.avatarUrl = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)).headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'
    this.adventureMatch()
  },
  onUnload() {
    if (tm) {
      clearTimeout(tm)
    }
    tm = null
  },
  methods: {
    back() {
      uni.navigateBack()
    },
    close() {
      this.popupFlag = true
      this.sucessPopupFlag = false
      this.requeue = true
    },
    /**
     * 实名认证按钮
     */
    goRealNameAuthFun() {
      uni.navigateTo({
        url: '/pagesCommon/authentication/authentication?status=NO_AUDIT'
      })
      this.authPopupFlag = false
    },
    /**
     * 匹配活动/继续匹配
     */
    adventureMatch() {
      if (tm) {
        clearTimeout(tm)
      }
      this.tipsFlag = false
      this.requeue = false
      tm = setTimeout(() => {
        IndexModel.adventureMatch()
          .then(res => {
            if (res.data.list.length > 0) {
              this.pageData = res.data.list
              this.popupFlag = false
            } else {
              this.tipsFlag = true
              this.requeue = true
            }
            tm = null
            this.$forceUpdate()
          })
          .catch(err => {
            this.requeue = true
            this.$forceUpdate()
          })
      }, 4000)
    },
    /**
     * 切换时修改缩放
     */
    changCurrentIndex(e) {
      this.currentIndex = e.detail.current
      this.$forceUpdate()
    },
    /**
     * 去往详情页
     * ' '
     */
    nextPage(url) {
      uni.navigateTo({
        url
      })
    },
    /**
     * 加入活动
     */
    addActivity() {
      let obj = {
        appointmentNo: this.pageData[this.currentIndex].appointmentNo
      }
      IndexModel.apply(obj).then(res => {
        console.log('活动申请', res)
        if (res.code == 'SUCCESS') {
          console.log('弹窗出现')
          this.sucessPopupFlag = true
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    /**
     * 校验用户是否实名过
     */
    async authSimple() {
      let res = await myModel.userInfoStatusV2()
      console.log(res)
      if (res.code == 'SUCCESS' && res.data.authSimple == 'SUCCESS') {
        this.addActivity()
      } else {
        this.authPopupFlag = true
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.status-bar {
  height: var(--status-bar-height);
  width: 100%;
  position: sticky;
  top: 0;
  z-index: 99;
  font-size: 32rpx;
}

.top-bar {
  width: 750rpx;
  height: 88rpx;
  text-align: center;
  line-height: 88rpx;
  position: relative;
  padding-left: 36rpx;
  z-index: 9;
}

.pop-bgi {
  width: 750rpx;
  height: 442rpx;
  position: absolute;
  top: -4rpx;
  left: 0;
  z-index: -1;
}

.page-box {
  width: 750rpx;
  min-height: 100vh;
}

.queue-box {
  width: 750rpx;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 3;
}

.animation-popup-box {
  width: 350rpx;
  height: 350rpx;
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.avatar {
  width: 210rpx;
  height: 210rpx;
  border-radius: 50%;
  display: block;
  z-index: 2;
}

.avatar-circle {
  width: 210rpx;
  height: 210rpx;
  display: block;
  border-radius: 50%;
  z-index: 1;
  animation: circle-animation 3s infinite;

  @keyframes circle-animation {
    0% {
      width: 210rpx;
      height: 210rpx;
      opacity: 0.4;
    }

    45% {
      width: 300rpx;
      height: 300rpx;
      opacity: 0.4;
    }

    46% {
      width: 300rpx;
      height: 300rpx;
      opacity: 0;
    }

    100% {
      width: 210rpx;
      height: 210rpx;
      opacity: 0;
    }
  }
}

.fan-blade {
  width: 350rpx;
  height: 350rpx;
  display: block;
  transform-origin: center;
  // background-color: blue;
  animation: rotate 3s linear infinite;

  @keyframes rotate {
    0% {
      transform: rotate(0deg) scale(1);
    }

    45% {
      transform: rotate(360deg) scale(2);
    }

    100% {
      transform: rotate(720deg) scale(0.5);
    }
  }
}

.tips {
  width: 450rpx;
  text-align: center;
  font-size: 32rpx;
  color: #d8d8d8;
  margin-top: 150rpx;
  margin-left: -50rpx;
}

.start-queue-btn {
  width: 420rpx;
  height: 112rpx;
  border: 2rpx solid #ffffff;
  border-radius: 58rpx;
  margin-top: 200rpx;
  margin-left: -35rpx;
  line-height: 112rpx;
  text-align: center;
  color: #2a343e;
  font-size: 32rpx;
  background: url('@/static/images/fortuitousMeeting-003.png') no-repeat;
  background-size: 100% 100%;
}

.matching-result {
  padding-top: 80rpx;
}

.swiper {
  width: 750rpx;
  height: 968rpx;
}

.swiper-item {
  width: 100%;
  height: 968rpx;
  padding: 10rpx 0;
  box-sizing: border-box;
  // background: blue;
}

.events-box {
  width: 600rpx;
  height: 100%;
  border-radius: 20rpx;
  margin: 0 auto;
  transform: scale(0.95);
  overflow: hidden;
  box-shadow: 0rpx 0 10rpx 4rpx #f0f3f8;
}

.current-swiper-item {
  transform: scale(1);
}

.events-images {
  position: relative;
  width: 600rpx;
  height: 800rpx;
  max-width: 600rpx;
  max-height: 800rpx;
  display: block;
  z-index: -1;
}

.events-info-box,
.user-info-box {
  width: 100%;
  height: 188rpx;
  padding: 20rpx 30rpx;
  color: #fff;
  font-size: 24rpx;
  margin-top: -188rpx;
  position: relative;
  z-index: 99;
}

.events-info-box {
  background-image: linear-gradient(to top, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.2));
}

.tag {
  width: 72rpx;
  height: 36rpx;
  border: 2rpx solid #ffffff;
  border-radius: 8rpx;
  text-align: center;
  line-height: 36rpx;
}

.icon {
  width: 28rpx;
  height: 28rpx;
  display: block;
}

.user-info-box {
  margin-top: 0;
}

.avatar-img {
  width: 88rpx;
  height: 88rpx;
  border-radius: 50%;
  display: block;
}

.organizer {
  display: flex;
  align-items: center;
  height: 148rpx;
  // padding: 34rpx 12rpx 40rpx;
  margin: 0 24rpx;

  .organizer-avatar {
    width: 88rpx;
    height: 88rpx;
    background: #dcd1ff;
    border-radius: 50%;
    margin-right: 20rpx;
  }

  .organizer-info {
    &-name {
      font-size: 30rpx;
      font-family: PingFang SC, PingFang SC-Medium;
      font-weight: 500;
      color: #040000;
      margin-bottom: 10rpx;
    }

    &-other {
      display: flex;
      align-items: center;

      .gray-text {
        font-size: 22rpx;
        font-family: PingFang SC, PingFang SC-Medium;
        font-weight: 500;
        color: #a7acb6;
        margin-right: 24rpx;
      }

      .score-box {
        width: 64rpx;
        height: 24rpx;
        background: #fff2f4;
        border-radius: 12px;
        justify-content: center;
      }

      .sex-icon {
        width: 32rpx;
        height: 32rpx;
        margin-right: 6rpx;
      }

      .rate-icon {
        width: 24rpx;
        height: 20rpx;
        margin-right: 4rpx;
      }
    }
  }
}

.add-events {
  width: 420rpx;
  height: 112rpx;
  margin: 100rpx auto 0;
  background: url('http://img.yiqitogether.com/yqyq-app/images/fortuitousMeeting-005.png') no-repeat;
  background-size: 100% 100%;
  display: block;
}

.success-img {
  width: 464rpx;
  height: 542rpx;
  display: block;
}

.close-icon {
  width: 52rpx;
  height: 52rpx;
  border-radius: 50%;
  background-color: #888586;
  display: block;
  margin: 30rpx auto 0;
  text-align: center;
  line-height: 52rpx;
  color: #cdc9c9;
  background: #888586;
}

/deep/ .u-popup__content {
  background-color: transparent;
}

.authentication {
  width: 640rpx;
  padding: 40rpx 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #fff;
  border-radius: 20rpx;

  .activity-type-delete {
    width: 16rpx;
    height: 16rpx;
    position: absolute;
    right: 30rpx;
    top: 24rpx;
  }

  .authentication-image {
    width: 150rpx;
    height: 150rpx;
    margin-bottom: 20rpx;
  }

  .authentication-title {
    font-size: 28rpx;
    font-weight: 400;
    text-align: center;
    color: #333333;
    margin-bottom: 20rpx;
  }

  .authentication-tips {
    font-size: 24rpx;
    font-weight: 500;
    text-align: center;
    color: #333333;
    line-height: 46rpx;
  }

  .authentication-button {
    width: 430rpx;
    height: 72rpx;
    background: #fe5e10;
    border-radius: 36rpx;
    font-size: 24rpx;
    font-weight: 400;
    text-align: center;
    color: #ffffff;
    line-height: 72rpx;
    margin: 40rpx auto 10rpx;
  }
}
</style>
