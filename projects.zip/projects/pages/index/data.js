//1.{}里包裹的是每一个视频的参数
const userList = [
  {
    //1
    _id: 'dad53b399a974ea49d2f9b807b8456fb', //1.每一个视频独有 id （自定义）
    userNumberId: '83672858', //2.视频拥有者名称
    href: 'https://img.yiqitogether.com/yyqc/20240708/upload_zbxaxjkwlmlh4r7lf5oftag77t3udvmg.jpg!yqyq0606', //3.头像
    title: '', //4.第一行标题
    msg: '这段当时看的时候也笑疯了\n辛芷蕾好可爱啊，想进去捏捏她的脸', //5.第二行内容
    state: 'pause', //6.初始状态标志（不改）
    isZan: false, //7.是否点赞了
    isCollect: false, //8.是否收藏了
    zanCount: 0, //8.点赞数量
    commentCount: 0, //9.评论数量
    src: 'https://img.yiqitogether.com/yyqc/20241105/upload_ks1v0wdxsw6lql0dlux8sd0oc4j3mgz9.mp4', //10.视频链接
    collectCount: 0, //11.收藏数量
    pinlun: [], //12.评论
    playIng: false, //13.播放（默认这个即可）
    isShowimage: false, //14.是否显示封面（默认这个即可）
    isShowProgressBarTime: false, //15.是否显示进度条（默认这个即可）
    isplay: true, //16.是否播放音频（默认这个即可）
    videoImgUrl: 'https://img.yiqitogether.com/yyqc/20241105/upload_ks1v0wdxsw6lql0dlux8sd0oc4j3mgz9.mp4!/snapshot/point/00:00:00/format/png' //17.视频封面
  },
  {
    //2
    _id: 'ec2b04dcecab487e8668fc51a9c71bf7',
    userNumberId: '56983606',
    href: 'https://img.yiqitogether.com/yyqc/20240705/upload_0uz8o6lzfqpamiengib0rhya9fkj4ad7.jpg!yqyq0606',
    title: '',
    msg: '符龙飞总决赛跳了迈克杰克逊🎩\n瓦哥总决赛给我帅迷糊了啊啊啊，这段舞蹈干净利落全程只有帅气！明明可以靠颜值，偏偏要用六边形战士征服大家。',
    state: 'pause',
    isZan: false,
    isCollect: false,
    zanCount: 0,
    commentCount: 0,
    src: 'https://img.yiqitogether.com/yyqc/20241028/upload_2bmcksfu4oo9du6ak6r3ncx1tdkz1h4p.mp4',
    collectCount: 0,
    pinlun: [],
    playIng: false,
    isShowimage: false,
    isShowProgressBarTime: false,
    isplay: true,
    videoImgUrl: 'https://img.yiqitogether.com/yyqc/20241028/upload_2bmcksfu4oo9du6ak6r3ncx1tdkz1h4p.mp4!/snapshot/point/00:00:00/format/png'
  },
  {
    //3
    _id: '7f34bb7305714aae86c9a287f959fbdd',
    userNumberId: '26641865',
    href: 'https://img.yiqitogether.com/yyqc/20231225/upload_8eyowksj6nrbp40uazwaqlvlcctpazpt.jpg!yqyq0606',
    title: '',
    msg: '这个视频剪的挺丝滑的\n他俩合作的话，我一集得看三遍，第一遍沉迷女主，第二遍沉迷男主，第三遍才能知道剧情在讲啥',
    state: 'pause',
    isZan: false,
    isCollect: false,
    zanCount: 0,
    commentCount: 0,
    src: 'https://img.yiqitogether.com/yyqc/20241027/upload_ahikwcbz5lamt8s4j608hh2v3oslozmm.mp4',
    collectCount: 0,
    pinlun: [],
    playIng: false,
    isShowimage: false,
    isShowProgressBarTime: false,
    isplay: true,
    videoImgUrl: 'https://img.yiqitogether.com/yyqc/20241027/upload_ahikwcbz5lamt8s4j608hh2v3oslozmm.mp4!/snapshot/point/00:00:00/format/png'
  },
  {
    //4
    _id: '94f76a34427f48d287daedf9c54c0866',
    userNumberId: '77076774',
    href: 'https://img.yiqitogether.com/yyqc/20240925/upload_s1xz0ganwjjjvlc7t42i1l51mgom4g2o.jpg!yqyq0606',
    title: '',
    msg: '我',
    state: 'pause',
    isZan: false,
    isCollect: false,
    zanCount: 81,
    commentCount: 0,
    src: 'https://im.yiqitogether.com/u/20241023/nd23yuv2h531c5xjrf2le83zy7nk7vwi.mp4?upt_=a94f474a1730974557',
    collectCount: 1,
    pinlun: [],
    playIng: false,
    isShowimage: false,
    isShowProgressBarTime: false,
    isplay: true,
    videoImgUrl: 'https://im.yiqitogether.com/u/20241023/nd23yuv2h531c5xjrf2le83zy7nk7vwi.mp4!/snapshot/point/00:00:00/format/png?upt_=0a106fb21730974557'
  },
  {
    //5
    _id: '1707b7ec6bf74d8980d30fe5caa0f1d6',
    userNumberId: '65715321',
    href: 'https://img.yiqitogether.com/yyqc/20240914/upload_0ywsqcsh08nzssf484nfbgn0uf2tn8wk.jpg!yqyq0606',
    title: '',
    msg: '蛋妞哟：“他不是嘉士伯！Jasper！ 啊！Jasper~”',
    state: 'pause',
    isZan: false,
    isCollect: false,
    zanCount: 0,
    commentCount: 0,
    src: 'https://img.yiqitogether.com/yyqc/20241026/upload_biw7d8qyg0y0wsvm1en3xpukul48jbaq.mp4',
    collectCount: 0,
    pinlun: [],
    playIng: false,
    isShowimage: false,
    isShowProgressBarTime: false,
    isplay: true,
    videoImgUrl: 'https://img.yiqitogether.com/yyqc/20241026/upload_biw7d8qyg0y0wsvm1en3xpukul48jbaq.mp4!/snapshot/point/00:00:00/format/png'
  }
]
export default userList
