<template>
  <view class="lucky-balls-draw-page">
    <image class="nav-back" src="@/static/images/back_black.png" mode="" @click="goBack()" />
    <view class="main">
      <view class="status-bar"></view>
      <!-- 背景图 -->
      <image class="bg-img" src="http://img.yiqitogether.com/yqyq-app/images/balls_bg.png" alt="" mode="widthFix"></image>
      <!-- 内容 -->
      <view class="content">
        <!-- 导航栏 -->
        <view class="nav-container">
          <view class="nav-btn" @click="showRule = true">玩法说明</view>
        </view>
        <!-- 顶部文字 -->
        <image class="top-img" src="http://img.yiqitogether.com/yqyq-app/images/balls_draw_text.png" mode="" />
        <!-- 开奖日期 -->
        <view class="date-wrap">
          <image class="date-bg" src="http://img.yiqitogether.com/yqyq-app/images/balls_date_bg.png" mode="" />
          <view class="date-text flex">
            <view>#{{ activityInfo.title || '' }}</view>
            <view class="dash"></view>
            <view>开奖日期: {{ $u.timeFormat(activityInfo.newOpenTime, 'yyyy-mm-dd hh:MM') }}</view>
          </view>
        </view>
        <!-- 参与人数 -->
        <view class="person-wrap">
          <view style="margin-right: 16rpx">
            当前已参与
            <text style="padding: 0 10rpx">
              <text class="em-text">{{ activityInfo.joinNumber || 0 }}</text>
              /{{ activityInfo.winningNumber || 0 }}
            </text>
            人
          </view>
          <!-- 开奖倒计时 -->
          <u-count-down style="flex-shrink: 0" :time="isStart ? openDifference : 0" format="mm:ss" autoStart millisecond @change="onChangeTime($event, 'openTimeData')" @finish="onFinishTime('openTime')">
            <view class="flex">
              <view class="time-box">{{ openTimeData.days * 24 + openTimeData.hours >= 10 ? openTimeData.days * 24 + openTimeData.hours : '0' + (openTimeData.days * 24 + openTimeData.hours) }}</view>
              <text>:</text>
              <view class="time-box">{{ openTimeData.minutes >= 10 ? openTimeData.minutes : '0' + openTimeData.minutes }}</view>
              <text>:</text>
              <view class="time-box">{{ openTimeData.seconds >= 10 ? openTimeData.seconds : '0' + openTimeData.seconds }}</view>
            </view>
          </u-count-down>
        </view>
        <!-- 抽奖箱 -->
        <image class="lottery-img" v-show="isInLottery" src="http://img.yiqitogether.com/yqyq-app/images/balls_draw_box.gif" mode="" />
        <image class="lottery-img" v-show="!isInLottery" src="http://img.yiqitogether.com/yqyq-app/images/balls_draw_box.png" mode="" />

        <!-- --------------------------------------已抽奖start-------------------------------------- -->
        <view class="draw-card" v-if="isStart && lotteryStatus == 1 && lotteryInfo.isRaffle && !lotteryInfo.lotteryNo">
          <image class="draw-card-title-img" src="@/static/images/balls_draw_title_bg1.png" mode="" />
          <view class="draw-card-title-text">{{ activityInfo && activityInfo.lotteryType ? activityInfo.lotteryType.text : '专属你的幸运' }}</view>

          <!-- 已抽奖-未抽中 -->
          <view style="margin: 84rpx 140rpx 0" v-if="!isWin && isWin !== null">
            <view class="draw-card-tip">你的运气在积攒到下一次哦~</view>
            <view class="lottery-tip">
              点击
              <image class="pointer-icon" src="@/static/images/point_down.png" mode="" />
              下方再次抽奖
            </view>
          </view>

          <!-- 已抽奖-抽中 -->
          <block v-if="isWin">
            <view class="draw-card-input">
              <view class="input-list">
                <block v-for="(item, index) in codeList" :key="index">
                  <view v-for="(subItem, subIndex) in item.list" :key="subIndex">
                    <input class="input-item" type="number" :value="subItem" :focus="focusIndex == '' + index + subIndex" maxlength="2" @input="codeInput($event, index, subIndex)" @blur="codeBlur(index, subIndex)" />
                  </view>
                  <view class="separator" v-show="index != codeList.length - 1"></view>
                </block>
              </view>
            </view>
            <view class="draw-card-btns">
              <view class="btn-text left-btn" @click="$u.throttle(getRandomCode, 500)">
                <image class="btn-icon" src="@/static/images/balls_draw_random.png" mode="" />
                号码随机
              </view>
              <view class="btn-text right-btn" :style="{ opacity: isCodeValid ? 1 : 0.5 }" @click="$u.throttle(submitRandomCode, 500)">提交</view>
            </view>
          </block>
        </view>
        <!-- --------------------------------------已抽奖end-------------------------------------- -->

        <!-- 活动进行中 -->
        <view v-if="isStart">
          <!-- 已开奖 -->
          <view class="lottery-btn-gray" v-if="lotteryStatus == 3">已开奖</view>
          <!-- 本期报名已结束 -->
          <view class="lottery-btn-gray btn-bg" v-else-if="lotteryStatus == 4">本期报名已结束</view>
          <!-- 名额已满 -->
          <view class="lottery-btn-gray" v-else-if="lotteryStatus == 2">名额已满</view>
          <!-- 积分抽奖 -->
          <view class="lottery-btn" v-else-if="(lotteryStatus == 1 && !isWin) || (lotteryStatus == 1 && lotteryInfo.lotteryNo)" @click="showLotteryModal = true">
            <view class="big">积分抽奖</view>
            <view class="small">(消耗100积分)</view>
          </view>
        </view>

        <!-- 活动未开始  展示倒计时 -->
        <view class="countdown-wrap flex" v-if="!isStart">
          <view style="margin-right: 12rpx">距离开始还剩</view>
          <u-count-down :time="startDifference" format="mm:ss" autoStart millisecond @change="onChangeTime($event, 'startTimeData')" @finish="onFinishTime('startTime')">
            <view class="flex">
              <view class="time-box">{{ startTimeData.days * 24 + startTimeData.hours >= 10 ? startTimeData.days * 24 + startTimeData.hours : '0' + (startTimeData.days * 24 + startTimeData.hours) }}</view>
              <text>:</text>
              <view class="time-box">{{ startTimeData.minutes >= 10 ? startTimeData.minutes : '0' + startTimeData.minutes }}</view>
              <text>:</text>
              <view class="time-box">{{ startTimeData.seconds >= 10 ? startTimeData.seconds : '0' + startTimeData.seconds }}</view>
            </view>
          </u-count-down>
        </view>

        <!-- 活动公告 -->
        <view class="common-wrap">
          <image class="title-img" src="@/static/images/balls_draw_title_bg.png" mode=""></image>
          <view class="title-text">活动公告</view>
          <view class="notice-tip">
            <text>本期中奖名单将在</text>
            <image class="pointer-icon" src="@/static/images/point_down.png" mode=""></image>
            <text>发布结果</text>
          </view>
          <view class="start-time" v-if="!isSend">{{ $u.timeFormat(activityInfo.newGiveTime, 'yyyy-mm-dd hh:MM') }}</view>
          <!-- 中奖名单排行榜 -->
          <view class="winner-list" v-else>
            <block v-if="rankList.length">
              <view class="winner-list-item" v-for="(item, index) in rankList" :key="index">
                <view class="winner-list-item-rank flex">
                  <image class="rank-icon" v-if="index == 0" src="@/static/images/balls_draw_rank_one.png" mode=""></image>
                  <image class="rank-icon" v-else-if="index == 1" src="@/static/images/balls_draw_rank_two.png" mode=""></image>
                  <image class="rank-icon" v-else-if="index == 2" src="@/static/images/balls_draw_rank_three.png" mode=""></image>
                  <view class="rank-num" v-else>{{ index + 1 }}</view>
                </view>
                <view class="winner-list-item-info flex" :style="index == rankList.length - 1 ? '' : 'border-bottom: 2rpx solid #f7f7f7;'">
                  <image class="info-avatar" :src="item.headUrl ? item.headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'" mode="aspectFill"></image>
                  <view class="info-name">{{ formatName(item.nikeName) }}</view>
                  <view class="info-bonus">
                    已获得
                    <text style="color: #ffb813">{{ item.amount || 0 }}元</text>
                    奖金
                  </view>
                </view>
              </view>
            </block>
            <view class="empty-text" v-else>“本期无中奖人员”</view>
          </view>
          <view class="tips-foot" v-show="rankList.length || !isSend">中奖金额会发放到余额 ~</view>
        </view>
        <!-- 抽奖记录 -->
        <view class="common-wrap" v-if="recordList.length">
          <image class="title-img" src="@/static/images/balls_draw_title_bg.png" mode=""></image>
          <view class="title-text">抽奖记录</view>
          <view class="record-list">
            <view class="record-list-item" style="padding: 12rpx 0">
              <view class="record-list-item-time">抽奖时间</view>
              <view class="record-list-item-number">抽奖号码</view>
              <view class="record-list-item-status">状态</view>
            </view>
            <view class="list-box">
              <block v-for="(item, index) in recordList" :key="index">
                <view class="record-list-item" :style="index == recordList.length - 1 ? '' : 'border-bottom: 2rpx solid #f7f7f7;'">
                  <view class="record-list-item-time">{{ $u.timeFormat(item.createTimeStamp, 'mm-dd hh:MM') }}</view>
                  <view class="record-list-item-number">{{ item.lotteryNo || '' }}</view>
                  <view class="record-list-item-status" :style="item.isLucky ? 'color: #ffb813' : ''">{{ item.isLucky ? '￥' + item.winningAmount : item.winningAmount }}</view>
                </view>
              </block>
            </view>
          </view>
        </view>
        <!-- 活动玩法 -->
        <view class="common-wrap" v-show="activityInfo.infoImg">
          <image class="title-img" src="@/static/images/balls_draw_title_bg.png" mode=""></image>
          <view class="title-text">活动玩法</view>
          <view class="rule-box">
            <image class="rule-img" :src="activityInfo.infoImg" mode="widthFix" />
          </view>
        </view>
      </view>
    </view>

    <!-- 玩法说明弹窗 -->
    <balls-rule-popup :show="showRule" @close="closeRule" />

    <!-- 确认抽奖弹窗 -->
    <custom-modal type="tipsConfirm" :show="showLotteryModal" :round="20" themeColor="#FE5E10" :title="`确认消耗${activityInfo.points || 100}积分进行资格抽奖?`" confirmText="确认" @cancel="showLotteryModal = false" @confirm="confirmLottery">
      <view class="modal-tip">资格获取概率{{ activityInfo.winningRate || 50 }}%。获取后需自选彩票号码，并等待彩票开票。未抽中积分不退回。</view>
    </custom-modal>

    <!-- 提交成功弹窗 -->
    <balls-success-popup :show="showSuccess" @confirm="toChat" @close="showSuccess = false" />

    <!-- 提交失败弹窗 -->
    <balls-fail-popup :show="showFail" :content="failContent" @close="closeFail" />

    <!-- 积分不足弹窗 -->
    <balls-short-popup :show="showShort" @confirm="toIntegral" @close="showShort = false" />

    <!-- 提示语 -->
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import IndexModel from '@/model/index'
import { load, save } from '@/utils/store.js'
import { LUCKYBALLSRULE, LUCKYBALLSEND } from '@/utils/cacheKey.js'
import BallsRulePopup from './components/balls-rule-popup.vue'
import BallsSuccessPopup from './components/balls-success-popup.vue'
import BallsFailPopup from './components/balls-fail-popup.vue'
import BallsShortPopup from './components/balls-short-popup.vue'

export default {
  name: 'luckyBallsDraw',
  components: { BallsRulePopup, BallsSuccessPopup, BallsFailPopup, BallsShortPopup },
  data() {
    return {
      finished: false,
      showRule: false,
      showLotteryModal: false,
      showSuccess: false,
      showFail: false,
      showShort: false,
      isInLottery: false, // 是否正在抽奖中
      isStart: false, // 活动是否开始
      isCodeValid: false, // 号码是否合法
      isWin: null, // 抽奖是否抽中
      isSend: false, // 是否发放名单
      failContent: '',
      isFirstShow: false, // 是否关闭弹窗后下次进来不再弹出

      // 活动开奖倒计时
      openDifference: 0,
      openTimeData: {},
      // 活动开始倒计时
      startDifference: 0,
      startTimeData: {},
      // 活动结束倒计时
      endCount: 0,
      // 发放名单倒计时
      sendCount: 0,

      activityId: '', // 活动ID
      inputValue: '', // 输入的值
      inputArr: [],
      lotteryNo: '', // 彩票号码
      systemNo: '', // 抽奖记录No
      codeFormatArr: [], // 彩票格式，例如5-2对应的为['5', '2']
      codeList: [], // 彩票号码输入框数组
      activityInfo: {}, // 活动信息
      lotteryInfo: {}, // 中奖信息
      rankList: [], // 排行榜
      recordList: [], // 抽奖记录

      /**
       * 抽奖状态：
       * 1-积分抽奖
       * 2-名额已满
       * 3-已开奖
       * 4-本期报名已结束
       */
      lotteryStatus: 0,
      focusIndex: -1
    }
  },
  onLoad(e) {
    if (load(LUCKYBALLSRULE)) {
      this.showRule = false
    } else {
      this.showRule = true
    }
    this.activityId = e.id || ''
    this.isStart = e.activityStatus === '进行中' ? true : false
    this.getDetail()
  },
  onUnload() {
    this.clearCountdown()
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack({ detail: 1 })
    },
    // 获取详情
    getDetail() {
      IndexModel.getLotteryActivityInfo({
        activityId: this.activityId
      })
        .then(res => {
          if (res.code == 'SUCCESS') {
            // 数据处理
            this.activityInfo = res.data.activity || {}
            this.lotteryInfo = res.data.lotteryInfo || {}
            this.rankList = res.data.lotteryLuckList || []
            this.recordList = res.data.record || []
            this.isWin = res.data.lotteryInfo.isWin
            this.systemNo = res.data.systemNo || ''

            let currTimeStamp = new Date().getTime()

            // this.startDifference = new Date(res.data.activity.startTime).getTime() - currTimeStamp || 0
            // this.endCount = new Date(res.data.activity.endTime).getTime() - currTimeStamp || 0
            // this.openDifference = new Date(res.data.activity.openTime).getTime() - currTimeStamp || 0
            // this.sendCount = new Date(res.data.activity.giveTime).getTime() - currTimeStamp || 0

            this.startDifference = res.data.activity.newStartTime - currTimeStamp || 0
            this.endCount = res.data.activity.newEndTime - currTimeStamp || 0
            this.openDifference = res.data.activity.newOpenTime - currTimeStamp || 0
            this.sendCount = res.data.activity.newGiveTime - currTimeStamp || 0

            // 活动是否开始
            this.isStart = this.startDifference > 0 ? false : true
            if (this.openDifference <= 0) {
              // 已开奖，开启发放名单倒计时
              this.lotteryStatus = 3
              this.clearCountdown()
              this.startCountdown('sendCount', 'sendFinish')
            } else if (this.endCount <= 0) {
              // 报名已结束
              this.lotteryStatus = 4
              // 抽过且抽中且未提交号码
              if (res.data.lotteryInfo.isRaffle && res.data.lotteryInfo.isWin && !res.data.lotteryInfo.lotteryNo && !load(LUCKYBALLSEND)) {
                this.failContent = '活动时间已过, 抽中未提交的积分已退回您的账户'
                this.showFail = true
                this.isFirstShow = true
              }
            } else if (res.data.activity.joinNumber >= res.data.activity.winningNumber) {
              // 名额已满，开启活动结束倒计时
              this.lotteryStatus = 2
            } else {
              // 积分抽奖，开启活动结束倒计时
              this.lotteryStatus = 1
            }

            if (res.data.activity.lotteryType && res.data.activity.lotteryType.value) {
              let arr = res.data.activity.lotteryType.value.split('-') || []
              this.codeFormatArr = arr
              let newArr = []
              let newArr2 = []
              arr.forEach(item => {
                let num = Number(item)
                let obj = {
                  list: new Array(num).fill('')
                }
                newArr.push(obj)
                newArr2.push([])
              })
              this.codeList = newArr
              this.inputArr = newArr2
            }

            this.$nextTick(() => {
              this.finished = true
            })
          } else {
            this.finished = true
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.finished = true
        })
    },
    // 倒计时
    onChangeTime(e, field) {
      this[field] = e
    },
    // 倒计时结束
    onFinishTime(field) {
      if (this.finished) {
        if (field === 'openTime' && this.isStart) {
          // 开奖倒计时结束
          this.lotteryStatus = 3
          this.refreshList() // 直接刷新getDetail会死循环
          // 开启发放名单倒计时
          // this.sendCount = this.activityInfo.giveTime ? new Date(this.activityInfo.giveTime).getTime() - new Date().getTime() : 0
          this.sendCount = this.activityInfo.newGiveTime ? this.activityInfo.newGiveTime - new Date().getTime() : 0
          this.clearCountdown()
          this.startCountdown('sendCount', 'sendFinish')
        }
        if (field === 'startTime' && !this.isStart) {
          // 活动开始倒计时结束，显示开奖倒计时（这里要刷新下开奖倒计时的时间戳）
          this.isStart = true
          // this.openDifference = this.activityInfo.openTime ? new Date(this.activityInfo.openTime).getTime() - new Date().getTime() : 0
          this.openDifference = this.activityInfo.newOpenTime ? this.activityInfo.newOpenTime - new Date().getTime() : 0
        }
      }
    },
    // 发放名单倒计时结束
    sendFinish() {
      this.isSend = true
      this.refreshList()
    },
    // 刷新抽奖记录和名单
    refreshList() {
      IndexModel.getLotteryActivityInfo({
        activityId: this.activityId
      })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.rankList = res.data.lotteryLuckList || []
            this.recordList = res.data.record || []
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {})
    },
    startCountdown(field, method) {
      this.timer = setInterval(() => {
        if (this[field] > 0) {
          this[field] = this[field] - 1000
        } else {
          this.clearCountdown()
          this[method]()
        }
      }, 1000)
    },
    clearCountdown() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    },
    // 昵称脱敏
    formatName(str) {
      if (!str) {
        return ''
      }
      let result = str.slice(0, 1)
      if (str) {
        for (let i = 0; i < str.length - 1; i++) {
          result += '*'
        }
      }
      return result
    },
    // 关闭规则弹窗
    closeRule() {
      this.showRule = false
      save(LUCKYBALLSRULE, 'nomoreShow')
    },
    // 关闭报名截止失败弹窗
    closeFail() {
      this.showFail = false
      if (this.isFirstShow) {
        save(LUCKYBALLSEND, 'nomoreShow')
      }
      this.isFirstShow = false
    },
    // 抽奖-确认
    confirmLottery() {
      this.showLotteryModal = false
      this.isInLottery = true
      let params = {
        productId: this.activityId,
        lotteryType: this.activityInfo.lotteryType.label
      }
      IndexModel.lotteryRaffle(params)
        .then(res => {
          // 两秒是保证动画至少能执行完整的一轮
          setTimeout(() => {
            this.isInLottery = false
            if (res.code == 'SUCCESS') {
              // 数据处理
              if (res.data.timeOut) {
                // 报名截止
                this.failContent = '活动时间已过, 抽中未提交的积分已退回您的账户'
                this.isFirstShow = false
                this.showFail = true
                this.lotteryStatus = 4
              } else {
                this.isWin = res.data.isWin
                this.getDetail()
              }
            } else if (res.code === 'OTHER') {
              this.showShort = true
            } else {
              this.$refs.uToast.show({
                ...res
              })
            }
          }, 2000)
        })
        .catch(err => {
          setTimeout(() => {
            this.isInLottery = false
          }, 2000)
        })
    },
    // 判断号码是否输入合法
    checkEmpty(arr) {
      let result = null
      if (arr && arr.length) {
        let newArr = []
        for (let i = 0; i < arr.length; i++) {
          let bool = arr[i].list.every(v => !!v)
          newArr.push(bool)
        }
        // 注意：every方法若收到一个空数组，则在一切情况下都会返回 true。
        result = newArr.length ? newArr.every(v => !!v) : false
      }
      return result
    },
    // 号码输入
    codeInput(e, index, subIndex) {
      let val = e.detail.value
      this.inputArr[index][subIndex] = val
      if (val.length >= 2) {
        this.focusIndex = -1
        if (subIndex < this.codeList[index].list.length - 1) {
          this.focusIndex = '' + index + (subIndex + 1)
        } else if (subIndex == this.codeList[index].list.length - 1 && index < this.codeList.length - 1) {
          this.focusIndex = '' + (index + 1) + 0
        } else {
          this.codeBlur(index, subIndex)
        }
      }
    },
    // 号码输入失焦
    codeBlur(index, subIndex) {
      this.codeList[index].list[subIndex] = this.inputArr[index][subIndex]
      this.$forceUpdate()
      this.isCodeValid = this.checkEmpty(this.codeList)
    },
    // 号码随机
    getRandomCode() {
      IndexModel.lotteryGenerate({
        lotteryType: this.activityInfo.lotteryType.label
      }).then(res => {
        if (res.code == 'SUCCESS') {
          let arr = res.data.lotteryNo || []
          let newArr = []
          let newArr2 = []
          let changeIndex = 0
          this.codeFormatArr.map(item => {
            let num = Number(item)
            newArr.push({
              list: arr.slice(changeIndex, changeIndex + num)
            })
            newArr2.push(arr.slice(changeIndex, changeIndex + num))
            changeIndex = num
          })
          this.codeList = newArr
          this.inputArr = newArr2
          this.isCodeValid = true
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    // 提交号码
    submitRandomCode() {
      if (!this.isCodeValid) {
        return
      }
      let lotteryNo = ''
      this.codeList.map(item => {
        let str = item.list.join('-')
        lotteryNo = lotteryNo ? lotteryNo + '-' + str : lotteryNo + str
      })
      let params = {
        productId: this.activityId,
        lotteryNo: lotteryNo,
        systemNo: this.systemNo,
        lotteryType: this.activityInfo.lotteryType.label
      }
      IndexModel.lotteryApply(params).then(res => {
        if (res.code == 'SUCCESS') {
          if (res.data.lotteryApplyState.code == 4) {
            // 提交成功
            this.showSuccess = true
            this.isWin = null
            this.getDetail()
          } else if (res.data.lotteryApplyState.code == 3) {
            // 人员已满
            this.failContent = '人员已满,积分已退回到您的账户!具体请到积分明细查看~'
            this.isFirstShow = false
            this.showFail = true
            this.getDetail()
          } else if (res.data.lotteryApplyState.code == 5) {
            // 本期报名已结束(这里手动更新状态，不调用接口刷新防止后台计算的结束跟前端计算的结束有误差)
            this.failContent = '活动时间已过, 抽中未提交的积分已退回您的账户'
            this.isFirstShow = false
            this.showFail = true
            this.lotteryStatus = 4
            this.refreshList()
          } else {
            uni.showToast({
              title: res.data.message,
              icon: 'none'
            })
          }
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    // 进入群聊
    toChat() {
      // #ifdef H5
      uni.showToast({
        title: '当前环境不支持群聊功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif

      this.showSuccess = false
      uni.navigateTo({
        url: '/pagesMessage/groupChat/index?groupNo=' + this.activityInfo.activityGroupNo + '&groupName=' + this.activityInfo.activityGroupName
      })
    },
    // 做任务赚积分
    toIntegral() {
      this.showShort = false
      uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
    }
  }
}
</script>

<style lang="scss" scoped>
.lucky-balls-draw-page {
  background-color: #ffb9c9;
  position: relative;
  z-index: 1;
  height: 100vh;
  overflow: hidden;

  .nav-back {
    width: 44rpx;
    height: 44rpx;
    padding: 22rpx 24rpx;
    position: fixed;
    top: var(--status-bar-height);
    left: 0;
    z-index: 999;
  }

  .main {
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: #ffb9c9;
    position: relative;
    z-index: 2;
  }
  .status-bar {
    width: 100%;
    height: var(--status-bar-height);
  }
  .bg-img {
    position: absolute;
    top: 0;
    left: 0;
    width: 750rpx;
    background-size: cover;
    z-index: 3;
  }

  .content {
    position: relative;
    z-index: 10;
    padding-bottom: 20rpx;
  }

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    z-index: 999;

    .nav-btn {
      font-size: 32rpx;
      color: #2a343e;
      line-height: 44rpx;
      padding: 10rpx 36rpx;
      background: linear-gradient(90deg, #fec6e9 15%, #fefaed 43%);
      border-radius: 30rpx 0 0 30rpx;
      box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(253, 120, 144, 0.5);
    }
  }
  .flex {
    display: flex;
    align-items: center;
  }
  .flex-center {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .top-img {
    width: 660rpx;
    height: 172rpx;
    display: block;
    margin: 24rpx auto 46rpx;
  }
  .date-wrap {
    width: 690rpx;
    height: 156rpx;
    margin: 0 auto;
    font-size: 0;
    position: relative;
    .date-bg {
      width: 100%;
      height: 100%;
    }
    .date-text {
      font-size: 28rpx;
      color: #000000;
      line-height: 40rpx;
      position: absolute;
      left: 168rpx;
      top: 50%;
      transform: translateY(-50%);
    }
    .dash::after {
      content: '';
      height: 32rpx;
      border-right: 2rpx dashed #616971;
      opacity: 0.5;
      margin: 0 12rpx;
    }
  }

  .person-wrap {
    width: 100%;
    margin: 10rpx auto 20rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    .em-text {
      color: #fe5e10;
    }
    .time-box {
      width: 40rpx;
      height: 40rpx;
      background: #000000;
      border-radius: 8rpx;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 24rpx;
      color: #f7f7f7;
      line-height: 32rpx;
      margin: 0 8rpx;
    }
  }

  .lottery-img {
    width: 698rpx;
    height: 612rpx;
    display: block;
    margin: 0 auto;
    position: relative;
    z-index: 4;
  }

  .draw-card {
    width: 630rpx;
    height: 418rpx;
    margin: -100rpx auto 40rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_card.png');
    background-size: cover;
    position: relative;
    z-index: 5;
    text-align: center;
    display: flex;
    align-items: center;
    flex-direction: column;
    .draw-card-title-img {
      flex-shrink: 0;
      width: 350rpx;
      height: 76rpx;
      display: block;
      margin: 0 auto;
    }
    .draw-card-title-text {
      position: absolute;
      font-size: 30rpx;
      color: #2a343e;
      line-height: 42rpx;
      top: 12rpx;
      left: 50%;
      transform: translateX(-50%);
    }
    .draw-card-tip {
      font-size: 44rpx;
      color: #ff778d;
      line-height: 60rpx;
      word-break: break-all;
    }
    .lottery-tip {
      font-size: 28rpx;
      color: #ff778d;
      line-height: 40rpx;
      margin-top: 60rpx;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .draw-card-input {
      flex: 1;
      margin: 0 50rpx;
      display: flex;
      align-items: center;
      justify-content: center;

      .input-list {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        .input-item {
          width: 72rpx;
          height: 72rpx;
          background: #ffadb9;
          border: 2rpx solid #fef0da;
          border-radius: 20rpx;
          font-size: 44rpx;
          color: #ffffff;
          line-height: 72rpx;
          text-align: center;
          margin: 6rpx 4rpx;
          box-sizing: border-box;
        }
        .separator {
          width: 24rpx;
          height: 4rpx;
          background: #ff9e9e;
          border-radius: 2rpx;
          margin: 40rpx 12rpx 40rpx;
        }
      }
    }
    .draw-card-btns {
      flex-shrink: 0;
      margin-bottom: 50rpx;
      display: flex;
      justify-content: center;
      .left-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2rpx solid #ffadb9;
        color: #ff889b;
        box-sizing: border-box;
      }
      .right-btn {
        margin-left: 20rpx;
        color: #fff;
        background: linear-gradient(90deg, #fe8787 11%, #fe5c97 92%);
        box-shadow: 0rpx 0rpx 22rpx 4rpx rgba(255, 255, 255, 0.5) inset;
      }
      .btn-text {
        width: 256rpx;
        padding: 22rpx 0;
        font-size: 32rpx;
        line-height: 44rpx;
        text-align: center;
        border-radius: 44rpx;
      }
      .btn-icon {
        width: 36rpx;
        height: 36rpx;
        margin-right: 8rpx;
      }
    }
  }

  .countdown-wrap {
    font-size: 32rpx;
    color: #2a343e;
    line-height: 42rpx;
    justify-content: center;
    margin: 60rpx auto;
    .time-box {
      width: 64rpx;
      height: 64rpx;
      background: #ff889b;
      border-radius: 12rpx;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 32rpx;
      color: #fff;
      line-height: 42rpx;
      margin: 0 12rpx;
    }
  }

  .lottery-btn {
    width: 426rpx;
    height: 128rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_btn_bg.png');
    background-size: cover;
    color: #ffffff;
    margin: 40rpx auto 60rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .big {
      font-size: 48rpx;
    }
    .small {
      font-size: 24rpx;
    }
  }
  .lottery-btn-gray {
    width: 426rpx;
    height: 128rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_btn_bg_gray.png');
    background-size: cover;
    font-size: 56rpx;
    color: #ffffff;
    line-height: 128rpx;
    text-align: center;
    margin: 40rpx auto 60rpx;
  }
  .btn-bg {
    width: 468rpx;
    height: 128rpx;
    background-image: url('http://img.yiqitogether.com/yqyq-app/images/balls_draw_btn_bg_gray2.png');
    background-size: cover;
    font-size: 48rpx;
  }

  .pointer-icon {
    width: 32rpx;
    height: 32rpx;
    margin: 0 4rpx;
  }
  .common-wrap {
    width: 678rpx;
    margin: 40rpx auto;
    border-radius: 40rpx;
    background-color: #fff;
    border: 2rpx solid #fff4d9;
    box-sizing: border-box;
    position: relative;
    .title-img {
      width: 340rpx;
      height: 68rpx;
      display: block;
      margin: 0 auto;
    }
    .title-text {
      position: absolute;
      font-size: 30rpx;
      color: #2a343e;
      line-height: 42rpx;
      top: 12rpx;
      left: 50%;
      transform: translateX(-50%);
    }
    .notice-tip {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28rpx;
      color: #64696f;
      margin: 32rpx auto 24rpx;
    }
    .start-time {
      width: 512rpx;
      height: 80rpx;
      background: #ffeff2;
      border-radius: 20rpx;
      margin: 0 auto 42rpx;
      text-align: center;
      line-height: 80rpx;
      font-size: 40rpx;
      color: #ff889b;
    }
    .winner-list {
      margin: 26rpx auto 44rpx;
      max-height: 840rpx;
      overflow-y: auto;

      &-item {
        padding: 0 36rpx;
        box-sizing: border-box;
        display: flex;
        align-items: center;

        &-rank {
          flex-shrink: 0;
          width: 92rpx;
          height: 92rpx;
          font-size: 0;
          margin-right: 16rpx;
          justify-content: center;
          .rank-icon {
            width: 92rpx;
            height: 92rpx;
          }
          .rank-num {
            width: 44rpx;
            height: 44rpx;
            background: #fe8b8c;
            border-radius: 50%;
            font-size: 28rpx;
            line-height: 44rpx;
            text-align: center;
            color: #fff;
          }
        }
        &-info {
          flex: 1;
          padding: 40rpx 0;
          .info-avatar {
            width: 72rpx;
            height: 72rpx;
            border-radius: 50%;
          }
          .info-name {
            width: 100rpx;
            height: 36rpx;
            font-size: 28rpx;
            color: #2d3f49;
            line-height: 36rpx;
            margin: 0 20rpx;
            overflow: hidden;
            text-overflow: clip;
            word-break: break-all;
          }
          .info-bonus {
            font-size: 28rpx;
            color: #adadad;
            line-height: 40rpx;
          }
        }
      }
    }
    .empty-text {
      font-size: 44rpx;
      text-align: center;
      color: #ff778d;
      line-height: 60rpx;
      margin: 54rpx auto 70rpx;
    }
    .tips-foot {
      font-size: 28rpx;
      text-align: center;
      color: #ff889b;
      margin: 0 auto 40rpx;
    }

    .record-list {
      padding: 36rpx;

      .list-box {
        max-height: 530rpx;
        overflow: auto;
      }
      .record-list-item {
        display: flex;
        align-items: center;
        font-size: 24rpx;
        color: #64696f;
        padding: 24rpx 0;
        box-sizing: border-box;

        &-time {
          width: 154rpx;
          flex-shrink: 0;
        }
        &-number {
          flex: 1;
          margin: 0 30rpx;
        }
        &-status {
          flex-shrink: 0;
          min-width: 100rpx;
        }
      }
    }

    .rule-box {
      padding: 40rpx 34rpx 64rpx;
      box-sizing: border-box;
      .rule-img {
        width: 100%;
      }
    }
  }

  .modal-tip {
    font-size: 24rpx;
    color: #838e9a;
    line-height: 40rpx;
    text-align: center;
    margin: 0 54rpx;
  }
}
</style>
