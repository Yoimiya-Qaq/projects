<template>
  <view class="public-page">
    <view class="back-icon flex1">
      <image src="../../static/images/back_black.png" class="h-icon-back" mode="" @click="goBack"></image>
      <view class="back-icon-text">
        {{ backText }}
      </view>
    </view>
    <!-- <image :src="imageUrl" mode="widthFix" style="width: 100vw; height: 100%; display: block"></image> -->
    <swiper circular :indicator-dots="imageList.length > 1" :disable-touch="imageList.length <= 1" indicatorActiveColor="#FE5E10" indicatorInactiveColor="#e5e7e9">
      <swiper-item v-for="(item, index) in imageList" :key="index">
        <view class="image-wrap">
          <view class="image-box" @longpress="onLongPress($event, item)">
            <image :src="item" mode="widthFix" style="width: 100vw; display: block"></image>
          </view>
        </view>
      </swiper-item>
    </swiper>
    <!-- 保存到相册弹窗 -->
    <custom-more-operate-popup :show="showMoreOperate" :list="btnList" @close="showMoreOperate = false" @click="handleBtnClick" />
    <!-- 相册权限弹窗 -->
    <accredit-popup ref="accreditRef" systemTitle="“一起一起”想访问您的相册" systemContent="用于保存照片/视频到相册功能" permisionID="android.permission.READ_EXTERNAL_STORAGE" cacheId="externalStorage" @successAccredit="handleSave" />
    <!-- loading 弹窗 -->
    <yue-loading :mask="true" loadTxet="保存中..." v-show="showLoading"></yue-loading>
  </view>
</template>

<script>
export default {
  data() {
    return {
      imageList: [],
      backText: '',
      showMoreOperate: false,
      btnList: ['保存到相册'],
      showLoading: false,
      currImageUrl: ''
    }
  },
  onLoad(e) {
    ;(this.imageList = e.imageList ? JSON.parse(e.imageList) : []), (this.backText = e.backText ? e.backText : '')
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    // 长按保存
    onLongPress(e, item) {
      // #ifdef APP
      this.currImageUrl = item
      this.showMoreOperate = true
      // #endif
    },
    // 更多操作
    handleBtnClick(index, item) {
      switch (item) {
        case '保存到相册':
          this.showMoreOperate = false
          this.$refs.accreditRef.triggerEvent()
          break
        default:
          break
      }
    },
    // 保存到相册
    handleSave() {
      let self = this
      this.showLoading = true
      uni.downloadFile({
        url: this.currImageUrl, // 图片地址
        success: function (res) {
          uni.saveImageToPhotosAlbum({
            filePath: res.tempFilePath, // 图片文件路径
            success: function (data) {
              self.showLoading = false
              uni.showToast({
                title: '保存成功',
                icon: 'none',
                mask: true
              })
            },
            complete(res) {
              self.showLoading = false
            }
          })
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.public-page {
  background-color: #fff;
  .back-icon {
    position: absolute;
    top: calc(var(--status-bar-height) + 22rpx);
    left: 30rpx;
    z-index: 9;
    background-color: rgba(255, 255, 255, 0.5);
  }
  /deep/ uni-swiper {
    width: 100vw;
    height: 100vh;
  }
  .image-wrap {
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .image-box {
    width: 100%;
    overflow-y: auto;
  }
}

.back-icon-text {
  font-size: 36rpx;
  font-family: PingFang SC, PingFang SC-Medium;
  font-weight: Medium;
  color: #333333;
  margin-left: 14rpx;
}
</style>
