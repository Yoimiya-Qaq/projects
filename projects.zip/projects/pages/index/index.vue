<template>
  <view :class="['indexPages', isversion ? 'fixed-page' : '']">
    <view class="topBg">
      <!-- @click="$u.throttle(bannerSkip, 500)"  不能加，加了获取不到值 -->
      <view class="swiper-box">
        <u-swiper v-if="bannerList1.length" radius="0rpx" height="472rpx" bgColor="#ffffff" :list="bannerList1" keyName="bannerUrl" :circular="true" @click="bannerSkip" class="aiImg"></u-swiper>
        <!-- 顶部导航 start -->

        <view class="header flex-1" :style="isScroll ? 'background:#fff' : ''">
          <view class="location flex-1" @click="changeAddress('/pagesCommon/cityList/cityList?typeOfOperation=saveStorage')">
            <view class="header-location ellipsis-single">{{ address.cityName ? address.cityName : '选择定位' }}</view>
            <view><image class="header-arrowImg" src="https://img.yiqitogether.com/yyqc/20240705/upload_xou81bcwg32u5b2y7flpbi63ewjkqv1k.png" mode="aspectFill" /></view>
          </view>

          <view class="header-right-box flex-1">
            <image v-if="isScroll" @click="$u.throttle(goSearchPages, 500)" class="search-icon" src="https://img.yiqitogether.com/yyqc/20240705/upload_8yilpm4l9yujdxb7dksrmrn5mfv8428c.png" mode="aspectFill" />
            <!-- <image class="qrCode" src="https://img.yiqitogether.com/yyqc/20240705/upload_rckiqcx4rhi2gt4nyavmv2b3jem22zls.png" mode="aspectFill" /> -->
          </view>
        </view>
        <!-- 顶部导航 end -->
      </view>
      <!-- AI智能 end -->
      <view class="top-input-box flex-1" @click="$u.throttle(goSearchPages, 500)">
        <view class="flex-0">
          <image class="top-input-searchImg" src="@/static/images/sousuo3.png" mode="scaleToFill" />
          <view class="top-input">搜索</view>
        </view>

        <!-- #ifdef APP-PLUS -->
        <view @click.stop="$noMultipleClicks(sweep)"><image class="top-scanQrcode" src="../../static/images/saoyisao2.png" mode="scaleToFill" /></view>
        <!-- #endif -->
      </view>
      <!-- 头部卡片模块 start -->
      <swiper class="banner-sub-box" circular :indicator-dots="subBannerList.length > 0">
        <swiper-item v-for="(item, index) in subBannerList" :key="index + 1000">
          <view class="banner-sub">
            <view class="banner-sub-item" v-for="(subItem, subIndex) in item" :key="subIndex + 100">
              <image
                class="banner-item-img"
                :src="subItem.bannerUrl"
                mode="aspectFill"
                @click="
                  $u.throttle(() => {
                    bannerSkip(subItem.linkUrl)
                  }, 500)
                "
              />
            </view>
          </view>
        </swiper-item>
      </swiper>
      <!-- 头部卡片模块 end -->

      <!-- 即将开始/进行中 活动 start-->
      <view class="recentActivity" v-if="recentActivityList.list1.length > 0 || recentActivityList.list2.length > 0">
        <view class="recentActivity_title flex-1">
          <view class="recentActivity_title_left flex-0">
            <view v-if="recentActivityList.list1.length > 0" @click="changeRecentActivityTab('即将开始')">
              <image v-if="recentActivityTab == '即将开始'" :class="recentActivityTab == '即将开始' ? 'Active-activityStatus' : 'activityStatus'" src="@/static/images/jijiangkaishi1.png" mode="scaleToFill" />
              <image v-else :class="recentActivityTab == '即将开始' ? 'Active-activityStatus' : 'activityStatus'" src="@/static/images/jijiangkaishi2.png" mode="scaleToFill" />
            </view>
            <view v-if="recentActivityList.list2.length > 0" @click="changeRecentActivityTab('进行中')">
              <image v-if="recentActivityTab == '进行中'" :class="recentActivityTab == '进行中' ? 'Active-activityStatus' : 'activityStatus'" src="@/static/images/jinxingzhong1.png" mode="scaleToFill" />
              <image v-else :class="recentActivityTab == '进行中' ? 'Active-activityStatus' : 'activityStatus'" src="@/static/images/jinxingzhong2.png" mode="scaleToFill" />
            </view>
          </view>
          <view @click="nextPage('/pagesCommon/details/myActivity?optionDatas=F2&pageType=index')" class="recentActivity_title_right flex-0">
            <view class="recentActivity_title_right-text">查看更多</view>
            <image class="recentActivity_title_right-icon" src="@/static/images/arrow_right.png" mode="scaleToFill" />
          </view>
        </view>
        <swiper class="recentActivity-swiper" :style="myActivityList.length > 1 ? 'height:330rpx' : 'height:310rpx'" circular :indicator-dots="myActivityList.length > 1" :interval="interval" :duration="duration" :current="myActivityListCurrent" @change="changeMyActivityListCurrent">
          <swiper-item
            @click="
              $u.throttle(() => {
                goActivityDetail(item)
              }, 500)
            "
            v-for="item in myActivityList"
            :key="item.appointmentNo"
          >
            <view class="swiper-item">
              <view class="swiper-item-content flex-0">
                <view class="item-content-left">
                  <image class="content-left-img" :src="item.logo" mode="aspectFill" />
                </view>
                <view class="item-content-right">
                  <view class="content-right-title ellipsis-single">{{ item.name }}</view>
                  <view class="content-right-location flex-1">
                    <view class="location-text flex-0">
                      <image class="img" src="@/static/images/weizhi2.png" mode="aspectFill" />
                      <view class="text ellipsis-single">{{ item.location.address.city }} . {{ item.place }}</view>
                    </view>
                    <view
                      @click="
                        $u.throttle(() => {
                          openMap(item)
                        }, 500)
                      "
                      class="location-icon"
                    >
                      <image class="img" src="@/static/images/daohang.png" mode="scaleToFill" />
                    </view>
                  </view>
                </view>
              </view>
              <view style="width: 622rpx; height: 2rpx; border-top: 1rpx dashed #e7eaec"></view>
              <view v-if="recentActivityTab == '即将开始'" class="swiper-item-time flex-1">
                <view class="flex-0">
                  <view>距开始时间剩余</view>
                  <u-count-down class="count" :time="item.datatime" format="HH:mm:ss" autoStart millisecond @change="onChange($event, item)">
                    <view v-if="item.timeDataObj" class="time">
                      <block v-if="item.timeDataObj.days">
                        <view class="time__custom">
                          <text class="time__custom__item">{{ item.timeDataObj.days ? item.timeDataObj.days : '' }}</text>
                        </view>
                        <text style="margin: 0 8rpx 0 8rpx; font-size: 28rpx">天</text>
                      </block>

                      <view class="time__custom">
                        <text class="time__custom__item">{{ item.timeDataObj.hours ? (item.timeDataObj.hours > 9 ? item.timeDataObj.hours : '0' + item.timeDataObj.hours) : '00' }}</text>
                      </view>
                      <text class="time__doc">:</text>
                      <view class="time__custom">
                        <text class="time__custom__item">{{ item.timeDataObj.minutes ? (item.timeDataObj.minutes > 9 ? item.timeDataObj.minutes : '0' + item.timeDataObj.minutes) : '00' }}</text>
                      </view>
                      <text class="time__doc">:</text>
                      <view class="time__custom">
                        <text class="time__custom__item">{{ item.timeDataObj.seconds ? (item.timeDataObj.seconds > 9 ? item.timeDataObj.seconds : '0' + item.timeDataObj.seconds) : '00' }}</text>
                      </view>
                    </view>
                  </u-count-down>
                </view>
                <view @click.stop="goNormaldetails(item)" v-if="item.datatime < 30 * 60 * 1000" :class="item.isSign ? 'active-swiper-item-time-btn' : 'swiper-item-time-btn'">{{ item.isSign ? '已签到' : '去签到' }}</view>
              </view>
              <view v-if="recentActivityTab == '进行中'" class="reacentActivityIng flex-1">
                <view class="reacentActivityIng-left">
                  <view class="reacentActivityIng-top flex-0">
                    <view class="reacentActivityIng-top-pass" v-for="(item, index) in item.finishedTime" :key="index"></view>
                    <block v-if="item.nofinishedTime"><view class="reacentActivityIng-top-nopass" v-for="(item, index) in item.nofinishedTime" :key="index + 'a'"></view></block>
                  </view>
                  <view v-if="item.tips" class="reacentActivityIng-bottom flex-0">
                    <image class="reacentActivityIng-bottom-img" src="@/static/images/laba.png" mode="scaleToFill" />
                    <view class="reacentActivityIng-bottom-tips">温馨提示: {{ item.tips }}</view>
                  </view>
                </view>
                <view class="reacentActivityIng-right">
                  <block v-if="item.group == '我参与的' && item.appointmentState.text == '已完成'">
                    <view @click="nextPage('/pagesCommon/details/myActivity?optionDatas=F3&pageType=index')" v-if="item.canFinishOrder" class="reacentActivityIng-right-btn" style="background: #2a343e">前往确认</view>

                    <view
                      v-if="item.canScore && !item.canFinishOrder"
                      class="reacentActivityIng-right-btn"
                      @click.stop="
                        $u.throttle(() => {
                          goEvaluate(item)
                        }, 500)
                      "
                    >
                      去评价
                    </view>
                  </block>
                  <block v-if="item.group == '我发起的'">
                    <view v-if="item.appointmentState.text != '已完成'" class="reacentActivityIng-right-btn">前往完成</view>
                  </block>
                </view>
              </view>
            </view>
          </swiper-item>
        </swiper>
      </view>
      <!-- 即将开始/进行中 活动 end-->

      <!-- 官方活动  start-->
      <view class="official-Box" v-if="officialListData.length > 0">
        <view class="official-top-box">
          <view class="official-title">官方活动</view>
          <view class="official-right-box" @click="nextPage('/pages/index/officialActivities?pageType=1')">
            <view class="official-right-btn">往期回顾</view>
            <image class="official-right-icon" src="@/static/images/arrow_right.png" mode="scaleToFill" />
          </view>
        </view>
        <view class="official-middle-box" :style="officialListData.length > 6 ? 'overflow-x: scroll;' : 'overflow-x: hidden;'">
          <view class="smallBox">
            <view v-for="(item, index) in officialListData" :key="index" class="smallBoxImg" @click="smallClick(item, index)">
              <image :src="item.pic[0]" alt="" :class="currentBig === index ? 'smallImgChanged' : 'smallImg'" mode="aspectFill"></image>
              <image v-if="currentBig === index" src="https://img.yiqitogether.com/yyqc/20240715/upload_ipjic5i7tigzp620ank67fa4ho7hc7bi.png" alt="" class="small-line"></image>
            </view>
          </view>
        </view>
        <swiper class="official-bottom-swiper" circular :current="currentBig" @change="officialSwiperChange">
          <swiper-item
            v-for="item in officialListData"
            :key="item.appointmentNo"
            @click="
              $u.throttle(() => {
                goActivityDetail(item)
              }, 500)
            "
          >
            <view class="official-bottom-box-all">
              <view class="official-bottom-box-top">
                <view class="official-bottom-left">
                  <view class="official-bottom-left-top">
                    <image class="swiper-item-left-img" :src="item.pic[0]" mode="aspectFill" />
                    <view class="swiper-item-left-top-box">{{ $u.timeFormat(item.appointDateTimestamp, 'mm-dd hh:MM') }}</view>
                  </view>
                </view>
                <view class="official-bottom-right">
                  <view class="item-right-content">
                    <!-- ellipsis-single -->
                    <view class="content-top">
                      <image class="content-name-img" src="https://img.yiqitogether.com/yyqc/20240715/upload_jvuc8sw2xuagpwti2xinty35ugcyythy.png" mode="scaleToFill" />
                      {{ item.name }}
                    </view>
                    <view class="content-intro">{{ item.description }}</view>
                    <image class="fenxian" src="http://img.yiqitogether.com/yyqc/202306/fengexian%E5%A4%87%E4%BB%BD%202%402x.png" mode="scaleToFill" />
                    <view class="content-location flex-0">
                      <view class="location-box">
                        <image class="content-location-img" src="http://img.yiqitogether.com/yyqc/image/weizhi%E5%A4%87%E4%BB%BD%2019%402x.png" mode="scaleToFill" />
                        <view class="content-location-text">{{ item.location.address.city }} . {{ item.place }}</view>
                      </view>
                      <image
                        class="map-icon"
                        src="@/static/images/daohang.png"
                        mode="aspectFill"
                        @click="
                          $u.throttle(() => {
                            openMap(item)
                          }, 500)
                        "
                      />
                    </view>
                  </view>
                </view>
              </view>
              <view class="official-bottom-box">
                <view class="official-bottom-left-bottom">
                  <view class="official-bottom-left-avatar-box" v-if="item.members.length > 0 && item.members.length <= 3">
                    <image class="official-bottom-left-avatar" v-for="(itemAvatar, indexAvatar) in item.members" :key="indexAvatar" :src="itemAvatar" mode="aspectFill" />
                  </view>
                  <view class="official-bottom-left-number-box">
                    <text class="official-bottom-left-prople">{{ item.currentCount || '0' }}</text>
                    <text class="official-bottom-left-all">/{{ item.appointmentCount }}</text>
                    <text class="official-bottom-left-all" style="margin-left: 8rpx">已报名</text>
                  </view>
                </view>
              </view>
            </view>
          </swiper-item>
        </swiper>
      </view>

      <!-- 官方活动  end-->
      <!-- 新人福利  start-->
      <choicenessActivity :choicenessActivityList="choicenessActivityList" @loadMore="loadMore"></choicenessActivity>
      <!-- 新人福利  end-->
    </view>

    <!-- 活动列表 start -->
    <view class="normalActivity">
      <view class="normalActivity-tab flex-0">
        <view
          @click="
            $u.throttle(() => {
              toggleTabItem(item.type)
            }, 500)
          "
          :class="activityTabFlag == item.type ? 'active-normalActivity-tab-item' : 'normalActivity-tab-item'"
          v-for="item in activityTabArr"
          :key="item.type"
        >
          {{ item.name }}
          <view :style="activityTabFlag == item.type ? '' : 'visibility: hidden;'" class="border"></view>
        </view>
      </view>
      <view v-if="activityType.length > 0" class="normalActivity-top flex-1">
        <scroll-view class="normalActivity-activityType" scroll-x>
          <view
            @click="
              $u.throttle(() => {
                changeAppointType(item.code)
              }, 500)
            "
            class="activityTypeItem"
            :style="activityTypeChecked.indexOf(item.code) > -1 ? 'background: #FE5E10;color: #ffffff;' : ''"
            v-for="item in activityType"
            :key="item.code"
          >
            {{ item.text }}
          </view>
        </scroll-view>
        <view @click="openFilterPopup" class="screenBox flex-3"><image class="screenImg" src="@/static/images/saixuan.png" mode="scaleToFill" /></view>
      </view>
      <normal-activity-list :activityList="activityList" :showLoading="showLoading" :loadStatus="activityloadStatus">
        <view class="tips-box" @click="$u.throttle(activityListLoadMore, 500)">
          <u-loadmore :status="activityloadStatus" :fontSize="23" nomore-text="到底了~" />
        </view>
      </normal-activity-list>
    </view>
    <!-- 活动列表 end -->

    <!-- 筛选弹窗 -->
    <yue-screen-popup v-show="screenPopupFlag" :cityName="address.cityName" @closePopup="closeFilterPopup" @startScreen="startScreen" :radiovalue4="activityTypeChecked" :activityType="activityType"></yue-screen-popup>

    <!-- 获取定位弹框 -->
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于显示附近的人和活动" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="setAddress" isImg isOnShow></accredit-popup>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
    <!-- 扫码 -->
    <accredit-popup ref="accreditSweep" systemTitle="“一起一起”想访问您的相机" systemContent="用于使用上传照片功能" permisionID="android.permission.CAMERA" cacheId="cameraAccredit" @successAccredit="sweepEvent"></accredit-popup>
    <!-- 升级弹窗  -->
    <view class="popup versionpopup" v-if="isversion">
      <view class="popup-activity">
        <view class="popup-activity-title">发现新版本</view>
        <view class="popup-activity-version">版本号：V{{ versionData.version }}</view>
        <scroll-view class="popup-activity-tips" scroll-y>
          <view class="txt" v-for="(item, index) in versionDescList" :key="index">
            {{ item }}
          </view>
        </scroll-view>
        <view class="popup-activity-renewal" @click="goupgradation()">立即更新</view>
        <view class="popup-activity-ignore" @click="ignoreAndroidVersionRenewal()">忽略此版本</view>
        <image @click="isversion = false" class="popup-activity-off" src="@/static/images/balls_close.png" mode=""></image>
      </view>
    </view>
    <!-- 生日弹窗 -->
    <custom-birthday-popup :show="showCake" @close="closeCake" />

    <u-toast ref="uToast"></u-toast>
    <!-- 测试权限 勿删！！！ -->
    <!-- <view style="position: fixed; left: 0; top: 160rpx; width: 100rpx; height: 100rpx; border-radius: 20rpx; background-color: aquamarine" @click="testButton">删除授权状态</view> -->
  </view>
</template>
<script>
// 导入接口
import myModel from '@/model/my.js'
import IndexModal from '@/model/index'
import toolsModel from '@/model/tools.js'
import loginModel from '@/model/login.js'

import { getFormateTime, formateDate, openMap } from '@/utils/tools'
import { getTokenConnectRongYun } from '@/utils/publicRequest.js'
// 导入缓存工具 及 缓存字典
import { save, load, clear } from '@/utils/store.js'
import { AUTH_STUDENT, POSITION, ACCESS_LOCATION, CITY_NAME, rongyunToken, ANDROIDVERSIONIGNORE, IP_ADDRESS, CONNECTRONGYUN, USER_INFO, BIRTHDAYCAKE, LOGIN_USERID } from '@/utils/cacheKey.js'
import { getLocation, changeVersion, compareVersion, uploadFile } from '@/utils/tools.js'
import { judgeIdentity } from '@/utils/methodStash.js'
// 导入组件
import choicenessActivity from '../index/components/choicenessActivity.vue'
import normalActivityList from '../index/components/normal-activity-list.vue'

export default {
  components: { choicenessActivity, normalActivityList },
  data() {
    return {
      // 在当前页点击tabbar，刷新开关。默认关闭，在onshow里先关闭，2s以后再开启
      clickCurrentTabbarFlag: false,
      showCake: false, // 生日弹窗
      // 定位相关
      address: {
        cityName: '',
        lat: '',
        lon: '',
        position: ''
      },
      // 版本升级弹窗flag
      isversion: false,
      // 版本升级信息
      versionData: {},
      versionDescList: [],
      // 是否认证
      authSimple: '',
      // 头部卡片
      bannerList: [],
      bannerList1: [],
      officialActivityList: [],
      timeData: {},
      recentActivityTab: '即将开始',
      loadStatus: 'loadmore',
      activityloadStatus: 'loadmore',
      officialListData: [],
      getFormateTime,
      activityType: [], //活动类型
      activityTypeStr: '', //选择的活动类型
      activityTypeChecked: [], //选择的活动类型
      screenPopupFlag: false, //筛选弹框
      screenDate: {}, //筛选数据
      pageNumber: 0,
      pages: 0,
      choicenessPageNumber: 0,
      choicenessPages: 0,
      // 活动切换flag
      activityTabFlag: 'G1',
      activityTabArr: [
        {
          name: '精选活动',
          type: 'G1'
        },
        {
          name: '成团活动',
          type: 'G2'
        },
        {
          name: '历史活动',
          type: 'G3'
        }
      ],
      interval: 2000,
      duration: 500,
      activityList: [],
      formateDate,
      showLoading: false,
      recentActivityList: { list1: [], list2: [] }, //活动
      myActivityList: [],
      noClick: true,
      choicenessActivityList: [],
      openMap,
      myActivityListCurrent: 0, //即将开始、进行中滑动current
      isIos: false,
      // banner节流
      bannerDebounce: false,
      isScroll: false,
      // 副轮播
      subBannerList: [],
      currentBig: 0,
      numberId: load(LOGIN_USERID).toString() || '' // 本人numberId
    }
  },
  watch: {
    'address.cityName': 'handleCityName'
  },
  onTabItemTap(e) {
    if (this.clickCurrentTabbarFlag) {
      uni.$u.debounce(this.refreshActivityList, 1000)
    }
  },
  onLoad(options) {
    let info = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)) : {}
    let nowDay = uni.$u.timeFormat(new Date().getTime(), 'mm-dd')
    if (info.birthday && info.birthday.slice(5, 10) == nowDay) {
      if (load(BIRTHDAYCAKE)) {
        this.showCake = false
      } else {
        this.showCake = true
      }
    }
    this.isIos = uni.getSystemInfoSync().platform === 'ios'
    this.getVersion()
    // #ifdef APP-PLUS
    this.getEngine()
    // this.getTotalUnreadCount()
    //获取当前页面的webview对象 禁止侧滑
    let currentWebview = this.$mp.page.$getAppWebview()
    currentWebview.setStyle({ popGesture: 'none' })
    // #endif

    this.appointmentType()
    this.getMyAppointmentIndex()
    this.getQueryByTag()
    this.getOfficialList()
    this.$nextTick(() => {
      this.getActivityList()
    })
    uni.$on('openIndexPopup', () => {
      this.closeCake()
      this.$refs.publishPopupRef.onOpen()
    })
  },
  onShow() {
    uni.showTabBar()
    this.clickCurrentTabbarFlag = false
    setTimeout(() => {
      this.clickCurrentTabbarFlag = true
    }, 1000)
    // #ifdef H5
    this.scrollTop = 0
    uni.pageScrollTo({
      scrollTop: 0,
      duration: 0
    })
    // #endif
    // #ifdef APP-PLUS
    this.getRealnameAuthStatus()
    // #endif
    // 如果当前没有定位信息，重新获取定位，如果有，直接读取
    let latLonStr = load(POSITION)
    let city = load(CITY_NAME)
    if (!latLonStr || !city) {
      // 获取位置及地理名称，存入缓存
      this.$nextTick(() => {
        this.$refs.accredit.triggerEvent()
      })
    } else {
      this.address.position = latLonStr
      this.address.cityName = city
    }
  },
  onHide() {
    this.closeCake()
    this.$refs.publishPopupRef.onClose()
    this.closeFilterPopup()
  },
  onPullDownRefresh() {
    if (this.isMask) return uni.stopPullDownRefresh()
    // 下拉时刷新活动列表 重置分页
    this.refreshActivityList()
  },
  onReachBottom() {
    this.activityListLoadMore()
  },
  onPageScroll({ scrollTop }) {
    this.isScroll = scrollTop > 20
  },
  methods: {
    closeCake() {
      this.showCake = false
      save(BIRTHDAYCAKE, 'nomoreShow')
    },
    // 打开筛选弹窗
    openFilterPopup() {
      uni.hideTabBar()
      this.screenPopupFlag = true
    },
    // 关闭筛选弹窗
    closeFilterPopup() {
      this.screenPopupFlag = false
      uni.showTabBar()
    },
    /**
     * 刷新数据使用，本页面或其他页面刷新列表 调用该方法
     */
    refreshActivityList() {
      this.activityList = []
      this.pageNumber = 0
      this.pages = 0
      this.choicenessPageNumber = 0
      this.choicenessPages = 0
      this.choicenessActivityList = []
      this.screenDate = {}
      this.screenPopupFlag = false
      this.activityTabFlag = 'G1'
      this.activityloadStatus = 'loadmore'

      this.getActivityList()
      this.getOfficialList()
      this.getMyAppointmentIndex()
      this.getQueryByTag()
      this.appointmentType()
    },
    // 上传进度示例，勿删
    upload() {
      let self = this
      uni.chooseVideo({
        sourceType: ['camera', 'album'],
        success: async function (res) {
          let data = await uploadFile(res.tempFilePath, uploadRes => {
            self.progressUpdate(uploadRes)
          })
        }
      })
    },
    progressUpdate(res) {
      console.log('上传进度', res.progress)
    },
    // 解决弹窗滚动穿透问题
    handleTouchMove(e) {
      e.stopPropagation()
    },
    // 测试按钮 暂时勿删！！！！！
    testButton() {
      clear(ACCESS_LOCATION)
      clear(EXTERNAL_STORAGE)
      clear(CAMERA_ACCREDIT)
      clear(CITY_NAME)
      clear(POSITION)
    },
    /**
     * 获取实名认证状态
     */
    async getRealnameAuthStatus() {
      let res = await myModel.userInfoStatusV2()
      if (res.code == 'SUCCESS') {
        // 实名认证状态
        this.authSimple = res.data.authSimple == 'SUCCESS' ? 'SUCCESS' : 'FAIL'
        save(AUTH_STUDENT, res.data.authStudent)
      }
    },
    /**
     * 去除城市中多余的市
     */
    handleCityName() {
      let str = this.address.cityName
      let char = '市'
      const regex = new RegExp(`${char}+`, 'g')
      this.address.cityName = str.replace(regex, char)
    },
    /**
     * 展示下方tabbar 及 重新 未实名时弹出实名弹窗
     */
    hiddenTab() {
      this.hiddenS = true
      this.authSimple = ''
    },

    /**
     * top 选择地址跳转后返回页面选择的地址
     */
    changeAddress(url) {
      let that = this
      uni.navigateTo({
        url,
        events: {
          getCityName: function (data) {
            console.log(`页面index,之前地址：${that.address.cityName},更新后地址${data}`)
            that.address.cityName = data
          }
        }
      })
    },
    /**
     * 同意获取定位授权
     */
    async setAddress() {
      let latLonStr = await getLocation()
      if (!latLonStr) {
        // console.log('未获取到定位或授权')
        this.address.position = ''
        this.address.cityName = '选择定位'
        return
      }
      // 用户地址的经纬度，首页左上角可以切换
      save(POSITION, latLonStr)
      // 用户的IP地址经纬度，不可手动更改
      save(IP_ADDRESS, latLonStr)
      // 根据经纬度，获取城市名称
      toolsModel
        .getAddressInfo({
          position: latLonStr
        })
        .then(res => {
          save(CITY_NAME, res.data.city)
          console.log('当前所在城市名称：', res)
          this.address.position = latLonStr
          this.address.cityName = res.data.city
          let province = res.data.province ? res.data.province : ''
          let city = res.data.city ? res.data.city : ''
          let addressStr2 = province + '&&' + city
          uni.setStorage({
            key: 'addressStr2',
            data: latLonStr
          })
        })
        .catch(err => {})
    },
    /**
     * 获取版本信息，判断是否需要 进行安卓弹窗升级
     */
    getVersion() {
      // #ifdef APP-PLUS
      if (uni.getSystemInfoSync().platform == 'android') {
        toolsModel.getVersion().then(dataRes => {
          if (dataRes.code == 'SUCCESS') {
            let ignoreVersionList = load(ANDROIDVERSIONIGNORE) || []
            this.versionData = dataRes.data
            this.versionDescList = dataRes.data && dataRes.data.renewInfo ? dataRes.data.renewInfo.split('。') : []
            let versionNum = plus.runtime.version
            this.isversion = compareVersion(versionNum, this.versionData.version) && !ignoreVersionList.includes(dataRes.data.version)
          }
        })
      }
      // #endif
    },
    /**
     * 跳转，更新地址
     */
    goupgradation() {
      // #ifdef APP-PLUS
      this.isversion = false
      uni.showToast({
        title: '正在升级版本',
        icon: 'none',
        duration: 2500
      })
      changeVersion(this.versionData.downloadUrl)
      //#endif
    },
    /**
     *
     */
    ignoreAndroidVersionRenewal() {
      let ignoreVersionList = load(ANDROIDVERSIONIGNORE) || []
      if (this.versionData.version) {
        ignoreVersionList.push(this.versionData.version)
        save(ANDROIDVERSIONIGNORE, ignoreVersionList)
      }
      this.isversion = false
      uni.showToast({
        title: '已忽略本版本更新',
        icon: 'none'
      })
    },
    // 获取所有的未读数
    async getTotalUnreadCount() {
      this.$store.state.engie.setOnUnreadCountByConversationTypesLoadedListener(res => {
        console.log(res, '未读数数量')
        if (res.count != 0) {
          uni.showTabBarRedDot({
            index: 2
          })
        } else {
          uni.removeTabBarBadge({
            //隐藏数字标
            index: 2 //tabbar下标
          })
          try {
            plus.runtime.setBadgeNumber(0)
            // plus.push.clear()
          } catch (error) {}
        }
      })
      let code = await this.$store.state.engie.getUnreadCountByConversationTypes([1, 2], null, false, null)
      // uni.removeTabBarBadge({
      //   //隐藏数字标
      //   index: 2 //tabbar下标
      // })
    },
    /**
     * 融云初始化，链接相应的应用
     */
    async getEngine() {
      let that = this
      if (!load(CONNECTRONGYUN)) {
        getTokenConnectRongYun(that)
      }
      this.$store.state.engie.setOnConnectedListener(res => {
        console.log('融云连接的回调', res)
        if (res.code == 0 || res.code == 34001) {
          // 获取融云所有的未读数
          this.getTotalUnreadCount()
        } else {
          console.log('连接异常,请稍后再试')
        }
      })
      this.$store.state.engie.setOnMessageReceivedListener(res => {
        //设置消息监听
        if (res.message.conversationType == 1) {
          // 全局注册事件，目的：当接收到外来消息时，要让私聊页面自动刷新
          uni.$emit('updateHistory', { msg: res })
        } else {
          // 群聊监听
          uni.$emit('updateHistoryGroup', { msg: res })
        }
      })
    },
    // 近期活动倒计时
    onChange(e, item) {
      this.timeData = e
      let newItem = item
      if (this.recentActivityTab == '即将开始') {
        this.recentActivityList.list1.map(item => {
          if (item.appointmentNo == newItem.appointmentNo) {
            item.timeDataObj = e
          } else {
            item.timeDataObj = { ...item.timeDataObj }
          }
        })
        this.myActivityList = this.recentActivityList.list1
        this.$forceUpdate()
      }
    },
    officialChange(e, item, index) {
      // console.log(e, '11')
      // console.log(item, '2211')
      // this.officialListData[index].timeDataObj = e
      let newItem = item
      this.officialListData.map(item => {
        if (item.appointmentNo == newItem.appointmentNo) {
          item.timeDataObj = e
        } else {
          item.timeDataObj = { ...item.timeDataObj }
        }
      })
      this.$forceUpdate()
    },
    /**
     * 近期活动tab切换（即将开始、进行中）
     */
    changeRecentActivityTab(type) {
      this.recentActivityTab = type

      this.getMyAppointmentIndex()
    },
    // 获取官方活动列表信息
    getOfficialList() {
      let data = {
        pageNo: 1,
        pageSize: 5,
        group: 'G1'
      }
      IndexModal.officialAppointment(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.officialListData = res.data.page.list || []
            // item.datatime = item.appointDate - Date.parse(new Date())
            this.officialListData.map(item => {
              item.datatime = item.appointDateTimestamp - Date.parse(new Date())
              item.membersLength = item.members.length
              item.position = item.position ? item.position : item.location.position
            })

            if (res.data.page.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.loadStatus = 'none'
        })
    },
    /**
     * 活动类型
     */
    appointmentType() {
      IndexModal.getActivityTypeV().then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          this.activityType = dataRes.data.appointmentType
          this.bannerList1 = dataRes.data.indexBanner || []
          this.bannerList = dataRes.data.indexBanner2 || []
          // this.bannerListLength = Math.ceil(this.bannerList.length / 5)
          this.subBannerList = this.arrayChunk(this.bannerList, 5)
        }
      })
    },
    // size每组数组多少个，如：8
    // array需要拆分的数组
    arrayChunk(array, size) {
      let data = []
      for (let i = 0; i < array.length; i += size) {
        data.push(array.slice(i, i + size))
      }
      return data
    },
    /**
     * @param {Object} queryData 筛选的结果
     * 筛选完成，获取数据
     */
    startScreen(queryData) {
      this.activityTypeStr = queryData.appointmentType
      this.screenDate = queryData
      this.pageNumber = 0
      this.pages = 0
      this.activityList = []
      this.screenPopupFlag = false
      uni.showTabBar()
      this.activityloadStatus = 'loadmore'

      this.getActivityList()
    },
    /**
     * 获取活动列表数据
     */
    getActivityList(data) {
      // loading弹窗
      this.showLoading = true
      let queryData = {
        position: this.address.position,
        group: this.activityTabFlag,
        ...this.screenDate,
        pageNo: this.pageNumber + 1,
        pageSize: 10
      }
      IndexModal.activityQuery(queryData)
        .then(res => {
          uni.stopPullDownRefresh()
          if (res.code == 'SUCCESS') {
            this.activityList.push(...res.data.page.list)
            this.pages = res.data.page.pages
            this.pageNumber = res.data.page.pageNumber
            if (res.data.page.total == 0) {
              this.activityloadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.activityloadStatus = 'nomore'
              } else {
                this.activityloadStatus = 'loadmore'
              }
            }
          } else {
          }
          this.showLoading = false
        })
        .catch(err => {
          uni.stopPullDownRefresh()
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    changeMyActivityListCurrent(e) {
      this.myActivityListCurrent = e.detail.current
      this.$forceUpdate()
    },
    /**
     * 获取首页我的活动(即将开始、进行时)
     */
    getMyAppointmentIndex() {
      this.myActivityListCurrent = 0
      this.$forceUpdate()
      IndexModal.getMyAppointmentIndex()
        .then(res => {
          if (res.code == 'SUCCESS') {
            res.data.list1.map(item => {
              item.datatime = item.appointDate - Date.parse(new Date())
              item.position = item.location.position
            })
            res.data.list2.map(item => {
              item.position = item.location.position
              let todyDate = Date.parse(new Date())
              item.datatime = item.appointDate - todyDate

              item.countTime = Math.ceil(Math.abs(new Date(todyDate) - new Date(item.appointDate)) / (1000 * 60 * 60 * 24))
              if (item.countTime >= 7) {
                item.finishedTime = 7
              } else {
                item.finishedTime = item.countTime
                item.nofinishedTime = 7 - item.countTime
              }
            })
            let newList = { list1: res.data.list1.slice(0, 7), list2: res.data.list2.slice(0, 7) }

            if (newList.list1.length < 1) {
              this.recentActivityTab = '进行中'
            }
            if (newList.list2.length < 1) {
              this.recentActivityTab = '即将开始'
            }

            if (this.recentActivityTab == '即将开始') {
              this.myActivityList = newList.list1
            } else {
              this.myActivityList = newList.list2
            }
            this.recentActivityList = newList
          }
        })
        .catch(err => {})
    },
    /**
     * 获取新人福利活动列表
     */
    getQueryByTag() {
      let data = {
        tag: '@REWARD_',
        pageNo: this.choicenessPageNumber + 1,
        pageSize: 4,
        position: this.address.position
      }
      IndexModal.getQueryByTag({ ...data })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.choicenessPages = res.data.page.pages
            this.choicenessPageNumber = res.data.page.pageNumber
            this.choicenessActivityList.push(...res.data.page.list)

            if (res.data.page.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          }
        })
        .catch(err => {
          uni.stopPullDownRefresh()
          this.loadStatus = 'none'
        })
    },
    /**
     * 加载更多
     */
    loadMore() {
      if (this.loadStatus != 'nomore') {
        if (this.choicenessPages > this.choicenessPageNumber) {
          this.getQueryByTag()
        }
      } else {
        this.loadStatus = 'nomore'
      }
    },
    /**
     * 普通活动列表加载更多
     */
    activityListLoadMore() {
      if (this.pages > this.pageNumber) {
        this.activityloadStatus = 'loadmore'
        this.getActivityList()
      }
    },
    // 切换活动选项
    toggleTabItem(type) {
      if (this.activityTabFlag == type) {
        return
      }
      this.activityTabFlag = type
      this.pages = 0
      this.pageNumber = 0
      this.activityList = []
      this.screenDate = {}
      this.activityTypeChecked = []
      this.activityTypeStr = ''
      this.activityloadStatus = 'loadmore'

      this.getActivityList()
    },
    // 切换活动类型
    changeAppointType(type) {
      if (this.activityTypeChecked.indexOf(type) == -1) {
        this.activityTypeChecked.push(type)
      } else {
        this.activityTypeChecked.splice(this.activityTypeChecked.indexOf(type), 1)
      }

      this.activityTypeStr = this.activityTypeChecked.toString()
      this.pages = 0
      this.pageNumber = 0
      this.activityList = []
      this.screenDate = { ...this.screenDate, appointmentType: this.activityTypeStr }
      this.$forceUpdate()
      this.startScreen(this.screenDate)
      // 滑动到底部时，拉取下一页数据
    },

    /**
     * 扫一扫
     */
    sweep() {
      this.$refs.accreditSweep.triggerEvent()
      this.noClick = false
    },
    sweepEvent() {
      // 允许从相机和相册扫码
      this.noClick = true
      let that = this
      uni.scanCode({
        success: function (res) {
          let strPosition = res.result.indexOf('/pagesCommon/details/details')
          let info = res.result.indexOf('"type":"joinGroup"')
          let pcLoginInfo = res.result.indexOf('"type":"pcLogin"')
          let activityDetails = res.result.indexOf('"type":"eventDetails"')
          if (info > -1) {
            let a = JSON.parse(res.result)
            uni.navigateTo({
              url: '/pagesMessage/privateChat/groupConfirm?groupNo=' + a.groupNo
            })
          } else if (strPosition > -1) {
            let path = res.result.substring(strPosition)
            uni.navigateTo({
              url: path
            })
          } else if (pcLoginInfo > -1) {
            let pcLoginData = JSON.parse(res.result)
            let data = {
              uuid: pcLoginData.uuid,
              numberId: that.numberId
            }
            loginModel
              .getScanQrCode(data)
              .then(res => {
                if (res.code == 'SUCCESS') {
                  uni.navigateTo({ url: '/pages/login/scanLoginQrCode?dataInfo=' + JSON.stringify(data) })
                } else {
                  uni.showToast({
                    title: res.message,
                    icon: 'none'
                  })
                }
              })
              .catch(err => {
                uni.showToast({
                  title: err.message,
                  icon: 'none'
                })
              })
          } else if (activityDetails > -1) {
            let activityDetailsInfo = JSON.parse(res.result)
            uni.navigateTo({ url: '/pagesCommon/details/details?appointmentNo=' + activityDetailsInfo.appointmentNo })
          } else {
            uni.showToast({
              title: '暂不支持该类型的二维码',
              icon: 'none'
            })
          }
        }
      })
    },
    /**
     * banner跳转
     * 101 内部跳转;  值为/pages/index/index 类型路由
     * 102 webview打开;  值为http://baidu.com 类型链接（靓靓 —— type=1）
     * 103 webview打开;  值为http://baidu.com 类型链接（钱包 —— type=2）
     * 104 不跳转展示提示语;   值为 暂未开发，敬请期待 类型提示语
     * 105 打开通用页面，携带图片链接  值为 图片链接地址
     * 106 其他（自定义）
     * 107 打开其他外部网页，如百度等
     * 400 无操作，无提示（理论上不会用到）。
     */
    bannerSkip(path) {
      console.log(path)
      if (this.bannerDebounce) {
        return
      }
      this.bannerDebounce = true
      // 兼容轮播图数据，path是当前索引值，number类型
      if (typeof path === 'number') {
        path = this.bannerList1[path].linkUrl
      }
      console.log(path)

      let type = path.substring(0, 3)
      let linkValue = path.substring(3, path.length)
      switch (type) {
        case '101':
          uni.navigateTo({
            url: linkValue,
            fail(e) {
              uni.showToast({
                title: '当前版本暂不支持',
                icon: 'none'
              })
            }
          })
          break
        case '102':
          let obj = {
            type: '1',
            openUrl: linkValue
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
          uni.navigateTo({ url: `/pages/my/webView` })
          break
        case '103':
          let obj2 = {
            type: '2',
            openUrl: linkValue
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj2))
          uni.navigateTo({ url: `/pages/my/webView` })
          break
        case '104':
          uni.showToast({
            title: linkValue,
            icon: 'none'
          })
          break
        case '105':
          uni.navigateTo({
            url: `/pages/index/publicPage?image=${linkValue}`
          })
          break
        case '106':
          if (linkValue == '/recruit') {
            judgeIdentity()
          }
          break
        case '107':
          uni.navigateTo({ url: `/pagesSetting/setting/webView?url=${linkValue}` })
          break
        case '108':
          uni.navigateTo({ url: `/pages/my/loadOtherPages?openUrl=${linkValue}` })
          break
        case '400':
          console.log('无操作，无提示')
          break
        default:
          uni.showToast({
            title: '当前版本暂不支持',
            icon: 'none'
          })
      }
      setTimeout(() => {
        this.bannerDebounce = false
      }, 1000)
    },
    // 去往搜索页面
    goSearchPages() {
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/indexSearch'
      })
      // uni.navigateTo({
      //   url: '/pagesFind/find/releaseArticle'
      // })
    },
    // 前往查看活动页面
    goActivityDetail(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo
      })
    },
    /**
     * 去签到
     */
    goNormaldetails(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/activitySignIn?appointmentNo=' + item.appointmentNo + '&sourcePage=index'
      })
    },
    // 去评价
    goEvaluate(item) {
      uni.navigateTo({
        url: `/pagesCommon/details/details?appointmentNo=${item.appointmentNo}&beNumberId=${item.creatorUserId}&sourcePage=index`
      })
    },
    /**
     * 跳转页面
     */ nextPage(url) {
      uni.$u.throttle(() => {
        uni.navigateTo({
          url
        })
      }, 500)
    },
    intervalChange(e) {
      this.interval = e.target.value
    },
    durationChange(e) {
      this.duration = e.target.value
    },
    // 轮播图小图点击
    smallClick(item, index) {
      this.currentBig = index
    },
    // 官方活动滑动
    officialSwiperChange(e) {
      this.currentBig = e.detail.current
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.indexPages {
  background-color: #f7f8f9;
  position: relative;
  .top-input-box {
    position: absolute;
    top: 374rpx;
    left: 36rpx;
    // background: url('@/static/images/sousuokuang.png');
    // background-size: 100% 100%;
    // width: 520rpx;
    // height: 76rpx;
    // padding: 20rpx 26rpx 20rpx 20rpx;
    width: 678rpx;
    height: 72rpx;
    background: #ffffff;
    // background-color: pink;
    border-radius: 38rpx;
    box-shadow: 0rpx 2rpx 14rpx 0rpx #f1f3f4;
    padding: 18rpx 40rpx;
    box-sizing: border-box;
    margin-top: -10rpx;
    // z-index: 999999;
    z-index: 1;
    .top-input-searchImg {
      width: 36rpx;
      height: 36rpx;
      margin-right: 8rpx;
    }
    .top-input {
      color: #838e9a;
      font-size: 28rpx;
    }
    .top-scanQrcode {
      width: 32rpx;
      height: 32rpx;
      display: block;
    }
  }
  // .topBg {
  //   background: linear-gradient(180deg, #ffffff, #ffffff 75%, #f7f8f9 86%, #f7f8f9 43%);
  // }

  .swiper-box {
    width: 750rpx;
    height: 472rpx;
    position: relative;
    // display: flex;
    // justify-content: center;
    // align-items: center;
    .header {
      z-index: 999;
      position: fixed;
      padding: calc(var(--status-bar-height) + 28rpx) 36rpx 18rpx;
      // background-color: #ffffff;
      width: 100%;
      box-sizing: border-box;
      top: 0;
      left: 0;
      .location {
        .header-location {
          // max-width: 112rpx;
          font-size: 36rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: left;
          color: #2a343e;
          line-height: 56rpx;
        }
        .header-arrowImg {
          margin-left: 8rpx;
          width: 20rpx;
          height: 20rpx;
        }
      }
      .search-icon {
        width: 56rpx;
        height: 56rpx;
        display: block;
        margin-right: 22rpx;
      }
      .qrCode {
        width: 56rpx;
        height: 56rpx;
        display: block;
      }
    }
  }
  .aiImg {
    width: 750rpx;
    height: 274rpx;
    background: #fff;
    margin: auto;
  }
  .banner-sub-box {
    width: 678rpx;
    height: 178rpx;
    background: #ffffff;
    border-radius: 24rpx;
    margin: 0 auto;
    padding-bottom: 8rpx;
    box-sizing: border-box;
    .banner-sub {
      padding: 24rpx 28rpx 0rpx 24rpx;
      display: flex;
      box-sizing: border-box;
      .banner-sub-item {
        margin-right: 36rpx;
        text-align: center;
        .banner-item-img {
          width: 96rpx;
          // height: 88rpx;
          // width: 144rpx;
          height: 132rpx;
          // background: #e5fffe;
          // border-radius: 28rpx;
        }
      }
      .banner-sub-item:last-child {
        margin-right: 0;
      }
    }
  }

  .recentActivity {
    margin-top: 52rpx;
    padding: 0 36rpx 20rpx;
    box-sizing: border-box;
    .recentActivity_title {
      .recentActivity_title_left {
        .activityStatus {
          width: 192rpx;
          height: 66rpx;
          border-radius: 20rpx 20rpx 0rpx 0rpx;
          display: block;
        }
        .Active-activityStatus {
          width: 192rpx;
          height: 66rpx;
          // background: #ffebe8;
          background-color: #fff;
          border-radius: 20rpx 20rpx 0rpx 0rpx;
          display: block;
        }
      }
      .recentActivity_title_right {
        .recentActivity_title_right-text {
          font-size: 24rpx;
          color: #838e9a;
          margin-right: 8rpx;
        }
        .recentActivity_title_right-icon {
          width: 20rpx;
          height: 20rpx;
        }
      }
    }
    .recentActivity-swiper {
      height: 330rpx;
      .swiper-item {
        background-color: #fff;
        background-size: 100% 100%;
        width: 678rpx;
        height: 310rpx;
        padding: 32rpx 28rpx;
        box-sizing: border-box;
        border-radius: 0rpx 20rpx 36rpx 36rpx !important;
        .swiper-item-content {
          margin-bottom: 16rpx;
          .item-content-left {
            margin-right: 16rpx;
            .content-left-img {
              width: 192rpx;
              height: 144rpx;
              border: 4rpx solid #ffffff;
              border-radius: 20rpx;
            }
          }
          .item-content-right {
            flex-grow: 1;
            .content-right-title {
              width: 406rpx;
              font-weight: 700;
              font-size: 32rpx;
              color: #0c0c0c;
            }
            .content-right-location {
              margin-top: 14rpx;
              .location-text {
                .img {
                  width: 20rpx;
                  height: 20rpx;
                  margin-right: 8rpx;
                }
                .text {
                  width: 250rpx;
                  font-size: 24rpx;
                  color: #2a343e;
                }
              }
              .location-icon {
                padding: 10rpx;
                .img {
                  width: 44rpx;
                  height: 44rpx;
                }
              }
            }
          }
        }
        .swiper-item-time {
          margin-top: 16rpx;
          font-size: 24rpx;
          color: #2a343e;
          .count {
            margin-left: 16rpx;
            .time {
              @include flex;
              align-items: center;

              &__custom {
                // margin-top: 4px;
                width: 22px;
                height: 22px;
                background: #ffe2e7;
                border-radius: 4px;
                /* #ifndef APP-NVUE */
                display: flex;
                /* #endif */
                justify-content: center;
                align-items: center;

                &__item {
                  color: #fb5c4e;
                  font-size: 12px;
                  text-align: center;
                }
              }

              &__doc {
                padding: 0px 4px;
              }

              &__item {
                color: #606266;
                font-size: 15px;
                margin-right: 4px;
              }
            }
          }
          .swiper-item-time-btn {
            width: 156rpx;
            height: 52rpx;
            background: #fe5e10;
            border-radius: 12rpx;
            font-size: 26rpx;
            color: #ffffff;
            line-height: 52rpx;
            text-align: center;
          }
          .active-swiper-item-time-btn {
            width: 156rpx;
            height: 52rpx;
            background: #ffeef1;
            border-radius: 12rpx;
            font-size: 26rpx;
            color: #fe5e10;
            line-height: 52rpx;
            text-align: center;
          }
        }
        .reacentActivityIng {
          margin-top: 23rpx;
          .reacentActivityIng-left {
            .reacentActivityIng-top {
              .reacentActivityIng-top-pass {
                width: 52rpx;
                height: 8rpx;
                background: #4e4e4e;
                border-radius: 4rpx 4rpx 0rpx 0rpx;
                margin-right: 4rpx;
              }
              .reacentActivityIng-top-nopass {
                width: 52rpx;
                height: 8rpx;
                background: #f0f1f3;
                border-radius: 4rpx 4rpx 0rpx 0rpx;
                margin-right: 4rpx;
              }
            }
            .reacentActivityIng-bottom {
              margin-top: 12rpx;
              .reacentActivityIng-bottom-img {
                width: 20rpx;
                height: 20rpx;
                margin-right: 6rpx;
              }
              .reacentActivityIng-bottom-tips {
                font-size: 16rpx;
                color: #a6acb2;
              }
            }
          }
          .reacentActivityIng-right {
            .reacentActivityIng-right-btn {
              width: 156rpx;
              height: 52rpx;
              background: #fe5e10;
              border-radius: 12rpx;
              text-align: center;
              font-size: 26rpx;
              color: #ffffff;
              line-height: 52rpx;
            }
          }
        }
      }
    }
  }

  .official-Box {
    padding: 0 36rpx;
    margin-top: 40rpx;
    .official-top-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
      .official-title {
        font-size: 32rpx;
        font-family: PingFang SC, PingFang SC-Regular;
        font-weight: 700;
        text-align: left;
        color: #2a343e;
        line-height: 50rpx;
      }
      .official-right-box {
        display: flex;
        align-items: center;
        .official-right-btn {
          font-size: 24rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: left;
          color: #838e9a;
          line-height: 34rpx;
          margin-right: 8rpx;
        }
        .official-right-icon {
          width: 20rpx;
          height: 20rpx;
        }
      }
    }

    .official-middle-box {
      box-sizing: border-box;
      margin-top: 38rpx;
      // overflow-x: auto;

      .smallBox {
        width: 100%;
        height: 104rpx;
        // position: absolute;
        // top: 500rpx;
        z-index: 999;
        display: flex;
        padding: 0 26rpx;
        align-items: center;
        // overflow: hidden;
        // background-color: pink;
      }

      .smallBoxImg {
        // width: 96rpx;
        // height: 96rpx;
        margin-right: 16rpx;
        margin-top: 8rpx;
        position: relative;
      }
      .smallImg {
        width: 88rpx;
        height: 88rpx;
        background-size: cover;
        border-radius: 10rpx;
        opacity: 0.5;
        margin-top: 8rpx;
      }
      .smallImgChanged {
        width: 88rpx;
        height: 88rpx;
        background: #ffffff;
        border-radius: 10rpx;
        margin-top: 8rpx;
      }
      .small-line {
        width: 96rpx;
        height: 96rpx;
        position: absolute;
        // top: -8rpx;
        // left: -8rpx;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
    }
    .official-bottom-swiper {
      height: 360rpx;
    }
    .official-bottom-box-all {
      height: 304rpx;
      background: #ffffff;
      border-radius: 20rpx;
      padding: 20rpx 0 0 20rpx;
      box-sizing: border-box;
      margin-top: 30rpx;
      .official-bottom-box-top {
        display: flex;
        // margin-bottom: 100rpx;
        .official-bottom-left {
          width: 264rpx;
          .official-bottom-left-top {
            position: relative;
            .swiper-item-left-img {
              width: 264rpx;
              height: 192rpx;
              border-radius: 16rpx;
            }
            .swiper-item-left-top-box {
              position: absolute;
              top: 0;
              left: 0;
              height: 40rpx;
              opacity: 0.7;
              background: #000000;
              border-radius: 12rpx 0rpx 20rpx 0rpx;
              font-size: 20rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: left;
              color: #ffffff;
              line-height: 28rpx;
              display: flex;
              justify-content: center;
              align-items: center;
              padding: 0 12rpx;
            }
          }
        }
        .official-bottom-right {
          padding: 38rpx 0 0 20rpx;
          // background-color: skyblue;
          box-sizing: border-box;
          .item-right-content {
            .content-top {
              width: 350rpx;
              display: flex;
              // align-items: center;
              font-size: 32rpx;
              color: #2a343e;
              font-weight: 700;
              display: -webkit-box;
              -webkit-line-clamp: 1;
              -webkit-box-orient: vertical;
              word-break: break-all;
              text-overflow: ellipsis;
              overflow: hidden;
              // background-color: skyblue;
              .content-name-img {
                width: 36rpx;
                height: 36rpx;
              }
            }
            .content-intro {
              width: 350rpx;
              margin: 12rpx 0 20rpx 0;
              font-size: 20rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: left;
              color: #64696f;
              line-height: 28rpx;
              display: -webkit-box;
              -webkit-line-clamp: 1;
              -webkit-box-orient: vertical;
              word-break: break-all;
              text-overflow: ellipsis;
              overflow: hidden;
            }
            .fenxian {
              width: 350rpx;
              height: 4rpx;
              display: block;
              margin-bottom: 8rpx;
            }
            .content-location {
              display: flex;
              // justify-content: space-between;
              align-items: center;
              .location-box {
                display: flex;
                align-items: center;
                .content-location-img {
                  width: 32rpx;
                  height: 32rpx;
                  margin-right: 8rpx;
                  flex-shrink: 0;
                }
                .content-location-text {
                  width: 260rpx;
                  font-size: 18rpx;
                  color: #64696f;
                  display: -webkit-box;
                  -webkit-line-clamp: 1;
                  -webkit-box-orient: vertical;
                  word-break: break-all;
                  text-overflow: ellipsis;
                  overflow: hidden;
                }
              }
              .map-icon {
                width: 40rpx;
                height: 40rpx;
                flex-shrink: 0;
              }
            }
          }
        }
      }
      .official-bottom-box {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-right: 20rpx;
        // background-color: skyblue;
        .official-bottom-left-bottom {
          display: flex;
          // align-items: center;
          margin-top: 24rpx;
          .official-bottom-left-avatar-box {
            margin-right: 12rpx;
            // background-color: skyblue;
            .official-bottom-left-avatar {
              width: 48rpx;
              height: 48rpx;
              border-radius: 50%;
            }
            .official-bottom-left-avatar:nth-child(2) {
              margin-left: -16rpx;
            }
            .official-bottom-left-avatar:nth-child(3) {
              margin-left: -16rpx;
            }
          }
          .official-bottom-left-number-box {
            // background-color: pink;
            font-size: 22rpx;
            font-family: PingFang SC, PingFang SC-Regular;
            font-weight: Regular;
            text-align: left;
            // line-height: 32rpx;
            display: flex;
            align-items: center;
            .official-bottom-left-prople {
              color: #1c1c1c;
            }
            .official-bottom-left-all {
              color: #a6acb2;
            }
          }
        }
      }
    }
  }
  .normalActivity {
    // background: #f7f8f9;
    padding: 40rpx 32rpx 20rpx 32rpx;
    position: relative;
    .normalActivity-tab {
      width: 750rpx;
      transform: translateX(-32rpx);
      background: #f7f8f9;
      padding: 10px 20px;
      margin-bottom: 38rpx;
      position: sticky;
      top: calc(var(--status-bar-height) + 95rpx);
      z-index: 9;
      box-sizing: border-box;
      .normalActivity-tab-item {
        font-size: 32rpx;
        color: #a6acb2;
        margin-right: 40rpx;
        text-align: center;
      }
      .active-normalActivity-tab-item {
        font-size: 32rpx;
        color: #2a343e;
        margin-right: 40rpx;
        text-align: center;
      }
      .border {
        margin: 6rpx auto 0;
        width: 40rpx;
        height: 6rpx;
        background: #000000;
        border-radius: 6rpx;
      }
    }
    .normalActivity-top {
      .normalActivity-activityType {
        width: 624rpx;
        overflow: hidden;
        .activityTypeItem {
          flex-shrink: 0;
          width: 144rpx;
          height: 60rpx;
          background: #ffffff;
          border-radius: 12rpx;
          font-size: 24rpx;
          color: #8695a3;
          line-height: 60rpx;
          text-align: center;
          margin-right: 12rpx;
        }
        /deep/.uni-scroll-view-content {
          display: flex;
        }
      }
      .screenBox {
        width: 60rpx;
        height: 60rpx;
        background: #ffffff;
        border-radius: 12rpx;
        text-align: center;
        .screenImg {
          width: 36rpx;
          height: 36rpx;
        }
      }
    }

    .normalActivity-empty {
      padding-top: 100rpx;
      height: 50vh;
      margin: auto;
      text-align: center;
      .empty-img {
        width: 312rpx;
        height: 244rpx;
        background-size: cover;
      }
      .empty-text {
        font-size: 24rpx;
        color: #f8c1ca;
        line-height: 34rpx;
        margin-top: 26rpx;
      }
    }
  }
  /deep/.uni-swiper-dots {
    bottom: 0;
  }
  /deep/.uni-swiper-dot {
    width: 8rpx;
    height: 8rpx;
    background: #e4e5e6;
  }
  /deep/ .uni-swiper-dot-active {
    width: 20rpx !important;
    height: 8rpx;
    background: #2a343e;
    border-radius: 35% !important;
  }
  .versionpopup {
    z-index: 999999;
  }
  .popup {
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.8);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;

    .popup-activity {
      width: 498rpx;
      height: 642rpx;
      box-sizing: border-box;
      padding: 108rpx 46rpx 0;
      background: url('http://img.yiqitogether.com/static/images/index/banbengengxin.png') no-repeat;
      background-size: 100% 100%;
      position: absolute;
      top: 45%;
      left: 50%;
      transform: translate(-50%, -50%);

      .popup-activity-title {
        font-size: 42rpx;
        color: #2c2c2c;
        line-height: 58rpx;
        font-weight: bold;
      }
      .popup-activity-version {
        font-size: 28rpx;
        color: #9fa7b4;
        line-height: 40rpx;
      }
      .popup-activity-tips {
        width: 100%;
        height: 208rpx;
        overflow-y: auto;
        margin: 30rpx 0;
        .txt {
          font-size: 24rpx;
          color: #615e5e;
          line-height: 36rpx;
          margin-bottom: 14rpx;
        }
        .txt:last-child {
          margin-bottom: 0;
        }
      }
      .popup-activity-renewal {
        width: 414rpx;
        height: 72rpx;
        background: #fe5e10;
        border-radius: 40rpx;
        font-size: 28rpx;
        color: #ffffff;
        text-align: center;
        line-height: 72rpx;
        margin-bottom: 16rpx;
      }
      .popup-activity-ignore {
        text-align: center;
        font-size: 24rpx;
        color: #9fa7b4;
        line-height: 34rpx;
      }
      .popup-activity-off {
        width: 52rpx;
        height: 52rpx;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translate(-50%, 120rpx);
      }
    }
  }
}

.fixed-page {
  height: 100vh !important;
  overflow: hidden !important;
}
.tips-box {
  padding-bottom: 50rpx;
}
</style>
