<template>
  <view class="message-page" :class="showCreatePopup || showOperate ? 'mask-css' : ''">
    <!-- 导航栏 -->
    <view class="nav-container">
      <view class="nav-left">
        <view class="messageBox">
          <text class="page-title">消息</text>
          <text class="page-title" v-if="isNoNetwork">(无网络)</text>
        </view>
      </view>
      <view class="nav-right">
        <image src="https://img.yiqitogether.com/yyqc/20240528/upload_mtj51iq6yqo8hf657w44bzlzjwew06jv.png" alt="" class="nav-icon" @click="searchMemberList"></image>
        <image src="https://img.yiqitogether.com/yyqc/20240531/upload_4pec8w5njqxsy4gb9hnox5ce127hlo0d.png" alt="" class="nav-icon" @click="addGroupChat"></image>
        <!-- 添加群聊弹窗 -->
        <u-overlay :show="showOperate" :opacity="0.5" @click="showOperate = false">
          <view class="operate-wrap">
            <image class="triangle" src="https://img.yiqitogether.com/yyqc/20240122/upload_jrorwd0lseqcxfks4et9bvm6zlu49j7g.png" mode=""></image>
            <view class="operate-list">
              <view class="operate-item" v-for="(item, i) in blackPupList" :key="i" @click="groupChatOption(i)">
                <image class="operate-item-icon" :src="item.images" mode="" />
                <view class="operate-item-text">{{ item.text }}</view>
              </view>
            </view>
            <view class="mask-page"></view>
          </view>
        </u-overlay>
      </view>
    </view>
    <view class="main-container">
      <!-- 开启通知提示 -->
      <view class="notice-wrap" v-if="isNotification == 'true'">
        <image class="notice-icon" src="http://img.yiqitogether.com/static/images/messageGray/icon_tongzhi.png" alt="" />
        <view class="notice-text">开启通知，避免错过Ta人消息~</view>
        <view class="notice-btn" @click="showTZ = true">去开启</view>
        <image class="notice-close" src="https://img.yiqitogether.com/yyqc/20240118/upload_svf1jth36jz1ao6epf6d1onuibct9ezh.png" alt="" @click.stop="closeTongzhi()"></image>
      </view>
      <!-- 无网络提示 -->
      <view class="network-wrap" v-if="isNoNetwork">
        <image class="warn-icon" src="https://img.yiqitogether.com/yyqc/20240429/upload_6xfeq0iqepliibabumt0d0buufbuj7cc.png" alt="" />
        <text class="warn-text">当前网络不可用，请检查你的网络设置。</text>
      </view>
      <!-- 聊天列表 -->
      <view class="chat-list">
        <block v-if="allMessageList.length > 0 && !showLoading">
          <uni-swipe-action ref="swipeAction" class="arrrr">
            <uni-swipe-action-item v-for="(item, index) in allMessageList" :key="item.targetNo" :threshold="0" :auto-close="true" :right-options="item.top ? option1 : option2" @click="handleSwiperClick($event, item, index)">
              <!-- 过滤粉丝群 -->
              <view
                v-show="!item.groupType || item.groupType != 'fan'"
                :class="['list-item', item.top ? 'top-item' : '']"
                @click="
                  $u.throttle(() => {
                    goChat(item, index)
                  }, 1000)
                "
              >
                <image class="list-item-img" v-if="item.targetType == 3" :src="item.groupUrl ? item.groupUrl : defaultGroupAvatar" alt="" mode="aspectFill" />
                <image class="list-item-img" v-else :src="item.headUrl ? item.headUrl : defaultAvatar" alt="" mode="aspectFill" />
                <view class="list-item-right">
                  <view class="right-top">
                    <view class="chat-name">
                      <view class="chat-title ellipsis-single">{{ item.targetType == 3 ? item.groupName : item.displayName ? item.displayName : item.nickName }}</view>
                      <view class="chat-tag" v-show="item.groupLabel">{{ item.groupLabel }}</view>
                    </view>
                    <view class="chat-time">{{ $u.timeFormat(messageData[item.targetNo] ? messageData[item.targetNo].sendDate : item.sendDate, 'sendMsgFormat') }}</view>
                  </view>
                  <view class="right-bottom">
                    <view class="chat-content ellipsis-single" v-if="item.messageType != null || item.targetType == 1">
                      <block v-if="item.targetNo == '10011' && unreadData[item.targetNo]">{{ `近期有${unreadData[item.targetNo]}位关注好友生日,送个祝福吧!` }}</block>
                      <block v-if="item.targetNo != '10011'">{{ messageData[item.targetNo] ? messageData[item.targetNo].content : item.content ? item.content : '' }}</block>
                    </view>
                    <view class="chat-content" v-if="item.messageType == null && item.targetType == 3">消息已撤回，无法查看</view>
                    <view class="chat-status">
                      <block v-if="item.targetNo != '10012' && unreadData[item.targetNo] && !item.distrub">
                        <view class="red-dot-icon" v-if="unreadData[item.targetNo] > 99">99+</view>
                        <view class="red-dot-circle" v-else>{{ unreadData[item.targetNo] }}</view>
                      </block>
                      <view class="red-dot" v-if="showFansTotal && item.targetNo == '10012' && totalUnread"></view>
                      <image class="no-disturb-icon" v-if="item.distrub" src="https://img.yiqitogether.com/yyqc/20231031/upload_obdb2y8n9lef54dbz4132l26pwworl5o.png" alt="" />
                    </view>
                  </view>
                </view>
              </view>
            </uni-swipe-action-item>
          </uni-swipe-action>
          <view @click="loadNextPage">
            <u-loadmore :status="loadStatus" :fontSize="20" marginTop="24" marginBottom="48" nomore-text="没有更多了~" />
          </view>
        </block>
        <view v-if="!allMessageList.length && !showLoading" class="empty-wrap">
          <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
          <view class="empty-text">暂无内容</view>
        </view>
      </view>
    </view>

    <u-toast ref="uToast"></u-toast>
    <!-- 获取上传图片权限弹窗 -->
    <accredit-popup ref="accredit" systemTitle="“一起一起”想访问您的相机" systemContent="用于使用上传照片功能" permisionID="android.permission.CAMERA" cacheId="cameraAccredit" @successAccredit="sweepEvent"></accredit-popup>
    <!-- 获取通知权限弹窗 -->
    <custom-modal type="tipsConfirm" :show="showTZ" :round="24" title="“一起一起”想访问您的通知权限" content="用于使用消息推送功能" cancelText="拒绝" confirmText="允许" @cancel="showTZ = false" @confirm="submitTZ" />
    <!-- 创建群聊弹窗 -->
    <CreateGroupPopup :show="showCreatePopup" @close="showCreatePopup = false" @open="showCreatePopup = true" @confirm="handleCreateGroup" />
    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- 生日弹窗 -->
    <custom-birthday-popup :show="showCake" @close="closeCake" />
  </view>
</template>
<script>
import permision from '@/js_sdk/wa-permission/permission.js'
import rongYun from '@/model/rongyun.js'
import { load, save } from '@/utils/store.js'
import { LOGIN_USERID, CONNECTRONGYUN, BIRTHDAYCAKE, USER_INFO } from '@/utils/cacheKey.js'
import { getTokenConnectRongYun } from '@/utils/publicRequest.js'
import { unique, dealMsgContent } from '@/utils/tools.js'
import CreateGroupPopup from './components/create-group-popup.vue'
import loginModel from '@/model/login.js'
import { scanQrcode } from '@/utils/qrcodeScan'

export default {
  components: {
    CreateGroupPopup
  },
  data() {
    return {
      // 默认头像
      defaultAvatar: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      // 默认群头像
      defaultGroupAvatar: 'http://img.yiqitogether.com/static/images/messageGray/group_avatar_normal.png',
      // 群聊弹窗数据
      blackPupList: [
        {
          text: '创建群聊',
          images: 'https://img.yiqitogether.com/yyqc/20240122/upload_snohlnqjavmmhq6dfru7kc14ugasclzh.png'
        },
        {
          text: '加入群聊',
          images: 'https://img.yiqitogether.com/yyqc/20240122/upload_aaooncj31mpn18xdczya3jwieemupt94.png'
        },
        {
          text: '扫一扫',
          images: 'https://img.yiqitogether.com/yyqc/20240122/upload_yd3ywrdcag5l45uiliugpca2b4be5dgg.png'
        }
      ],
      showOperate: false, // 群聊弹窗显示
      isNotification: 'true', // 去通知
      numberId: '', // 当前登录用户的numberId
      option1: [
        {
          text: '取消置顶',
          style: {
            backgroundColor: '#eee',
            color: '#2D3F49',
            fontSize: '24rpx',
            width: '150rpx'
          }
        },
        {
          text: '删除',
          style: {
            backgroundColor: '#FB5C4E',
            fontSize: '24rpx',
            width: '150rpx'
          }
        }
      ],
      option2: [
        {
          text: '置顶',
          style: {
            backgroundColor: '#eee',
            color: '#2D3F49',
            fontSize: '24rpx',
            width: '150rpx'
          }
        },
        {
          text: '删除',
          style: {
            backgroundColor: '#FB5C4E',
            fontSize: '24rpx',
            width: '150rpx'
          }
        }
      ],
      /**
       * 新版V3的字段
       */
      // 全部未读数
      totalUnread: 0,
      unreadData: {},
      showFansTotal: true,
      pages: 0,
      pageNumber: 1,
      pageSize: 100,
      loadStatus: 'loadmore',
      // 所有消息的列表（私聊+群聊）
      allMessageList: [],
      // 所有消息内容
      messageData: {},
      userInfoData: {},
      groupInfoData: {},
      // 置顶数组
      topList: [],
      // 不置顶数组
      noTopList: [],
      // 其他会话类型
      conversationTypeList: ['10001', '10002', '10003', '10004', '10005', '10008', '10009', '10010', '10011', '10012'],
      // 通知权限弹窗
      showTZ: false,
      // 创建群聊弹窗
      showCreatePopup: false,
      // loading加载
      showLoading: true,
      // 是否无网络
      isNoNetwork: false,
      isGreet: false, // 判断收到的消息是否是打招呼
      showCake: false, // 生日弹窗
      fansIndex: -1 // 初始状态下，列表中不存在折叠的群聊
    }
  },
  watch: {
    totalUnread: {
      handler(val) {
        if (val && val > 0) {
          uni.setTabBarBadge({
            index: 2,
            text: `${val}`
          })
        } else {
          // 隐藏数字标
          uni.removeTabBarBadge({
            index: 2 // tabbar下标
          })
        }
      }
    },
    showCreatePopup: {
      handler(val) {
        this.isPullDown()
      }
    },
    showOperate: {
      handler(val) {
        this.isPullDown()
      }
    }
  },
  // 下拉刷新
  onPullDownRefresh() {
    if (this.showCreatePopup || this.showOperate) {
      return uni.stopPullDownRefresh()
    }
    this.refreshList()
  },
  // 页面触底加载下一页
  onReachBottom() {
    this.loadNextPage()
  },
  onLoad(e) {
    let info = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)) : {}
    let nowDay = uni.$u.timeFormat(new Date().getTime(), 'mm-dd')
    if (info.birthday && info.birthday.slice(5, 10) == nowDay) {
      if (load(BIRTHDAYCAKE)) {
        this.showCake = false
      } else {
        this.showCake = true
      }
    }
    this.numberId = load(LOGIN_USERID)

    // #ifdef APP-PLUS
    if (!load(CONNECTRONGYUN)) {
      // 融云未连接，连接融云，连接成功后获取列表
      getTokenConnectRongYun(this)
    } else {
      // 融云已经连接过，直接获取列表
      this.getInfoList()
    }
    // #endif

    // #ifdef H5
    this.getInfoList()
    // #endif

    // 首次判断网络状态
    uni.getNetworkType({
      success: res => {
        const networkType = res.networkType
        if (networkType === 'none') {
          // 无网络
          this.isNoNetwork = true
        } else {
          // 有网络
          this.isNoNetwork = false
        }
      }
    })
    try {
      // #ifdef APP-PLUS
      // 绑定cid
      if (!uni.getStorageSync('cid')) {
        plus.push.getClientInfoAsync(info => {
          let cid = info['clientid']
          this.bindCid(cid)
        })
      }
      // 收到连接状态的回调
      this.$store.state.engie.setOnConnectedListener(res => {
        if (res.code == 0 || res.code == 34001) {
          console.log('消息首页用户连接融云成功，获取消息列表')
          // 连接成功后，获取列表数据
          this.getInfoList()
        } else {
          console.log('连接状态变更——连接已断开', res.code)
        }
      })

      // 监听连接状态
      this.$store.state.engie.setOnConnectionStatusChangedListener(async res => {
        if (res.status == 4) {
          // uni.showToast({
          //   title: '登录过期',
          //   duration: 2000,
          //   icon: 'none'
          // })
          // uni.reLaunch({ url: '/pages/login/index' })
        } else if (res.status == 0) {
          uni.showToast({
            title: '网络异常，请检查网络',
            duration: 2000,
            icon: 'none'
          })
        }
      })
      // #endif

      // 在页面的onLoad中添加事件监听
      uni.$on('refreshMessageList', this.refreshList)
    } catch (error) {}
  },
  onShow() {
    uni.showTabBar()

    // #ifdef APP
    // 监听总的未读数(不包含免打扰)
    this.$store.state.engie.setOnUnreadCountByConversationTypesLoadedListener(res => {
      this.totalUnread = res.count || 0
      try {
        if (this.totalUnread) {
          plus.runtime.setBadgeNumber(this.totalUnread)
        } else {
          plus.runtime.setBadgeNumber(0)
          plus.runtime.setBadgeNumber(-1)
        }
      } catch (error) {}
    })
    // 监听未读数更新
    this.$store.state.engie.setOnUnreadCountLoadedListener(res => {
      this.unreadData[res.targetId] = res.count
      this.$forceUpdate()
    })
    // 监听接收消息
    this.$store.state.engie.setOnMessageReceivedListener(res => {
      if (res.message.messageType == 0) {
        return
      }
      if (res.message.conversationType == 1) {
        // 全局注册事件，目的：当接收到外来消息时，要让聊天页面自动刷新
        uni.$emit('updateHistory', { msg: res })
        this.msgReceiveRefresh(res)
      } else {
        // 群聊监听
        uni.$emit('updateHistoryGroup', { msg: res })
        this.msgReceiveRefresh(res)
      }
    })
    // #endif

    // 监听网络状态，状态发生变化时触发，头条小程序不支持
    uni.onNetworkStatusChange(res => {
      this.isNoNetwork = !res.isConnected
    })
    // 获取通知权限
    this.getPermission()
    this.isPullDown()
  },
  onReady() {
    // 发布弹窗
    uni.$on('openMessagePopup', () => {
      this.closeCake()
      this.$refs.publishPopupRef.onOpen()
    })
  },
  onHide() {
    this.showOperate = false
    this.showCreatePopup = false
    this.closeCake()
    this.$refs.publishPopupRef.onClose()
    uni.stopPullDownRefresh()
  },
  onUnload() {
    uni.$off('refreshMessageList', this.refreshList)
  },
  methods: {
    closeCake() {
      this.showCake = false
      save(BIRTHDAYCAKE, 'nomoreShow')
    },
    // 弹窗打开时关闭下拉刷新
    isPullDown() {
      // #ifdef APP-PLUS
      // 获取当前 Webview 窗口对象
      const pages = getCurrentPages()
      const page = pages[pages.length - 1]
      const currentWebview = page.$getAppWebview()
      // 根据状态值来切换禁用/开启下拉刷新
      currentWebview.setStyle({
        pullToRefresh: {
          support: this.showCreatePopup || this.showOperate ? false : true,
          style: 'circle'
        }
      })
      // #endif
    },
    // 绑定用户CID
    async bindCid(cid) {
      let res = await rongYun.bindCid({ cid: cid })
      if (res.code == 'SUCCESS') {
        uni.setStorageSync('cid', cid)
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    // 获取通知权限
    getPermission() {
      let that = this
      // #ifdef APP-PLUS
      if (uni.getSystemInfoSync().platform == 'android') {
        let main = plus.android.runtimeMainActivity()
        let NotificationManagerCompat = plus.android.importClass('android.support.v4.app.NotificationManagerCompat')
        // android.support.v4升级为androidx
        if (NotificationManagerCompat == null) {
          NotificationManagerCompat = plus.android.importClass('androidx.core.app.NotificationManagerCompat')
        }
        let areNotificationsEnabled = NotificationManagerCompat.from(main).areNotificationsEnabled()
        if (areNotificationsEnabled) {
          that.isNotification = 'false'
        } else {
          that.isNotification = uni.getStorageSync('tongzhiStorage') || 'true'
        }
      } else if (uni.getSystemInfoSync().platform == 'ios') {
        // permision.judgeIosPermission('push')
        var isOn = undefined
        var types = 0
        var app = plus.ios.invoke('UIApplication', 'sharedApplication')
        var settings = plus.ios.invoke(app, 'currentUserNotificationSettings')
        if (settings) {
          types = settings.plusGetAttribute('types')
          plus.ios.deleteObject(settings)
        } else {
          types = plus.ios.invoke(app, 'enabledRemoteNotificationTypes')
        }
        plus.ios.deleteObject(app)
        isOn = 0 != types
        // 判断ios手机是否开启通知
        if (isOn == false) {
          // var app = plus.ios.invoke('UIApplication', 'sharedApplication');
          // 		var setting = plus.ios.invoke('NSURL', 'URLWithString:', 'app-settings:');
          // 		plus.ios.invoke(app, 'openURL:', setting);
          // 		plus.ios.deleteObject(setting);
          // 		plus.ios.deleteObject(app);

          that.isNotification = uni.getStorageSync('tongzhiStorage') || 'true'
        } else {
          that.isNotification = 'false'
        }
      } else {
      }
      // #endif
    },
    // 刷新列表
    refreshList() {
      this.fansIndex = -1
      this.showFansTotal = true
      this.pageNumber = 1
      this.showLoading = true
      this.getInfoList(true)
    },
    // 获取消息列表
    getInfoList(isRefresh = false) {
      rongYun
        .getComplexDialog({ pageNo: this.pageNumber, pageSize: this.pageSize })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.pages = res.data.pager.pages || 1
            let list = res.data.pager.list || []
            if (list.length) {
              // fansIndex == -1，即列表中没有折叠的群聊 => 查询list中是否存在粉丝群 ，并找出第一个粉丝群的索引index
              if (this.fansIndex == -1) {
                let index = list.findIndex(v => v.groupType && v.groupType == 'fan')
                if (index != -1) {
                  // 存在粉丝群 => 1.给fansIndex赋值，fansIndex不再是-1，翻看下一页的时候就不用再查询 2.把第一个粉丝群改成折叠的群聊，粉丝群通过v-show隐藏
                  this.fansIndex = index
                  list[index].targetNo = '10012'
                  list[index].distrub = false
                  list[index].groupType = '' // groupType置空是为了让它显示出来
                  list[index].groupName = '折叠的群聊'
                  list[index].groupUrl = 'http://img.yiqitogether.com/static/images/messageGray/group_fans.png'
                }
                // 不存在粉丝群，fansIndex值还是-1，翻看下一页的时候会继续查找
              }
              try {
                for (const item of list) {
                  // #ifdef APP-PLUS
                  // 处理会话未读数
                  let type = item.targetType == 3 ? 2 : 1
                  this.$store.state.engie.getUnreadCount(type, item.targetNo, null)
                  // #endif
                }
              } catch (error) {}
            }
            if (isRefresh) {
              // 刷新清空列表后再赋值
              this.allMessageList = []
            }
            this.allMessageList = [...this.allMessageList, ...list]
            this.allMessageList = unique(this.allMessageList, 'targetNo')
            this.topList = this.allMessageList.filter(v => v.top)
            this.noTopList = this.allMessageList.filter(v => !v.top)
            this.messageData = {}
            for (let i = 0; i < list.length; i++) {
              let key = list[i].targetNo
              this.messageData[key] = { content: list[i].content, sendDate: list[i].sendDate }
            }
            this.showLoading = false
            if (res.data.pager.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.pager.pages <= res.data.pager.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
            // 首次加载获取总的未读数（不包含免打扰）
            if (this.pageNumber == 1) {
              // #ifdef APP-PLUS
              this.$store.state.engie.getUnreadCountByConversationTypes([1, 2], null, false, null)
              // #endif
            }
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
          }
          this.queryEnd()
        })
        .catch(err => {
          this.queryEnd()
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    // 接口请求结束
    queryEnd() {
      uni.stopPullDownRefresh()
    },
    // 加载下一页
    loadNextPage() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.pageNumber++
          this.getInfoList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    // 接收消息 => 刷新消息列表
    async msgReceiveRefresh(data) {
      // console.log('🚀 ~ msgReceiveRefresh ~ data:', data)
      let identifier = data.message && data.message.fields && data.message.fields.identifier ? data.message.fields.identifier : data.message.identifier
      let fieldsContent = data.message && data.message.fields ? data.message.fields.content : ''
      let reversal = data.message && data.message.fields && data.message.fields.reversal ? true : false
      /**
       * 注意：
       * 1. 创建群聊、礼物、分享、红包消息等由后台代发的消息：双方都更新会话内容
       * 2. 礼物提示类消息：senderUserId == 自己，更新会话内容（特殊情况，为了保证消息私有）
       * 3. 除上述两种情况外的其他消息：senderUserId != 自己，更新会话内容（这里具体指的是哪种消息不记得了，初版的逻辑就是这样的，就没有去改动这个逻辑）
       */
      try {
        if (reversal || (identifier == 'prompt' && fieldsContent == '你有一份礼物待领取')) {
          // 礼物提示消息
          if (data.message && data.message.senderUserId != this.numberId) {
            return
          }
        } else {
          // 非礼物提示消息
          if (data.message && data.message.senderUserId == this.numberId && identifier != 'create' && identifier != 'gift' && identifier != 'share' && identifier != 'RedPacket') {
            return
          }
        }
      } catch (error) {}
      let itemData = {
        targetType: data.message.conversationType == 1 ? '1' : '3',
        content: data.message && data.message.text ? data.message.text : '',
        fromUserNo: data.message.senderUserId,
        messageType: data.message.messageType,
        msgUID: data.message.messageUId,
        sendDate: data.message.sentTime,
        targetNo: data.message.targetId,
        identifier: data.message.identifier || '',
        fields: data.message.fields,
        top: false
      }
      // 处理会话内容显示
      itemData.content = dealMsgContent(itemData)
      // 获取补充数据
      try {
        if (data.message.conversationType == 1) {
          // 私聊
          if (this.userInfoData && this.userInfoData[data.message.targetId]) {
            itemData = { ...itemData, ...this.userInfoData[data.message.targetId] }
          } else {
            await rongYun.getSimpleUser({ userNo: data.message.targetId }).then(res => {
              if (res.code == 'SUCCESS') {
                let params = {
                  toUserNo: res.data.userInfo.numberId,
                  headUrl: res.data.userInfo.headUrl,
                  nickName: res.data.userInfo.nickName || '',
                  displayName: res.data.userInfo.displayName || ''
                }
                itemData = { ...itemData, ...params }
                this.userInfoData[data.message.targetId] = params
              }
            })
          }
        } else {
          // 群聊
          if (this.groupInfoData && this.groupInfoData[data.message.targetId]) {
            itemData = { ...itemData, ...this.groupInfoData[data.message.targetId] }
          } else {
            await rongYun.getGroup({ groupNo: data.message.targetId }).then(res => {
              if (res.code == 'SUCCESS') {
                let params = {
                  toUserNo: res.data.group.groupNo,
                  groupNo: res.data.group.groupNo,
                  groupName: res.data.group.groupName,
                  userCount: res.data.group.userCount,
                  groupUrl: res.data.group.groupUrl,
                  groupType: res.data.group.groupType
                }
                itemData = { ...itemData, ...params }
                this.groupInfoData[data.message.targetId] = params
              }
            })
          }
        }
      } catch (error) {}
      if (itemData.groupType && itemData.groupType == 'fan') {
        // 粉丝群
        itemData.targetNo = '10012'
        itemData.distrub = false
        itemData.groupType = ''
        itemData.groupName = '折叠的群聊'
        itemData.groupUrl = 'http://img.yiqitogether.com/static/images/messageGray/group_fans.png'
        this.refreshTotal()
      } else {
        // 获取当前会话免打扰状态
        this.$store.state.engie.setOnConversationNotificationLevelLoadedListener(res => {
          let distrub = res.level == 5 ? true : false
          itemData.distrub = distrub
          if (!distrub) {
            this.refreshUnreadCount(data.message.conversationType, data.message.targetId)
          }
        })
        await this.$store.state.engie.getConversationNotificationLevel(data.message.conversationType, data.message.targetId, null, null)
      }
      let index1 = this.topList.findIndex(v => v.targetNo == itemData.targetNo)
      let index2 = this.noTopList.findIndex(v => v.targetNo == itemData.targetNo)
      if (index1 == -1 && index2 == -1) {
        // 插入一条该新消息
        this.noTopList.unshift(itemData)
        this.messageData[itemData.targetNo] = { sendDate: data.message.sentTime, content: itemData.content }
        if (itemData.targetNo == '10012') {
          this.fansIndex = this.topList.length
          this.showFansTotal = true
        }
      } else if (index1 != -1) {
        // 新消息替换“置顶消息”中的某条旧消息
        itemData.distrub = this.topList[index1].distrub
        itemData.top = true
        this.topList.splice(index1, 1)
        this.topList.unshift(itemData)
        this.messageData[itemData.targetNo].sendDate = itemData.sendDate
        this.messageData[itemData.targetNo].content = itemData.content
        if (itemData.targetNo == '10012') {
          this.fansIndex = index1
          this.showFansTotal = true
        }
      } else if (index2 != -1) {
        // 新消息替换“非置顶消息”中的某条旧消息
        itemData.distrub = this.noTopList[index2].distrub
        itemData.top = false
        this.noTopList.splice(index2, 1)
        this.noTopList.unshift(itemData)
        this.messageData[itemData.targetNo].sendDate = itemData.sendDate
        this.messageData[itemData.targetNo].content = itemData.content
        if (itemData.targetNo == '10012') {
          this.fansIndex = index2
          this.showFansTotal = true
        }
      }
      this.allMessageList = [...this.topList, ...this.noTopList]
    },
    // 判断接收到的消息是否是打招呼
    async judgeGreet(targetId) {
      this.isGreet = false
      await rongYun.getRongLimitReversal({ targetNumberId: targetId }).then(res => {
        if (res.code == 'SUCCESS' && res.data.limit == '0') {
          this.isGreet = true
        }
      })
    },
    // 刷新未读数
    async refreshUnreadCount(type, targetId) {
      // #ifdef APP-PLUS
      // 指定会话未读数
      let code = await this.$store.state.engie.getUnreadCount(type, targetId, null)
      // 总未读数
      await this.$store.state.engie.getUnreadCountByConversationTypes([1, 2], null, false, null)
      // #endif
    },
    // 刷新总的未读数
    refreshTotal() {
      this.$store.state.engie.getUnreadCountByConversationTypes([1, 2], null, false, null)
    },
    // 去聊天
    goChat(item, index) {
      if (item.targetType == 3) {
        this.toGroupChat(item)
      } else {
        this.toPrivateChat(item)
      }
    },
    // 进私聊页
    toPrivateChat(item) {
      let self = this
      // 清除指定会话未读数（先清未读数再跳转防止进程阻塞清空逻辑）
      // #ifdef APP
      try {
        let time = new Date().getTime()
        this.$store.state.engie.clearUnreadCount(1, item.targetNo, null, time).then(res => {
          this.refreshUnreadCount(1, item.targetNo)
          this.unreadData[item.targetNo] = 0
        })
      } catch (error) {}
      // #endif
      if (item.targetNo.length == 5) {
        let index = this.conversationTypeList.findIndex(v => v == item.targetNo)
        if (index == -1) {
          uni.showToast({
            title: '当前版本暂不支持',
            icon: 'none',
            mask: true
          })
          return
        }
        switch (item.targetNo) {
          case '10001':
            // 10001-系统消息
            uni.navigateTo({ url: '/pagesCommon/message/systemMessage' })
            break
          case '10002':
            // 10002-粉丝消息
            uni.navigateTo({ url: '/pagesCommon/message/fansMessage' })
            break
          case '10003':
            // 10003-活动消息
            uni.navigateTo({ url: '/pagesCommon/message/actionMessage' })
            break
          case '10004':
            // 10004-订单消息
            uni.navigateTo({ url: '/pagesMy/my/myOrder/orderMessage' })
            break
          case '10005':
            // 10005-入群申请
            uni.navigateTo({ url: '/pagesMessage/groupChat/applyGroup' })
            break
          case '10008':
            // 10008-活动信箱
            uni.navigateTo({ url: '/pagesCommon/message/interactiveMessage' })
            break
          case '10009':
            // 10009-一起钱包
            uni.navigateTo({ url: '/pagesCommon/message/walletMessage/index' })
            break
          case '10010':
            // 10010-积分中心
            uni.navigateTo({ url: '/pagesCommon/message/integrationCenter/index' })
            break
          case '10011':
            // 10011-生日提醒
            uni.navigateTo({ url: '/pagesCommon/message/birthdayMessage?sendDate=' + item.sendDate })
            break
          default:
            break
        }
      } else {
        // 去私聊页面
        uni.navigateTo({
          url: '/pagesMessage/privateChat/index?userId=' + item.targetNo + '&otherAvatar=' + item.headUrl + '&otherNickName=' + item.nickName + '&sourcePage=message',
          events: {
            // 从私聊页面返回消息列表
            privateBack: function (data) {
              // 清除指定会话未读数（聊天页面的清空写在这而不是直接写在跳转后，是因为得考虑进去后发的消息也要已读）
              // #ifdef APP
              try {
                let time = new Date().getTime()
                self.$store.state.engie.clearUnreadCount(1, item.targetNo, null, time).then(res => {
                  self.refreshUnreadCount(1, item.targetNo)
                  self.unreadData[item.targetNo] = 0
                })
              } catch (error) {}
              // #endif
            }
          }
        })
      }
    },
    // 进群聊页
    toGroupChat(item) {
      if (item.targetNo.length == 5) {
        let index = this.conversationTypeList.findIndex(v => v == item.targetNo)
        if (index == -1) {
          uni.showToast({
            title: '当前版本暂不支持',
            icon: 'none',
            mask: true
          })
          return
        }
        switch (item.targetNo) {
          case '10012':
            // 10012-折叠的群聊
            uni.navigateTo({ url: '/pagesMessage/groupChat/fansGroupList' })
            break
          default:
            break
        }
      } else {
        let self = this
        uni.navigateTo({
          url: '/pagesMessage/groupChat/index?groupNo=' + item.groupNo + '&groupName=' + item.groupName,
          events: {
            // 从群聊页面返回消息列表
            groupBack: function (data) {
              // 清除指定会话未读数
              // #ifdef APP
              try {
                let time = new Date().getTime()
                self.$store.state.engie.clearUnreadCount(2, data.groupNo, null, time).then(res => {
                  self.refreshUnreadCount(2, data.groupNo)
                  self.unreadData[data.groupNo] = 0
                })
              } catch (error) {}
              // #endif
            }
          }
        })
      }
    },
    /**
     * 发送消息 => 更新某条会话的最新消息发送时间和会话内容，并排序
     * @param {object} data 消息体
     * @param {boolean} isTop 是否是置顶会话
     */
    refreshSingleMsgContent(data, isTop) {
      data = data.message
      if (!data) return
      data.targetType = data.conversationType == 2 ? 3 : 1
      this.messageData[data.targetId].sendDate = data.sentTime
      this.messageData[data.targetId].content = dealMsgContent(data, 'text')
      // 刷新排序
      if (isTop) {
        // 置顶的
        this.topList.map(item => {
          if (item.targetNo == data.targetId) {
            item.sendDate = data.sentTime
          }
        })
        this.topList.sort(function (a, b) {
          return b.sendDate - a.sendDate
        })
      } else {
        // 非置顶的
        this.noTopList.map(item => {
          if (item.targetNo == data.targetId) {
            item.sendDate = data.sentTime
          }
        })
        this.noTopList.sort(function (a, b) {
          return b.sendDate - a.sendDate
        })
      }
      this.allMessageList = [...this.topList, ...this.noTopList]
      this.$forceUpdate()
    },
    /**
     * 更新某条会话的某个属性值
     * @param {string|number} targetId 会话id
     * @param {string} field 要改变的字段名
     * @param {object} val 值
     */
    refreshSingleMsgInfo(targetId, field, val) {
      this.allMessageList.map(item => {
        if (item.targetNo == targetId) {
          item[field] = val
        }
      })
    },
    // 侧滑操作的点击事件
    handleSwiperClick(e, item, index) {
      if (e.index == 0) {
        this.handleTop(item)
      } else {
        this.handleDelete(item, index)
      }
    },
    // 置顶、取消置顶
    handleTop(item) {
      let top = item.top
      if (item.targetType == 3) {
        // 群聊
        let params = {
          groupNo: item.groupNo,
          top: !top
        }
        rongYun.getTopGroup(params).then(res => {
          if (res.code == 'SUCCESS') {
            // 前端刷新，不频繁调用后台接口刷新
            this.onTopRefresh(item, top)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        // 私聊
        let params = {
          targetNumberId: item.targetNo,
          top: !top
        }
        rongYun.getTop(params).then(res => {
          if (res.code == 'SUCCESS') {
            // 前端更新，不频繁调用后台接口刷新
            this.onTopRefresh(item, top)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    onTopRefresh(item, top) {
      item.top = !item.top
      if (top) {
        // 点击取消置顶后顶更新列表
        let i = this.topList.findIndex(v => (item.targetType == 1 && v.targetNo == item.targetNo) || (item.targetType == 3 && v.targetNo == item.targetNo))
        this.topList.splice(i, 1)
        this.noTopList.push(item)
        this.noTopList.sort((a, b) => b.sendDate - a.sendDate)
      } else {
        // 点击置顶后更新列表
        let i = this.noTopList.findIndex(v => (item.targetType == 1 && v.targetNo == item.targetNo) || (item.targetType == 3 && v.targetNo == item.targetNo))
        this.noTopList.splice(i, 1)
        this.topList.unshift(item)
      }
      this.allMessageList = [...this.topList, ...this.noTopList]
    },
    // 删除
    handleDelete(item, index) {
      let params = {
        type: 'dialog',
        userId: item.targetType == 1 ? item.targetNo : '',
        groupNo: item.targetType == 3 ? item.groupNo : ''
      }
      rongYun.deleteDialog(params).then(res => {
        if (res.code == 'SUCCESS') {
          this.allMessageList.splice(index, 1)
          if (item.top) {
            this.topList.splice(index, 1)
          } else {
            this.noTopList.splice(index - this.topList.length, 1)
          }
          let type = item.targetType == 3 ? 2 : 1
          // #ifdef APP-PLUS
          try {
            // 删除单个会话，未读数也会减掉
            this.$store.state.engie.removeConversation(type, item.targetNo, null)
            // 清空聊天记录
            this.$store.state.engie.clearMessages(type, item.targetNo, null, 0, 2)
          } catch (error) {}
          // #endif
          this.refreshUnreadCount(type, item.targetNo)
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    /**
     * 显示群聊
     */
    addGroupChat() {
      this.showOperate = !this.showOperate
    },
    /**
     * @param {number} i 0 创建群聊 1 加入已有群聊
     * 创建群聊 / 加入已有群聊
     */
    groupChatOption(i) {
      if (i == 0) {
        this.showCreatePopup = true
      } else if (i == 1) {
        this.showOperate = false
        uni.navigateTo({
          url: '/pagesMessage/groupChat/searchGroup'
        })
      } else {
        this.sweep()
      }
    },
    /**
     * 创建群聊
     */
    handleCreateGroup(list) {
      let data = {
        userId: list.join('&')
      }
      rongYun.createGroup(data).then(res => {
        this.showCreatePopup = false
        if (res.code == 'SUCCESS') {
          this.toGroupChat(res.data.group)
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    /**
     * 扫一扫
     */
    sweep() {
      this.$refs.accredit.triggerEvent()
    },
    sweepEvent() {
      scanQrcode()
      // // 允许从相机和相册扫码
      // let that = this
      // uni.scanCode({
      //   scanType: ['qrCode'],
      //   success: function (res) {
      //     let strPosition = res.result.indexOf('/pagesCommon/details/details')
      //     let info = res.result.indexOf('"type":"joinGroup"')
      //     let pcLoginInfo = res.result.indexOf('"type":"pcLogin"')
      //     let activityDetails = res.result.indexOf('"type":"eventDetails"')

      //     if (info > -1) {
      //       let a = JSON.parse(res.result)
      //       uni.navigateTo({
      //         url: '/pagesMessage/privateChat/groupConfirm?groupNo=' + a.groupNo
      //       })
      //     } else if (strPosition > -1) {
      //       let path = res.result.substring(strPosition)
      //       uni.navigateTo({
      //         url: path
      //       })
      //     } else if (pcLoginInfo > -1) {
      //       let pcLoginData = JSON.parse(res.result)
      //       let data = {
      //         uuid: pcLoginData.uuid,
      //         numberId: that.numberId
      //       }
      //       loginModel
      //         .getScanQrCode(data)
      //         .then(res => {
      //           if (res.code == 'SUCCESS') {
      //             uni.navigateTo({ url: '/pages/login/scanLoginQrCode?dataInfo=' + JSON.stringify(data) })
      //           } else {
      //             uni.showToast({
      //               title: res.message,
      //               icon: 'none'
      //             })
      //           }
      //         })
      //         .catch(err => {
      //           uni.showToast({
      //             title: err.message,
      //             icon: 'none'
      //           })
      //         })
      //     } else if (activityDetails > -1) {
      //       let activityDetailsInfo = JSON.parse(res.result)
      //       uni.navigateTo({ url: '/pagesCommon/details/details?appointmentNo=' + activityDetailsInfo.appointmentNo })
      //     } else {
      //       uni.showToast({
      //         title: '暂不支持该类型的二维码',
      //         icon: 'none'
      //       })
      //     }
      //   }
      // })
    },
    // 关掉通知弹框
    closeTongzhi() {
      uni.setStorageSync('tongzhiStorage', 'false')
      this.isNotification = 'false'
    },
    // 开启通知
    submitTZ() {
      this.showTZ = false
      permision.gotoAppPermissionSetting()
    },
    // 顶部搜索
    searchMemberList() {
      uni.navigateTo({ url: '/pages/message/components/searchUser' })
    }
  }
}
</script>

<style scoped lang="scss">
/* 遮罩层不可滚动不可点击 */
.mask-css {
  height: 100vh;
  overflow: hidden !important;
}

.message-page {
  width: 100%;
  min-height: 100vh;
  overflow-y: scroll;
  background-color: #fff;
  .nav-container {
    width: 100%;
    height: 88rpx;
    padding-top: calc(var(--status-bar-height) + 20rpx);
    box-sizing: content-box;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 998;
    background-color: #fff;
    .nav-left {
      flex: 1;
      margin-left: 36rpx;
      display: flex;
      align-items: center;
      margin-right: 60rpx;
      .messageBox {
        position: relative;
        .page-title {
          font-size: 40rpx;
          font-weight: bold;
          color: #333333;
          line-height: 62rpx;
        }
      }
    }
    .nav-right {
      flex-shrink: 0;
      position: relative;
      margin: 0 22rpx;
      font-size: 0;
      .nav-icon {
        width: 44rpx;
        height: 44rpx;
        padding: 14rpx;
      }
    }
  }

  .operate-wrap {
    position: relative;
    top: calc(98rpx + var(--status-bar-height));
    left: calc(100% - 228rpx - 22rpx);
    width: 228rpx;

    .triangle {
      width: 28rpx;
      height: 14rpx;
      margin-left: 178rpx;
      margin-bottom: -6rpx;
    }
    .operate-list {
      width: 228rpx;
      height: 230rpx;
      background: #fff;
      border-radius: 16rpx;
      padding: 0 8rpx 0 20rpx;
      box-sizing: border-box;
      .operate-item {
        width: 100%;
        height: 76rpx;
        display: flex;
        align-items: center;
        border-bottom: 2rpx solid #f7f7f7;
        .operate-item-icon {
          width: 32rpx;
          height: 32rpx;
          margin-right: 18rpx;
        }
        .operate-item-text {
          font-size: 24rpx;
          color: #2a343e;
          line-height: 34rpx;
        }
      }
    }
    .operate-item:last-child {
      border-bottom: none;
    }
  }
}

/* 遮罩样式 */
.mask-page {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgba(255, 170, 127, 0.5);
  z-index: 999; /* 遮罩层级设置 */
  display: none; /* 隐藏遮罩层 */
}

.main-container {
  height: 100%;
  padding-top: calc(var(--status-bar-height) + 128rpx);
  box-sizing: border-box;
  overflow-y: auto;

  .notice-wrap {
    margin: -8rpx 30rpx 20rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 88rpx;
    background: #ffffff;
    border-radius: 28rpx;
    box-shadow: 0rpx 8rpx 10rpx 0rpx rgba(207, 216, 232, 0.5);
    padding-left: 24rpx;
    box-sizing: border-box;
    z-index: 999;
    .notice-icon {
      width: 52rpx;
      height: 52rpx;
      margin-right: 8rpx;
      flex-shrink: 0;
    }
    .notice-text {
      flex: 1;
      font-size: 26rpx;
      color: #6c7d8f;
      line-height: 36rpx;
    }
    .notice-btn {
      width: 114rpx;
      height: 44rpx;
      background: #fd5e0f;
      border-radius: 22rpx;
      font-size: 24rpx;
      text-align: center;
      color: #ffffff;
      line-height: 44rpx;
      flex-shrink: 0;
    }
    .notice-close {
      width: 28rpx;
      height: 28rpx;
      padding: 0 14rpx;
      flex-shrink: 0;
    }
  }
  .network-wrap {
    display: flex;
    align-items: center;
    height: 88rpx;
    background: #ffeeef;
    padding-left: 56rpx;
    box-sizing: border-box;
    margin-bottom: 20rpx;
    z-index: 999;
    .warn-icon {
      width: 40rpx;
      height: 40rpx;
      background-size: cover;
      margin-right: 48rpx;
    }
    .warn-text {
      font-size: 28rpx;
      text-align: center;
      color: #838e9a;
      line-height: 40rpx;
    }
  }
  .chat-list {
    background-color: #fff;
    padding-bottom: 100rpx;
    .top-item {
      background-color: #f6f7f8;
    }
    .list-item {
      display: flex;
      align-items: center;
      box-sizing: border-box;
      padding: 16rpx 36rpx;
      .list-item-img {
        width: 90rpx;
        height: 90rpx;
        border-radius: 50%;
        flex-shrink: 0;
      }
      .list-item-right {
        flex: 1;
        margin-left: 20rpx;

        .right-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          .chat-name {
            display: flex;
            align-items: center;
          }
          .chat-title {
            font-size: 30rpx;
            color: #2d3f49;
          }
          .chat-tag {
            height: 24rpx;
            flex-shrink: 0;
            font-size: 18rpx;
            color: #fe5e10;
            line-height: 24rpx;
            padding: 0 8rpx;
            background: #ffede4;
            border-radius: 4rpx;
            margin-left: 10rpx;
          }
          .chat-time {
            flex-shrink: 0;
            font-size: 24rpx;
            color: #adb3ba;
            line-height: 32rpx;
          }
        }
        .right-bottom {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 8rpx;
          .chat-content {
            width: 360rpx;
            font-size: 24rpx;
            color: #adb3ba;
            line-height: 32rpx;
          }
          .chat-status {
            display: flex;
            align-items: center;
            .no-disturb-icon {
              width: 26rpx;
              height: 28rpx;
              margin-left: 10rpx;
            }
            .red-dot {
              width: 16rpx;
              height: 16rpx;
              background: #fb5c4e;
              border-radius: 50%;
            }
            .red-dot-icon {
              padding: 4rpx 8rpx;
              box-sizing: border-box;
              background: #fb5c4e;
              font-size: 18rpx;
              text-align: center;
              color: #ffffff;
              border-radius: 16rpx;
            }
            .red-dot-circle {
              width: 30rpx;
              height: 30rpx;
              background: #fb5c4e;
              font-size: 18rpx;
              text-align: center;
              color: #ffffff;
              line-height: 30rpx;
              border-radius: 50%;
            }
          }
        }
      }
    }
  }
  .empty-wrap {
    width: 326rpx;
    height: 322rpx;
    margin: 240rpx auto 0;
    text-align: center;
    .empty-img {
      width: 100%;
      height: 100%;
      background-size: cover;
    }
    .empty-text {
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
}
</style>
