<template>
  <view class="create-group-popup">
    <u-popup :show="show" mode="bottom" class="createGroupPopup" :round="20" duration="0" bgColor="#FFF" @close="onClose" @open="onOpen">
      <view class="popup-header">
        <image class="back-icon" v-if="isFansPopup" @click="isFansPopup = false" src="@/static/images/back_black.png" mode=""></image>
        <text class="title-txt">{{ isFansPopup ? '我的粉丝' : '选择人员' }}</text>
        <image class="close-icon" @click="onClose" src="https://img.yiqitogether.com/yyqc/20240219/upload_j6eu8jb3q2wmcddymdzlzb53y3gs3l6x.png" alt="" mode="aspectFill"></image>
      </view>
      <!-- 搜索 -->
      <view class="search-wrap" v-if="!isFansPopup">
        <view class="search-box">
          <image class="search-icon" src="@/static/images/sousuo.png" mode=""></image>
          <u-input class="search-text" v-model.trim="searchText" confirmType="search" placeholder="搜索昵称" placeholder-style="font-size: 28rpx;color: #c8c8c8;" border="none" maxlength="10" @blur="searchConfirm" @change="searchChange" :adjustPosition="false">
            <template slot="suffix" v-if="searchText">
              <u-icon name="https://img.yiqitogether.com/yyqc/20240219/upload_j6eu8jb3q2wmcddymdzlzb53y3gs3l6x.png" color="#ADB3BA" size="36" @click="onClear"></u-icon>
            </template>
          </u-input>
        </view>
      </view>
      <!-- 列表 -->
      <view :style="{ height: isFansPopup ? '1032rpx' : '900rpx' }" class="scroll-area">
        <!-- 搜索列表 -->
        <view class="list-box" v-if="showSearchList">
          <view class="flex1" v-if="searchList.length == 0">
            <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" mode=""></image>
          </view>
          <block v-else>
            <view class="list-item" v-for="(item, i) in searchList" :key="i">
              <view class="list-item-member" @click="searchSelectUser(item, i)">
                <view class="left-content">
                  <image class="member-avatar" :src="item.headUrl" alt="" mode="aspectFill"></image>
                  <view class="member-name" v-html="highlightText(item.nickName)"></view>
                </view>
                <image class="right-checkbox" v-show="!item.isChoose" src="@/static/images/radio_unchecked.png" alt="" mode="aspectFill" />
                <image class="right-checkbox" v-show="item.isChoose" src="@/static/images/radio_checked.png" alt="" mode="aspectFill" />
              </view>
            </view>
          </block>
        </view>
        <!-- 互关列表 -->
        <view class="list-box" v-if="!isFansPopup && !showSearchList">
          <view class="list-item-member" @click="toFansPage()">
            <view class="left-content">
              <image class="member-avatar" src="https://img.yiqitogether.com/yyqc/20240219/upload_7sl6aqfv73qys9xuynh2mhw8uv4sh5u2.png" alt="" mode="aspectFill" />
              <view class="member-name">我的粉丝({{ fansTotal || 0 }})</view>
            </view>
            <image class="right-arrow" src="https://img.yiqitogether.com/yyqc/20240219/upload_j2beth1181hfc33l1cp93jl1vk0n3qui.png" alt="" mode="aspectFill"></image>
          </view>
          <view class="attention-txt">互关</view>
          <view class="flex1" v-if="formatContactList.length == 0">
            <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" mode=""></image>
          </view>
          <block v-else>
            <view class="list-item" v-for="(item, i) in formatContactList" :key="i">
              <view class="list-item-letter">{{ item.letter }}</view>
              <view class="list-item-member" v-for="(item1, ii) in item.data" :key="ii" @click="selectUser(item1, i, ii, 'formatContactList')">
                <view class="left-content">
                  <image class="member-avatar" :src="item1.headUrl" alt="" mode="aspectFill"></image>
                  <view class="member-name">{{ item1.nickName }}</view>
                </view>
                <image class="right-checkbox" v-show="!item1.isChoose" src="@/static/images/radio_unchecked.png" alt="" mode="aspectFill" />
                <image class="right-checkbox" v-show="item1.isChoose" src="@/static/images/radio_checked.png" alt="" mode="aspectFill" />
              </view>
            </view>
          </block>
        </view>
        <!-- 粉丝列表 -->
        <view class="list-box" v-if="isFansPopup && !showSearchList">
          <view class="flex1" v-if="fansList.length == 0">
            <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" mode=""></image>
          </view>
          <block v-else>
            <view class="list-item" v-for="(item, i) in fansList" :key="i">
              <view class="list-item-letter">{{ item.letter }}</view>
              <view class="list-item-member" v-for="(item1, ii) in item.data" :key="ii" @click="selectUser(item1, i, ii, 'fansList')">
                <view class="left-content">
                  <image class="member-avatar" :src="item1.headUrl" alt="" mode="aspectFill"></image>
                  <view class="member-name">{{ item1.nickName }}</view>
                </view>
                <image class="right-checkbox" v-show="!item1.isChoose" src="@/static/images/radio_unchecked.png" alt="" mode="aspectFill" />
                <image class="right-checkbox" v-show="item1.isChoose" src="@/static/images/radio_checked.png" alt="" mode="aspectFill" />
              </view>
            </view>
          </block>
        </view>
      </view>
      <!-- 底部按钮 -->
      <view class="btn-wrap">
        <view class="create-btn" @click="$u.throttle(createGroup, 1000)">
          创建群聊
          <text v-if="selectedList.length > 0">({{ selectedList.length }})</text>
        </view>
      </view>
    </u-popup>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import rongYun from '@/model/rongyun.js'
import pinyin from 'js-pinyin'

export default {
  name: 'CreateGroupPopup',
  props: {
    // 是否展示弹框
    show: {
      type: Boolean,
      default: false
    },
    // 设置圆角值，数值，单位rpx
    round: {
      type: [Number, String],
      default: 20
    },
    // 点击遮罩是否关闭弹窗，只会在开启closeOnClickOverlay后点击遮罩层执行close回调
    closeOnClickOverlay: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      // 搜索内容
      searchText: '',
      // 格式化字母排序列表
      formatContactList: [],
      // 搜索成员列表
      searchList: [],
      // 是否显示搜索列表
      showSearchList: false,
      // 创建群聊选中人员的数组
      selectedList: [],
      // 粉丝总数
      fansTotal: '',
      // 粉丝列表
      fansList: [],
      // 粉丝和关注的合并后的数组（用于搜索使用）
      fansAttentionList: [],
      // 是否打开粉丝弹窗
      isFansPopup: false
    }
  },
  methods: {
    // 打开弹窗
    onOpen() {
      this.searchText = ''
      this.showSearchList = false
      this.isFansPopup = false
      this.selectedList = []
      this.getListFansGroup()
      this.getFansList()
      this.$emit('open')
    },
    // 关闭弹窗
    onClose() {
      this.formatContactList = []
      this.fansList = []
      this.$emit('close')
    },
    /**
     * 获取互关列表数据
     */
    async getListFansGroup() {
      let data = {
        type: 'eachOtherType',
        groupNo: ''
      }
      let res = await rongYun.listFansGroup(data)
      this.formatContactSortList(res.data.list, 'formatContactList')
      this.addMultipleChoiceParam('formatContactList')
    },
    // 获取粉丝列表
    async getFansList() {
      let data = {
        type: 'fansType',
        groupNo: ''
      }
      let res = await rongYun.listFansGroup(data)
      this.fansTotal = res.data.list.length
      this.formatContactSortList(res.data.list, 'fansList')
      this.addMultipleChoiceParam('fansList')
      this.fansAttentionList = [...this.formatContactList, ...this.fansList]
    },
    /**
     * 格式化数据并排序
     */
    formatContactSortList(datas, field) {
      let formatList = []
      let formatlistNoLetter = []
      datas.forEach(item => {
        // 获取首字母
        const firstLetter = pinyin.getCamelChars(item.nickName).slice(0, 1).toLocaleUpperCase()
        // 判断是否是字母
        const isLetter = firstLetter >= 'A' && firstLetter <= 'Z'

        if (isLetter) {
          // 是字母
          if (formatList.length === 0) {
            formatList.push({
              letter: firstLetter,
              data: [item]
            })
          } else {
            let findLetterIndex = formatList.findIndex(item => {
              return item.letter == firstLetter
            })
            if (findLetterIndex === -1) {
              formatList.push({
                letter: firstLetter,
                data: [item]
              })
            } else {
              // 说明是已存在相同的首字母，push进去后，重新赋值给原数组中的data
              let indexData = formatList[findLetterIndex].data
              indexData.push(item)
              formatList[findLetterIndex].data = indexData
            }
          }
        } else {
          // 非字母 全部归类#
          if (formatlistNoLetter.length === 0) {
            formatlistNoLetter.push({
              letter: '#',
              data: [item]
            })
          } else {
            let indexData = formatlistNoLetter[0].data
            indexData.push(item)
            formatlistNoLetter[0].data = indexData
          }
        }
      })
      formatList.sort(function (a, b) {
        if (a.letter.charCodeAt(0) > b.letter.charCodeAt(0)) {
          return 1
        } else {
          return -1
        }
      })
      // 把#的塞在最后
      if (formatlistNoLetter[0] !== undefined) {
        formatList.push(formatlistNoLetter[0])
      }
      this[field] = formatList
    },
    /**
     * 添加多选参数
     */
    addMultipleChoiceParam(field) {
      let datas = {}
      this[field].forEach((item, index) => {
        item.data.forEach((item1, index1) => {
          datas.isChoose = this.selectedList?.includes(item1.numberId)
          Object.assign(item1, datas)
        })
      })
    },
    /**
     * 选择互关和粉丝列表用户
     */
    selectUser(item, index, index1, field) {
      if (!item.isChoose) {
        this[field][index].data[index1].isChoose = true
        this.selectedList.push(item.numberId)
      } else {
        this[field][index].data[index1].isChoose = false
        let index2 = this.selectedList.indexOf(item.numberId)
        if (index2 > -1) {
          this.selectedList.splice(index2, 1)
        }
      }
      this.$forceUpdate()
    },
    /**
     * 输入触发
     */
    searchChange(e) {
      if (e.length == 0) {
        this.showSearchList = false
      }
    },
    /**
     * 确认搜索
     */
    searchConfirm(e) {
      if (e.length !== 0) {
        let arr = this.fansAttentionList
        this.searchList = []
        this.showSearchList = true
        arr.forEach((item, index) => {
          item.data.forEach((item1, index1) => {
            if (item1.nickName.indexOf(e) > -1) {
              this.searchList.push(item1)
            }
          })
        })
      }
    },
    /**
     * 搜索里的选择用户
     */
    searchSelectUser(item, index) {
      if (!item.isChoose) {
        this.searchList[index].isChoose = true
        this.selectedList.push(item.numberId)
      } else {
        this.searchList[index].isChoose = false
        let index2 = this.selectedList.indexOf(item.numberId)
        if (index2 > -1) {
          this.selectedList.splice(index2, 1)
        }
      }
      this.$forceUpdate()
    },
    // 处理高亮
    highlightText(text) {
      let highlightStr = `<text style="color:#F4858A">${this.searchText}</text>`
      // new 出来一个正则表达式reg根据动态数据变量来创建
      // 参数一 将 this.searchValue的值解析成字符串,并根据这个创建正则表达式,
      // 参数二 匹配模式  "gi"
      let reg = new RegExp(this.searchText, 'gi')
      // 返回替换后的心字符串
      return text.replace(reg, highlightStr)
    },
    // 清除搜索
    onClear() {
      this.searchText = ''
      this.showSearchList = false
      this.searchList = []
    },
    // 打开粉丝列表弹框
    toFansPage() {
      this.isFansPopup = true
      this.$forceUpdate()
    },
    // 创建群聊
    createGroup() {
      this.$emit('confirm', this.selectedList)
    }
  }
}
</script>

<style lang="scss" scoped>
.create-group-popup {
  .popup-header {
    position: relative;
    padding: 36rpx 0;
    box-sizing: border-box;
    text-align: center;
    .back-icon {
      width: 44rpx;
      height: 44rpx;
      padding: 24rpx;
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
    }
    .title-txt {
      font-size: 32rpx;
      color: #0c0c0c;
      line-height: 44rpx;
      font-weight: bold;
    }
    .close-icon {
      width: 32rpx;
      height: 32rpx;
      padding: 36rpx;
      background-size: cover;
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }

  .search-wrap {
    width: 100%;
    padding: 30rpx 36rpx;
    box-sizing: border-box;
    .search-box {
      height: 72rpx;
      background-color: #f7f7f7;
      border-radius: 36rpx;
      display: flex;
      align-items: center;
      padding: 0 18rpx;
      .search-icon {
        width: 40rpx;
        height: 40rpx;
        margin-right: 16rpx;
      }
      .search-text {
        /deep/ .uni-input-input {
          font-size: 28rpx;
          color: #2a343e;
        }
      }
    }
  }

  .scroll-area {
    box-sizing: border-box;
    overflow-y: auto;
    .list-box {
      padding: 10rpx 36rpx 0;
      box-sizing: border-box;

      .attention-txt {
        font-size: 20rpx;
        color: #adadad;
        line-height: 26rpx;
        margin-bottom: 30rpx;
      }
      .list-item-letter {
        width: 100%;
        font-size: 20rpx;
        color: #adadad;
        line-height: 26rpx;
      }
      .list-item-member {
        padding: 30rpx 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .left-content {
          display: flex;
          align-items: center;
          .member-avatar {
            width: 88rpx;
            height: 88rpx;
            border-radius: 50%;
            margin-right: 28rpx;
          }
          .member-name {
            font-size: 28rpx;
            color: #2d3f49;
            line-height: 36rpx;
          }
        }
        .right-arrow {
          width: 20rpx;
          height: 20rpx;
          flex-shrink: 0;
        }
        .right-checkbox {
          width: 32rpx;
          height: 32rpx;
          flex-shrink: 0;
        }
      }
    }
  }
  .btn-wrap {
    width: 100%;
    background-color: #fff;
    padding: 12rpx 36rpx 40rpx;
    box-sizing: border-box;
    // position: fixed;
    // left: 0;
    // bottom: 0;
    // z-index: 99;
    // 底部按钮
    .create-btn {
      width: 100%;
      background: #f4858a;
      height: 88rpx;
      border-radius: 20rpx;
      font-size: 32rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
      box-sizing: border-box;
    }
  }
  .empty-img {
    width: 310rpx;
    height: 310rpx;
    margin: 80rpx auto 40rpx;
  }
}
</style>
