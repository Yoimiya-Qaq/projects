<template>
  <view class="search-user-page">
    <!-- 搜索 -->
    <view class="search-wrap">
      <image @click.stop="goBack()" class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      <view class="search-box">
        <u-icon name="search" color="#ACADC5" size="44"></u-icon>
        <u--input class="search-box-input" v-model="searchText" confirmType="search" placeholder="搜索昵称" placeholderStyle="font-size:28rpx;color: #9fa7b4;" border="none" maxlength="10" clearable @confirm="searchConfirm" @change="searchChange" :adjustPosition="false"></u--input>
      </view>
      <view class="search-btn" @click="searchConfirm">搜索</view>
    </view>
    <!-- 搜索列表(过滤打招呼targetNo == '10007') -->
    <view class="list-wrap" v-if="allMessageList.length > 0 && !showLoading">
      <view
        v-for="(item, index) in allMessageList"
        :key="index"
        @click="
          $u.throttle(() => {
            goChat(item, index)
          }, 1000)
        "
      >
        <view class="list-box-item" v-if="item.targetType == 1 && item.targetNo != '10007'">
          <image
            class="list-box-item-avatar"
            :src="item.headUrl || defaultAvatar"
            mode="aspectFill"
            @click.stop="
              $u.throttle(() => {
                toPersonalPage(item)
              }, 1000)
            "
          />
          <view class="list-box-item-name ellipsis-single" v-html="highlightText(item.displayName ? item.displayName : item.nickName)"></view>
        </view>
        <view class="list-box-item" v-if="item.targetType == 3">
          <image class="list-box-item-avatar" :src="item.groupUrl || defaultGroupAvatar" mode="aspectFill" />
          <view class="list-box-item-name ellipsis-single">
            <text v-html="highlightText(item.groupName)"></text>
            <text>({{ item.userCount || 0 }})</text>
          </view>
        </view>
      </view>
      <view @click="loadNextPage" v-show="!(allMessageList.length == 1 && allMessageList[0].targetNo == '10007')">
        <u-loadmore :status="loadStatus" :fontSize="20" nomore-text="没有更多了~" />
      </view>
    </view>
    <!-- 缺省图(过滤打招呼targetNo == '10007') -->
    <view class="empty-wrap" v-if="showSearchList && (allMessageList.length == 0 || (allMessageList.length == 1 && allMessageList[0].targetNo == '10007')) && !showLoading">
      <image class="empty-img" src="https://img.yiqitogether.com/yyqc/20240528/upload_bmf1yp6dzui8wr0o3ilz7whofj9o3w1s.png" alt="" mode="aspectFill" />
    </view>
    <u-toast ref="uToast"></u-toast>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
  </view>
</template>

<script>
import rongYun from '@/model/rongyun.js'

export default {
  data() {
    return {
      // 默认头像
      defaultAvatar: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      // 默认群头像
      defaultGroupAvatar: 'http://img.yiqitogether.com/static/images/messageGray/group_avatar_normal.png',
      // 是否显示搜索列表
      showSearchList: false,
      // 绑定的搜索框内容
      searchText: '',

      currIndex: 0,
      pages: 0,
      pageNumber: 1,
      pageSize: 100,
      loadStatus: 'loadmore',
      allMessageList: [],
      showLoading: false
    }
  },
  // 页面触底加载一级评论列表下一页
  onReachBottom() {
    this.loadNextPage()
  },
  methods: {
    /**
     * 退出页面
     */
    goBack() {
      this.searchText = ''
      uni.navigateBack()
    },
    /**
     * 输入触发
     */
    searchChange(e) {
      if (e.length == 0) {
        this.showSearchList = false
        this.pageNumber = 1
        this.allMessageList = []
      }
    },
    getList() {
      let params = {
        pageNo: this.pageNumber,
        pageSize: this.pageSize,
        searchName: this.searchText
      }
      rongYun
        .getComplexDialog(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.pages = res.data.pager.pages || 1
            let list = res.data.pager.list || []
            this.allMessageList = [...this.allMessageList, ...list]
            if (res.data.pager.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.pager.pages <= res.data.pager.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
            this.showLoading = false
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    // 加载下一页
    loadNextPage() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.pageNumber++
          this.getList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    /**
     * 确认搜索
     */
    searchConfirm() {
      if (!this.searchText) {
        uni.showToast({
          title: '搜索昵称不能为空',
          icon: 'none'
        })
        return
      }
      this.pageNumber = 1
      this.allMessageList = []
      this.showLoading = true
      this.showSearchList = true
      this.getList()
    },
    // 处理高亮
    highlightText(text) {
      let highlightStr = `<text style="color:#FE5E10">${this.searchText}</text>`
      // new 出来一个正则表达式reg根据动态数据变量来创建
      // 参数一 将 this.searchValue的值解析成字符串,并根据这个创建正则表达式,
      // 参数二 匹配模式  "gi"
      let reg = new RegExp(this.searchText, 'gi')
      // 返回替换后的心字符串
      return text.replace(reg, highlightStr)
    },
    // 点击头像进个人主页
    toPersonalPage(item) {
      if (item.targetType == 1 && item.targetNo) {
        uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + item.targetNo })
      }
    },
    // 去聊天
    goChat(item, index) {
      this.currIndex = index
      if (item.targetType == 3) {
        this.toGroupPage(item)
      } else {
        this.toPrivatePage(item)
      }
    },
    // 去私聊页
    async toPrivatePage(item) {
      // #ifdef APP
      // 进私聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(1, item.targetNo, null, timeFiff)
      // #endif
      uni.navigateTo({
        url: '/pagesMessage/privateChat/index' + '?userId=' + item.targetNo + '&otherAvatar=' + item.headUrl + '&otherNickName=' + item.nickName
      })
    },
    // 去群聊页
    async toGroupPage(item) {
      // #ifdef APP
      this.$store.state.engie.setOnUnreadCountClearedListener(res => {
        console.log('🚀 ~ 监听清除群聊未读数', res)
      })

      // 进群聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(2, item.groupNo, null, timeFiff)
      // #endif
      uni.navigateTo({ url: '/pagesMessage/groupChat/index?groupNo=' + item.groupNo + '&groupName=' + item.groupName })
    }
  }
}
</script>

<style lang="scss" scoped>
.search-user-page {
  background-color: #ffffff;
  min-height: 100vh;

  .search-wrap {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    width: 100%;
    background-color: #fff;
    padding-top: calc(var(--status-bar-height) + 20rpx);
    padding-bottom: 20rpx;
    display: flex;
    align-items: center;
    .back-image {
      width: 44rpx;
      height: 44rpx;
      padding: 0 24rpx;
      flex-shrink: 0;
    }
    .search-box {
      flex: 1;
      height: 72rpx;
      background: #f5f5f8;
      border-radius: 36rpx;
      display: flex;
      align-items: center;
      padding: 0 20rpx;
      .search-box-input {
        flex: 1;
        margin-left: 20rpx;
        /deep/.uni-input-input {
          font-size: 28rpx;
          color: #2a343e;
        }
      }
    }
    .search-btn {
      font-size: 28rpx;
      color: #2d3f49;
      line-height: 36rpx;
      padding: 0 36rpx 0 24rpx;
    }
  }
}

.list-wrap {
  height: 100%;
  padding-top: calc(var(--status-bar-height) + 112rpx);
  padding-bottom: 30rpx;
  box-sizing: border-box;
  overflow-y: auto;

  .list-box-item {
    display: flex;
    align-items: center;
    padding: 30rpx 36rpx;
    .list-box-item-avatar {
      width: 90rpx;
      height: 90rpx;
      border-radius: 50%;
      margin-right: 24rpx;
      flex-shrink: 0;
    }
    .list-box-item-name {
      flex: 1;
      font-size: 28rpx;
      color: #2d3f49;
      line-height: 36rpx;
    }
  }
}
.empty-wrap {
  width: 212rpx;
  height: 246rpx;
  margin: 270rpx auto 0;
  .empty-img {
    width: 100%;
    height: 100%;
    background-size: cover;
  }
}
</style>
