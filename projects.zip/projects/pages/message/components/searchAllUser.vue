<template>
  <view class="search-all-user-page">
    <!-- 搜索 -->
    <view class="search-wrap">
      <image @click.stop="goBack()" class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      <view class="search-box">
        <u-icon name="search" color="#ACADC5" size="44"></u-icon>
        <u--input class="search-box-input" confirmType="search" placeholder="搜索昵称" placeholderStyle="font-size:28rpx;color: #9fa7b4;" border="none" maxlength="10" clearable v-model="searchText" @confirm="searchConfirm" @change="searchChange" :adjustPosition="false"></u--input>
      </view>
      <view class="search-btn" @click="searchConfirm">搜索</view>
    </view>
    <!-- 搜索列表 -->
    <view class="list-wrap">
      <!-- 用户列表 -->
      <view class="list-box" v-if="userList.length > 0">
        <block v-for="(item, index) in userList" :key="index">
          <view
            class="list-box-item"
            @click="
              $u.throttle(() => {
                toPrivatePage(item)
              }, 1000)
            "
          >
            <image
              class="list-box-item-avatar"
              :src="item.headUrl || defaultAvatar"
              mode="aspectFill"
              @click.stop="
                $u.throttle(() => {
                  toPersonalPage(item)
                }, 1000)
              "
            />
            <view class="list-box-item-name ellipsis-single" v-html="highlightText(item.displayName ? item.displayName : item.nickName)"></view>
          </view>
        </block>
      </view>
      <!-- 群列表 -->
      <view class="list-box" v-if="groupList.length > 0">
        <block v-for="(item, index) in groupList" :key="index">
          <view
            class="list-box-item"
            @click="
              $u.throttle(() => {
                toGroupPage(item)
              }, 1000)
            "
          >
            <image class="list-box-item-avatar" :src="item.groupUrl || defaultGroupAvatar" mode="aspectFill" />
            <view class="list-box-item-name ellipsis-single" v-html="highlightText(item.displayName ? item.displayName : item.groupName)"></view>
            <text class="list-box-item-name ellipsis-single">({{ item.userCount }})</text>
          </view>
        </block>
      </view>
    </view>
    <view class="empty-wrap" v-if="showSearchList && userList.length == 0 && groupList.length == 0">
      <image class="empty-img" src="https://img.yiqitogether.com/yyqc/20240528/upload_bmf1yp6dzui8wr0o3ilz7whofj9o3w1s.png" alt="" mode="aspectFill"></image>
    </view>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
export default {
  data() {
    return {
      // 默认头像
      defaultAvatar: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      // 默认群头像
      defaultGroupAvatar: 'http://img.yiqitogether.com/static/images/messageGray/group_avatar_normal.png',
      // 是否显示搜索列表
      showSearchList: false,
      // 绑定的搜索框内容
      searchText: '',

      // 用户列表
      userList: [],
      // 所有的用户列表
      allUserList: [],
      // 群列表
      groupList: [],
      // 所有的群列表
      allGroupList: []
    }
  },

  onLoad(e) {
    if (e.allUserList) {
      console.log(e.allUserList)
      this.allUserList = JSON.parse(decodeURIComponent(e.allUserList)) || []
      // console.log(this.allUserList, '112')
    }
    if (e.allGroupList) {
      this.allGroupList = JSON.parse(decodeURIComponent(e.allGroupList)) || []
      // console.log(this.allGroupList, '88112')
    }
    this.searchText = e.searchText
    this.searchConfirm()
  },
  // 在页面退出时清除监听事件
  // onUnload() {
  //   this.searchText = ''
  //   this.allMemberList = []
  // },
  methods: {
    /**
     * 退出页面
     */
    goBack() {
      this.searchText = ''
      uni.navigateBack()
    },

    /**
     * 输入触发
     */
    searchChange(e) {
      if (e.length == 0) {
        this.showSearchList = false
        // 用户列表
        this.userList = []
        // 群列表
        this.groupList = []
      }
    },
    /**
     * 确认搜索
     */
    searchConfirm() {
      let that = this
      console.log(this.searchText, 'this.searchText')
      if (this.searchText) {
        // 用户列表
        this.userList = []
        // 群列表
        this.groupList = []
        this.showSearchList = true
        if (this.allUserList.length > 0) {
          this.allUserList.forEach((item, index) => {
            let userNickName = item.nickName?.indexOf(this.searchText)
            let userDisplayName = item.displayName?.indexOf(this.searchText)
            if (userNickName > -1 || userDisplayName > -1) {
              this.userList.push(item)
            }
          })
        } else {
          console.log('用户为空')
        }
        if (this.allGroupList.length > 0) {
          this.allGroupList.forEach((item, index) => {
            let groupNickName = item.groupName?.indexOf(this.searchText)
            let groupDisplayName = item.displayName?.indexOf(this.searchText)
            if (groupNickName > -1 || groupDisplayName > -1) {
              this.groupList.push(item)
            }
          })
        } else {
          console.log('群聊为空')
        }
      }
    },
    // 处理高亮
    highlightText(text) {
      let highlightStr = `<text style="color:#FE5E10">${this.searchText}</text>`
      // new 出来一个正则表达式reg根据动态数据变量来创建
      // 参数一 将 this.searchValue的值解析成字符串,并根据这个创建正则表达式,
      // 参数二 匹配模式  "gi"
      let reg = new RegExp(this.searchText, 'gi')
      // 返回替换后的心字符串
      return text.replace(reg, highlightStr)
    },
    // 点击头像进个人主页
    toPersonalPage(item) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + item.targetNo })
    },
    // 去私聊页
    async toPrivatePage(item) {
      // #ifdef APP
      // 进私聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(1, item.targetNo, null, timeFiff)
      // #endif
      uni.navigateTo({ url: '/pagesMessage/privateChat/index?userId=' + item.targetNo + '&otherAvatar=' + item.headUrl + '&otherNickName=' + item.nickName })
    },
    // 去群聊页
    async toGroupPage(item) {
      // #ifdef APP
      this.$store.state.engie.setOnUnreadCountClearedListener(res => {
        console.log('🚀 ~ 监听清除群聊未读数', res)
      })
      // 进群聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(2, item.groupNo, null, timeFiff)
      // #endif
      uni.navigateTo({ url: '/pagesMessage/groupChat/index?groupNo=' + item.groupNo + '&groupName=' + item.groupName })
    }
  }
}
</script>

<style lang="scss" scoped>
.search-all-user-page {
  background-color: #ffffff;
  min-height: 100vh;

  .search-wrap {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    width: 100%;
    background-color: #fff;
    padding-top: calc(var(--status-bar-height) + 28rpx);
    padding-bottom: 8rpx;
    display: flex;
    align-items: center;
    .back-image {
      width: 44rpx;
      height: 44rpx;
      padding: 0 24rpx;
      flex-shrink: 0;
    }
    .search-box {
      flex: 1;
      height: 72rpx;
      background: #f5f5f8;
      border-radius: 36rpx;
      display: flex;
      align-items: center;
      padding: 0 20rpx;
      .search-box-input {
        flex: 1;
        margin-left: 20rpx;
        /deep/.uni-input-input {
          font-size: 28rpx;
          color: #2a343e;
        }
      }
    }
    .search-btn {
      font-size: 28rpx;
      color: #2d3f49;
      line-height: 36rpx;
      padding: 0 36rpx 0 24rpx;
    }
  }
}

.list-wrap {
  padding-top: calc(var(--status-bar-height) + 108rpx);
  padding-bottom: 50rpx;
  box-sizing: border-box;
  .list-box {
    margin-top: 20rpx;
    margin-bottom: 44rpx;
    padding: 0 42rpx;
    box-sizing: border-box;
    .title {
      font-size: 24rpx;
      color: #adadad;
      line-height: 32rpx;
      margin-bottom: 28rpx;
    }
    .list-box-item {
      display: flex;
      align-items: center;
      justify-items: center;
      margin-bottom: 40rpx;
      .list-box-item-avatar {
        width: 90rpx;
        height: 90rpx;
        border-radius: 50%;
        margin-right: 20rpx;
        flex-shrink: 0;
      }
      .list-box-item-name {
        flex: 1;
        font-size: 28rpx;
        color: #2d3f49;
        line-height: 36rpx;
      }
    }
  }
}

.empty-wrap {
  width: 212rpx;
  height: 246rpx;
  margin: 200rpx auto 0;
  .empty-img {
    width: 100%;
    height: 100%;
    background-size: cover;
  }
}
</style>
