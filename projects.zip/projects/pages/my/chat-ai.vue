<template>
  <view class="pages">
    <view class="chat-list">
      <block v-for="(item, index) in historyTextList" :key="index">
        <view class="h-flex h-mg-b-40">
          <image v-if="item.role == 'user'" :src="avatarUrl" class="avatar h-mg-r-30 h-mg-t-10" mode=""></image>
          <image v-if="item.role == 'assistant'" src="http://img.yiqitogether.com/yqyq-app/images/logo1024.png" class="avatar h-mg-r-30" mode=""></image>

          <view class="h-flex-1 content-box">
            <zero-markdown-view style="padding: 0" :markdown="item.content"></zero-markdown-view>
            <view class="operation-button h-pg-t-20">
              <image src="@/uni_modules/zhouWei-APPshare/static/icon_copy.png" mode="" class="h-icon-back" @click="copyText(item.content)"></image>
            </view>
          </view>
        </view>
      </block>
      <block v-if="sparkResult">
        <view class="h-flex h-mg-b-40">
          <image src="http://img.yiqitogether.com/yqyq-app/images/logo1024.png" class="avatar h-mg-r-30 h-mg-t-10" mode=""></image>
          <view class="h-flex-1 content-box">
            <zero-markdown-view style="padding: 0" :markdown="sparkResult"></zero-markdown-view>
          </view>
        </view>
      </block>
    </view>

    <!-- 底部固定输入框 -->
    <view class="foot-box">
      <view class="input-box">
        <input class="ai-input" placeholder="输入想咨询的问题" v-model="TEXT" />
        <image class="send-btn" src="@/static/images/chat-send.png" @click="sendToSpark()"></image>
        <!-- <button @click="sendToSpark()" class="send-btn">发送</button> -->
      </view>
    </view>

    <view style="opacity: 0; height: 150rpx; background-color: #f6f6f8" id="foot">foot</view>
  </view>
</template>

<script>
import * as base64 from 'base-64'
import CryptoJS from '../../node_modules/crypto-js/crypto-js.js'
import { load, save } from '@/utils/store.js'
import { USER_INFO, AI_CHAT_LIST } from '@/utils/cacheKey.js'
import MyInfo from '@/model/my.js'
// import * as utf8 from "utf8"
export default {
  data() {
    return {
      TEXT: '',
      APPID: '', // 控制台获取填写
      APISecret: '',
      APIKey: '',
      sparkResult: '', //当前答复
      historyTextList: [], // 历史会话信息，由于最大token12000,可以结合实际使用，进行移出
      avatarUrl: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      sendChatFlag: true,
      socketTask: null
    }
  },
  onLoad() {
    this.historyTextList = load(AI_CHAT_LIST) || []
    this.avatarUrl = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)).headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'
    setTimeout(() => {
      this.scrollToBottom(300)
    }, 1500)
  },
  onUnload() {
    try {
      if (this.socketTask) {
        this.socketTask.close()
      }
    } catch (e) {
      //TODO handle the exception
    }
  },
  methods: {
    scrollToBottom(time) {
      uni.pageScrollTo({
        selector: '#foot',
        duration: time || 50
      })
    },
    copyText(text) {
      uni.setClipboardData({
        data: text,
        success: function () {
          uni.showToast({
            title: '复制成功',
            icon: 'none'
          })
        }
      })
    },
    async sendToSpark() {
      let self = this
      if (!this.sendChatFlag) {
        return uni.showToast({
          title: '请等待当前对话结束',
          icon: 'none'
        })
      }
      if (this.TEXT.trim() == '') {
        return uni.showToast({
          title: '输入为空',
          icon: 'none'
        })
      }
      this.sendChatFlag = false
      let myUrl = ''
      let appid = ''
      let dateStr = new Date().toGMTString()
      let obj = {
        content: this.TEXT,
        dateGMT: dateStr,
        dateEncode: encodeURI(dateStr)
      }
      try {
        let res = await MyInfo.queryQualification(obj)
        if (!res.success) {
          this.sendChatFlag = true
          return uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        myUrl = res.data.url
        appid = res.data.appId
      } catch (e) {
        self.sendChatFlag = true
        return
      }
      // let myUrl = await this.getWebSocketUrl();
      this.sparkResult = ''
      this.socketTask = uni.connectSocket({
        url: myUrl,
        method: 'GET',
        success: res => {
          console.log(res, 'ws成功连接...', myUrl)
        }
      })
      self.socketTask.onError(res => {
        this.sendChatFlag = true
        return uni.showToast({
          title: '连接发生错误',
          icon: 'none'
        })
      })
      self.socketTask.onOpen(res => {
        this.historyTextList.push({
          role: 'user',
          content: this.TEXT
        })
        this.TEXT = ''
        let params = {
          header: {
            app_id: appid,
            uid: 'aef9f963-7'
          },
          parameter: {
            chat: {
              domain: 'generalv3.5',
              temperature: 0.5,
              max_tokens: 1024
            }
          },
          payload: {
            message: {
              text: [this.historyTextList[this.historyTextList.length - 1]]
            }
          }
        }
        console.log(`send成功，参数为${JSON.stringify(params)}`)
        setTimeout(() => {
          this.scrollToBottom()
        }, 100)
        self.socketTask.send({
          // 发送消息，，都用uni的官方版本
          data: JSON.stringify(params),
          success() {}
        })
      })

      // 接受到消息时
      self.socketTask.onMessage(res => {
        console.log('收到API返回的内容：', res.data)
        try {
          let obj = JSON.parse(res.data)
          let dataArray = obj.payload.choices.text
          for (let i = 0; i < dataArray.length; i++) {
            self.sparkResult = self.sparkResult + dataArray[i].content
          }
        } catch (e) {
          //TODO handle the exception
        }
        let temp = JSON.parse(res.data)
        if (temp.header.code === 0) {
          if (res.data && temp.header.status === 2) {
            // 答案结束，记录问题及回答
            self.historyTextList.push({
              role: 'assistant',
              content: self.sparkResult
            })
            self.sparkResult = ''
            if (self.historyTextList.length > 20) {
              self.historyTextList.slice(self.historyTextList.length - 21)
            }
            save(AI_CHAT_LIST, self.historyTextList)

            setTimeout(() => {
              self.sendChatFlag = true
              self.scrollToBottom()
              self.socketTask.close()
            }, 1000)
          }
        } else if (temp.header.code !== 0) {
          uni.showModal({
            title: '提示',
            content: temp.header.message,
            showCancel: false,
            success: function (res) {
              self.historyTextList = load(AI_CHAT_LIST) || []
              self.sparkResult = ''
              self.sendChatFlag = true
              self.socketTask.close()
            }
          })
        }

        // 将滚动位置设置为页面底部
        this.scrollToBottom()
      })
    },
    // 鉴权
    getWebSocketUrl() {
      return new Promise((resolve, reject) => {
        // https://spark-api.xf-yun.com/v1.1/chat  V1.5 domain general
        // https://spark-api.xf-yun.com/v2.1/chat  V2.0 domain generalv2
        var url = 'wss://spark-api.xf-yun.com/v3.5/chat'
        var host = 'spark-api.xf-yun.com'
        var apiKeyName = 'api_key'
        var date = new Date().toGMTString()
        console.log('date', date)
        console.log(encodeURI(date))
        var algorithm = 'hmac-sha256'
        var headers = 'host date request-line'
        var signatureOrigin = `host: ${host}\ndate: ${date}\nGET /v3.5/chat HTTP/1.1`
        var signatureSha = CryptoJS.HmacSHA256(signatureOrigin, this.APISecret)
        var signature = CryptoJS.enc.Base64.stringify(signatureSha)
        var authorizationOrigin = `${apiKeyName}="${this.APIKey}", algorithm="${algorithm}", headers="${headers}", signature="${signature}"`
        var authorization = base64.encode(authorizationOrigin)
        url = `${url}?authorization=${authorization}&date=${encodeURI(date)}&host=${host}`

        console.log(url)
        resolve(url) // 主要是返回地址
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.pages {
  width: 750rpx;
  min-height: 100vh;
  padding: 30rpx 30rpx 0;
  box-sizing: border-box;
  background-color: #f6f6f8;
}
.chat-list {
  width: 95%;
  flex-wrap: wrap;
}
.avatar {
  width: 80rpx;
  height: 80rpx;
  display: block;
  border-radius: 50%;
}
.content-box {
  box-sizing: border-box;
  padding: 20rpx;
  background-color: #fdfefe;
  border-radius: 10rpx;
}

.foot-box {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 750rpx;
  height: 126rpx;
  box-sizing: border-box;
  background-color: #f6f6f8;
  z-index: 9;
  padding: 0 30rpx;
  display: flex;
  align-items: center;
}
.input-box {
  flex: 1;
  background-color: #fff;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10rpx 10rpx 10rpx 30rpx;
  border-radius: 70rpx;
}
.ai-input {
  flex: 1;
}
.send-btn {
  width: 100rpx;
  font-size: 26rpx;
  height: 60rpx;
  margin-bottom: 0;
  margin-left: 30rpx;
}
.operation-button {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
</style>
