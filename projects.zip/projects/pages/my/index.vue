<template>
  <view class="myPages">
    <video style="position: absolute; top: 0; left: -750rpx" :src="videoPlayUrl" loop id="videoId" @fullscreenchange="videoFullScreenChange"></video>

    <!-- 我的相关信息卡片 我的页面numberId传自己的 -->
    <user-info :sourcePage="'tabarMy'" ref="userInfo" :checkedTabProps="checkedTab" :isscrollTop="isscrollTop" :userLoginFlag="userLoginFlag" :isMyself="isMyself" :targetNumberId="numberId" @playVideo="playVideo"></user-info>

    <!-- 更多信息弹框 -->
    <accredit-popup ref="accredit" systemTitle="“一起一起”想访问您的相机" systemContent="用于使用上传照片功能" permisionID="android.permission.CAMERA" cacheId="cameraAccredit" @successAccredit="sweepEvent"></accredit-popup>

    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
    <!-- 升级弹窗  -->
    <view class="popup versionpopup" v-if="isversion">
      <view class="popup-activity">
        <view class="popup-activity-title">发现新版本</view>
        <view class="popup-activity-version">版本号：V{{ versionData.version }}</view>
        <scroll-view class="popup-activity-tips" scroll-y>
          <view class="txt" v-for="(item, index) in versionDescList" :key="index">
            {{ item }}
          </view>
        </scroll-view>
        <view class="popup-activity-renewal" @click="goupgradation()">立即更新</view>
        <view class="popup-activity-ignore" @click="ignoreAndroidVersionRenewal()">忽略此版本</view>
        <image @click="isversion = false" class="popup-activity-off" src="@/static/images/balls_close.png" mode=""></image>
      </view>
    </view>
  </view>
</template>
<script>
// 导入组件
import userInfo from '@/pages/my/components/user-info.vue'
import myMorePopup from '@/pages/my/components/my-more-popup.vue'
import activityType from '@/pagesCommon/compons/activityType.vue'
import toolsModel from '@/model/tools.js'

// 导入缓存工具 及 缓存字典
import { load, save } from '@/utils/store.js'
import { LOGIN_TOKEN, LOGIN_USERID, CONNECTRONGYUN, ANDROIDVERSIONIGNORE, DOWNLOAD_TIME } from '@/utils/cacheKey.js'
import { getTokenConnectRongYun } from '@/utils/publicRequest.js'
import { changeVersion, compareVersion } from '@/utils/tools.js'

export default {
  components: {
    activityType,
    userInfo,
    myMorePopup
  },
  data() {
    return {
      isMyself: true, // 是否是本人
      videoPlayUrl: '', // video的视频源
      myMorePopShow: false, //更多展示弹框
      isscrollTop: false, // 滑动距离
      userLoginFlag: load(LOGIN_TOKEN) || '',
      userInfoDTO: '',
      numberId: load(LOGIN_USERID).toString() || '', // 本人numberId
      addressStr2: '',
      noClick: true,
      balanceCount: 0, //积分余额
      checkedTab: 4, // 选中的tab
      // 版本升级弹窗flag
      isversion: false,
      // 版本升级信息
      versionData: {},
      versionDescList: []
    }
  },
  onPageScroll: function (e) {
    let top = 171
    //nvue暂不支持滚动监听，可用bindingx代替
    if (e.scrollTop <= top) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  onReady() {
    // 视频
    this.videoContext = uni.createVideoContext('videoId')
  },
  onPullDownRefresh() {
    this.refreshList()
    this.$refs.userInfo.getPersoanalInfo()
    this.$refs.userInfo.getBalance()
    setTimeout(() => {
      uni.stopPullDownRefresh()
    }, 1000)
  },
  onLoad(e) {
    let that = this
    uni.$on('openMyPopup', () => {
      this.$refs.publishPopupRef.onOpen()
      this.$refs.userInfo.closemyMore()
      this.$refs.userInfo.closeImageBtnClick()
    })
    if (e.checkedTab) {
      this.checkedTab = Number(e.checkedTab)
    }
    // #ifdef APP-PLUS
    // 如果已经连接融云成功便不再连接
    if (!load(CONNECTRONGYUN)) {
      getTokenConnectRongYun(that)
    }
    // #endif
    this.getVersion()
  },
  watch: {
    numberId(newVal, oldVal) {
      /**
       * 用于切换账户更新用户数据
       */
      if (this.$refs.userInfo) {
        this.$refs.userInfo.refreshList()
      }
    }
  },
  onShow() {
    uni.showTabBar()
    this.userLoginFlag = load(LOGIN_TOKEN) || ''
    this.numberId = load(LOGIN_USERID).toString() || ''
    this.$forceUpdate()
  },
  onHide() {
    // 关闭更多弹窗
    setTimeout(() => {
      this.$refs.userInfo.closemyMore()
    }, 200)
    this.$refs.userInfo.closeImageBtnClick()
    this.$refs.publishPopupRef.onClose()

    if (this.$refs.userInfo.$refs.findPlazaList) {
      this.$refs.userInfo.$refs.findPlazaList.closeMoreClick()
    }
  },

  methods: {
    /**
     *  管理企业后更新状态
     */
    getPersoanalInfoRequest() {
      this.$refs.userInfo.getPersoanalInfo()
    },
    /**
     * 刷新数据使用，本页面或其他页面刷新列表 调用该方法
     */
    refreshList() {
      // 个人列表卡片组件
      this.$refs.userInfo.refreshList()
    },
    /**
     * 更改个性签名
     */
    changeSignature(data) {
      this.$refs.userInfo.userInfoDTO.signature = data
    },
    // 点击播放视频
    playVideo(type) {
      let self = this
      this.videoPlayUrl = type.videoUrl
      // #ifdef H5
      try {
        this.$nextTick(() => {
          self.videoContext.requestFullScreen({ direction: 0 })
        })
      } catch (e) {
        console.log(e)
      }
      // #endif
      // #ifndef H5
      if (this.videoPlayUrl) {
        uni.navigateTo({
          url: '/pages/my/videoPlay?url=' + this.videoPlayUrl,
          events: {
            setFullscreen() {
              plus.navigator.setFullscreen(false)
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    /**
     * @param {Object} e 视频是否进入全屏
     */
    videoFullScreenChange(e) {
      if (e.detail.fullScreen) {
        // 开始播放
        this.videoContext.play()
      } else {
        // 停止播放，销毁数据源
        this.videoContext.pause()
        this.videoPlayUrl = null
      }
    },
    closemyMore() {
      this.myMorePopShow = false
    },
    openmyMore() {
      this.myMorePopShow = true
    },
    /**
     * 扫一扫
     */
    sweep() {
      this.$refs.accredit.triggerEvent()
      this.noClick = false
    },
    sweepEvent() {
      // 允许从相机和相册扫码
      this.noClick = true
      uni.scanCode({
        success: function (res) {
          let strPosition = res.result.indexOf('/pagesCommon/details/details')
          let info = res.result.indexOf('"type":"joinGroup"')
          if (info > -1) {
            let a = JSON.parse(res.result)
            uni.navigateTo({
              url: '/pagesMessage/privateChat/groupConfirm?groupNo=' + a.groupNo
            })
          } else if (strPosition > -1) {
            let path = res.result.substring(strPosition)
            uni.navigateTo({
              url: path
            })
          } else {
            uni.showToast({
              title: '暂不支持该类型的二维码',
              icon: 'none'
            })
          }
        }
      })
    },
    /**
     * 获取版本信息，判断是否需要 进行安卓弹窗升级
     */
    getVersion() {
      // #ifdef APP-PLUS
      if (uni.getSystemInfoSync().platform == 'android') {
        toolsModel.getVersion().then(dataRes => {
          if (dataRes.code == 'SUCCESS') {
            let downloadTime = new Date().getTime() - load(DOWNLOAD_TIME) > 60 * 60 * 1000 * 2
            console.log('下载时间是否超过2小时', downloadTime)
            let ignoreVersionList = load(ANDROIDVERSIONIGNORE) || []
            this.versionData = dataRes.data
            this.versionDescList = dataRes.data && dataRes.data.renewInfo ? dataRes.data.renewInfo.split('。') : []
            let versionNum = plus.runtime.version
            this.isversion = compareVersion(versionNum, this.versionData.version) && !ignoreVersionList.includes(dataRes.data.version) && downloadTime
          }
        })
      }
      // #endif
    },
    /**
     * 跳转，更新地址
     */
    goupgradation() {
      // #ifdef APP-PLUS
      this.isversion = false
      uni.showToast({
        title: '正在升级版本',
        icon: 'none',
        duration: 2500
      })
      changeVersion(this.versionData.downloadUrl)
      //#endif
    },
    /**
     *
     */
    ignoreAndroidVersionRenewal() {
      let ignoreVersionList = load(ANDROIDVERSIONIGNORE) || []
      if (this.versionData.version) {
        ignoreVersionList.push(this.versionData.version)
        save(ANDROIDVERSIONIGNORE, ignoreVersionList)
      }
      this.isversion = false
      uni.showToast({
        title: '已忽略本版本更新',
        icon: 'none'
      })
    }
  }
}
</script>
<style scoped lang="scss">
* {
  margin: 0;
  padding: 0;
  font-style: normal;
  font-weight: normal;
}
.flex-1 {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.flex-2 {
  display: flex;
  align-items: center;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  align-items: center;
  justify-content: end;
}
.myPages {
  background: #f6f7f8;
  min-height: 100vh;
}
.versionpopup {
  z-index: 999999;
}
.popup {
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.8);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;

  .popup-activity {
    width: 498rpx;
    height: 642rpx;
    box-sizing: border-box;
    padding: 108rpx 46rpx 0;
    background: url('http://img.yiqitogether.com/static/images/index/banbengengxin.png') no-repeat;
    background-size: 100% 100%;
    position: absolute;
    top: 45%;
    left: 50%;
    transform: translate(-50%, -50%);

    .popup-activity-title {
      font-size: 42rpx;
      color: #2c2c2c;
      line-height: 58rpx;
      font-weight: bold;
    }
    .popup-activity-version {
      font-size: 28rpx;
      color: #9fa7b4;
      line-height: 40rpx;
    }
    .popup-activity-tips {
      width: 100%;
      height: 208rpx;
      overflow-y: auto;
      margin: 30rpx 0;
      .txt {
        font-size: 24rpx;
        color: #615e5e;
        line-height: 36rpx;
        margin-bottom: 14rpx;
      }
      .txt:last-child {
        margin-bottom: 0;
      }
    }
    .popup-activity-renewal {
      width: 414rpx;
      height: 72rpx;
      background: #fe5e10;
      border-radius: 40rpx;
      font-size: 28rpx;
      color: #ffffff;
      text-align: center;
      line-height: 72rpx;
      margin-bottom: 16rpx;
    }
    .popup-activity-ignore {
      text-align: center;
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
    }
    .popup-activity-off {
      width: 52rpx;
      height: 52rpx;
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translate(-50%, 120rpx);
    }
  }
}
</style>
