<template>
	<view class="allheaders">
		<view class="downBtn left" @click="downloadFun(1)"></view>
		<view class="downBtn centent" @click="downloadFun(2)"></view>
		<view class="downBtn right" @click="downloadFun(3)"></view>
		<view class="popup" v-if="guide" @click="guide = false">
			<image class="popup_img" src="http://img.yiqitogether.com/yqyq-app/images/h5_xzzy.png" mode="widthFix"></image>
		</view>
	</view>
</template>
<script>
	import UserModel from '@/model/user'
	export default {
		components: {},
		data() {
			return {
				downloadUrl: {},
				guide: false
			}
		},
		mounted() {
			let that = this
			// this.getDoenUrl()
		},
		methods: {
			getDoenUrl() {
				UserModel.getDownloadUrl().then((dataRes) => {
					if (dataRes.code == 'SUCCESS') {
						console.log(dataRes)
						this.downloadUrl = dataRes.data
					}
				})
			},
			downloadFun(data) {
				let userAgent = navigator.userAgent.toLowerCase()
				let isWeChat = userAgent.indexOf('micromessenger') !== -1
				if (isWeChat) {
					// 如果是微信小程序
					// uni.navigateTo({
					//   url: '/pagesMy/my/downloadIOS',
					// })
					this.guide = true
					return
				}
				const info = uni.getSystemInfoSync()
				if (data == 1) { // && info.osName == 'ios'
					//下载ios
					// window.location.href = this.downloadUrl.iosUrl
					window.location.href = 'https://apps.apple.com/cn/app/%E4%B8%80%E8%B5%B7%E4%B8%80%E8%B5%B7/id6449738533'
				} else if (data == 2) { // && info.osName == 'android'
					//下载安卓
					console.log('安卓');
					// window.location.href = this.downloadUrl.androidUrl
					window.location.href = 'http://img.yiqitogether.com/yyqc/apkDownload/yq.apk'
				} else if (data == 3) { // && info.osName == 'android'
					//下载安卓
					console.log('安卓');
					// window.location.href = this.downloadUrl.androidUrl
					window.location.href = 'market://details?id=com.ecpss.together'
				}
			},
		},
	}
</script>
<style scoped lang="scss">
	* {
		margin: 0;
		padding: 0;
		font-style: normal;
		font-weight: normal;
	}

	.allheaders {
		width: 100%;
		height: 100vh;
		overflow-y: scroll;
		overflow-x: hidden;
		position: relative;
		background-image: url('https://img.yiqitogether.com/static/local/don/bg@2x.png');
		background-origin: inherit;
		background-position: center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.downBtn {
		width: 214rpx;
		height: 80rpx;
		position: absolute;
		bottom: 128rpx;
		z-index: 1000;
		background-origin: inherit;
		background-position: center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.left {
		background-image: url('https://img.yiqitogether.com/yqyq-app/images/ios_shop.png');
		left: 34rpx;
		bottom: 128rpx;
	}

	.centent {
		background-image: url('https://img.yiqitogether.com/yqyq-app/images/android_apk.png');
		left: 268rpx;
		bottom: 128rpx;
	}

	.right {
		background-image: url('https://img.yiqitogether.com/yqyq-app/images/android_shop.png');
		left: 502rpx;
		bottom: 128rpx;
	}

	.popup {
		width: 100vw;
		height: 100vh;
		background: rgba(0, 0, 0, 0.7);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 9999;
		display: flex;
		justify-content: flex-end;
	}

	.popup_img {
		width: 466rpx;
		// height: 350rpx;
		margin: 12rpx 50rpx 0 0;
	}
</style>