<template>
  <u-popup class="myMorePop" :show="myMorePopShow" mode="right" @close="onClose">
    <scroll-view scroll-y style="height: 100vh">
      <view class="moreBox">
        <view
          @click="
            $u.throttle(() => {
              goPage(item.name)
            }, 500)
          "
          v-for="item in navList"
          :key="item.name"
        >
          <view class="moreItem flex-1">
            <view class="moreItem-left flex-0">
              <image class="moreItem-left-img" :src="item.image" mode="scaleToFill" />
              <view class="moreItem-left-text">{{ item.name }}</view>
              <view class="balance" v-if="item.name === '积分中心'">{{ balanceCount >= 10000 ? (balanceCount / 10000).toFixed(2) + 'w' : balanceCount }}</view>
            </view>
            <view class="moreItem-right">
              <image class="moreItem-right-arrow" src="@/static/images/qianwang.png" mode="scaleToFill" />
            </view>
          </view>

          <view class="moreItem-border" v-if="item.isborder"></view>
        </view>
      </view>
    </scroll-view>
  </u-popup>
</template>
<script>
// 导入接口
import MyInfo from '@/model/my.js'

// 导入缓存工具 及 缓存字典
import { load } from '../../../utils/store'
import { LOGIN_USERID, USER_INFO } from '@/utils/cacheKey.js'
import { removeCache } from '@/utils/tools.js'
export default {
  props: {
    myMorePopShow: false, // 弹窗显示
    userLoginFlag: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      navList: [
        { name: '我的钱包', image: require('../../../static/images/qb.png'), isborder: false },
        { name: '积分中心', image: require('@/static/images/gn_qh_1.png'), isborder: false },
        { name: '活动订单', image: 'http://img.yiqitogether.com/static/images/myImgs/icon_activityorder.png', isborder: false },
        { name: '我的账单', image: require('@/static/images/gn_qh.png'), isborder: true },
				{ name: '我的二维码', image: require('@/static/images/gn_qrcode.png'), isborder: false },
        { name: '我的访客', image: require('@/static/images/my-visitor.png'), isborder: false },
        { name: '礼物', image: require('@/static/images/gn_zwgl_2.png'), isborder: false },
        { name: '收藏', image: require('@/static/images/gn_wdsc.png'), isborder: false },
        { name: '足迹', image: require('@/static/images/gn_lsll_1.png'), isborder: true },
        { name: '我的商家', image: require('@/static/images/gn_zwgl.png'), isborder: false },
        { name: '我的推广码', image: require('@/static/images/gn_gs.png'), isborder: false },
        { name: '认证中心', image: require('@/static/images/gn_lsll.png'), isborder: false },
        { name: '消息气泡', image: require('@/static/images/gn_bubble.png'), isborder: true },
        { name: '客服中心', image: require('@/static/images/gn_zwgl1.png'), isborder: false },
        { name: '设置', image: require('@/static/images/gn_zwgl_1.png'), isborder: false }
      ],
      balanceCount: 0, // 积分余额
      traineeInfo: {}, // 实习生数据
      storeStatus: 0
    }
  },
  created() {
    // this.getStoreStatus()
    // this.getBalance()
  },
  methods: {
    // 刷新
    refreshList() {
      this.balanceCount = 0
      this.storeStatus = 0
      // 目前调用的是苏州的，getStoreStatus不用了
      // this.getStoreStatus()
      this.getBalance()
    },
    goPage(type) {
      let self = this

      switch (type) {
        case '我的钱包':
          uni.navigateTo({ url: '/pagesMy/my/myAccountCenter/index' })
          break
        case '积分中心':
          uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
          break
        case '活动订单':
          uni.navigateTo({ url: '/pagesCommon/details/myActivity?optionDatas=F2' })
          break
        case '我的账单':
          uni.navigateTo({ url: '/pagesMy/my/myBill' })
          break
				case '我的二维码':
				  uni.navigateTo({ url: '/pagesMy/my/myQrCode' })
				  break
        case '我的访客':
          uni.navigateTo({ url: '/pagesMy/my/myHomePages/accessRecord' })
          break
        case '礼物':
          // #ifdef H5
          uni.showToast({
            title: '该操作需要在APP内进行',
            icon: 'none'
          })
          return
          // #endif

          let obj = {
            type: '1',
            openUrl: '/giftList/yiqi'
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
          this.$nextTick(() => {
            uni.navigateTo({
              url: '/pages/my/webView'
            })
          })

          break
        case '收藏':
          uni.navigateTo({ url: '/pagesMy/my/myCollectNew' })
          break
        case '足迹':
          uni.navigateTo({ url: '/pagesMy/my/historicalBrowser' })
          break
        case '我的商家':
          // if (this.storeStatus == 3) {
          //   this.goMerchant()
          // } else if (this.storeStatus == 2) {
          //   uni.navigateTo({
          //     url: '/pagesMy/my/Mybrand'
          //   })
          // } else {
          //   uni.showToast({
          //     title: '商家信息获取中，请稍后再试',
          //     icon: 'none'
          //   })
          // }
          uni.navigateTo({
            url: '/shangchaoMall/index'
          })
          break
        case '我的推广码':
          let userInfoDTO = JSON.parse(load(USER_INFO)) || {}
          uni.navigateTo({
            url: `/pagesMy/my/myPromotion?name=${userInfoDTO.nickName}&avatar=${userInfoDTO.headUrl}`
          })
          break
        case '认证中心':
          uni.navigateTo({
            url: '/pagesMy/my/myCertification'
          })
          break
        case '消息气泡':
          uni.navigateTo({
            url: '/pagesCommon/message/messageBubble'
          })
          break
        case '实习生':
          uni.navigateTo({
            url: '/pagesMy/my/trainee?traineeInfo=' + JSON.stringify(this.traineeInfo)
          })
          break
        case '客服中心':
          uni.navigateTo({
            url: '/pagesMy/my/serviceCenter'
          })
          break
        case '设置':
          if (!this.userLoginFlag) {
            uni.showModal({
              title: '提示',
              content: '请登录后使用',
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  self.submitOut()
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          } else {
            uni.navigateTo({
              url: '/pagesSetting/setting/index'
            })
          }
          break
        default:
          break
      }
    },
    // 获取商户入驻状态
    getStoreStatus() {
      MyInfo.getMerchantInfo().then(res => {
        if (res.code == 'SUCCESS') {
          let info = res.data.applyMerchantInfo || {}
          if (res.data.applied && info.merchantState && info.merchantState.label == 'APPLYPASSYES') {
            this.getToken()
          } else {
            this.storeStatus = 2
          }
        } else {
          // this.$refs.uToast.show({
          //   ...res
          // })
        }
      })
    },
    // 获取商户token
    getToken() {
      MyInfo.getMerchantToKen()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.merchantToKen = res.data.merchantToKen || ''
          } else {
            this.errMessage = res.message
          }
          this.storeStatus = 3
        })
        .catch(err => {
          this.storeStatus = 3
        })
    },
    // 跳转商户资金页面
    goMerchant() {
      if (this.merchantToKen) {
        let token = load(LOGIN_TOKEN)
        let obj = {
          type: '2',
          openUrl: '/business',
          token: token || '',
          MerToken: this.merchantToKen
        }
        getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
        this.$nextTick(() => {
          uni.navigateTo({ url: '/pages/my/webView' })
        })
      } else {
        uni.showToast({
          title: this.errMessage || '获取商户信息失败',
          icon: 'none',
          duration: 2000
        })
      }
    },
    // 积分余额
    getBalance() {
      MyInfo.getBalance()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.balanceCount = res.data.balance ? res.data.balance : 0
            this.traineeInfo = { isCandidate: res.data.isCandidate, rankCount: res.data.rankCount, candidateCount: res.data.candidateCount }
            if (this.traineeInfo.isCandidate) {
              this.navList[8].isborder = false
              let index = this.navList.findIndex(item => item.name == '实习生')
              if (index == -1) {
                this.navList.splice(9, 0, { name: '实习生', image: require('@/static/images/gn_lsll_2.png'), isborder: true })
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    // 确定退出登录
    submitOut() {
      let that = this
      removeCache(that)
      setTimeout(() => {
        uni.reLaunch({ url: '/pages/login/index' })
      }, 100)
    },
    onClose() {
      this.$emit('close')
    },
    onOpen() {
      this.$emit('open')
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.myMorePop {
  .moreBox {
    width: 496rpx;
    padding: 144rpx 46rpx 100rpx 40rpx;
    .moreItem {
      padding: 30rpx 0;
      .moreItem-left {
        .moreItem-left-img {
          width: 44rpx;
          height: 44rpx;
          margin-right: 30rpx;
        }
        .moreItem-left-text {
          font-size: 32rpx;
          color: #2a343e;
        }
        .balance {
          font-size: 32rpx;
          color: #fe5e10;
          margin-left: 20rpx;
        }
      }
      .moreItem-right {
        .moreItem-right-arrow {
          width: 10rpx;
          height: 18rpx;
        }
      }
    }
    .moreItem-border {
      width: 100%;
      border-bottom: 2rpx solid #f6f6f8;
    }
    // .moreItem:nth-child(3n + 3) {
    //   padding-bottom: 50rpx;
    //   border-bottom: 2rpx solid #f6f6f8;
    // }
    // .moreItem:nth-child(3n + 4) {
    //   padding-top: 50rpx;
    // }
  }
}
</style>
