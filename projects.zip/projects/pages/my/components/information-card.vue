<template>
  <view class="informationCard">
    <!-- 关于我 -->
    <view class="detailsBox">
      <view class="title">关于我</view>
      <view class="tipList flex-0">
        <view class="tipItem flex-0">
          <!-- <view class="scoreBox flex-1">
            <text class="scoreText" v-if="userInfoDTO.score">{{ Number(userInfoDTO.score).toFixed(1) }}</text>
            <text class="score">分</text>
          </view> -->
          <image class="authGoodImg" v-if="userInfoDTO.authGood" src="https://img.yiqitogether.com/yyqc/20240722/upload_1pye86wqz25fv1tijyf0kjgec5xbt0wf.png!yqyq0606" alt="" mode="aspectFill"></image>
          <image class="authSimpleImg" v-if="!userInfoDTO.authSimple && userInfoDTO.headUrl" src="https://img.yiqitogether.com/yyqc/20231205/upload_dqu0vcpsmprsnj3rgg952h7gjmh5rivj.png" alt="" mode="aspectFill"></image>
          <image class="authSimpleImg" v-if="userInfoDTO.authSimple" src="https://img.yiqitogether.com/yyqc/20240722/upload_kmi1zb5cg8dnllb2xijnc6ty29a0k8t7.png!yqyq0606" alt="" mode="aspectFill"></image>
          <image class="authStudentImg1" v-if="userInfoDTO.authStudent_v2 == 'SUCCESS'" src="https://img.yiqitogether.com/yyqc/20231205/upload_nzje6s9t3ed3zgc0321pz0jwgbv7os46.png" alt="" mode="aspectFill"></image>
          <image class="authStudentImg2" v-if="userInfoDTO.authStudent_v2 == 'FINISH_SUCCESS'" src="https://img.yiqitogether.com/yyqc/20240722/upload_oraqso2ke4umpd3oz9odxd0qj4icp612.png!yqyq0606" alt="" mode="aspectFill"></image>
          <image class="authStudentImg3" v-if="userInfoDTO.isBlogger" src="@/static/images/bozhu.png" alt="" mode="aspectFill"></image>
        </view>
      </view>
      <view class="infoBox">
        <view class="flex-0">
          <view class="info-item flex-0">
            <view class="info-item-left">年龄</view>
            <view class="info-item-content ellipsis-single">
              <text v-if="userInfoDTO.age">{{ userInfoDTO.age }}</text>
            </view>
          </view>
          <view class="info-item flex-0">
            <view class="info-item-left">星座</view>
            <view class="info-item-content ellipsis-single">
              <text v-if="userInfoDTO.constellation">{{ userInfoDTO.constellation }}</text>
            </view>
          </view>
        </view>
        <view class="flex-0">
          <view class="info-item flex-0">
            <view class="info-item-left">现居地</view>
            <!-- 截取地区字符串到省 -->
            <view class="info-item-content ellipsis-single">
              <text v-if="userInfoDTO.localArea">{{ userInfoDTO.localArea.substring(userInfoDTO.localArea.indexOf('&&') + 2, 100) }}</text>
            </view>
          </view>
          <view class="info-item flex-0">
            <view class="info-item-left">IP地址</view>
            <view class="info-item-content ellipsis-single">
              <text v-if="userInfoDTO.ipAddress">
                <text v-if="userInfoDTO.ipAddress.includes('&')">{{ userInfoDTO.ipAddress.substring(0, userInfoDTO.ipAddress.indexOf('&&')) }}</text>
                <text v-else>{{ userInfoDTO.ipAddress }}</text>
              </text>
            </view>
          </view>
        </view>
        <view class="flex-0">
          <view class="info-item flex-0">
            <view class="info-item-left">标签</view>
            <view class="flex-0" v-if="tagList">
              <u-tag class="info-item-label" v-for="(item, index) in tagList" :key="index" plain :text="item.name" :borderColor="item.color" :color="item.color" name="1"></u-tag>
            </view>
          </view>
        </view>
      </view>
    </view>

    <!-- 颜值照片 start -->
    <view class="auth-good-img" v-if="userInfoDTO.authGoodImg">
      <view class="title">颜值认证</view>
      <scroll-view class="images-list-box" scroll-x>
        <block v-for="(item, index) in userInfoDTO.authGoodImg.split('&&')" :key="index">
          <image :src="item" mode="aspectFill" class="face-image-item h-mg-r-20" @click="previewImageItem(index)"></image>
        </block>
      </scroll-view>
    </view>
    <!-- 颜值照片 end -->

    <!-- 印象标签 -->
    <!-- <view class="impressionBox">
      <view class="title">印象标签</view>
      <block v-if="neWimpressionList.length > 0">
        <view id="impressionList" :class="[isImpressShow ? 'impression-ActiveList' : 'impression-list']">
          <view class="flex-0" style="flex-wrap: wrap">
            <view v-for="(item, index) in neWimpressionList" :key="index" class="impression-item">
              <text>
                {{ item.name }}
                <text style="margin-left: 20rpx">{{ item.count }}</text>
              </text>
            </view>
          </view>
        </view>
        <view v-if="isImpressShow" class="impression-arrow" @click="changeImpressionListShow">
          <image class="arrowImg" v-if="!allImpressionListShow" src="https://img.yiqitogether.com/yyqc/20230913/upload_a4xbkd9bbxm16eadjv4exc788tfj8ffj.png" mode="aspectFill" alt=""></image>
          <image class="arrowImg" v-else src="https://img.yiqitogether.com/yyqc/20230913/upload_8hxn3liv4vhxp4ih5b07ki7frw9eke8s.png" mode="aspectFill" alt=""></image>
        </view>
      </block>
      <block v-else>
        <view class="normalActivity-empty" v-if="impressionList.length == 0">
          <image class="impression-img" src="@/static/images/zwpj.png" alt="" mode="widthFix" />
          <view class="impression-text">还没有人对他评价印象</view>
        </view>
      </block>
    </view> -->
  </view>
</template>
<script>
export default {
  props: {
    userInfoDTO: {
      type: Object,
      default: {}
    },
    tagList: {
      type: Array,
      default: []
    },
    impressionList: {
      type: Array,
      default: []
    }
  },
  data() {
    return {
      isImpressShow: false, // 是否超出两行
      allImpressionListShow: false,
      lineNum: 0,
      lastIndex: 0,
      oldimpressionList: [],
      neWimpressionList: []
    }
  },
  watch: {
    impressionList(newValue, oldValue) {
      this.oldimpressionList = [...newValue]
      this.neWimpressionList = [...newValue]
    }
  },
  methods: {
    // 印象标签展示处理
    getimpressionListHeight() {
      let that = this
      this.lineNum = 0

      // 获取文字所在元素的高度
      uni
        .createSelectorQuery()
        .selectAll('.impression-item')
        .boundingClientRect(function (data) {
          let firstLeft = data[0].left
          for (let i = 0; i < data.length; i++) {
            let item1 = data[i]
            if (item1.left == firstLeft) {
              that.lineNum++
              // 3行进行折叠
              if (that.lineNum == 4) {
                that.lastIndex = i
              }
            }
            if (that.lastIndex) {
              that.isImpressShow = true
              that.allImpressionListShow = false
              that.neWimpressionList.splice(that.lastIndex)
            }
          }
        })
        .exec()
    },
    // 印象标签全部展示
    changeImpressionListShow() {
      this.allImpressionListShow = !this.allImpressionListShow
      if (this.allImpressionListShow) {
        this.neWimpressionList = [...this.oldimpressionList]
      } else {
        this.neWimpressionList.splice(this.lastIndex)
      }

      this.$forceUpdate()
    },
    // 图片预览
    previewImageItem(index) {
      uni.previewImage({
        urls: this.userInfoDTO.authGoodImg.split('&&'),
        current: index,
        success: function (data) {},
        fail: function (err) {
          console.log(err.errMsg)
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.informationCard {
  .title {
    font-size: 28rpx;
    color: #2a343e;
    margin-bottom: 30rpx;
  }
  .detailsBox {
    background: #ffffff;
    padding: 46rpx 30rpx 32rpx;
    margin-bottom: 20rpx;

    .tipList {
      .tipItem {
        .scoreBox {
          padding: 0rpx 8rpx;
          background: #fff2f4;
          border-radius: 16rpx;
          margin-right: 20rpx;
          color: #ff603d;
          .scoreText {
            font-size: 22rpx;
          }
          .score {
            font-size: 20rpx;
          }
        }
        .authGoodImg {
          width: 32rpx;
          height: 32rpx;
          margin-right: 20rpx;
        }
        .authSimpleImg {
          width: 32rpx;
          height: 32rpx;
          margin-right: 20rpx;
        }
        .authStudentImg1 {
          width: 50rpx;
          height: 34rpx;
          margin-right: 20rpx;
        }
        // .authStudentImg2 {
        //   width: 50rpx;
        //   height: 34rpx;
        //   margin-right: 20rpx;
        // }
        .authStudentImg2 {
          width: 22rpx;
          height: 34rpx;
          margin-right: 20rpx;
        }
        .authStudentImg3 {
          width: 40rpx;
          height: 40rpx;
          margin-right: 20rpx;
        }
      }
    }
    .infoBox {
      margin-top: 32rpx;
      .info-item {
        margin-bottom: 30rpx;
        flex: 1;
        .info-item-left {
          // max-width: 80rpx;
          margin-right: 20rpx;
          font-size: 24rpx;
          color: #a6acb2;
        }
        .info-item-content {
          // width: 260rpx;
          font-size: 24rpx;
          color: #333333;
        }
        .info-item-label {
          margin-right: 20rpx;
          /deep/.u-tag {
            padding: 0 16rpx;
            border-radius: 8rpx;
          }
          /deep/ .u-tag__text {
            font-size: 24rpx !important;
          }
        }
      }
    }
  }
  .auth-good-img {
    padding: 26rpx 30rpx;
    background: #ffffff;
    margin-bottom: 20rpx;
    .images-list-box {
      width: 100%;
      overflow-x: auto;
      white-space: nowrap;
      .face-image-item {
        display: inline-block;
        width: 246rpx;
        height: 246rpx;
        background: #f3f3f3;
      }
    }
  }

  .impressionBox {
    padding: 26rpx 30rpx;
    background: #ffffff;
    min-height: 15vh;
    .impression-list {
      .impression-item {
        color: #2a343e;
        font-size: 28rpx;
        background: #fff0f0;
        border-radius: 26rpx;
        padding: 6rpx 20rpx;
        margin: 0 20rpx 20rpx 0;
      }
    }
    .impression-ActiveList {
      display: -webkit-box;
      -webkit-line-clamp: 2;
      /*! autoprefixer: ignore next */
      -webkit-box-orient: vertical;
      word-break: break-all;
      text-overflow: ellipsis;
      overflow: hidden;
      .impression-item {
        color: #2a343e;
        font-size: 28rpx;
        background: #fff0f0;
        border-radius: 26rpx;
        padding: 6rpx 20rpx;
        margin: 0 20rpx 20rpx 0;
      }
    }
    .impression-arrow {
      text-align: center;
      .arrowImg {
        width: 28rpx;
        height: 16rpx;
      }
    }
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 25vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    font-size: 24rpx;
    color: #f8c1ca;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
  .impression-img {
    width: 262rpx;
    height: 142rpx;
    background-size: cover;
  }
  .impression-text {
    font-size: 24rpx;
    color: #a6acb2;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
