<template>
  <view class="boxList" style="padding: 0">
    <view class="giftBoxNew">
      <view class="gift-number-box">
        <view class="leftBox" @click="toReceiveList()">
          <view class="leftNumber">{{ wishInfo.receiveCount || '0' }}</view>
          <view class="leftInfo">收到的礼物</view>
        </view>
        <view class="rightBox" @click="toGiveList()">
          <view class="rightNumber">{{ wishInfo.giveCount || '0' }}</view>
          <view class="rightInfo">送出的礼物</view>
        </view>
      </view>
      <view class="middleBox">
        <view class="leftBox">
          <image src="https://img.yiqitogether.com/yyqc/20231020/upload_bmcikopi0g9xw7q6asff03kw61j8cf3b.png" alt="" mode="aspectFill" class="leftImage"></image>
          <view class="leftInfo">许下心愿 收获惊喜好礼</view>
        </view>
        <view class="rightBox" @click="toMyWish()">
          <view v-if="isMyself" class="rightNumber">编辑我的心愿</view>
          <image v-if="isMyself" src="https://img.yiqitogether.com/static/local/myImages/goTo@2x.png" alt="" mode="aspectFill" class="rightImage"></image>
        </view>
      </view>
      <!-- 列表 -->
      <view class="al-list-box" v-if="wishInfo.list">
        <view class="a1-card" v-for="item in wishInfo.list" :key="item.productId" @click="clickWishList(item)">
          <view class="a1-card-top">
            <image :src="item.productPic" mode="aspectFill" alt="" class="a1-card-top-image"></image>
            <view v-if="item.productState == '1'" class="a1-card-top-titleBox">
              <view class="a1-card-top-title">已抢光</view>
            </view>
          </view>
          <view class="a1-card-bottom">
            <view :class="item.productState == '0' ? 'a1-title' : 'a1-title2'">{{ item.productTitle }}</view>
            <view class="a1-price" v-if="item.productState == '0'">
              <text :class="item.productState == '0' ? 'a1-price-icon' : 'a1-price-icon2'">￥</text>
              <text :class="item.productState == '0' ? 'a1-price-yuan' : 'a1-price-yuan2'">{{ item.price }}</text>
            </view>
            <view class="a1-card-btn" v-if="item.productState == '0'">
              <image src="https://img.yiqitogether.com/yyqc/20230907/upload_785lheevpbtwjy7qwdnqjvr9nuxj9u9u.png" alt="" class="a1-btn"></image>
              <image src="https://img.yiqitogether.com/yyqc/20230907/upload_6ccehairo3gglw8fk6a17za3alropoax.png" alt="" class="a1-btn-gift"></image>
              <text v-if="!isMyself" class="a1-card-btn-text">赠送</text>
              <text v-if="isMyself" class="a1-card-btn-text">购买</text>
            </view>
          </view>
        </view>
      </view>
      <view v-else class="wishWu">
        <image src="https://img.yiqitogether.com/yyqc/20230904/upload_bm2jyvznofyv9y4mwx5nxc3iufhctbye.png" alt="" mode="aspectFill" class="wishqs"></image>
        <view class="wishwuRecord">暂无记录</view>
      </view>
    </view>
  </view>
</template>
<script>
export default {
  props: {
    wishInfo: {
      type: Object,
      default: {}
    },
    targetNumberId: {
      type: String,
      default: ''
    },
    isMyself: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      linkWish2: ''
    }
  },
  methods: {
    // 收到的礼物列表
    toReceiveList() {
      if (!this.isMyself) {
        return
      }

      let obj = {
        type: '1',
        openUrl: '/giftList/yiqi'
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    // 送出的礼物
    toGiveList() {
      // 只有是本人才可以跳转
      if (!this.isMyself) {
        return
      }
      // // let url = 'http://gm.h5.test.viigoo.com:3315/#/orderList/yiqi'
      // let url = 'http://h5.gm.myyummy.com/#/orderList/yiqi'
      // let testModule = uni.requireNativePlugin('TestModule')
      // testModule.goNativeAppWebView(
      //   {
      //     linkUrl: url
      //   },
      //   ret => {}
      // )
      // //   window.open('http://h5.gm.myyummy.com/#/orderList/yiqi')
      let obj = {
        type: '1',
        openUrl: '/orderList/yiqi'
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    // 我的心愿列表
    toMyWish() {
      // // let url2 = 'http://gm.h5.test.viigoo.com:3315/#/myWish/yiqi'
      // let url2 = 'http://h5.gm.myyummy.com/#/myWish/yiqi'
      // let testModule = uni.requireNativePlugin('TestModule')
      // testModule.goNativeAppWebView(
      //   {
      //     linkUrl: url2
      //   },
      //   ret => {}
      // )
      // //   window.open('http://h5.gm.myyummy.com/#/myWish/yiqi')
      let obj = {
        type: '1',
        openUrl: '/myWish/yiqi'
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    // 心愿列表点击进入详情页
    clickWishList(item) {
      let that = this
      // 测试
      // that.linkWish2 = 'http://gm.h5.test.viigoo.com:3315/#/ConfirmOrder/yiqi' + '?productId=' + item.productId + '&userId=' + that.targetNumberId

      // that.targetNumberId
      if (!that.isMyself) {
        // 生产,不是本人
        // that.linkWish2 = 'http://h5.gm.myyummy.com/#/ConfirmOrder/yiqi' + '?productId=' + item.productId + '&userId=' + that.targetNumberId
        let obj = {
          type: '1',
          openUrl: '/ConfirmOrder/yiqi',
          productId: item.productId,
          userId: that.targetNumberId
        }
        getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      } else {
        // that.linkWish2 = 'http://h5.gm.myyummy.com/#/ConfirmOrder/yiqi' + '?productId=' + item.productId
        let obj = {
          type: '1',
          openUrl: '/ConfirmOrder/yiqi',
          productId: item.productId
        }
        getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      }
      // 'http://h5.gm.myyummy.com/#/ConfirmOrder/yiqi'
      // that.linkWish2 = that.wishInfo.url + '?id=' + item.productId
      if (item.productState == 1) {
        return
      }
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.boxList {
  min-height: calc(100vh - 276rpx);
  .giftBoxNew {
    background-color: #fff;
    height: auto;
    text-align: center;
    padding: 0 32rpx;
    padding-top: 32rpx;
    .gift-number-box {
      width: 343 * 2 rpx;
      height: 62 * 2rpx;
      border-radius: 12 * 2rpx;
      background: #fffcf0;
      border: 2px solid #ffea9b;
      margin-bottom: 32rpx;
      display: flex;
      justify-content: space-evenly;
      padding-top: 20rpx;
      box-sizing: border-box;
      .leftBox {
        .leftNumber {
          font-family: PingFangSCBold-Bold;
          font-size: 36rpx;
          font-weight: normal;
          line-height: normal;
          text-align: center;
          color: #2d2f37;
        }
        .leftInfo {
          font-family: PingFangSCMedium-Medium;
          font-size: 24rpx;
          font-weight: normal;
          line-height: normal;
          text-align: center;
          color: #9e9e9e;
        }
      }
      .rightBox {
        .rightNumber {
          font-family: PingFangSCBold-Bold;
          font-size: 36rpx;
          font-weight: normal;
          line-height: normal;
          text-align: center;
          color: #2d2f37;
        }
        .rightInfo {
          font-family: PingFangSCMedium-Medium;
          font-size: 24rpx;
          font-weight: normal;
          line-height: normal;
          text-align: center;
          color: #9e9e9e;
        }
      }
    }
    .middleBox {
      display: flex;
      justify-content: space-between;
      padding-bottom: 20rpx;
      .leftBox {
        display: flex;
        align-items: center;
        .leftImage {
          width: 66rpx;
          height: 40rpx;
          background-size: cover;
        }
        .leftInfo {
          font-family: PingFangSCRegular-Regular;
          font-size: 24rpx;
          font-weight: normal;
          line-height: normal;
          color: #000000;
          margin-left: 22rpx;
        }
      }
      .rightBox {
        display: flex;
        align-items: center;
        .rightNumber {
          font-family: PingFangSCRegular-Regular;
          font-size: 24rpx;
          font-weight: normal;
          line-height: normal;
          color: #aaacae;
        }
        .rightImage {
          width: 12rpx;
          height: 18rpx;
          background-size: cover;
          margin-left: 12rpx;
        }
      }
    }
    .al-list-box {
      height: auto;
      overflow: hidden;
      margin-top: 20rpx;
      display: flex;
      flex-wrap: wrap;
      border-radius: 32rpx;
      background-color: #fff;
      padding-bottom: 100rpx;
      .a1-card {
        width: 216rpx;
        border-radius: 32rpx;
        background: #ffffff;
        margin-right: 14rpx;
        margin-bottom: 14rpx;

        .a1-card-top {
          width: 100%;
          height: 216rpx;
          position: relative;
          border-radius: 16rpx;
          z-index: 9999;
          .a1-card-top-image {
            width: 100%;
            height: 100%;
            background-size: cover;
            border-radius: 16rpx;
          }
          .a1-card-top-titleBox {
            width: 100%;
            height: 216rpx;
            .a1-card-top-title {
              position: absolute;
              left: 72rpx;
              top: 92rpx;
              font-family: PingFangSCMedium-Medium;
              font-size: 28rpx;
              font-weight: normal;
              line-height: normal;
              letter-spacing: 0px;
              color: #ffffff;
              z-index: 99999;
            }
          }
          .a1-card-top-titleBox:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.3);
            z-index: 999;
            border-radius: 16rpx;
          }
        }
        .a1-card-bottom {
          padding: 32rpx 32rpx 10rpx 32rpx;
          height: auto;
          text-align: left;
          .a1-title {
            height: 70rpx;
            font-family: PingFangSCMedium-Medium;
            font-size: 24rpx;
            font-weight: normal;
            line-height: 35rpx;
            letter-spacing: 0px;
            color: #2d2f37;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
          }
          .a1-title2 {
            font-family: PingFangSCMedium-Medium;
            font-size: 24rpx;
            font-weight: normal;
            line-height: 35rpx;
            letter-spacing: 0px;
            color: #aaacae;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
          }
          .a1-price {
            text-align: left;
            .a1-price-icon {
              font-family: PingFangSCBold-Bold;
              font-weight: 400;
              font-size: 12rpx;
              color: #eb4d57;
            }
            .a1-price-icon2 {
              font-family: PingFangSCBold-Bold;
              font-weight: 400;
              font-size: 12rpx;
              color: #aaacae;
            }
            .a1-price-yuan {
              font-family: PingFangSCBold-Bold;
              font-weight: 400;
              font-size: 28rpx;
              color: #eb4d57;
            }
            .a1-price-yuan2 {
              font-family: PingFangSCBold-Bold;
              font-weight: 400;
              font-size: 28rpx;
              color: #aaacae;
            }
          }
          .a1-card-btn {
            position: relative;
            margin-top: 20rpx;
            .a1-btn {
              width: 116rpx;
              height: 50rpx;
              border-radius: 64px;
            }
            .a1-btn-gift {
              width: 28rpx;
              height: 28rpx;
              position: absolute;
              left: 16rpx;
              top: 10rpx;
            }
            .a1-card-btn-text {
              position: absolute;
              right: 54rpx;
              top: 0rpx;
              font-size: 24rpx;
              font-weight: normal;
              line-height: 50rpx;
              text-align: center;
              letter-spacing: 0px;
              color: #ffffff;
            }
          }
        }
      }
      .a1-card:nth-child(3n) {
        margin-right: 0 !important;
      }
    }
  }
}
.wishWu {
  position: absolute;
  left: 315rpx;
  margin: 148rpx auto 0;
  text-align: center;
  .wishqs {
    width: 122rpx;
    height: 136rpx;
    background-size: cover;
  }
  .wishwuRecord {
    font-size: 28rpx;
    font-weight: 400;
    text-align: center;
    color: #838e9a;
    line-height: 36rpx;
    margin-top: 40rpx;
  }
}
</style>
