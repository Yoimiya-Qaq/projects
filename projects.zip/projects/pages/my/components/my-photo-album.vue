<template>
  <view class="myPhotoAlbum">
    <!-- 创建相册按钮 -->
    <view v-if="isMyself" @click="$u.throttle(goAddAlbum, 500)" class="add-photoalbum-btn flex-5">
      <image class="add-img" src="@/static/images/jia.png" mode="scaleToFill" />
      <view class="add-text">创建相册, 记录生活点滴</view>
    </view>

    <!-- 颜值照片 start -->
    <view class="auth-good-img" v-if="userInfoDTO.authGoodImg">
      <view class="title">颜值认证</view>
      <scroll-view class="images-list-box" scroll-x>
        <block v-for="(item, index) in userInfoDTO.authGoodImg.split('&&')" :key="index">
          <image :src="item" mode="aspectFill" class="face-image-item" @click="previewImageItem(index)"></image>
        </block>
      </scroll-view>
    </view>
    <!-- 颜值照片 end -->

    <block v-if="albumDTOList.length > 0">
      <!-- 贡献值展示 -->
      <view v-if="!isMyself && notice" class="myPhotoAlbum-top flex-1">
        <view class="top-left flex-0">
          <image class="top-img" src="@/static/images/xinalbum.png" mode="scaleToFill" />
          <view class="top-text">{{ notice }}</view>
        </view>
      </view>
      <view class="myPhotoAlbum-List flex-1">
        <view
          class="myPhotoAlbum-Item"
          @click="
            $u.throttle(() => {
              gomyAlbum(item), 500
            })
          "
          v-for="item in albumDTOList"
          :key="item.id"
        >
          <image :style="item.isCanRead ? '' : 'filter: blur(5rpx) brightness(1.2);'" class="myPhotoAlbum-Item-bgImg" :src="item.coverUrl ? item.coverUrl : require('@/static/images/album_bg.png')" mode="aspectFill" />
          <image class="myPhotoAlbum-Item-occupiedImg" lazy-load src="@/components/post-list/transparent.png" mode="aspectFill"></image>

          <view class="myPhotoAlbum-Item-coverBox flex-5" :style="item.isCanRead ? '' : ' background: rgba(0, 0, 0, 0.5);'">
            <view v-if="item.scorePercentage !== 0 && !item.isCanRead" class="monthIntiScore-tip flex-0">已贡献{{ monthIntiScore >= 10000 ? (monthIntiScore / 10000).toFixed(2) + 'w' : monthIntiScore }}/{{ item.permissionScore }}</view>
            <view v-if="item.scorePercentage === 6 && item.isCanRead && item.permissionScore !== 0" class="monthIntiScore-tip flex-0" style="color: #ff7f75">
              <image lazy-load class="isCanReadImg" :src="item.coverImg" mode="scaleToFill" />
              已解锁
            </view>
            <block v-if="!item.isCanRead">
              <view class="coverBox-center">
                <image class="coverBox-coverImg" :src="item.coverImg" mode="aspectFill" />

                <view class="cover-Btn" @click="$u.throttle(handleSendGift, 500)">
                  {{ item.scorePercentage !== 0 ? '继续解锁' : `${item.permissionScore}解锁` }}
                </view>
              </view>
            </block>
          </view>
          <view class="item-content">
            <view class="item-title ellipsis-single">
              {{ item.albumName }}
            </view>
            <view class="item-bottom flex-0">
              <view class="item-photo-number">{{ item.picCount ? item.picCount : 0 }}张</view>
              <view class="item-authority" v-if="isMyself">
                <text style="margin: 0 5rpx">·</text>
                <text v-if="item.permissionScore > 0">贡献值{{ item.permissionScore }}</text>
                <text v-else>公开</text>
              </view>
            </view>
          </view>
        </view>
      </view>
    </block>
    <!-- 缺省图 -->
    <view class="normalActivity-empty" v-if="albumDTOList.length == 0 && !showLoading">
      <image class="empty-img" src="@/static/images/album_empty.png" alt="" mode="widthFix" />
      <view class="empty-text">还没有创建相册噢~</view>
    </view>
    <!-- 贡献值弹出框 -->
    <u-popup class="intimacyPop" mode="center" :show="intimacyPopShow" @open="openIntimacyPop">
      <view class="intimacyPop-content flex-5">
        <view>
          <view class="content-userAvatar flex-1">
            <view class="userAvatar-left">
              <image class="userImg" :src="userInfoDTO.headUrl" mode="scaleToFill" />
            </view>
            <view class="userAvatar-center">
              <image class="heartImg" src="@/static/images/wd_qinmidu.png" mode="scaleToFill" />
              <view class="heart-text">贡献值</view>
              <view class="heart-number">{{ monthIntiScore >= 10000 ? (monthIntiScore / 10000).toFixed(2) + 'w' : monthIntiScore }}</view>
            </view>
            <view class="userAvatar-right">
              <image class="userImg" :src="selfAvatar" mode="scaleToFill" />
            </view>
          </view>
          <view class="content-intro flex-5">
            你对
            <view class="active-text ellipsis-single" style="max-width: 120rpx">{{ userInfoDTO.nickName }}</view>
            当前贡献值为
            <text class="active-text">{{ monthIntiScore >= 10000 ? (monthIntiScore / 10000).toFixed(2) + 'w' : monthIntiScore }}</text>
          </view>
          <view class="content-tips">
            送礼可提升贡献值，解锁更多特权…
            <br />
            若长时间未送礼，分值也会逐渐流失噢~
          </view>
          <view class="giftBtn" @click="$u.throttle(handleSendGift, 500)">送TA礼物</view>
        </view>
        <view class="closeBtn">
          <image class="closeIcon" src="@/static/images/shanchuicon.png" mode="scaleToFill" />
        </view>
      </view>
    </u-popup>
  </view>
</template>
<script>
// 导入组件
import albumAdd from '@/pagesMy/my/components/album-add.vue'

// 导入接口
import MyInfo from '@/model/my'

// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'

export default {
  components: {
    albumAdd
  },
  props: {
    showLoading: {
      type: Boolean
    },
    // 相册列表
    albumDTOList: {
      type: Array,
      default: []
    },
    // 是否是本人
    isMyself: {
      type: Boolean,
      default: true
    },
    userInfoDTO: {
      type: Object,
      default: {}
    },
    monthIntiScore: {
      type: Number,
      default: 0
    },
    notice: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      intimacyPopShow: false, // 贡献值弹出框
      selfAvatar: JSON.parse(load(USER_INFO)).headUrl
    }
  },
  methods: {
    // 调转到新建相册
    goAddAlbum() {
      uni.navigateTo({ url: '/pagesMy/my/myAlbum/editAlbum' })
    },
    // 立即创建
    handleAdd(params) {
      MyInfo.createAlbum({ ...params })
        .then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '创建成功',
              icon: 'none'
            })
            this.$emit('refreshList')
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.closeAddAlbum()
        })
        .catch(err => {
          this.closeAddAlbum()
        })
    },
    // 相册页面
    gomyAlbum(item) {
      // 没有解锁不能跳转页面
      if (!item.isCanRead) {
        return
      }
      uni.navigateTo({ url: '/pagesMy/my/myAlbum/index?isMyself=' + this.isMyself + '&albumId=' + item.albumId + '&targetNumberId=' + item.numberId })
    },
    // 送礼物
    handleSendGift() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let obj = {
        type: '1',
        openUrl: '/giveGift/searchList/yiqi',
        userId: this.userInfoDTO.numberId,
        enterType: 1
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    // 图片预览
    previewImageItem(index) {
      uni.previewImage({
        urls: this.userInfoDTO.authGoodImg.split('&&'),
        current: index,
        success: function (data) {},
        fail: function (err) {
          console.log(err.errMsg)
        }
      })
    },
    openIntimacyPop() {
      this.intimacyPopShow = true
    },
    /**
     * 点击预览图片
     */
    // 图片预览
    previewImageItem(index) {
      uni.previewImage({
        urls: this.userInfoDTO.authGoodImg.split('&&'),
        current: index,
        success: function (data) {},
        fail: function (err) {
          console.log(err.errMsg)
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.myPhotoAlbum {
  background: #ffffff;
  .auth-good-img {
    background: #ffffff;
    margin-bottom: 52rpx;
    .title {
      font-size: 32rpx;
      color: #2a343e;
      margin-bottom: 24rpx;
    }
    .images-list-box {
      width: 100%;
      overflow-x: auto;
      white-space: nowrap;
      .face-image-item {
        display: inline-block;
        width: 256rpx;
        height: 256rpx;
        background: #f3f3f3;
        border-radius: 20rpx;
        margin-right: 12rpx;
      }
    }
  }
  .add-photoalbum-btn {
    width: 678rpx;
    height: 144rpx;
    border: 2rpx dashed #9fa7b4;
    border-radius: 24rpx;
    text-align: center;
    margin-bottom: 32rpx;
    .add-img {
      width: 40rpx;
      height: 40rpx;
      margin-right: 10rpx;
    }
    .add-text {
      font-size: 28rpx;
      color: #333333;
    }
  }
  .myPhotoAlbum-top {
    min-width: 678rpx;
    height: 82rpx;
    background: #f8fbfd;
    border-radius: 42rpx;
    padding: 18rpx;
    box-sizing: border-box;
    margin-bottom: 34rpx;
    .top-left {
      .top-img {
        width: 76rpx;
        height: 48rpx;
        margin-right: 4rpx;
      }
      .top-text {
        font-size: 24rpx;
        color: #2a343e;
      }
    }
  }
  .myPhotoAlbum-List {
    flex-wrap: wrap;
    .myPhotoAlbum-Item {
      width: 332rpx;
      border-radius: 20rpx;
      position: relative;
      margin-bottom: 32rpx;
      .myPhotoAlbum-Item-bgImg {
        width: 332rpx;
        height: 332rpx;
        border-radius: 20rpx;
      }
      .myPhotoAlbum-Item-occupiedImg {
        width: 332rpx;
        height: 332rpx;
        border-radius: 20rpx;
        position: absolute;
        left: 0;
        z-index: -1;
      }
      .myPhotoAlbum-Item-coverBox {
        border-radius: 20rpx;
        top: 0;
        position: absolute;
        width: 332rpx;
        height: 332rpx;
        .monthIntiScore-tip {
          top: 0;
          left: 0;
          position: absolute;
          height: 40rpx;
          background: rgba(255, 255, 255, 0.5);
          border-radius: 16rpx 0rpx 24rpx 0rpx;
          font-size: 20rpx;
          color: #000000;
          line-height: 40rpx;
          padding: 0 24rpx;
          box-sizing: border-box;
          .isCanReadImg {
            width: 24rpx;
            height: 28rpx;
            margin-right: 6rpx;
          }
        }
        .coverBox-center {
          text-align: center;
          .coverBox-coverImg {
            width: 94rpx;
            height: 118rpx;
            margin-bottom: 24rpx;
          }
          .cover-Btn {
            padding: 8rpx 26rpx;
            border-radius: 32rpx;
            font-size: 28rpx;
            background: linear-gradient(322deg, #fb9191 11%, #ffb474 100%);
          }
        }
      }
      .item-content {
        width: 100%;
        padding: 16rpx 0 0 20rpx;
        box-sizing: border-box;
        border-radius: 0 0 20rpx 20rpx;
        .item-title {
          font-size: 32rpx;
          font-weight: bold;
          margin-bottom: 4rpx;
        }
        .item-bottom {
          color: #c6c6c6;
          font-size: 28rpx;
        }
      }
    }
  }
  .intimacyScoreBtn {
    position: fixed;
    bottom: 300rpx;
    right: 20rpx;

    .intimacyScoreBtn-img {
      width: 100rpx;
      height: 100rpx;
    }
    .intimacyScoreBtn-number {
      width: 100rpx;
      position: absolute;
      top: 26rpx;
      right: 0;
      font-size: 24rpx;
      text-align: center;
      color: #ffffff;
    }
  }
  .createAlbumBtn {
    position: fixed;
    bottom: 160rpx;
    right: 20rpx;
    .createAlbumBtn-img {
      width: 100rpx;
      height: 100rpx;
    }
  }
  .intimacyPop {
    /deep/.u-popup__content {
      background: url('http://img.yiqitogether.com/yqyq-app/images/wd_qmd_k.png');
      background-size: 100% 100%;
    }
    .intimacyPop-content {
      width: 552rpx;
      height: 610rpx;
      padding: 70rpx 68rpx 0;
      box-sizing: border-box;
      .content-userAvatar {
        text-align: center;
        .userAvatar-center {
          position: relative;
          .heart-number {
            position: absolute;
            top: 22rpx;
            width: 100rpx;
            font-size: 24rpx;
            color: #ffffff;
            text-align: center;
          }
        }
        .heartImg {
          width: 100rpx;
          height: 84rpx;
        }
        .heart-text {
          font-size: 22rpx;
          color: #fe5e10;
        }
        .userImg {
          width: 112rpx;
          height: 112rpx;
          border-radius: 50%;
        }
      }
      .content-intro {
        font-size: 24rpx;
        color: #2a343e;
        margin-top: 38rpx;
        .active-text {
          font-size: 24rpx;
          color: #fe5e10;
          margin: 0 6rpx;
        }
      }
      .content-tips {
        font-size: 22rpx;
        color: #bdc1c5;
        margin-top: 62rpx;
      }
      .giftBtn {
        width: 300rpx;
        height: 68rpx;
        background: linear-gradient(270deg, #ffb6ae, #fe5e10);
        border-radius: 36rpx;
        font-size: 28rpx;
        text-align: center;
        color: #ffffff;
        line-height: 68rpx;
        margin: 20rpx auto 0;
      }
      .closeBtn {
        position: absolute;
        bottom: -70rpx;
        .closeIcon {
          width: 50rpx;
          height: 50rpx;
        }
      }
    }
  }
  .normalActivity-empty {
    padding-top: 100rpx;
    height: 50vh;
    margin: auto;
    text-align: center;
    .empty-img {
      width: 218rpx;
      height: 194rpx;
      background-size: cover;
    }
    .empty-text {
      font-size: 24rpx;
      color: #bdc1c5;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
}
</style>
