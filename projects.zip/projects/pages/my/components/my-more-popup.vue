<template>
  <u-popup class="myMorePop" :show="myMorePopShow" mode="right" @close="onClose">
    <scroll-view scroll-y style="height: 100vh">
      <view class="more-box">
        <view class="more-box-item" v-for="(item, i) in optionList" :key="i">
          <view class="more-box-title">
            {{ item.title }}
          </view>
          <view class="more-options-grid">
            <view
              class="more-options flex1"
              v-for="(option, j) in item.option"
              :key="j"
              @click="
                $u.throttle(() => {
                  goPage(option.name)
                }, 500)
              "
            >
              <image class="moreItem-img" :src="option.image" mode=""></image>
              <text class="text-name">{{ option.name }}</text>
              <text class="text-num" v-if="option.name === '积分中心'">
                {{ balanceCount >= 10000 ? (balanceCount / 10000).toFixed(2) + 'w' : balanceCount }}
              </text>
            </view>
          </view>
        </view>
      </view>
    </scroll-view>
  </u-popup>
</template>
<script>
// 导入接口
import MyInfo from '@/model/my.js'

// 导入缓存工具 及 缓存字典
import { load } from '../../../utils/store'
import { LOGIN_USERID, USER_INFO } from '@/utils/cacheKey.js'
import { removeCache } from '@/utils/tools.js'
export default {
  props: {
    myMorePopShow: false, // 弹窗显示
    userLoginFlag: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      optionList: [
        {
          title: '我的账户',
          option: [
            {
              name: '钱包',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option13.png'
            },
            {
              name: '积分中心',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option7.png'
            },
            {
              name: '全部账单',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option6.png'
            },
            {
              name: '二维码',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option3.png'
            },
            {
              name: '活动订单',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option5.png'
            }
          ]
        },
        {
          title: '常用功能',
          option: [
            {
              name: '收藏',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option15.png'
            },
            {
              name: '足迹',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option1.png'
            },
            {
              name: '访客',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option2.png'
            },
            {
              name: '礼物',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option12.png'
            },
            {
              name: '个性化',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option4.png'
            }
          ]
        },
        {
          title: '认证推广',
          option: [
            {
              name: '认证中心',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option14.png'
            },
            {
              name: '推广码',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option3.png'
            },
            {
              name: '我的商家',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option9.png'
            }
          ]
        },
        {
          title: '其他功能',
          option: [
            // {
            // name:'青少年模式',
            // image:'http://img.yiqitogether.com/yqyq-app/images/new-more-option8.png'
            // },
            {
              name: '客服中心',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option11.png'
            },
            {
              name: '设置',
              image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option10.png'
            }
          ]
        }
      ],
      balanceCount: 0, // 积分余额
      traineeInfo: {}, // 实习生数据
      storeStatus: 0
    }
  },
  created() {
    // this.getStoreStatus()
    // this.getBalance()
  },
  methods: {
    // 刷新
    refreshList() {
      this.balanceCount = 0
      this.storeStatus = 0
      // 目前调用的是苏州的，getStoreStatus不用了
      // this.getStoreStatus()
      this.getBalance()
    },
    goPage(type) {
      let self = this

      switch (type) {
        case '钱包':
          uni.navigateTo({ url: '/pagesMy/my/myAccountCenter/index' })
          break
        case '积分中心':
          uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
          break
        case '活动订单':
          uni.navigateTo({ url: '/pagesCommon/details/myActivity?optionDatas=F2' })
          break
        case '全部账单':
          uni.navigateTo({ url: '/pagesMy/my/myBill' })
          break
        case '二维码':
          uni.navigateTo({ url: '/pagesMy/my/myQrCode' })
          break
        case '访客':
          uni.navigateTo({ url: '/pagesMy/my/myHomePages/accessRecord' })
          break
        case '礼物':
          // #ifdef H5
          uni.showToast({
            title: '该操作需要在APP内进行',
            icon: 'none'
          })
          return
          // #endif

          let obj = {
            type: '1',
            openUrl: '/giftList/yiqi'
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
          this.$nextTick(() => {
            uni.navigateTo({
              url: '/pages/my/webView'
            })
          })

          break
        case '收藏':
          uni.navigateTo({ url: '/pagesMy/my/myCollectNew' })
          break
        case '足迹':
          uni.navigateTo({ url: '/pagesMy/my/historicalBrowser' })
          break
        case '我的商家':
          // if (this.storeStatus == 3) {
          //   this.goMerchant()
          // } else if (this.storeStatus == 2) {
          //   uni.navigateTo({
          //     url: '/pagesMy/my/Mybrand'
          //   })
          // } else {
          //   uni.showToast({
          //     title: '商家信息获取中，请稍后再试',
          //     icon: 'none'
          //   })
          // }
          uni.navigateTo({
            url: '/shangchaoMall/index'
          })
          break
        case '推广码':
          let userInfoDTO = JSON.parse(load(USER_INFO)) || {}
          uni.navigateTo({
            url: `/pagesMy/my/myPromotion?name=${userInfoDTO.nickName}&avatar=${userInfoDTO.headUrl}`
          })
          break
        case '认证中心':
          uni.navigateTo({
            url: '/pagesMy/my/myCertification'
          })
          break
        case '个性化':
          uni.navigateTo({
            url: '/pagesCommon/message/messageBubble'
          })
          break
        case '实习生':
          uni.navigateTo({
            url: '/pagesMy/my/trainee?traineeInfo=' + JSON.stringify(this.traineeInfo)
          })
          break
        case '客服中心':
          uni.navigateTo({
            url: '/pagesMy/my/serviceCenter'
          })
          break
        case '设置':
          if (!this.userLoginFlag) {
            uni.showModal({
              title: '提示',
              content: '请登录后使用',
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  self.submitOut()
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          } else {
            uni.navigateTo({
              url: '/pagesSetting/setting/index'
            })
          }
          break
        default:
          break
      }
    },
    // 获取商户入驻状态
    getStoreStatus() {
      MyInfo.getMerchantInfo().then(res => {
        if (res.code == 'SUCCESS') {
          let info = res.data.applyMerchantInfo || {}
          if (res.data.applied && info.merchantState && info.merchantState.label == 'APPLYPASSYES') {
            this.getToken()
          } else {
            this.storeStatus = 2
          }
        } else {
          // this.$refs.uToast.show({
          //   ...res
          // })
        }
      })
    },
    // 获取商户token
    getToken() {
      MyInfo.getMerchantToKen()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.merchantToKen = res.data.merchantToKen || ''
          } else {
            this.errMessage = res.message
          }
          this.storeStatus = 3
        })
        .catch(err => {
          this.storeStatus = 3
        })
    },
    // 跳转商户资金页面
    goMerchant() {
      if (this.merchantToKen) {
        let token = load(LOGIN_TOKEN)
        let obj = {
          type: '2',
          openUrl: '/business',
          token: token || '',
          MerToken: this.merchantToKen
        }
        getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
        this.$nextTick(() => {
          uni.navigateTo({ url: '/pages/my/webView' })
        })
      } else {
        uni.showToast({
          title: this.errMessage || '获取商户信息失败',
          icon: 'none',
          duration: 2000
        })
      }
    },
    // 积分余额
    getBalance() {
      MyInfo.getBalance()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.balanceCount = res.data.balance ? res.data.balance : 0
            this.traineeInfo = { isCandidate: res.data.isCandidate, rankCount: res.data.rankCount, candidateCount: res.data.candidateCount }
            if (this.traineeInfo.isCandidate) {
              let index = this.optionList[3].option.findIndex(item => item.name == '实习生')
              if (index == -1) {
                this.optionList[3].option.splice(0, 0, { name: '实习生', image: 'http://img.yiqitogether.com/yqyq-app/images/new-more-option16.png', isborder: true })
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    // 确定退出登录
    submitOut() {
      let that = this
      removeCache(that)
      setTimeout(() => {
        uni.reLaunch({ url: '/pages/login/index' })
      }, 100)
    },
    onClose() {
      this.$emit('close')
    },
    onOpen() {
      this.$emit('open')
    }
  }
}
</script>
<style lang="scss" scoped>
.myMorePop {
  .more-box {
    width: 496rpx;
    min-height: 100vh;
    padding: 144rpx 20rpx 40rpx;
    background-color: #f6f6f8;
    box-sizing: border-box;
  }
}

.more-box-item {
  width: 456rpx;
  height: auto;
  background: #ffffff;
  border-radius: 20rpx;
  padding: 24rpx 0 10rpx 0;
  box-sizing: border-box;
  font-family: PingFang SC, PingFang SC-Medium;
  font-weight: Medium;
  color: #2a343e;
  margin-bottom: 16rpx;
}

.more-box-title {
  font-size: 28rpx;
  margin-bottom: 12rpx;
  margin-left: 30rpx;
}

.more-options-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}

.more-options {
  position: relative;
  height: 150rpx;
  flex-direction: column;
  justify-content: center;
  font-size: 24rpx;
  .text-name {
    white-space: nowrap;
    margin-top: 6rpx;
  }
  .text-num {
    position: absolute;
    top: 0;
    right: 20rpx;
    font-size: 24rpx;
    color: #f4858a;
  }
}

.moreItem-img {
  width: 60rpx;
  height: 60rpx;
}
</style>
