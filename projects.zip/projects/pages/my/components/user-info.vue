<template>
  <view class="userInfo-page">
    <view class="header">
      <view class="bgImg-box" v-if="isscrollTop">
        <image class="header-bgimg" v-if="isscrollTop" :style="isscrollTop ? 'bottom:-45rpx;' : ''" :src="userInfoDTO.photoUrl ? userInfoDTO.photoUrl.split('&&')[0] : 'http://img.yiqitogether.com/static/images/myImgs/wo_bg.png'" mode="aspectFill" />
        <view class="shadow-cover" v-if="isscrollTop" :style="isscrollTop ? 'bottom:-45rpx;' : ''"></view>
      </view>
      <view class="header-box flex-1">
        <view class="header-left">
          <view class="header-icon-box flex-6">
            <!-- #ifdef APP-PLUS -->
            <!-- 扫描二维码 -->
            <!-- <image v-if="sourcePage === 'tabarMy'" class="sweepImg" @click="$noMultipleClicks(sweep)" src="@/static/images/wd_saoma.png"></image> -->
            <!-- #endif -->

            <image v-if="sourcePage !== 'tabarMy'" class="sweepImg" style="margin-right: 23rpx" src="http://img.yiqitogether.com/static/images/detailsImg/details_back_icon.png" alt="" @click="goBack"></image>
            <view v-if="!isscrollTop" class="id-box flex-0" @click.stop="copy(targetNumberId)">
              <text>
                ID:
                <text style="margin: 0 8rpx">{{ targetNumberId }}</text>
              </text>
              <image class="copy-img" src="@/static/images/fuzhi.png" mode="scaleToFill" />
            </view>
          </view>
        </view>
        <view class="header-icon-box" style="text-align: center; position: absolute; bottom: 0rpx; left: 46%">
          <image class="header-avatar" style="display: block" v-if="isscrollTop" :src="userInfoDTO.headUrl ? userInfoDTO.headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'" mode="aspectFill" />
        </view>
        <view class="header-icon-box flex-6">
          <image class="moreImg" @click="$u.throttle(goSearchPages, 500)" src="http://img.yiqitogether.com/static/images/myImgs/sousuo.png" mode="aspectFill" />
          <image v-if="sourcePage === 'tabarMy'" style="margin-left: 24rpx" class="moreImg" @click="openmyMore" src="@/static/images/erweima.png" mode="aspectFill" />
          <image v-if="!isMyself && sourcePage !== 'tabarMy' && sourcePage != 'fortuitousMeeting'" style="margin-left: 24rpx" @click="openMoreOperations" class="moreImg" src="http://img.yiqitogether.com/static/images/detailsImg/details_more_icon.png" mode="aspectFill" />
        </view>
      </view>
    </view>
    <view class="userBox">
      <view class="bgImg-box" @click="showImageBtn(userInfoDTO.photoUrl)">
        <image class="userBox-bgImg" :src="userInfoDTO.photoUrl ? userInfoDTO.photoUrl.split('&&')[0] : 'http://img.yiqitogether.com/static/images/myImgs/wo_bg.png'" mode="aspectFill" />
        <view class="shadow-cover"></view>
      </view>
      <view class="userContent">
        <view class="userInfo">
          <image class="userImg" :src="userInfoDTO.headUrl ? userInfoDTO.headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'" mode="aspectFill" @click.stop="previewAvatar" />
          <view class="userInfo-right flex-6">
            <view style="width: 160rpx"></view>
            <view class="userInfo-right-tipsitem" @click.stop="toFanList">
              <view class="tips-number">{{ countDTO.fansCount ? formatNumber(countDTO.fansCount) : 0 }}</view>
              <view class="tips-text">粉丝</view>
            </view>
            <view class="userInfo-right-tipsitem" @click.stop="goAttention">
              <view class="tips-number">{{ countDTO.atentionCount ? formatNumber(countDTO.atentionCount) : 0 }}</view>
              <view class="tips-text">关注</view>
            </view>
            <view class="userInfo-right-tipsitem" @click.stop="getZanPop">
              <view class="tips-number">{{ countDTO.zanCount ? formatNumber(countDTO.zanCount) : 0 }}</view>
              <view class="tips-text">获赞</view>
            </view>
            <view v-if="isMyself" class="userInfo-right-btn" @click.stop="$u.throttle(editInfo, 500)">编辑</view>
          </view>
        </view>
        <view class="userIntroBox">
          <view class="userIntroBox-title flex-1">
            <view class="flex-0">
              <view class="userInfo-name ellipsis-single">{{ userInfoDTO.nickName }}</view>
              <view class="userInfo-act" v-if="!isMyself && countDTO.actMsg">
                <text v-if="countDTO.actMsg == '0分钟前'">刚刚活跃</text>
                <text v-else>{{ countDTO.actMsg ? countDTO.actMsg : '刚刚' }}活跃</text>
              </view>
            </view>

            <view class="title-right flex-0" @click="openShowInformation">
              {{ showInformation ? '收起' : '展开' }}
              <image class="title-right-img" :src="showInformation ? require('@/static/images/arrow_up.png') : require('@/static/images/arrow_down.png')" mode="scaleToFill" />
            </view>
          </view>
          <view class="userInfo-oldName ellipsis-single" v-if="userInfoDTO.showNickName !== userInfoDTO.nickName">(昵称：{{ userInfoDTO.showNickName }})</view>

          <view class="userIntroBox-userIntro">
            <span v-if="userInfoDTO.signature">{{ userInfoDTO.signature }}</span>
            <view v-if="!userInfoDTO.signature && isMyself" class="flex-0" @click.stop="$u.throttle(editSignature, 500)">
              快写点什么,让我看看你的独一无二
              <image class="userIntro-img" src="@/static/images/bianji.png" mode="scaleToFill" />
            </view>
          </view>
          <!-- 认证图标 -->
          <view class="authentication-box flex-0">
            <view class="authentication-content">
              <image class="authentication-img" style="width: 50rpx; height: rpx" @click="openAuthenticationTips('authGood')" v-if="userInfoDTO.authGood" src="@/static/images/qzq_hg.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'authGood'" class="authentication-tips-box">
                <view class="tips-box-content">颜值认证</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
            <view class="authentication-content">
              <image class="authentication-img" @click="openAuthenticationTips('authSimple')" v-if="userInfoDTO.authSimple" src="http://img.yiqitogether.com/static/images/myImgs/shimingrenzheng.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'authSimple'" class="authentication-tips-box">
                <view class="tips-box-content">实名认证</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
            <view class="authentication-content">
              <image class="authStudentImg1" @click="openAuthenticationTips('undergraduate')" v-if="userInfoDTO.authStudent_v2 == 'SUCCESS'" src="https://img.yiqitogether.com/yyqc/20231205/upload_nzje6s9t3ed3zgc0321pz0jwgbv7os46.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'undergraduate'" class="authentication-tips-box">
                <view class="tips-box-content">在校大学生</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
            <view class="authentication-content">
              <image class="authentication-img" @click="openAuthenticationTips('authStudent')" v-if="userInfoDTO.authStudent_v2 == 'FINISH_SUCCESS'" src="http://img.yiqitogether.com/static/images/myImgs/xueli.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'authStudent'" class="authentication-tips-box">
                <view class="tips-box-content">学历认证</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
            <view class="authentication-content">
              <image class="authentication-img" style="width: 60rpx; height: 60rpx" @click="openAuthenticationTips('isBlogger')" v-if="userInfoDTO.isBlogger" src="http://img.yiqitogether.com/static/images/myImgs/bozhu.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'isBlogger'" class="authentication-tips-box">
                <view class="tips-box-content">博主认证</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
            <view class="authentication-content">
              <image class="authentication-img" @click="openAuthenticationTips('authComplex')" v-if="userInfoDTO.authComplex" src="http://img.yiqitogether.com/static/images/myImgs/zhanghu.png" alt="" mode="aspectFill"></image>
              <view v-if="authenticationTips == 'authComplex'" class="authentication-tips-box">
                <view class="tips-box-content">账户认证</view>
                <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
              </view>
            </view>
						<view class="authentication-content">
						  <image class="authentication-img" @click="openAuthenticationTips('actors')" v-if="isCertified" src="http://img.yiqitogether.com/static/images/myImgs/yanyuanrenzheng.png" alt="" mode="aspectFill"></image>
						  <view v-if="authenticationTips == 'actors'" class="authentication-tips-box">
						    <view class="tips-box-content">演员认证</view>
						    <image class="tips-box-img" src="http://img.yiqitogether.com/static/images/myImgs/sanjiao.png" mode=""></image>
						  </view>
						</view>
          </view>
          <!-- 企业认证 -->
          <view class="company-box" v-if="companyList && companyList.length > 0">
            <!-- 自己主页 显示 他人主页 未审核通过不显示 -->
            <view class="company-list" v-for="(item, index) in companyList" :key="index">
              <!-- v-if="(targetNumberId !== numberId && item.yyqCmpMemberState.label !== 'PENDING') || targetNumberId == numberId" -->
              <block>
                <view class="company-left" @click="goCompantHome(item.companyId)">
                  <image class="company-img" src="http://img.yiqitogether.com/static/images/myImgs/qiye@2x.png" alt="" mode="aspectFill"></image>
                  <text class="company-name">{{ item.companyName }}</text>
                  <text class="company-info">({{ item.memberCount }}人)</text>
                </view>
                <view class="company-right" @click="handelCompany(item.companyId, item.yyqCmpMemberState ? item.yyqCmpMemberState.label : '', item.createId)">
                  <text>{{ item.yyqCmpMemberState ? (item.yyqCmpMemberState.label == 'PENDING' ? '申请中' : item.yyqCmpMemberState.label == 'SUCCESS' ? '查看成员' : '') : '' }}</text>
                  <!-- targetNumberId numberId -->
                  <view class="unread-message-number" v-if="item.createId == targetNumberId && item.createId == numberId && item.pendingCount !== 0" :style="{ minWidth: item.pendingCount > 9 ? '36rpx' : '' }">{{ item.pendingCount > 99 ? '99+' : item.pendingCount }}</view>
                  <image class="tips-box-img" src="@/static/images/act_arrow_right.png" mode="" v-if="item.yyqCmpMemberState"></image>
                </view>
              </block>
            </view>
          </view>
          <!-- 演员 -->
          <view class="showbiz-box" v-if="isActorCurriculum">
            <view class="showbiz-list" @click="$u.throttle(goShowbizCreateResume, 500)">
              <view class="showbiz-left">
                <image class="showbiz-img" src="http://img.yiqitogether.com/yqyq-app/images/yanyuan.png" alt="" mode="aspectFill"></image>
                <text class="showbiz-info">演员简历</text>
              </view>
              <view class="showbiz-right">
                <text>查看</text>
                <image class="tips-box-img" src="@/static/images/act_arrow_right.png" mode=""></image>
              </view>
            </view>
          </view>
          <!-- 资料内容 -->
          <view class="info-box" v-if="showInformation">
            <view class="info-box-item flex-0" v-if="userInfoDTO.localArea || userInfoDTO.age || userInfoDTO.sex || userInfoDTO.constellationImg">
              <view class="item-title">基本信息:</view>
              <view v-if="userInfoDTO.localArea" class="item-right flex-5">
                <view v-if="userInfoDTO.localArea.includes('&')" class="flex-0">
                  <image class="location" src="http://img.yiqitogether.com/yqyq-app/images/weizhi.png" mode="scaleToFill" />
                  <text class="item-tips ellipsis-single" style="padding: 0 12rpx 0 0">
                    {{ userInfoDTO.localArea.substring(0, userInfoDTO.localArea.indexOf('&&')) }}
                  </text>
                </view>
                <view v-else class="flex-0">
                  <image class="location" src="http://img.yiqitogether.com/yqyq-app/images/weizhi.png" mode="scaleToFill" />

                  <text class="item-tips ellipsis-single" style="padding: 0 12rpx 0 0">
                    {{ userInfoDTO.localArea }}
                  </text>
                </view>
              </view>

              <view v-if="userInfoDTO.age || userInfoDTO.sex" class="item-right flex-5">
                <view class="item-tips flex-0">
                  <image v-if="userInfoDTO.sex == '女'" class="gender" src="http://img.yiqitogether.com/static/images/myImgs/nv.png" mode="scaleToFill" />
                  <image v-if="userInfoDTO.sex == '男'" class="gender" src="http://img.yiqitogether.com/static/images/myImgs/nan.png" mode="scaleToFill" />
                  {{ userInfoDTO.age || 0 }}岁
                </view>
              </view>
              <view v-if="userInfoDTO.constellationImg" class="item-right flex-5">
                <image class="constellation-img" :src="userInfoDTO.constellationImg" mode="scaleToFill" />
                <view class="item-tips">{{ userInfoDTO.constellation }}</view>
              </view>
            </view>
            <view v-if="tagList.length > 0" class="info-box-item flex-0">
              <view class="item-title">个性标签:</view>
              <view class="flex-0" style="flex-shrink: 1; flex-wrap: wrap">
                <u-tag class="info-item-label" v-for="(item, index) in tagList" :key="index" mode="dark" :text="item.name" borderColor="#ffffff" :bgColor="item.color" color="#2A343E" shape="circle" name="1"></u-tag>
              </view>
            </view>
          </view>
          <!-- <view class="userIntroBox-userTips flex-1"> -->
          <!-- <view class="userTips-right flex-0"> -->
          <!-- 本人 -->
          <!-- <block v-if="isMyself">
                <view class="normalBtn" @click.stop="$u.throttle(editInfo, 500)">编辑</view>
              </block> -->
          <!-- 不是本人 fortuitousMeeting 奇遇搭子不展示操作按钮-->
          <!-- <block v-if="!isMyself && sourcePage != 'fortuitousMeeting'">
                <image class="chatImg" @click.stop="toChat" src="@/static/images/wd_sl.png" mode="scaleToFill" />
                <view class="normalBtn" @click.stop="toOpenAttention">{{ countDTO.isAtention ? '已关注' : '关注' }}</view>
              </block> -->
          <!-- </view> -->
          <!-- </view> -->

          <!-- 按钮列表 -->
          <view v-if="sourcePage === 'tabarMy'" class="userIntroBox-card flex-1">
            <view class="card-item" @click.stop="$u.throttle(goMerchantPage, 500)">
              <image src="@/static/images/my-merchant.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">我的商家</view>
            </view>
            <view
              class="card-item"
              @click.stop="
                $u.throttle(() => {
                  toMyActivity('F2')
                }, 500)
              "
            >
              <image src="@/static/images/liebiao1.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">活动订单</view>
            </view>
            <view class="card-item" @click.stop="$u.throttle(goMyAccountCenter, 500)">
              <image src="@/static/images/wallet.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">账户钱包</view>
            </view>
            <view class="card-item" @click.stop="$u.throttle(goIntegralCenter, 500)">
              <image src="@/static/images/integral.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">积分兑换</view>
              <view class="card-item-badge" v-if="balanceCount">{{ balanceCount >= 10000 ? (balanceCount / 10000).toFixed(2) + 'w' : balanceCount }}</view>
            </view>
            <view class="card-item" @click.stop="$u.throttle(goGiftPage, 500)">
              <image src="@/static/images/gift.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">礼物背包</view>
            </view>
            <!-- <view class="card-item" @click.stop="$u.throttle(goAccessRecord, 500)">
              <image src="http://img.yiqitogether.com/static/images/myImgs/fangke.png" mode="scaleToFill" class="card-item-right" />
              <view class="card-item-left">我的访客</view>
              <view class="card-item-badge" v-if="dayNumber">{{ dayNumber ? '+' + formatNumber(dayNumber) : 0 }}</view>
            </view> -->
          </view>
        </view>
      </view>
    </view>

    <view class="nolook-box" v-if="black || beBlack">
      <view class="box-content" v-if="black">
        <image class="content-img1" src="http://img.yiqitogether.com/yqyq-app/images/hmd.png" mode="scaleToFill" />
        <view class="content-tips">
          对方已在黑名单中
          <br />
          移出黑名单可查看
        </view>
        <view
          class="content-btn"
          @click="
            $u.throttle(() => {
              removeInfo(userInfoDTO)
            }, 500)
          "
          style="width: 140rpx"
        >
          移出黑名单
        </view>
      </view>
      <view class="box-content" v-else>
        <image class="content-img2" src="http://img.yiqitogether.com/yqyq-app/images/wsj.png" mode="scaleToFill" />
        <view class="content-tips">对方设置了访问权限无法查看Ta的主页</view>

        <view class="content-btn" style="width: 92rpx" @click="isAddBlack">拉黑TA</view>
      </view>
    </view>

    <block v-else>
      <!-- 列表 -->
      <view class="cardBox">
        <view :class="sourcePage !== 'tabarMy' ? 'cardBox-top flex-0' : 'cardBox-top-active flex-0'">
          <view class="cardBox-top-item" v-for="item in tabList" :key="item.code" @click.stop="changeCheckedTab(item.code)">
            <view :class="checkedTab == item.code ? 'activeText' : 'itemText'">{{ item.name }}</view>
            <image v-if="checkedTab == item.code" class="borderImg" src="@/static/images/huakuai.png" mode="scaleToFill" />
            <view v-else class="borderImg"></view>
          </view>
        </view>
        <swiper :duration="swiperDuration" :class="sourcePage !== 'tabarMy' ? (!isMyself ? 'swiper-active-nomy ' : 'swiper-active') : 'swiper-activeindex'" :current="checkedTab - 2" @change="changeCheckedTabList">
          <!-- 资料 -->
          <!-- <swiper-item>
          <scroll-view :class="sourcePage !== 'tabarMy' ? 'swiper-scroll-active' : 'swiper-scroll-activeindex'" scroll-y>
            <information-card ref="informationCard" :userInfoDTO="userInfoDTO" :tagList="tagList" :impressionList="impressionList"></information-card>
          </scroll-view>
        </swiper-item> -->
          <swiper-item style="background: linear-gradient(180deg, rgba(255, 255, 255, 1), #f0f0f0f0 50%)">
            <scroll-view :class="isMyself ? 'swiper-scroll-active' : 'swiper-scroll-active-nomy'" :scroll-y="isscrollTop" @scrolltolower="loadMore">
              <!-- 活动评价 -->
              <view class="activity-evaluate-box flex-1">
                <view class="evaluate-box-left">
                  <view class="title">活动评分</view>
                  <view class="box-left-score">{{ activityCount }}</view>
                  <view class="box-left-rate">
                    <u-rate count="5" :value="activityCount" inactiveIcon="star-fill" inactiveColor="#f4f5f6" :allowHalf="true" active-color="#F5D865" size="26" readonly></u-rate>
                  </view>
                  <view class="box-left-tips">
                    <text style="margin-right: 16rpx">{{ peopleCount ? formatNumber(peopleCount) : 0 }}</text>
                    用户参与评价
                  </view>
                </view>
                <view class="evaluate-box-right">
                  <view class="title">对我的印象</view>
                  <!-- 记录整体标签labelDTOS 解决下拉刷新标签排版错乱  -->
                  <block v-if="labelDTOS.length > 0">
                    <view class="box-right-aniMove flex-1">
                      <view class="aniMove-item flex-0" v-for="item in firstLabelDTOS" :key="item.text">
                        <image class="item-img" :src="item.url" mode="scaleToFill" />
                        <view class="item-text">{{ item.text }}</view>
                        <view class="item-text" style="margin-left: 10rpx" v-if="item.count">{{ '+' + formatNumber(item.count) || 1 }}</view>
                      </view>
                    </view>
                    <view class="box-right-aniMove flex-1" style="padding-left: 80rpx">
                      <view class="aniMove-item flex-0" v-for="item in lastLabelDTOS" :key="item.text">
                        <image class="item-img" :src="item.url" mode="scaleToFill" />
                        <view class="item-text">{{ item.text }}</view>
                        <view class="item-text" style="margin-left: 10rpx" v-if="item.count">{{ '+' + formatNumber(item.count) || 1 }}</view>
                      </view>
                    </view>
                  </block>
                </view>
              </view>
              <!-- 活动 -->
              <normal-activity-list class="normal-List" :activityList="activityList" :showLoading="showLoading" :loadStatus="activityloadStatus">
                <view class="tips-box" style="padding-top: 24rpx; padding-bottom: 50rpx" @click.stop="$u.throttle(loadMore, 500)">
                  <u-loadmore :status="activityloadStatus" :fontSize="23" nomore-text="到底了~" />
                </view>
              </normal-activity-list>
            </scroll-view>
          </swiper-item>
          <swiper-item>
            <!-- 合集标签 -->
            <view v-if="compilationsList.length > 0" class="scroll" :class="isscrollTop ? (sourcePage !== 'tabarMy' ? 'scroll-active' : 'scroll-activeindex') : ''">
              <scroll-view scroll-x class="" @touchmove.stop>
                <view class="compilations-list flex-0">
                  <view
                    class="list-item flex-0"
                    @click="
                      $u.throttle(() => {
                        clickedCompilations(item)
                      }, 500)
                    "
                    v-for="item in compilationsList"
                    :key="item.groupId"
                  >
                    <image class="imgIcon" src="@/static/images/heji.png" mode="scaleToFill" />
                    <view class="text">{{ item.groupName }}</view>
                  </view>
                </view>
              </scroll-view>
            </view>
            <scroll-view
              :class="!isMyself ? (compilationsList.length > 0 ? 'swiper-scroll-active-compilationsList-noMy' : 'swiper-scroll-activeindex-compilationsList') : compilationsList.length > 0 ? 'swiper-scroll-active-compilationsList' : 'swiper-scroll-active'"
              :scroll-y="isscrollTop"
              @scrolltolower="loadMore"
            >
              <view style="position: relative">
                <!-- 笔记 -->
                <view class="waterfall" v-if="!showLoading">
                  <post-list :showLoading="showLoading" :list="postList.list" sourcePage="my" :status="postList.status" @playVideo="playVideo" @done="done" @refreshList="refreshList">
                    <view class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
                      <u-loadmore :status="postListloadStatus" :fontSize="23" nomore-text="到底了~" />
                    </view>
                  </post-list>
                </view>
              </view>
            </scroll-view>
          </swiper-item>
          <swiper-item>
            <scroll-view :class="isMyself ? 'swiper-scroll-active' : 'swiper-scroll-active-nomy'" :scroll-y="isscrollTop" @scrolltolower="$u.throttle(loadMore, 500)">
              <!-- 置顶动态 -->
              <view class="pinned-box flex1" v-if="dynamicTopList.length !== 0" @click="nextPinned">
                <view class="flex1">
                  <view class="pinned-title">置顶</view>
                  <view class="pinned-box-l">
                    <view class="pinned-item" v-for="(item, i) in dynamicTopList" :key="i">
                      <image class="pinned-photo" v-if="item.twitterInfo.images.length > 0 && !item.twitterInfo.videoUrl" :src="item.twitterInfo.images[0]" mode="aspectFill"></image>
                      <view class="pinned-video" v-if="item.twitterInfo.videoUrl">
                        <image class="pinned-photo" :src="item.twitterInfo.imageUrls" mode="aspectFill"></image>
                        <image class="pinned-pause" src="/static/images/myImgs/fx_gc_sp.png" mode=""></image>
                      </view>
                      <view class="pinned-text" v-if="item.twitterInfo.content && !item.twitterInfo.imageUrls && !item.twitterInfo.videoUrl">
                        <u--text :lines="4" size="24" :text="item.twitterInfo.content"></u--text>
                      </view>
                    </view>
                  </view>
                </view>
                <image class="pinned-l" src="/static/images/myImgs/gengduo.png" mode=""></image>
              </view>
              <!-- 动态 -->
              <find-plaza-list ref="findPlazaList" :showLoading="showLoading" :activtyData="dynamicList" @playVideo="playVideo" :checkTabCode="checkTabCode" @refreshList="refreshList" :pageType="'my'">
                <view class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
                  <u-loadmore :status="dynamicListloadStatus" :fontSize="23" nomore-text="到底了~" />
                </view>
              </find-plaza-list>
            </scroll-view>
          </swiper-item>
          <swiper-item>
            <scroll-view style="background: #ffffff" :class="isMyself ? 'swiper-scroll-active' : 'swiper-scroll-active-nomy'" :scroll-y="isscrollTop">
              <!-- 相册 -->
              <myPhotoAlbum v-if="checkedTab === 5 && !showLoading" :showLoading="showLoading" class="myPhotoAlbum" :albumDTOList="albumList" :monthIntiScore="monthIntiScore" :notice="notice" :userInfoDTO="userInfoDTO" :isMyself="isMyself" @refreshList="refreshList"></myPhotoAlbum>
            </scroll-view>
          </swiper-item>
          <swiper-item>
            <scroll-view :class="isMyself ? 'swiper-scroll-active' : 'swiper-scroll-active-nomy'" scroll-y>
              <wish-card v-if="checkedTab === 6" :wishInfo="wishInfo" :targetNumberId="targetNumberId" :isMyself="isMyself"></wish-card>
            </scroll-view>
            <!-- 心愿 -->
          </swiper-item>
        </swiper>
      </view>

      <!-- 底部按钮 -->
      <!-- 不是本人 fortuitousMeeting 奇遇搭子不展示操作按钮-->
      <view class="bottom-btn" v-if="!isMyself && sourcePage != 'fortuitousMeeting' && userInfoDTO.nickName">
        <view class="flex-3">
          <view class="normal-btn" @click.stop="toOpenAttention" :style="countDTO.isAtention ? 'border: 2rpx solid #c1c6cc;color: #838e9a;background: #ffffff;' : 'background: #1c1c1c'">{{ countDTO.isAtention ? '已关注' : '关注' }}</view>
          <view class="normal-btn" @click.stop="toChat" style="background: linear-gradient(322deg, #fb9191 11%, #ffb474 100%)">私聊</view>
        </view>
      </view>
    </block>
    <!-- 获赞弹框 -->
    <u-popup class="zanPop" mode="center" :show="zanshow" @close="zanclose" @open="zanopen">
      <view class="zanPopcontent">
        <view class="body">
          <view class="text">
            “{{ userInfoDTO.nickName }}”
            <br />
            共获得 {{ countDTO.zanCount }} 个赞
          </view>
          <view class="btn" @click="zanclose">确认</view>
        </view>
      </view>
    </u-popup>
    <!-- 加载 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- 更换背景图操作弹窗 -->
    <custom-more-operate-popup :show="showImageOperate" :list="ImageBtnList" @close="closeImageBtnClick" @click="handleImageBtnClick" />
    <!-- 更多信息弹框 -->
    <view @touchmove.stop.prevent="handleTouchMove">
      <my-more-popup v-if="sourcePage === 'tabarMy'" ref="myMorepopup" class="myMorePopup" :myMorePopShow="myMorePopShow" :userLoginFlag="userLoginFlag" @close="closemyMore" @open="openmyMore"></my-more-popup>
    </view>
    <!-- 拉黑私聊提示框 -->
    <custom-modal type="tipsConfirm" :show="addBlackShow" :round="24" title="提示" content="您已将TA拉黑,无法使用私信功能是否将TA移出黑名单?" themeColor="#FE5E10" cancelText="取消" confirmText="确认" @cancel="handleClose" @confirm="removeBlackList" />

    <!-- 拉黑二次确认提示框 -->
    <custom-modal type="tipsConfirm" :show="addBlackVerifyFlag" :round="24" title="是否拉黑TA？" themeColor="#FE5E10" cancelText="取消" confirmText="确认" @cancel="addBlackVerifyFlag = false" @confirm="handleBlack">
      <view class="tipsconfirm-wrap-content-new">
        <view class="">你们将收不到对方的消息</view>
        <view class="">且互相看不见对方的动态</view>
        <view class="">可前往“我的-设置-黑名单”移出</view>
      </view>
    </custom-modal>
    <!-- 扫描 -->
    <accredit-popup ref="accredit" systemTitle="“一起一起”想访问您的相机" systemContent="用于使用上传照片功能" permisionID="android.permission.CAMERA" cacheId="cameraAccredit" @successAccredit="sweepEvent"></accredit-popup>
    <!-- 取消关注 -->
    <custom-modal type="tipsConfirm" :show="attentionShow" :round="24" title="提示" :content="`是否取消关注 ${userInfoDTO.nickName}?`" themeColor="#FE5E10" cancelText="保持关注" confirmText="取消关注" @cancel="closeAttention" @confirm="toAttention" />
    <!-- 上传主页相册权限弹窗 -->
    <accredit-popup ref="accreditAlbum" systemTitle="“一起一起”想访问您的相册" systemContent="用于使用上传照片功能" permisionID="android.permission.READ_EXTERNAL_STORAGE" cacheId="externalStorage" @successAccredit="handleUploadImg"></accredit-popup>
    <view>
      <u-popup class="moreOperationsPop" :show="moreOperationsShow" @close="closemoreOperations" @open="openMoreOperations" customStyle="height:388rpx;">
        <view class="blockInfo" @click="isAddBlack">拉黑</view>
        <view class="blockInfo" @click="handleReport">举报</view>
        <view class="quxiao" @click="closemoreOperations">取消</view>
      </u-popup>
    </view>
  </view>
</template>
<script>
// 引用瀑布流组件-帖子
import postList from '@/components/post-list/waterfall-list.vue'

// 导入组件
import informationCard from '@/pages/my/components/information-card.vue'
import normalActivityList from '@/pages/index/components/normal-activity-list.vue'
import wishCard from '@/pages/my/components/wish-card.vue'
import findPlazaList from '@/pages/find/commponent/find-plaza-list.vue'
import myPhotoAlbum from '@/pages/my/components/my-photo-album.vue'
import myMorePopup from '@/pages/my/components/my-more-popup.vue'

// 导入接口
import MyInfo from '@/model/my.js'
import findModel from '@/model/find.js'
import IndexModel from '@/model/index.js'

// 导入缓存工具 及 缓存字典
import { USER_INFO, LOGIN_USERID, POSITION } from '@/utils/cacheKey.js'
import { save, load } from '@/utils/store.js'
import { formatNumber, getLocation, judgeImageSize, handleImgWinthAndHeight, uploadFile } from '@/utils/tools.js'
import { TAG2 } from '@/utils/cacheKey.js'

export default {
  components: {
    informationCard,
    normalActivityList,
    wishCard,
    postList,
    findPlazaList,
    myPhotoAlbum,
    myMorePopup
  },
  props: {
    // 选中的tab
    checkedTabProps: {
      type: Number,
      default: 4
    },
    isscrollTop: {
      type: Boolean,
      default: false
    },
    //是否是本人
    isMyself: {
      type: Boolean,
      default: true
    },
    // 来源页面
    sourcePage: {
      type: String,
      default: ''
    },
    // 目标用户的numberId
    targetNumberId: {
      default: ''
    },
    userLoginFlag: {
      type: String
    }
  },
  data() {
    return {
      // 拉黑二次确认弹窗
      addBlackVerifyFlag: false,
      formatNumber,
      numberId: load(LOGIN_USERID) || '', // 用户id
      userInfoDTO: {}, // 用户信息
      isActorCurriculum: false, // 是否创建演员简历且公开（简历信息完整填写且设置公开为true）
      actorUrl: '', // 演员简历跳转链接
			isCertified: false, //演员认证
      countDTO: {}, // 关注等信息
      zanshow: false, // 获赞弹框
      attentionShow: false, // 关注弹框
      black: false, // 拉黑
      beBlack: false, // 被拉黑
      addBlackShow: false, // 拉黑提示
      toPrivateDebounce: false, // 去私聊防抖
      tabList: [
        // { name: '资料', code: 1 },
        { name: '活动', code: 2 },
        { name: '笔记', code: 3 },
        { name: '动态', code: 4 },
        { name: '相册', code: 5 },
        { name: '心愿', code: 6 }
      ],
      checkedTab: this.checkedTabProps, // 选中的tab
      tagList: [], // 标签list
      impressionList: [], // 印象list
      monthIntiScore: 0,
      wishInfo: {}, //心愿信息
      address: uni.getStorageSync('position') || '',
      showLoading: false,
      DraftList: [], // 草稿数据
      twitterType: 'TWITTER',
      checkTabCode: 'SELF',
      tagLabelList: ['GOOD_PHOTO', 'APPOINTMENT', 'TWITTER_FORWARD', 'BIRTHDAY', 'NOTES_FORWARD_TWITTER'], //活动卡片标签
      // 活动列表
      activityList: [],
      activityloadStatus: 'loadmore',
      activitypageNumber: 0,
      activitypages: 0,
      dynamicTopList: [], // 置顶动态列表
      // 动态列表
      dynamicList: [],
      dynamicListloadStatus: 'loadmore',
      dynamicpageNumber: 0,
      dynamicpages: 0,
      dynamiclastKeyWord: '', //查询下一页动态关键词
      // 笔记列表
      postList: {
        status: '',
        reset: 'reset',
        list: []
      },
      postListloadStatus: 'loadmore',
      postListpageNumber: 0,
      postListpages: 0,
      postListlastKeyWord: '', //查询下一页笔记键词
      postListloadDone: false, // 笔记渲染是否完成
      albumList: [], // 相册列表
      myMorePopShow: false, //更多展示弹框
      noClick: true,
      moreOperationsShow: false, // 对他人的更多操作
      showImageOperate: false, // 点击背景操作
      ImageBtnList: ['查看大图', '更换背景'], //  点击背景操作选项
      imgList: [],
      bgImgUrl: [],
      allNumber: 0, //总访客数量
      dayNumber: 0, // 一天的访客数量
      notice: '', // 相册提醒文案
      compilationsList: [], //合集列表
      compilCheckedItem: {}, //选中的合集item
      loadedList: [], // 已加载的tab
      activityCount: 0, // 个人活动评价总分数
      peopleCount: 0, // 个人活动评价人数
      labelDTOS: [], // 对我印象list
      firstLabelDTOS: [], // 对我印象list第一行
      lastLabelDTOS: [], // 对我印象list第二行
      swiperDuration: 0, // 滑动效果
      showInformation: false, // 展示基本信息
      balanceCount: 0, // 积分余额
      constellationList: [
        { name: '水瓶座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/shuiping.png' },
        { name: '白羊座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/baiyang.png' },
        { name: '金牛座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/jinniu.png' },
        { name: '双子座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/shuangzi.png' },
        { name: '巨蟹座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/juxie.png' },
        { name: '处女座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/chunu.png' },
        { name: '天秤座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/tiancheng.png' },
        { name: '天蝎座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/tianxie.png' },
        { name: '射手座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/sheshou.png' },
        { name: '摩羯座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/moxie.png' },
        { name: '狮子座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/shizi.png' },
        { name: '双鱼座', image: 'http://img.yiqitogether.com/static/images/constellationImgs/shuangyu.png' }
      ],
      authenticationTips: '',
      companyList: [] //认证企业列表
    }
  },
  created() {
    this.refreshList()
    this.getPersoanalInfo()
    if (this.isMyself) {
      this.getBalance()
    }
  },
  methods: {
    // 跳转置顶列表
    nextPinned() {
      uni.navigateTo({
        url: `/pagesMy/my/pinnedList?targetNumberId=${this.targetNumberId}`
      })
    },
    handleTouchMove(e) {
      e.stopPropagation()
    },
    closemyMore() {
      this.myMorePopShow = false
    },
    openmyMore() {
      this.$refs.myMorepopup.refreshList()
      this.myMorePopShow = true
    },
    playVideo(type) {
      this.$emit('playVideo', type)
    },
    // 加载更多
    loadMore() {
      if (this.checkedTab === 1) {
        this.getPersoanalInfo()
      } else if (this.checkedTab === 2) {
        if (this.activitypages > this.activitypageNumber) {
          this.getActivityList()
        }
      } else if (this.checkedTab === 3) {
        if (this.postListpages > this.postListpageNumber && this.postListloadDone) {
          this.getFindList(this.postListlastKeyWord)
          this.postListloadDone = false
        }
      } else if (this.checkedTab === 4) {
        if (this.dynamicpages > this.dynamicpageNumber) {
          this.getFindList(this.dynamiclastKeyWord)
        }
      } else if (this.checkedTab === 5) {
        this.getMyPhoto()
      }
    },
    /**
     * 笔记渲染完成
     */
    done() {
      this.postListloadDone = true
    },
    /**
     * 刷新数据使用，本页面或其他页面刷新列表 调用该方法
     */
    refreshList() {
      this.showLoading = true

      // 活动列表
      this.activitypageNumber = 0
      this.activitypages = 0
      this.activityList = []
      this.activityloadStatus = 'loadmore'
      // 活动评价置空
      this.activityCount = 0
      this.peopleCount = 0
      this.labelDTOS = []
      this.firstLabelDTOS = []
      this.lastLabelDTOS = []

      // 动态列表置空
      this.dynamicpageNumber = 0
      this.dynamicpages = 0
      this.dynamicList = []
      // 查询动态关键字
      this.dynamiclastKeyWord = ''
      this.dynamicListloadStatus = 'loadmore'

      // 瀑布流数据置空
      this.postList = { status: 'reset', reset: '', list: [] }
      this.postListpageNumber = 0
      this.postListpages = 0
      this.postListloadStatus = 'loadmore'
      this.postListloadDone = false
      // 查询笔记关键字
      this.postListlastKeyWord = ''
      // 草稿箱数据置空
      this.DraftList = []
      // 笔记合集数据置空
      this.compilationsList = []

      // 相册清空
      this.albumList = []
      this.albumListloadStatus = 'loadmore'

      // 清空加载的tab
      this.loadedList = [this.checkedTab]
      setTimeout(() => {
        this.getList()
      }, 50)
    },
    /**
     * 调用tab列表数据接口
     */
    getList() {
      if (this.checkedTab === 1) {
        this.getPersoanalInfo()
      } else if (this.checkedTab === 2) {
        // console.log('🚀 ~ getList ~ this.checkedTab:', this.checkedTab)
        this.getActivityList()
        this.getUserScore()
      } else if (this.checkedTab === 3) {
        this.twitterType = 'NOTES'
        if (this.isMyself) {
          this.getMyDraftList()
        } else {
          this.getFindList('')
          this.getTaGroup()
        }
      } else if (this.checkedTab === 4) {
        this.twitterType = 'TWITTER'
        this.getFindList('')
        this.getTopTwitter()
      } else if (this.checkedTab === 5) {
        this.getMyPhoto()
      } else if (this.checkedTab === 6) {
        this.getWishList()
      }
    },
    // 获取前三置顶列表
    getTopTwitter() {
      let datas = {
        findType: 'TATOP',
        pageSize: 3,
        targetNumberId: this.targetNumberId,
        position: this.address,
        twitterType: this.twitterType
      }
      findModel.getFindList(datas).then(res => {
        if (res.code == 'SUCCESS') {
          let list = res.data.twitterlist.list || []
          if (res.data.twitterlist && res.data.twitterlist.list) {
            list.forEach(async item => {
              // 图片处理
              let arr = item.twitterInfo.imageUrls ? item.twitterInfo.imageUrls.split('&&') : []
              item.twitterInfo.images = arr

              if (arr.length === 1) {
                item.twitterInfo.itemType = item.twitterInfo.videoUrl ? 'video' : 'image'
              }
            })
          }
          this.dynamicTopList = res.data.twitterlist.list ? res.data.twitterlist.list : []
        } else {
          this.myShowToast(res.message)
        }
      })
    },
    // 获取个人主页信息
    async getPersoanalInfo() {
      let position = load(POSITION) || ''
      // if (this.sourcePage == 'tabarMy') {
      // try {
      //   position = await getLocation()
      // } catch (e) {}
      let data = {
        targetNumberId: this.targetNumberId,
        position: position
      }
      MyInfo.personHomepage(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            // 星座处理
            if (res.data.userInfoDTO.constellation) {
              this.constellationList.forEach(item => {
                if (item.name == res.data.userInfoDTO.constellation) {
                  res.data.userInfoDTO.constellationImg = item.image
                }
              })
            }

            this.companyList = res.data.companyList
            this.userInfoDTO = res.data.userInfoDTO
            this.isActorCurriculum = res.data.isActorCurriculum || false
						this.isCertified = res.data.isCertified || false
            this.actorUrl = res.data.actorUrl || ''
            let signature = res.data.userInfoDTO.signature ? res.data.userInfoDTO.signature.trim() : ''
            this.userInfoDTO.signature = signature
            this.countDTO = { ...res.data.countDTO }
            this.black = res.data.black
            this.beBlack = res.data.beBlack
            this.allNumber = res.data.allNumber
            this.dayNumber = res.data.dayNumber
            this.$forceUpdate()

            // 固定范围随机颜色
            let colorList = [
              'rgba(255,70,109,0.1)',
              'rgba(255,188,23,0.1)',
              'rgba(255,137,76,0.1)',
              'rgba(2,107,19,0.1)',
              'rgba(255,85,121,0.1)',
              'rgba(228,34,34,0.1)',
              'rgba(110,80,255,0.1)',
              'rgba(236,65,219,0.1)',
              'rgba(139,56,215,0.1)',
              'rgba(66,162,240,0.1)',
              'rgba(255,86,112,0.1)',
              'rgba(255,151,25,0.1)',
              'rgba(86,216,44,0.1)',
              'rgba(30,205,187,0.1)',
              'rgba(15,249,194,0.1)'
            ] // 标签处理
            if (res.data.userInfoDTO.labelName) {
              let oldLabelName = res.data.userInfoDTO.labelName.split('&&')
              let tagColorList = load(TAG2)
              this.tagList = []
              let totalTagList = []
              if (tagColorList) {
                //取交集
                let m = tagColorList.filter(item => oldLabelName.includes(item.name))

                let m2 = oldLabelName.map(item => {
                  return {
                    name: item
                  }
                })
                // 两个数组对象取差集
                let arr = [...m2].filter(x => [...tagColorList].every(y => y.name !== x.name))

                let tag3 = [...arr]
                tag3.forEach(item => {
                  if (item.name == '吃货') {
                    item.color = 'rgba(15,249,194,0.1)'
                  } else if (item.name == '小姐姐') {
                    item.color = 'rgba(255,85,121,0.1)'
                  } else if (item.name == '摄影') {
                    item.color = 'rgba(30,205,187,0.1)'
                  } else if (item.name == '旅游') {
                    item.color = 'rgba(86,216,44,0.1)'
                  } else if (item.name == '小哥哥') {
                    item.color = 'rgba(2,107,19,0.1)'
                  } else if (item.name == '露营') {
                    item.color = 'rgba(110,80,255,0.1)'
                  } else if (item.name == '摩托') {
                    item.color = 'rgba(228,34,34,0.1)'
                  } else if (item.name == '逛街') {
                    item.color = 'rgba(236,65,219,0.1)'
                  } else if (item.name == '电影') {
                    item.color = 'rgba(255,151,25,0.1)'
                  } else if (item.name == '喵星人') {
                    item.color = 'rgba(255,137,76,0.1)'
                  } else if (item.name == '游戏') {
                    item.color = 'rgba(139,56,215,0.1)'
                  } else if (item.name == '大叔') {
                    item.color = 'rgba(66,162,240,0.1)'
                  } else if (item.name == '汪星人') {
                    item.color = 'rgba(255,188,23,0.1)'
                  } else if (item.name == '萌宠') {
                    item.color = 'rgba(255,86,112,0.1)'
                  } else {
                    item.color = colorList[Math.floor(Math.random() * colorList.length)]
                  }
                })

                totalTagList = tag3.concat(m)
                this.tagList.push(...totalTagList)
              } else {
                totalTagList = oldLabelName.map(item => {
                  return {
                    name: item,
                    color: colorList[Math.floor(Math.random() * colorList.length)]
                  }
                })
                totalTagList.forEach(item => {
                  if (item.name == '吃货') {
                    item.color = 'rgba(15,249,194,0.1)'
                  } else if (item.name == '小姐姐') {
                    item.color = 'rgba(255,85,121,0.1)'
                  } else if (item.name == '摄影') {
                    item.color = 'rgba(30,205,187,0.1)'
                  } else if (item.name == '旅游') {
                    item.color = 'rgba(86,216,44,0.1)'
                  } else if (item.name == '小哥哥') {
                    item.color = 'rgba(2,107,19,0.1)'
                  } else if (item.name == '露营') {
                    item.color = 'rgba(110,80,255,0.1)'
                  } else if (item.name == '摩托') {
                    item.color = 'rgba(228,34,34,0.1)'
                  } else if (item.name == '逛街') {
                    item.color = 'rgba(236,65,219,0.1)'
                  } else if (item.name == '电影') {
                    item.color = 'rgba(255,151,25,0.1)'
                  } else if (item.name == '喵星人') {
                    item.color = 'rgba(255,137,76,0.1)'
                  } else if (item.name == '游戏') {
                    item.color = 'rgba(139,56,215,0.1)'
                  } else if (item.name == '大叔') {
                    item.color = 'rgba(66,162,240,0.1)'
                  } else if (item.name == '汪星人') {
                    item.color = 'rgba(255,188,23,0.1)'
                  } else if (item.name == '萌宠') {
                    item.color = 'rgba(255,86,112,0.1)'
                  } else {
                    item.color = colorList[Math.floor(Math.random() * colorList.length)]
                  }
                })
                this.tagList.push(...totalTagList)
              }
            }
            // 对TA印象处理
            if (res.data.userInfoDTO.impressionLabel) {
              let arr = res.data.userInfoDTO.impressionLabel.split('&&')
              arr = arr.filter(item => item !== '')
              var newArr = []
              //使用set进行数组去重
              newArr = [...new Set(arr)]
              var newarr2 = new Array(newArr.length)
              for (var t = 0; t < newarr2.length; t++) {
                newarr2[t] = 0
              }
              for (var p = 0; p < newArr.length; p++) {
                for (var j = 0; j < arr.length; j++) {
                  if (newArr[p] == arr[j]) {
                    newarr2[p]++
                  }
                }
              }
              let arr2 = []
              for (var m = 0; m < newArr.length; m++) {
                arr2 = newArr
              }
              let arr3 = []
              for (var m = 0; m < newArr.length; m++) {
                arr3 = newarr2
              }
              let arr4 = []
              arr4 = arr2.map((item, index) => {
                return {
                  name: item,
                  count: arr3[index]
                }
              })
              this.impressionList = []
              this.impressionList.push(...arr4)
              // 对TA的印象展示处理
              // if (this.impressionList.length > 0) {
              //   setTimeout(() => {
              //     this.$refs.informationCard.getimpressionListHeight()
              //   }, 1000)
              // }
            }

            if (this.sourcePage === 'tabarMy') {
              let data = JSON.parse(load(USER_INFO))
              let newData = {
                ...data,
                ...res.data.userInfoDTO
              }
              // 更新缓存当中的用户信息
              save(USER_INFO, JSON.stringify(newData))
            }
            // ip地址 中国显示2级，国外显示1级
            let newIpAddress = res.data.userInfoDTO.localArea ? res.data.userInfoDTO.localArea.split('&&') : ''
            if (newIpAddress[0] == '中国') {
              this.userInfoDTO.localArea = newIpAddress[1]
            } else {
              this.userInfoDTO.localArea = newIpAddress[0]
            }

            this.$forceUpdate()
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 获取活动列表数据
     */
    getActivityList() {
      let data = {
        pageSize: 10,
        pageNo: this.activitypageNumber + 1,
        userId: this.targetNumberId,
        position: this.address.position
      }
      MyInfo.userIndex({ ...data })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.activityList.push(...res.data.page.list)
            this.activitypages = res.data.page.pages
            this.activitypageNumber = res.data.page.pageNumber
            if (res.data.page.total == 0) {
              this.activityloadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.activityloadStatus = 'nomore'
              } else {
                this.activityloadStatus = 'loadmore'
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
          this.activityloadStatus = 'none'
        })
    },
    // 获取心愿列表
    getWishList() {
      let data = {
        taNumberId: this.targetNumberId
      }
      MyInfo.wishList(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.wishInfo = res.data.wishList
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 获取草稿
    getMyDraftList() {
      let params = {
        pageSize: 10,
        pageNumber: 1,
        twitterType: 'NOTES',
        lastKeyWord: ''
      }
      findModel.myDraftList({ ...params }).then(res => {
        if (res.code == 'SUCCESS') {
          this.DraftList = res.data.pager
          this.getFindList('')
          this.getMyGroup()
        } else {
        }
      })
    },
    // 获取动态和笔记
    getFindList(lastKeyWord2) {
      let that = this
      if (!this.isMyself) {
        this.checkTabCode = 'TARGET'
      } else {
        this.checkTabCode = 'SELF'
      }
      let datas = {
        findType: this.checkTabCode, //	String	是	ATENTION(“关注”)NEAR(“附近”)PUSH(“推荐”)SELF(“自己主页”)TARGET(“他人主页”)
        pageSize: 10, //	String	否	每页请求数据
        // pageNo:this.pageNumber,
        lastKeyWord: lastKeyWord2 || '', //	String	否	分页查询关键词（第一页可不传，其他页必传）
        targetNumberId: this.targetNumberId, //	String	否	目标用户ID。如果是看他人主页，必传
        position: this.address, //   31.233815  ，121.390467 {"lat":28.228209,"lon":112.938814}
        twitterType: this.twitterType
      }
      this.postList.status = 'loading'
      findModel
        .getFindList(datas)
        .then(res => {
          /**
           * 将showLoading放上面是因为瀑布流的渲染时
           * 根据postList.status的值发生改变且值为SUCCESS才会渲染
           */
          this.showLoading = false
          if (res.code == 'SUCCESS') {
            let list = res.data.twitterlist.list || []

            if (res.data.twitterlist && res.data.twitterlist.list) {
              list.forEach(async item => {
                let arr
                // 动态数据处理
                if (this.checkedTab === 4) {
                  // 活动卡片展示处理
                  if (item.twitterInfo.quoteInfoDTO) {
                    item.isContent = item.twitterInfo.quoteInfoDTO.officialTarget ? true : false
                    item.isShow = item.twitterInfo.quoteInfoDTO.officialTarget ? this.tagLabelList.indexOf(item.twitterInfo.quoteInfoDTO.officialTarget[0].label) : -1
                    try {
                      JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                      item.twitterInfo.quoteInfoDTO.quoteContent = JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                    } catch (error) {
                      item.twitterInfo.quoteInfoDTO.quoteContent = item.twitterInfo.quoteInfoDTO.quoteContent
                    }
                    this.$forceUpdate()
                  } else {
                    item.isContent = false
                    item.isShow = -1
                  }

                  // 图片处理
                  arr = item.twitterInfo.imageUrls ? item.twitterInfo.imageUrls.split('&&') : []
                  item.twitterInfo.images = arr

                  if (arr.length === 1) {
                    // let imgObj = await judgeImageSize(arr[0])
                    let imgObj = await handleImgWinthAndHeight(item.twitterInfo.imgSize, arr[0])
                    item.twitterInfo.images = [imgObj]
                    // console.log(imgObj)
                    item.twitterInfo.itemType = item.twitterInfo.videoUrl ? 'video' : 'image'
                  }

                  // 礼物
                  item.userinfo.isGift = item.userinfo.tags ? item.userinfo.tags.split(',').includes('TAG_GIFTVIP') : false
                }
                // 更多操作（是否是自己）
                item.showMoreOperate = false
                let numberId = item.userinfo.numberId || ''

                let selfNumberId = load(LOGIN_USERID) || ''
                if (numberId == selfNumberId) {
                  item.moreBtnList = ['删除动态']
                  item.isSelf = true
                } else {
                  // item.moreBtnList = ['不看TA动态', '举报']
                  item.moreBtnList = ['举报']
                  item.isSelf = false
                }

                //标签数据处理和长度处理最多显示五条
                if (item.twitterInfo.markTopic && item.twitterInfo.markTopic != null && item.twitterInfo.markTopic != '') {
                  let markList = item.twitterInfo.markTopic.split('#').filter(v => v && v.trim())
                  if (markList.length > 5) {
                    item.twitterInfo.markTopics = markList.slice(0, 5)
                  } else {
                    item.twitterInfo.markTopics = markList
                  }
                } else {
                  item.twitterInfo.markTopics = []
                }
              })

              if (this.checkedTab === 4) {
                list = list.filter(item => {
                  if (item.isShow != -1) {
                    return item.isContent == true
                  } else {
                    // item.isShow != -1 (不是特殊卡片类型动态或label里没有)
                    // item.isContent == false 普通动态
                    return item.isContent == false
                  }
                })
                // 从新获取的数据开始计算，老数据不重复计算(展开、收起)
                let oldindex = this.dynamicList.length == 0 ? 0 : this.dynamicList.length
                setTimeout(() => {
                  list.forEach((item, index) => {
                    this.$refs.findPlazaList.isOverflow(item, index + oldindex)
                  })
                }, 300)
                this.dynamicList.push(...list)
              } else {
                // 如果后台当前页返回数据为空，页面会变成白屏
                if (this.postListlastKeyWord == '') {
                  if ((this.DraftList.list ? this.DraftList.list.length : 0) >= 1) {
                    this.postList.list = [{ id: 0, total: this.DraftList.total, url: this.DraftList.list[0].imageUrls }, ...list]
                  } else {
                    this.postList.list = [...list]
                  }
                } else {
                  if (list.length > 0) {
                    this.postList.list = [...list]
                  }
                }
                // 个别手机不能使用nextTick，无法及时更新status,并调用启动渲染方法
                setTimeout(() => {
                  this.postList.status = 'success'
                  this.$forceUpdate()
                }, 50)
              }
            }
            // 处理动态如果当前页没有数据，但有下一页
            if (res.data.twitterlist.list.length == 0 && res.data.twitterlist.hasNextPage) {
              this.loadMore()
            }
            if (this.checkedTab === 4) {
              this.dynamicpages = res.data.twitterlist.pages
              this.dynamicpageNumber = res.data.twitterlist.pageNumber
              this.dynamiclastKeyWord = res.data.twitterlist.lastKeyWord
              if (res.data.twitterlist.total == 0) {
                this.dynamicListloadStatus = 'none'
              } else {
                if (res.data.twitterlist.pages <= res.data.twitterlist.pageNumber) {
                  this.dynamicListloadStatus = 'nomore'
                } else {
                  this.dynamicListloadStatus = 'loadmore'
                }
              }
            } else {
              this.postListlastKeyWord = res.data.twitterlist.lastKeyWord
              this.postListpageNumber = res.data.twitterlist.pageNumber
              this.postListpages = res.data.twitterlist.pages

              if (res.data.twitterlist.total == 0) {
                this.postListloadStatus = 'none'
              } else {
                if (res.data.twitterlist.pages <= res.data.twitterlist.pageNumber) {
                  this.postListloadStatus = 'nomore'
                } else {
                  this.postListloadStatus = 'loadmore'
                }
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 3000
            })
          }
        })
        .catch(err => {
          that.showLoading = false
        })
    },
    // 获取相册列表
    getMyPhoto() {
      let params = {
        targetNumberId: this.targetNumberId
      }
      MyInfo.albumListNoPage({ ...params })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.monthIntiScore = res.data.monthIntiScore ? res.data.monthIntiScore : 0
            this.notice = res.data.notice
            let list = []
            let scorePercentage
            let percentage = 0
            let coverImg = ''
            res.data.albumDTOList.map(item => {
              percentage = Math.round((this.monthIntiScore / item.permissionScore) * 100) ? Math.round((this.monthIntiScore / item.permissionScore) * 100) : 0
              if (0 < percentage && percentage <= 20) {
                scorePercentage = 1
                coverImg = require('@/static/images/suozi1.png')
              } else if (20 < percentage && percentage <= 40) {
                scorePercentage = 2
                coverImg = require('@/static/images/suozi2.png')
              } else if (40 < percentage && percentage <= 60) {
                scorePercentage = 3
                coverImg = require('@/static/images/suozi3.png')
              } else if (60 < percentage && percentage <= 80) {
                scorePercentage = 4
                coverImg = require('@/static/images/suozi4.png')
              } else if (80 < percentage && percentage < 100) {
                scorePercentage = 5
                coverImg = require('@/static/images/suozi5.png')
              } else if (percentage && percentage >= 100) {
                scorePercentage = 6
                coverImg = require('@/static/images/suozi6.png')
              } else {
                scorePercentage = 0
                coverImg = require('@/static/images/suozi0.png')
              }

              item.coverImg = coverImg
              item.scorePercentage = scorePercentage
              list.push(item)
            })
            setTimeout(() => {
              // 解决新创建有贡献值的相册刷新样式紊乱
              this.albumList = [...list]
              this.$forceUpdate()
            }, 100)
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          if (res.data.total == 0) {
            this.albumListloadStatus = 'none'
          } else {
            if (res.data.pages <= res.data.pageNumber) {
              this.albumListloadStatus = 'nomore'
            } else {
              this.albumListloadStatus = 'loadmore'
            }
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 获取自己的合集列表
     */
    getMyGroup() {
      MyInfo.getMyGroup()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.compilationsList = res.data.list || []
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 获取他人的合集列表
     */
    getTaGroup() {
      let params = {
        taNumberId: this.targetNumberId
      }
      MyInfo.getTaGroup(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.compilationsList = res.data.list || []
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 选择合集跳转到合集笔记列表
     */
    clickedCompilations(item) {
      let self = this
      this.compilCheckedItem = item
      uni.navigateTo({
        url: '/pagesMy/my/compilations/index?compilationsInfo=' + JSON.stringify(this.compilCheckedItem) + '&targetNumberId=' + this.targetNumberId + '&isMyself=' + this.isMyself,
        events: {
          /**
           * 编辑合集调用刷新草稿箱、笔记、合集列表
           */
          refreshList: function (data) {
            self.refreshList()
          }
        }
      })
    },
    /**
     * 扫一扫
     */
    sweep() {
      this.$refs.accredit.triggerEvent()
      this.noClick = false
    },
    sweepEvent() {
      // 允许从相机和相册扫码
      this.noClick = true
      uni.scanCode({
        success: function (res) {
          let strPosition = res.result.indexOf('/pagesCommon/details/details')
          let info = res.result.indexOf('"type":"joinGroup"')

          if (info > -1) {
            let a = JSON.parse(res.result)
            uni.navigateTo({
              url: '/pagesMessage/privateChat/groupConfirm?groupNo=' + a.groupNo
            })
          } else if (strPosition > -1) {
            let path = res.result.substring(strPosition)
            uni.navigateTo({
              url: path
            })
          } else {
            uni.showToast({
              title: '暂不支持该类型的二维码',
              icon: 'none'
            })
          }
        }
      })
    },

    // 前往粉丝页
    toFanList() {
      if (!this.isMyself) {
        return
      }
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/fanList'
      })
    },
    // 前往关注页
    goAttention() {
      if (!this.isMyself) {
        return
      }
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/attention'
      })
    },
    // 获赞弹框
    getZanPop() {
      this.zanopen()
    },
    zanopen() {
      this.zanshow = true
    },
    zanclose() {
      this.zanshow = false
    },
    // 访客页面
    goAccessRecord() {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/accessRecord'
      })
    },
    // 编辑资料
    editInfo() {
      uni.navigateTo({
        url: '/pagesMy/my/editPersonalInfo?sourcePage=' + this.sourcePage
      })
    },
    /**
     * 编辑个性签名
     */
    editSignature() {
      uni.navigateTo({
        url: '/pagesMy/my/personalSignature?sourcePage=userInfo'
      })
    },
    // 打开关注弹框
    toOpenAttention() {
      if (this.countDTO.isAtention) {
        this.attentionShow = true
      } else {
        this.toAttention()
      }
    },
    // 关闭关注弹框
    closeAttention() {
      this.attentionShow = false
    },
    // 去关注
    toAttention() {
      let pamise = {
        targetNumberId: this.targetNumberId
      }
      if (this.countDTO.isAtention) {
        MyInfo.cancelAttention(pamise)
          .then(res => {
            if (res.code == 'SUCCESS') {
              this.countDTO.isAtention = !this.countDTO.isAtention
              uni.showToast({
                title: '取消关注',
                icon: 'none'
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
          .catch(err => {})
      } else {
        MyInfo.attention(pamise)
          .then(res => {
            if (res.code == 'SUCCESS') {
              this.countDTO.isAtention = !this.countDTO.isAtention
              uni.showToast({
                title: '关注成功',
                icon: 'none'
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
          .catch(err => {})
      }
      this.attentionShow = false
    },
    // 去私聊
    async toChat() {
      // #ifdef H5
      uni.showToast({
        title: '当前环境不支持私信功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let that = this
      if (this.toPrivateDebounce) {
        return
      }
      this.toPrivateDebounce = true
      // #ifdef APP
      // 进私聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(1, that.targetNumberId, null, timeFiff)
      // #endif
      uni.navigateTo({
        url: '/pagesMessage/privateChat/index' + '?userId=' + that.targetNumberId + '&otherAvatar=' + that.userInfoDTO.headUrl + '&otherNickName=' + that.userInfoDTO.nickName
      })
      setTimeout(() => {
        that.toPrivateDebounce = false
      }, 1000)
    },
    // 打开对他人更多操作弹框
    openMoreOperations() {
      this.moreOperationsShow = true
    },
    // 关闭对他人更多操作弹框
    closemoreOperations() {
      this.moreOperationsShow = false
    },
    // 展示更多操作弹框
    showImageBtn(url) {
      // 是本人并且是tabar页面
      if (this.isMyself && this.sourcePage === 'tabarMy') {
        this.showImageOperate = true
        this.bgImgUrl[0] = url ? url.split('&&')[0] : 'http://img.yiqitogether.com/static/images/myImgs/wo_bg.png'
      }
    },
    // 头像预览
    previewAvatar() {
      let urls = [this.userInfoDTO.headUrl ? this.userInfoDTO.headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png']
      urls = urls.map(item => item.replace('!yqyq0606', ''))
      // 2024/07/09 增加，其他人为预览头像
      uni.previewImage({
        current: 0,
        urls
      })
    },
    // 取消更多操作
    closeImageBtnClick() {
      this.showImageOperate = false
    },
    // 更多操作的具体按钮
    handleImageBtnClick(index, item) {
      let that = this
      // 查看大图
      if (item == '查看大图') {
        uni.previewImage({
          urls: that.bgImgUrl
        })
      } else if (item == '更换背景') {
        this.judgeAlbumAuth()
      }
      this.showImageOperate = false
    },
    // 判断相册权限
    judgeAlbumAuth() {
      this.$refs.accreditAlbum.triggerEvent()
    },
    // 上传图片
    handleUploadImg() {
      let self = this
      this.imgList = []
      uni.chooseImage({
        count: 1, // 默认9 现改成1
        sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album'], // 从相册选择
        success: async res => {
          let list = res.tempFilePaths || []
          let arr = list.filter(item => item.toLowerCase().includes('heic'))
          if (arr.length > 0) {
            uni.showToast({
              title: '暂不支持上传HEIC格式的文件',
              icon: 'none',
              duration: 2000
            })
          }
          list = list.filter(item => !item.toLowerCase().includes('heic'))
          for (let i = 0; i < list.length; i++) {
            let imgUrl = await uploadFile(list[i])
            self.imgList.push({ url: imgUrl })
          }
          this.addPhotoAlbum(self.imgList[0].url)
        }
      })
    },
    // 修改相册接口
    addPhotoAlbum(urlList, type) {
      this.showLoading = true
      let albumData = {
        imgUrl: urlList
      }
      MyInfo.addPhotoAlbum(albumData)
        .then(res => {
          if (res.code == 'SUCCESS') {
            // this.refreshList()
            // 将背景图修改为上传的图片
            this.userInfoDTO.photoUrl = urlList
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 拉黑二次弹窗确认
    isAddBlack() {
      this.addBlackVerifyFlag = true
      this.moreOperationsShow = false
    },
    // 拉黑
    handleBlack() {
      if (this.black) {
        uni.showToast({
          title: '已加入黑名单，不可重复添加',
          icon: 'none'
        })
      } else {
        this.addUserBlack()
      }
      this.addBlackVerifyFlag = false
    },

    // 加入黑名单
    addUserBlack() {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let that = this
      let number = uni.getStorageSync('numberId')
      let data = {
        userId: number,
        //被举报人id
        blackUserId: that.targetNumberId
      }
      MyInfo.addUserBlack(data).then(async res => {
        if (res.code == 'SUCCESS') {
          this.black = true
          let result = await this.$store.state.engie.addToBlacklist(that.targetNumberId)
          uni.showToast({
            title: '成功加入黑名单',
            icon: 'none'
          })
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      setTimeout(() => {
        this.getPersoanalInfo()
      }, 1000)
    },
    // 举报
    handleReport() {
      uni.navigateTo({
        url: '/pagesCommon/message/report?userId=' + this.targetNumberId + '&reportTargetType=PERSON' + '&targetId=' + this.targetNumberId
      })
      this.moreOperationsShow = false
    },
    // 取消私聊拉黑弹框
    handleClose() {
      this.addBlackShow = false
    },
    // 移除黑名单
    removeBlackList() {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let that = this
      let data = {
        blackUserId: this.targetNumberId
      }
      MyInfo.removeUserBlack(data).then(async res => {
        if (res.code == 'SUCCESS') {
          let result = await this.$store.state.engie.removeFromBlacklist(that.targetNumberId)
          uni.showToast({
            title: '已移出黑名单',
            icon: 'none'
          })
          this.getPersoanalInfo()
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      this.addBlackShow = false
    },

    // 去积分中心
    goIntegralCenter() {
      uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
    },
    // 我的活动
    toMyActivity(optionDatas) {
      // 待付订单 F1 \ 活动列表 F2 \ 活动评价 F3
      uni.navigateTo({
        url: '/pagesCommon/details/myActivity?optionDatas=' + optionDatas
      })
    },
    // 退款/取消列表
    toRefundpages(optionDatas) {
      // F1
      uni.navigateTo({
        url: '/pagesCommon/details/acticityRefund?optionDatas=' + optionDatas
      })
    },
    // 去往搜索页面
    goSearchPages() {
      // sourcePage=self 不显示用户列表，只搜索本人相关信息
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/indexSearch?sourcePage=self&targetNumberId=' + this.targetNumberId
      })
    },
    /**
     * 切换tab --改变swiper的current
     * 调用changeCheckedTabList
     */
    changeCheckedTab(tab) {
      this.checkedTab = tab
      this.swiperDuration = 0
    },
    /**
     * swiper滑动切换tab列表
     */
    changeCheckedTabList(e) {
      /**
       * 使下次滑动时有动画效果
       */
      this.swiperDuration = 500
      this.checkedTab = e.detail.current + 2
      if (this.checkedTab == 3) {
        this.twitterType = 'NOTES'
      } else if (this.checkedTab == 4) {
        this.twitterType = 'TWITTER'
      }
      if (this.loadedList.includes(e.detail.current + 2)) {
        return
      }
      this.loadedList.push(e.detail.current + 2)
      this.getList()
    },
    // 钱包
    goMyAccountCenter() {
      uni.navigateTo({ url: '/pagesMy/my/myAccountCenter/index' })
    },
    /**
     * 礼物背包
     */
    goGiftPage() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif

      let obj = {
        type: '1',
        openUrl: '/giftList/yiqi'
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    /**
     * 商家入驻
     */
    goMerchantPage() {
      uni.navigateTo({
        url: '/shangchaoMall/index'
      })
    },
    /**
     * 复制
     */
    copy(data) {
      uni.setClipboardData({
        data: data,
        success: function () {
          uni.showToast({
            title: '用户ID已复制',
            icon: 'none',
            success: function (res) {
              console.log('已复制', res)
            }
          })
        }
      })
    },
    /**
     * 获取我的活动评价
     */
    getUserScore() {
      let data = {
        targetNumberId: this.targetNumberId
      }
      IndexModel.getUserScore(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.activityCount = res.data.score
            this.peopleCount = res.data.peopleCount
            let labelDTOS = res.data.labelDTOS || []
            if (labelDTOS.length > 0) {
              this.labelDTOS = labelDTOS
              let length = Math.floor(labelDTOS.length / 2)
              this.firstLabelDTOS = labelDTOS.slice(0, length)
              this.lastLabelDTOS = labelDTOS.slice(length, labelDTOS.length)
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    /**
     * 展开个人基本信息
     */
    openShowInformation() {
      this.showInformation = !this.showInformation
    },
    // 积分余额
    getBalance() {
      MyInfo.getBalance()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.balanceCount = res.data.balance ? res.data.balance : 0
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    /**
     * 展示认证图标说明
     */
    openAuthenticationTips(name) {
      this.authenticationTips = name
      // 1秒后消失
      setTimeout(() => {
        this.authenticationTips = ''
      }, 1000)
    },
    goBack() {
      uni.navigateBack()
    },
    // 查看企业信息
    goCompantHome(companyId) {
      uni.navigateTo({
        url: `/pagesRecruit/recruit/companyHomePage?companyId=${companyId}`
      })
    },
    // 点击企业跳转
    handelCompany(companyId, yyqCmpMemberState, createId) {
      switch (yyqCmpMemberState) {
        case 'PENDING':
          uni.showToast({
            title: '你已申请加入该企业, 请耐心等待审批~',
            icon: 'none'
          })
          break
        case 'SUCCESS':
          uni.navigateTo({
            url: `/pagesMy/enterpriseMemberManagement/enterpriseMemberManagement?companyId=${companyId}&createId=${createId}`
          })
          break
        default:
          uni.navigateTo({
            url: `/pagesRecruit/recruit/companyHomePage?companyId=${companyId}`
          })
          break
      }
    },
    /**
     * 移出黑名单
     */
    removeInfo(item) {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      // console.log(typeof item.numberId ==='number',"7788");  // 结果为true, item.numberId类型为Number类型
      let data = {
        blackUserId: item.numberId
      }
      console.log('🚀 ~ removeInfo ~ data:', data)
      MyInfo.removeUserBlack(data).then(async res => {
        if (res.code == 'SUCCESS') {
          // #ifdef APP-PLUS
          let result = await this.$store.state.engie.removeFromBlacklist(String(item.numberId))
          // #endif
          uni.showToast({
            title: '已移出黑名单',
            icon: 'none'
          })
          this.black = false
          // setTimeout(() => {
          //   this.getUserBlackList()
          // }, 800)
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    myShowToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    },
    /**
     * 前往演员简历
     */
    goShowbizCreateResume() {
      uni.navigateTo({ url: `${this.actorUrl}&sharePage=h5` })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.flex-7 {
  display: flex;
  align-items: start;
}
.userInfo-page {
  position: relative;
  .header {
    width: 100%;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    z-index: 3;
    .header-box {
      padding: calc(var(--status-bar-height) + 22rpx) 30rpx 0 30rpx;
      position: relative;
      .header-icon-box {
        // width: 128rpx;
      }
      .header-left {
        // height: 44rpx;
        .id-box {
          background: rgba(255, 255, 255, 0.5);
          border-radius: 24rpx;
          padding: 4rpx 20rpx;
          font-size: 28rpx;
          color: #1c1c1c;
        }
        .copy-img {
          width: 32rpx;
          height: 32rpx;
          // margin-left: 8rpx;
        }
        .sweepImg {
          width: 56rpx;
          height: 56rpx;
        }
      }
      .header-avatar {
        width: 56rpx;
        height: 56rpx;
        border-radius: 50%;
      }

      .searchImg {
        width: 44rpx;
        height: 44rpx;
        padding: 0 20rpx;
      }
      .moreImg {
        width: 56rpx;
        height: 56rpx;
      }
    }
    .bgImg-box {
      position: absolute;
      bottom: 0;
      width: 100%;
      height: 520rpx;
      .header-bgimg {
        width: 100%;
        height: 100%;
      }
      .shadow-cover {
        width: 100%;
        height: 100%;
        position: absolute;
        bottom: 0;
        background: #000000;
        opacity: 0.5;
      }
    }
  }
  .userBox {
    width: 750rpx;
    padding-top: calc(var(--status-bar-height) + 392rpx);
    box-sizing: border-box;
    position: relative;
    .bgImg-box {
      width: 100%;
      height: 620rpx;
      position: absolute;
      top: 0;
      .userBox-bgImg {
        width: 100%;
        height: 100%;
      }
      .shadow-cover {
        width: 100%;
        height: 100%;
        position: absolute;
        bottom: 0;
        background: #000000;
        opacity: 0.5;
      }
    }

    .userBox-bgImg::before {
      filter: blur(5rpx) brightness(0.5);
      transform: scale(1.2);
    }
    .userContent {
      position: relative;
      z-index: 1;
      padding: 0 30rpx 30rpx;
      background: #ffffff;
      border-radius: 40rpx 40rpx 0 0;
      .userInfo {
        position: relative;
        padding: 16rpx 0 5rpx 0;
        .userImg {
          width: 192rpx;
          height: 192rpx;
          border-radius: 50%;
          position: absolute;
          top: -92rpx;
        }
        .userInfo-right {
          .userInfo-right-tipsitem {
            padding: 0 24rpx;
            text-align: center;
            flex: 1;
            .tips-number {
              color: #2a343e;
            }
            .tips-text {
              font-size: 24rpx;
              color: #adb3ba;
            }
          }
          .userInfo-right-btn {
            width: 142rpx;
            height: 76rpx;
            background: #131313;
            border-radius: 38rpx;
            font-size: 28rpx;
            text-align: center;
            color: #ffffff;
            line-height: 76rpx;
          }
        }
      }
      .userIntroBox {
        padding: 32rpx 0 30rpx;
        .userIntroBox-title {
          .userInfo-name {
            font-size: 40rpx;
            color: #2a343e;
          }
          .userInfo-act {
            font-size: 24rpx;
            color: #ff9942;
            margin-left: 16rpx;
          }
          .title-right {
            font-size: 24rpx;
            color: #c8c8c8;
            .title-right-img {
              margin-left: 7rpx;
              width: 18rpx;
              height: 18rpx;
            }
          }
        }
        .userInfo-oldName {
          font-size: 24rpx;
          color: #9fa7b4;
          margin-top: 6rpx;
        }
        .userIntroBox-userIntro {
          margin-top: 8rpx;
          font-size: 24rpx;
          white-space: pre-wrap; /* 保留空白符并自动换行 */
          overflow-wrap: break-word; /* 在长单词或URL地址内部进行换行 */
          word-break: break-all;
          color: #9fa7b4;
          padding-right: 20rpx;
          .userIntro-img {
            width: 28rpx;
            height: 28rpx;
            margin-left: 10rpx;
          }
        }
        .authentication-box {
          margin-top: 24rpx;
          position: relative;
          .authentication-content {
            flex-shrink: 1;
          }
          .authentication-img {
            width: 56rpx;
            height: 56rpx;
            margin-right: 20rpx;
          }
          .authentication-tips-box {
            position: absolute;
            top: -40rpx;
            .tips-box-content {
              padding: 4rpx 18rpx 8rpx;
              background: #ffffff;
              box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(217, 221, 223, 0.5);
              font-size: 24rpx;
              text-align: center;
              color: #4e4e4e;
              border-radius: 14rpx;
            }
            .tips-box-img {
              width: 30rpx;
              height: 14rpx;
              display: block;
              margin-left: 15rpx;
            }
          }

          .authStudentImg1 {
            width: 50rpx;
            height: 34rpx;
            margin-right: 20rpx;
          }
        }
        .company-box {
          .company-list {
            margin-top: 20rpx;
            display: flex;
            align-items: center;
            justify-content: space-between;
            .company-left {
              display: flex;
              align-items: center;
              .company-img {
                width: 56rpx;
                height: 56rpx;
              }
              .company-name {
                max-width: 400rpx;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
                font-size: 24rpx;
                color: #779be8;
              }
              .company-info {
                font-size: 24rpx;
                color: #779be8;
              }
            }
            .company-right {
              font-size: 24rpx;
              color: #c6c6c6;
              display: flex;
              align-items: center;
              .tips-box-img {
                width: 22rpx;
                height: 22rpx;
              }
            }
          }
        }
        .showbiz-box {
          .showbiz-list {
            margin-top: 20rpx;
            display: flex;
            align-items: center;
            justify-content: space-between;
            .showbiz-left {
              display: flex;
              align-items: center;
              .showbiz-img {
                width: 46rpx;
                height: 46rpx;
              }
              .showbiz-info {
                font-size: 24rpx;
                color: #fe5e10;
                padding: 0 20rpx;
                line-height: 30rpx;
                margin-left: -16rpx;
                background: linear-gradient(90deg, #ffddcd, rgba(255, 252, 250, 0) 100%);
              }
            }
            .showbiz-right {
              font-size: 24rpx;
              color: #c6c6c6;
              display: flex;
              align-items: center;
              .tips-box-img {
                width: 22rpx;
                height: 22rpx;
              }
            }
          }
        }
        .info-box {
          .info-box-item {
            margin-top: 32rpx;
            .item-title {
              font-size: 28rpx;
              color: #2a343e;
              flex-shrink: 0;
              margin-right: 12rpx;
            }
            .item-right {
              font-size: 24rpx;
              padding: 10rpx 0;
              width: 158rpx;
              background: #f8fbfd;
              border-radius: 26rpx;
              margin-right: 20rpx;
              text-align: center;
              .gender {
                width: 32rpx;
                height: 32rpx;
                margin-right: 14rpx;
              }
              .location {
                width: 32rpx;
                height: 32rpx;
                display: block;
                flex-shrink: 0;
              }
              .item-tips {
                padding: 0 2rpx;
                box-sizing: border-box;
              }
              .constellation-img {
                width: 28rpx;
                height: 28rpx;
                margin-right: 14rpx;
              }
            }
            .info-item-label {
              margin: 0 20rpx 0 0;
            }
          }
        }
        .userIntroBox-userTips {
          .userTips-right {
            .normalBtn {
              padding: 10rpx 30rpx;
              border: 1.6rpx solid #ffffff;
              border-radius: 30rpx;
              font-size: 20rpx;
              color: #ffffff;
            }
            .chatImg {
              width: 46rpx;
              height: 44rpx;
              margin-right: 30rpx;
            }
          }
        }
        .userIntroBox-card {
          padding: 36rpx 0 0rpx;
          .card-item {
            border-radius: 8rpx;
            padding-right: 20rpx;
            box-sizing: border-box;
            font-size: 22rpx;
            color: #2a343e;
            text-align: center;
            position: relative;
            .card-item-right {
              width: 40rpx;
              height: 40rpx;
            }
            .card-item-badge {
              padding: 4rpx 6rpx;
              background: #fb5c4e;
              border-radius: 14rpx;
              font-size: 14rpx;
              text-align: center;
              color: #ffffff;
              position: absolute;
              top: -15rpx;
              left: 44rpx;
            }
          }
        }
      }
    }
  }
  .cardBox {
    position: relative;
    border-radius: 24rpx 24rpx 0rpx 0rpx;
    margin-top: -30rpx;
    .cardBox-top {
      background: #ffffff;
      border-radius: 24rpx 24rpx 0rpx 0rpx;
      padding-top: 24rpx;
      box-sizing: border-box;
      position: sticky;
      top: calc(100rpx + var(--status-bar-height));
      z-index: 3;
      .cardBox-top-item {
        text-align: center;
        padding: 0 30rpx;
        width: 64rpx;
        flex-shrink: 0;

        .itemText {
          font-size: 28rpx;
          color: #a6acb2;
        }
        .activeText {
          font-size: 32rpx;
          color: #2a343e;
          font-weight: bold;
        }
        .borderImg {
          width: 40rpx;
          height: 6rpx;
          display: block;
          margin: 12rpx auto 0;
        }
      }
    }
    .cardBox-top-active {
      background: #ffffff;
      border-radius: 24rpx 24rpx 0rpx 0rpx;
      padding-top: 24rpx;
      box-sizing: border-box;
      position: sticky;
      top: calc(95rpx + var(--status-bar-height));
      z-index: 3;
      .cardBox-top-item {
        text-align: center;
        padding: 0 30rpx;
        width: 64rpx;
        flex-shrink: 0;

        .itemText {
          font-size: 28rpx;
          color: #a6acb2;
        }
        .activeText {
          font-size: 32rpx;
          color: #2a343e;
          font-weight: bold;
        }
        .borderImg {
          width: 40rpx;
          height: 6rpx;
          display: block;
          margin: 12rpx auto 0;
        }
      }
    }
    .swiper-active {
      min-height: calc(100vh - 88rpx - 84rpx);
      position: relative;
    }
    .swiper-active-nomy {
      min-height: calc(100vh - 88rpx - 84rpx - 176rpx);
      position: relative;
    }
    .swiper-activeindex {
      min-height: calc(100vh - 88rpx - 84rpx);
      position: relative;
    }
    .scroll {
      width: 100%;
      z-index: 3;
      padding: 20rpx 20rpx 20rpx 30rpx;
      background: #ffffff;
      box-sizing: border-box;
      .compilations-list {
        .list-item {
          padding: 10rpx 16rpx;
          border: 2rpx solid #f6f6f8;
          border-radius: 2px;
          margin-right: 15rpx;
          flex-shrink: 0;
          .imgIcon {
            width: 28rpx;
            height: 28rpx;
            margin-right: 10rpx;
          }
          .text {
            font-size: 24rpx;
            color: #a6acb2;
          }
          .active-text {
            font-size: 24rpx;
            color: #373d44;
          }
        }
      }
    }
    .scroll-active {
      position: sticky;
      // top: calc(160rpx + var(--status-bar-height));
      top: 0;
    }
    .scroll-activeindex {
      position: sticky;
      // top: calc(266rpx);
      top: 0;
    }
    .swiper-scroll-activeindex {
      height: calc(100vh - 88rpx - 84rpx);
      position: relative;
    }
    .swiper-scroll-active {
      height: calc(100vh - 88rpx - 84rpx);
      position: relative;
    }
    .swiper-scroll-active-nomy {
      height: calc(100vh - 88rpx - 84rpx - 176rpx);
      position: relative;
    }
    .swiper-scroll-active-compilationsList {
      height: calc(100vh - 88rpx - 84rpx - 100rpx);
      position: relative;
    }
    .swiper-scroll-active-compilationsList-noMy {
      height: calc(100vh - 88rpx - 84rpx - 100rpx - 176rpx);
      position: relative;
    }
    .swiper-scroll-activeindex-compilationsList {
      height: calc(100vh - 88rpx - 84rpx - 100rpx - 50rpx);
      position: relative;
    }
  }
  .bottom-btn {
    position: sticky;
    bottom: 0;
    width: 100%;
    height: 176rpx;
    background: #ffffff;
    margin: auto;
    padding: 10rpx 46rpx 0;
    box-sizing: border-box;
    .normal-btn {
      width: 324rpx;
      height: 88rpx;
      border-radius: 46rpx;
      font-size: 32rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
      box-sizing: border-box;
    }
  }

  .nolook-box {
    position: relative;
    border-radius: 24rpx 24rpx 0rpx 0rpx;
    background: #ffffff;
    height: 46vh;
    padding-top: 250rpx;
    // margin-top: -30rpx;
    .box-content {
      margin: auto;
      width: 255rpx;

      .content-img1 {
        width: 68rpx;
        height: 68rpx;
        display: block;
        margin: auto;
      }
      .content-img2 {
        width: 110rpx;
        height: 66rpx;
        display: block;
        margin: auto;
      }
      .content-tips {
        margin: 22rpx 0 16rpx;
        width: 255rpx;
        font-size: 28rpx;
        text-align: center;
        color: #bdc1c5;
      }
      .content-btn {
        margin: auto;
        height: 40rpx;
        font-size: 28rpx;
        text-align: center;
        color: #fd5e0f;
        border-bottom: 2rpx solid #fd5e0f;
      }
    }
  }
}
.waterfall {
  // background: linear-gradient(180deg, rgba(255, 255, 255, 1), #f0f0f0f0 14%);
}
.zanPop {
  /deep/ .u-popup__content {
    background-color: transparent;
  }
  .zanPopcontent {
    background: url('http://img.yiqitogether.com/yqyq-app/images/tanchuang.png') no-repeat;
    background-size: contain;
    width: 536rpx;
    height: 752rpx;
    position: relative;
    .body {
      position: absolute;
      width: 100%;
      top: 414rpx;
      .text {
        margin: auto;
        font-size: 32rpx;
        text-align: center;
        color: #2a343e;
        line-height: 44rpx;
      }
      .btn {
        margin: 75rpx auto 0;
        background: url('http://img.yiqitogether.com/yqyq-app/images/queren.png') no-repeat;
        background-size: contain;
        width: 460rpx;
        height: 88rpx;
        font-size: 28rpx;
        text-align: center;
        color: #2a343e;
        line-height: 88rpx;
      }
    }
  }
}
.moreOperationsPop {
  .blockInfo {
    height: 110rpx;
    font-size: 24rpx;
    font-weight: 400;
    text-align: center;
    color: #333333;
    line-height: 32rpx;
    border-bottom: 1rpx solid #f0f0f0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .quxiao {
    height: 110rpx;
    font-size: 28rpx;
    font-weight: 500;
    text-align: center;
    color: #adb3ba;
    line-height: 36rpx;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
.activity-evaluate-box {
  padding: 0 36rpx;
  margin-top: 30rpx;
  .evaluate-box-left {
    padding: 20rpx;
    box-sizing: border-box;
    width: 252rpx;
    height: 254rpx;
    background: #f8fbfd;
    border-radius: 24rpx;
    .box-left-score {
      margin-top: 28rpx;
      font-size: 50rpx;
      color: #2a343e;
      font-weight: bold;
      text-align: center;
    }
    .box-left-rate {
      // text-align: center;
      margin-top: 10rpx;
      /deep/.u-rate {
        justify-content: center;
      }
      /deep/.u-rate__content__item__icon-wrap--half {
        width: 15rpx !important;
      }
    }
    .box-left-tips {
      margin-top: 20rpx;
      text-align: center;
      font-size: 20rpx;
      color: #9fa7b4;
    }
  }
  .evaluate-box-right {
    padding: 20rpx;
    box-sizing: border-box;
    width: 410rpx;
    height: 254rpx;
    background: #f8fbfd;
    border-radius: 24rpx;
    .box-right-aniMove {
      margin-top: 28rpx;
      overflow: hidden;
      .aniMove-item {
        margin-right: 65rpx;
        flex-shrink: 0;
        animation: aniMove 10s linear infinite;
        animation-fill-mode: forwards;
        background: #ffffff;
        padding: 5rpx 25rpx;
        border-radius: 50rpx;
        .item-img {
          width: 54rpx;
          height: 54rpx;
          margin-right: 9rpx;
        }
        .item-text {
          font-size: 26rpx;
          color: #2a343e;
        }
      }
      /* 文字滚动 */
      @keyframes aniMove {
        0% {
          transform: translate3d(100px, 0, 0);
        }

        100% {
          transform: translate3d(-850px, 0, 0);
        }
      }
    }
  }
  .title {
    font-size: 22rpx;
    color: #2a343e;
  }
}
.normal-List {
  padding: 0 32rpx;
}
.myPhotoAlbum {
  padding: 30rpx 36rpx 0 36rpx;
  min-height: calc(100vh - var(--status-bar-height) - 600rpx);
  box-sizing: border-box;
}

.tips-box {
  padding-top: 24rpx;
  padding-bottom: 50rpx;
}

/deep/.u-loadmore__content__text {
  line-height: 23rpx !important;
}
/deep/.u-tag--medium {
  padding: 0;
}
/deep/.u-tag__text--medium {
  width: 154rpx;
  font-size: 24rpx !important;
  text-align: center;
}

.unread-message-number {
  box-sizing: border-box;
  min-width: 28rpx;
  height: 28rpx;
  border-radius: 50%;
  background-color: #ff0b0b;
  color: #fff;
  font-size: 18rpx;
  text-align: center;
  line-height: 28rpx;
  margin-left: 16rpx;
}
.tipsconfirm-wrap-content-new {
  width: 560rpx;
  height: 196rpx;
  padding: 0 50rpx 4rpx;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: center;
  font-size: 24rpx;
  text-align: center;
  color: #333333;
  line-height: 48rpx;
}

.pinned-box-l {
  // width: 520rpx;
  height: 172rpx;
  display: flex;
  // justify-content: space-between;
  vertical-align: middle;
  border-radius: 12rpx;
  overflow: hidden;
}

.pinned-box {
  width: 100%;
  height: 230rpx;
  padding: 8rpx 30rpx 24rpx;
  box-sizing: border-box;
  justify-content: space-between;
  background-color: #fff;
}

.pinned-title {
  font-size: 32rpx;
  color: #2a343e;
  margin-right: 42rpx;
}

.pinned-item {
  // flex: 1;
  // margin-right: 4rpx;
}

.pinned-photo {
  width: 172rpx;
  height: 172rpx;
  margin-right: 4rpx;
}

.pinned-video {
  position: relative;
}

.pinned-pause {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 36rpx;
  height: 36rpx;
}

.pinned-l {
  width: 16rpx;
  height: 26rpx;
}

.pinned-text {
  width: 172rpx;
  height: 172rpx;
  background: #f6f6f8;
  font-size: 24rpx;
  color: #484848;
  line-height: 36rpx;
  padding: 12rpx;
  box-sizing: border-box;
  margin-right: 4rpx;
}
</style>
