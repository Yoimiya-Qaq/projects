<template>
	<view class="page">
		<view class="nav_box">
			<image @click="goBack()" class="back-image"
				src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
		</view>
		<image src="http://img.yiqitogether.com/yqyq-app/images/bg33%402x.png" class="poster_img" mode=""></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				closeEmit:'/pages/my/recruit'
			};
		},
		methods: {
			// 返回上一页
			goBack() {
				uni.navigateBack()
				// if (uni.getSystemInfoSync().platform == 'ios') {
				// 	let testModule = uni.requireNativePlugin('TestModule')
				// 	testModule.closeUniMPShowAppPage({
				// 			linkUrl: this.closeEmit
				// 		},
				// 		ret => {}
				// 	)
				// } else if (uni.getSystemInfoSync().platform == 'android') {
				// 	uni.sendNativeEvent(
				// 		'closeSubUniMP', {
				// 			msg: ''
				// 		},
				// 		ret => {}
				// 	)
				// }
			},
		}
	}
</script>

<style lang="scss" scoped>
	.page {
		position: relative;
		width: 750rpx;
		height: 1624rpx;
	}

	.poster_img {
		width: 750rpx;
		height: 1624rpx;
	}

	.nav_box {
		position: absolute;
		top: 80rpx;
		height: 88rpx;
		display: flex;
		align-items: center;
		z-index: 9;
	}

	.back-image {
		width: 44rpx;
		height: 44rpx;
		margin-left: 30rpx;
	}
</style>