<template>
  <view :class="['find-details-page', showComment || showReward ? 'fixed-page' : '']">
    <!-- 导航栏 -->
    <view v-if="!isFwb" class="nav-container" :style="{ height: pageType == 2 ? '108rpx' : '88rpx' }">
      <image class="nav-back" src="@/static/images/back_black.png" mode="" @click="goBack" />
      <view
        class="nav-title ellipsis-single"
        v-show="pageScrollTop > 63 || pageType == 2"
        @click="
          $u.throttle(() => {
            goMyPage(infoData.userinfo.numberId)
          })
        "
      >
        <image class="user-avatar" :src="infoData.userinfo ? infoData.userinfo.headUrl : ''" mode="aspectFill" />
        <view class="user-name">{{ infoData.userinfo ? infoData.userinfo.nickName : '' }}</view>
      </view>
      <view class="flex-0">
        <view class="peddingbox flex-0" v-if="pageType == 2 && infoData.userinfo && infoData.userinfo.numberId == currUserId && infoData.twitterInfo.checkState == 1" @click.stop="hint">
          <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
          <view class="paddingbox-text">待审核</view>
        </view>
        <view class="nav-btn common-follow-btn-active" v-if="pageType == 2 && infoData.userinfo && infoData.userinfo.numberId != currUserId" @click="$u.throttle(handleAttentionOrChat, 500)">{{ infoData.isAtention ? '私信' : '关注' }}</view>
        <image class="nav-icon" src="@/static/images/more2.png" mode="" @click="showMoreOperate = true" />
      </view>
    </view>
    <!-- 文章头部 -->
    <block v-else>
      <view v-if="pageScrollTop < 63" class="fwb-top" :style="{ height: pageType == 2 ? '108rpx' : '88rpx' }">
        <image class="nav-back" src="https://img.yiqitogether.com/static/local/myImages/back_02@2x.png" mode="" @click="goBack" />
        <image class="nav-icon" src="@/static/images/more_white.png" mode="" @click="showMoreOperate = true" />
      </view>
      <view v-else class="fwb-top" :style="{ height: pageType == 2 ? '108rpx' : '88rpx', background: '#ffffff' }">
        <image class="nav-back" src="@/static/images/back_black.png" mode="" @click="goBack" />
        <view
          class="nav-title ellipsis-single"
          v-show="pageScrollTop > 63 || pageType == 2"
          @click="
            $u.throttle(() => {
              goMyPage(infoData.userinfo.numberId)
            })
          "
        >
          <image class="user-avatar" :src="infoData.userinfo ? infoData.userinfo.headUrl : ''" mode="aspectFill" />
          <view class="user-name">{{ infoData.userinfo ? infoData.userinfo.nickName : '' }}</view>
        </view>
        <view class="peddingbox flex-0" @click.stop="hint" v-if="infoData.userinfo && infoData.userinfo.numberId == currUserId && infoData.twitterInfo.checkState == 1" style="margin-right: 20rpx">
          <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
          <view class="paddingbox-text">待审核</view>
        </view>
        <view class="nav-btn common-follow-btn-active" v-if="pageType == 2 && infoData.userinfo && infoData.userinfo.numberId != currUserId" @click="$u.throttle(handleAttentionOrChat, 500)">{{ infoData.isAtention ? '私信' : '关注' }}</view>
        <image class="nav-icon" src="@/static/images/more2.png" mode="" @click="showMoreOperate = true" />
      </view>
    </block>

    <!-- -----------------------页面内容start----------------------- -->
    <view class="main-container">
      <!-- 笔记轮播图 -->
      <view class="lunbo" v-if="pageType == 2">
        <u-swiper
          v-if="!videoUrl && infoData.twitterInfo && infoData.twitterInfo.imgList.length"
          :list="infoData.twitterInfo.imgList"
          :height="swiperHeight + 'rpx'"
          :autoplay="false"
          :radius="0"
          bgColor="#fff"
          :style="{ paddingBottom: infoData.twitterInfo.imgList.length > 1 ? '48rpx' : 0 }"
          :indicator="infoData.twitterInfo.imgList.length > 1 ? true : false"
          indicatorMode="dot"
          indicatorActiveColor="#FE5E10"
          indicatorInactiveColor="#e5e7e9"
          indicatorStyle="left: center;bottom: 20rpx;"
          imgMode="aspectFit"
          @click="handlePreviewImg"
        ></u-swiper>
        <block v-if="videoUrl">
          <image
            class="video-img"
            :style="{ height: swiperHeight + 'rpx' }"
            :src="videoImgUrl"
            mode="aspectFit"
            @click="
              $u.throttle(() => {
                playVideo(infoData.twitterInfo)
              }, 500)
            "
          />
          <image
            class="play-icon"
            src="@/static/images/shipin@2x.png"
            mode="aspectFill"
            @click="
              $u.throttle(() => {
                playVideo(infoData.twitterInfo)
              }, 500)
            "
          />
        </block>
      </view>

      <view :class="isFwb ? 'fwb-box' : ''" style="padding: 0 36rpx">
        <!-- 笔记标题 -->
        <view class="main-title" v-if="pageType == 2 && infoData.twitterInfo && infoData.twitterInfo.title">{{ infoData.twitterInfo.title }}</view>
        <!-- 笔记-文章-用户信息 -->
        <view v-if="isFwb" class="main-user">
          <view class="user-box">
            <image class="user-img" :src="infoData.userinfo ? infoData.userinfo.headUrl : ''" mode="apsectFill" />
            <view class="user-name">{{ infoData.userinfo ? infoData.userinfo.nickName : '' }}</view>
          </view>
          <view class="flex-0" v-if="infoData.twitterInfo">
            <view class="user-text" v-if="infoData.twitterInfo.checkState == 0">{{ infoData.viewCount || 0 }}人浏览</view>
            <view class="peddingbox flex-0" @click.stop="hint" v-if="infoData.userinfo && infoData.userinfo.numberId == currUserId && infoData.twitterInfo.checkState == 1 && pageScrollTop < 63" style="margin-right: 20rpx">
              <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
              <view class="paddingbox-text">待审核</view>
            </view>
          </view>
        </view>
        <!-- 动态用户信息 -->
        <view class="top-wrap" v-if="pageType == 1">
          <image
            class="avatar-img"
            :src="infoData.userinfo ? infoData.userinfo.headUrl : ''"
            mode="aspectFill"
            @click="
              $u.throttle(() => {
                goMyPage(infoData.userinfo.numberId)
              })
            "
          />
          <view class="user-info">
            <view
              class="user-name"
              style="display: inline-block"
              @click="
                $u.throttle(() => {
                  goMyPage(infoData.userinfo.numberId)
                })
              "
            >
              {{ infoData.userinfo ? infoData.userinfo.nickName : '' }}
            </view>
            <view class="others">
              <image class="sex-img" v-if="infoData.userinfo && infoData.userinfo.sex === '男'" src="@/static/images/nan.png" mode="aspectFill" />
              <image class="sex-img" v-if="infoData.userinfo && infoData.userinfo.sex === '女'" src="@/static/images/nv.png" mode="aspectFill" />
              {{ infoData.twitterInfo && infoData.twitterInfo.createTime ? $u.timeFrom(infoData.twitterInfo.createTime, 'yyyy-mm-dd') + '发布 · ' : '' }}{{ infoData.viewCount || 0 }}浏览{{ infoData.twitterInfo && infoData.twitterInfo.city ? ' · ' + infoData.twitterInfo.city : '' }}
            </view>
          </view>
          <view class="attention-btn common-follow-btn-active" v-if="infoData.userinfo && infoData.userinfo.numberId != currUserId" @click="$u.throttle(handleAttentionOrChat, 500)">{{ infoData.isAtention ? '私信' : '关注' }}</view>
          <view class="peddingbox flex-0" v-if="pageType == 1 && infoData.userinfo && infoData.userinfo.numberId == currUserId && infoData.twitterInfo.checkState == 1" @click.stop="hint">
            <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
            <view class="paddingbox-text">待审核</view>
          </view>
        </view>

        <!-- 动态文本 -->
        <view class="word-wrap" id="descriptionTxt" v-if="describe && !isFwb" @longpress="handleCopy(1)" @touchend="touchEnd" @touchmove="touchMove">
          <view :class="['fold-text', isFold ? 'ellipsis' : '']">{{ describe || '' }}</view>
          <view class="fold-btn" v-if="showFold" style="color: #bdc1c5" @click.stop="changFold">{{ isFold ? '全文' : '收起' }}</view>
        </view>
        <!-- 富文本样式必须得是这个ql-container类名，不然样式不生效 -->
        <view class="editor-info-box" v-if="isFwb">
          <rich-text :nodes="describe"></rich-text>
        </view>
        <!-- 动态图片/视频 -->
        <block v-if="pageType == 1">
          <view class="imgs-wrap">
            <!-- 展示动态图片 -->
            <image-processing v-if="!videoUrl && infoData.twitterInfo && infoData.twitterInfo.imgList.length" type="image" :imageList="infoData.twitterInfo.imgList" />
            <!-- 展示动态视频 -->
            <image-processing
              v-if="videoUrl && infoData.twitterInfo && infoData.twitterInfo.imgList.length"
              type="video"
              :imageList="infoData.twitterInfo.imgList"
              @playVideo="
                $u.throttle(() => {
                  playVideo(infoData.twitterInfo)
                }, 500)
              "
            />
          </view>
        </block>

        <!-- 标签卡 -->
        <view class="card-wrap" v-if="infoData.twitterInfo && infoData.twitterInfo.quoteInfoDTO && infoData.twitterInfo.quoteInfoDTO.officialTarget && infoData.twitterInfo.quoteInfoDTO.quoteTitle && infoData.twitterInfo.quoteInfoDTO.isShow != -1">
          <custom-tag-card :twitterInfo="infoData.twitterInfo" />
        </view>

        <!-- 位置 -->
        <view class="topic-wrap" v-if="infoData && infoData.twitterInfo">
          <view class="tag-box1" v-if="infoData.twitterInfo.positionShortName" @click="$u.throttle(goMap, 500)">
            <image class="card-tag-pointIcon" style="margin-right: 10rpx; margin-top: 2rpx" src="http://img.yiqitogether.com/yqyq-app/images/fx_dingwei.png"></image>
            <view class="tag-box-text ellipsis-single">{{ infoData.twitterInfo.positionShortName }}</view>
            <image class="card-tag-narright" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="aspectFill" />
          </view>
        </view>
        <!-- 话题 -->
        <view class="topic-wrap" v-if="infoData && infoData.twitterInfo">
          <block v-if="infoData.twitterInfo.quoteInfoDTO && infoData.twitterInfo.quoteInfoDTO.officialTarget && infoData.twitterInfo.quoteInfoDTO.officialTarget.length">
            <block v-for="(item, index) in infoData.twitterInfo.quoteInfoDTO.officialTarget" :key="index">
              <view
                v-if="item.url"
                class="tag-box"
                @click.stop="
                  $u.throttle(() => {
                    goJumpUrl(item.url)
                  })
                "
              >
                <image class="tag-box-icon" style="margin-right: 10rpx" src="@/static/images/find_vote_tag.png"></image>
                <view class="tag-box-text ellipsis-single">{{ item.text }}</view>
              </view>
            </block>
          </block>
          <block v-if="infoData.twitterInfo.topicList && infoData.twitterInfo.topicList.length">
            <view
              class="tag-box"
              v-for="(item, index) in infoData.twitterInfo.topicList"
              :key="index"
              @click="
                $u.throttle(() => {
                  goTopic(item)
                }, 500)
              "
            >
              <!-- <image class="tag-box-icon" style="margin-right: 4rpx" src="@/static/images/tagColor.png" mode="aspectFill" /> -->
              <view class="tag-box-text ellipsis-single">#{{ item }}</view>
            </view>
          </block>
        </view>
        <!-- 笔记发布时间 -->
        <view class="h-flex-align h-flex-sb time-wrap">
          <view v-if="pageType == 2 && infoData.twitterInfo">
            {{ infoData.twitterInfo.editTime ? '编辑于' + $u.timeFrom(infoData.twitterInfo.editTime, 'yyyy-mm-dd') : $u.timeFrom(infoData.twitterInfo.createTime, 'yyyy-mm-dd') }} {{ infoData.twitterInfo && infoData.twitterInfo.city ? ' · ' + infoData.twitterInfo.city : '' }}
          </view>
          <view class="h-flex-align" v-if="infoData.twitterInfo && infoData.twitterInfo.groupName">
            <image class="compilation-icon h-mg-r-10" src="@/static/images/heji.png" mode="scaleToFill" />
            {{ infoData.twitterInfo.groupName }}
          </view>
        </view>

        <!-- 打赏提示 -->
        <view class="reward-wrap" v-if="pageType == 2 && isGoodNote">
          <image class="reward-img" src="@/static/images/fx_detail_reward.png" mode="aspectFill" @click="showReward = true" />
          <view class="reward-text">喜欢可以支持一下哟~</view>
        </view>

        <!-- 评论 -->
        <view class="comment-wrap">
          <view class="title-box">
            <text class="title-box-text">评论</text>
            <text class="title-box-num">{{ formatKWNumber(infoData.commentCount) || 0 }}</text>
          </view>
          <view class="input-box">
            <image
              class="input-box-avatar"
              :src="currUserAvatar"
              mode="aspectFill"
              @click="
                $u.throttle(() => {
                  goMyPage(currUserId)
                })
              "
            />
            <view class="input-box-tips" @click="openComment()">文明用语，友善交流…</view>
          </view>
          <!-- 评论列表 -->
          <view class="comment-list" v-show="!showLoading">
            <custom-comment-list :listData="commentList" :featureList="featureList" :currUserId="currUserId" :totalCommentCount="infoData.commentCount" :firstLoadStatus="firstLoadStatus" @like="handleLikeComment" @open="getChildList" @reply="handleReply" @longpress="openCommentOperate" />
          </view>
        </view>
      </view>
    </view>
    <!-- -----------------------页面内容end----------------------- -->

    <!-- 底部盒子 -->
    <view class="bottom-container">
      <!-- 评论 -->
      <view class="left-comment" @click="openComment">
        <image class="left-icon" src="@/static/images/findPen.png" mode="aspectFill" />
        文明用语，友善交流
      </view>
      <!-- 点赞、收藏、转发 -->
      <view class="right-operate">
        <view class="operate-box" @click="handleShare">
          <image class="operate-box-icon" src="@/static/images/fx_zf.png" mode="aspectFill" />
          <view class="operate-box-text">分享</view>
        </view>
        <view class="operate-box" v-if="pageType == 1 && isGift" @click="$u.throttle(handleSendGift, 500)">
          <image class="operate-box-icon" src="@/static/images/fx_gift.png" mode="aspectFill" />
          <view class="operate-box-text" style="color: #fe5e10">礼物</view>
        </view>
        <view class="operate-box" v-if="pageType == 2 && isGoodNote" @click="showReward = true">
          <image class="operate-box-icon" src="@/static/images/fx_reward.png" mode="aspectFill" />
          <view class="operate-box-text">打赏</view>
        </view>
        <view class="operate-box" @click="$u.throttle(handleLikeDynamic, 500)">
          <image class="operate-box-icon" v-if="infoData.isZan" src="@/static/images/fx_dz_a.png" mode="aspectFill" />
          <image class="operate-box-icon" v-else src="@/static/images/fx_dz.png" mode="aspectFill" />
          <view class="operate-box-text">{{ infoData.zanCount && Number(infoData.zanCount) > 0 ? infoData.zanCount : '点赞' }}</view>
        </view>
        <view class="operate-box" @click="$u.throttle(handleCollect, 500)">
          <image class="operate-box-icon" v-if="infoData.isCollect" src="@/static/images/fx_sc_a.png" mode="aspectFill" />
          <image class="operate-box-icon" v-else src="@/static/images/fx_sc.png" mode="aspectFill" />
          <view class="operate-box-text">{{ infoData.collectCount && Number(infoData.collectCount) > 0 ? infoData.collectCount : '收藏' }}</view>
        </view>
        <!-- <view class="operate-box" @click="openComment">
          <image class="operate-box-icon" src="@/static/images/fx_dz_l_02.png" mode="aspectFill" />
          <view class="operate-box-text">{{ infoData.commentCount && Number(infoData.commentCount) > 0 ? infoData.commentCount : '评论' }}</view>
        </view> -->
        <!-- <view class="operate-box" @click="$u.throttle(handleForward, 500)" v-if="pageType == 1">
          <image class="operate-box-icon" src="@/static/images/fx_zf.png" mode="aspectFill" />
          <view class="operate-box-text">{{ infoData.forwardCount && Number(infoData.forwardCount) > 0 ? infoData.forwardCount : '转发' }}</view>
        </view> -->
      </view>
    </view>
    <video style="position: absolute; top: 0; left: -750rpx" :src="videoPlayUrl" loop id="videoId" @fullscreenchange="videoFullScreenChange"></video>

    <!-- <video id="myVideo" style="position: absolute; top: 0; left: -100%" :poster="videoImgUrl" :src="videoUrl" :autoplay="false" loop @fullscreenchange="fullscreenchange" @play="videoPlayFun"></video> -->
    <!-- 评论弹窗 -->
    <custom-interaction :customStyle="{ bottom: activeheight + 'px' }" :show="showComment" :placeholder="placeholder" @close="showComment = false" @send="handleSendComment" />
    <!-- 更多操作弹窗 -->
    <custom-more-operate-popup :show="showMoreOperate" :list="moreBtnList" @close="showMoreOperate = false" @click="handleMoreClick" />
    <!-- 评论长按操作弹窗 -->
    <custom-more-operate-popup :show="showCommentOperate" :list="commentBtnList" @close="showCommentOperate = false" @click="handleBtnClick" />
    <!-- 拉黑提示框 -->
    <custom-modal type="tipsConfirm" :show="showBlack" :round="24" title="是否拉黑TA？" content="将不再推送TA的动态，若想再次查看可前往“我的-设置-黑名单”移出该用户" cancelText="取消" confirmText="确定" @cancel="showBlack = false" @confirm="addUserBlack"></custom-modal>
    <!-- 移出黑名单提示框 -->
    <custom-modal type="tipsConfirm" :show="showRemove" :round="24" title="提示" content="您已将TA拉黑，无法使用私信功能" cancelText="取消" confirmText="确定" @cancel="showRemove = false" @confirm="confirmRemoveBlack">
      <view class="popup-content">是否将TA移出黑名单?</view>
    </custom-modal>
    <!-- 删除动态/笔记/评论 -->
    <custom-modal type="tipsConfirm" :show="showDel" :round="24" title="提示" :content="delContent" cancelText="点错了" confirmText="是的" @cancel="showDel = false" @confirm="confirmDel" />
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- loading 弹窗 -->
    <yue-loading :mask="true" loadTxet="正在奋力加载中..." v-show="showSendLoading"></yue-loading>
    <!-- 错误提示 -->
    <u-toast ref="uToast"></u-toast>
    <!-- 分享弹窗 -->
    <common-sharing-module :shareData="shareData" v-if="sharePopupFlag" @closePopup="sharePopupFlag = false" @handleForward="handleForward"></common-sharing-module>
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于获取当前城市位置" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="getAddress" isImg isOnShow></accredit-popup>
    <!-- 打赏弹窗 -->
    <reward-popup :show="showReward" title="礼物打赏" :twitterId="twitterId" :targetNumberId="infoData.userinfo ? infoData.userinfo.numberId : ''" @close="showReward = false" @success="handleTip"></reward-popup>
    <!-- 赠送积分礼物提示弹窗 -->
    <view class="tip-popup">
      <u-popup :show="showTip" @close="showTip = false" mode="center" :overlay="false">
        <view class="tip-box">
          <image class="tip-avatar" :src="currUserAvatar" mode="aspectFill" />
          <view class="tip-content">
            <view class="tip-content-name ellipsis-single">{{ currUserName || '' }}</view>
            <view class="tip-content-desc ellipsis-single">赠送{{ giftData.name || '' }}</view>
          </view>
          <image class="tip-img" :src="giftData.src ? giftData.src : ''" mode="aspectFill" />
        </view>
        <view class="tip-num">x{{ giftData.num || 0 }}</view>
      </u-popup>
    </view>
    <!-- 赠送靓靓礼物提示弹窗 -->
    <view class="tip-popup">
      <u-popup :show="showGiftTip" @close="showGiftTip = false" mode="center" :overlay="false">
        <view class="gift-box">
          <view class="gift-top">
            <image class="gift-icon" src="http://img.yiqitogether.com/static/images/messageGray/chat_gift_success.png" mode="aspectFill" />
            <view>打赏成功</view>
          </view>
          <view class="gift-desc">请在私聊中查看领取情况~</view>
        </view>
      </u-popup>
    </view>
    <!-- 加积分弹窗 -->
    <custom-bonus-popup :show="showBonus && score > 0" :score="score" @close="showBonus = false" />
  </view>
</template>

<script>
import findModel from '@/model/find.js'
import MyInfo from '@/model/my'
import { load } from '@/utils/store'
import { LOGIN_USERID, USER_INFO, LOGIN_NICKNAME } from '@/utils/cacheKey'
import { rpxTopx, formatKWNumber, judgeImageSize, handleImgWinthAndHeight, getImageHeight, openMap, getLocation } from '@/utils/tools'
import ImageProcessing from './commponent/image-processing.vue'

export default {
  name: 'findDetails',
  components: { ImageProcessing },
  data() {
    return {
      shareData: {},
      sharePopupFlag: false,
      currentFullScreenState: null,
      formatKWNumber,
      pageScrollTop: 0,
      swiperHeight: 1000,
      pageType: 1, // 1-动态 2-笔记
      position: '',
      showMoreOperate: false, // 更多操作
      showDel: false, // 删除动态/笔记/评论二次确认弹窗
      delContent: '您确定要删除此动态？',
      showCommentOperate: false, // 长按评论操作
      showFold: false, // 是否展示全文/收起
      isFold: false, // 右下角文字：true-全文 false-收起
      showLoading: true, // 评论列表loading
      showSendLoading: false, // 发送评论loading
      showBlack: false, // 拉黑弹窗
      showRemove: false, // 移出黑名单弹窗
      showComment: false, // 评论弹窗
      placeholder: '文明用语，友善交流…', // 评论弹窗提示语
      currUserId: '', // 当前登录用户id
      currUserName: '', // 当前登录用户昵称
      currUserAvatar: '', // 当前登录用户头像
      twitterId: '', // 动态id
      currCommentIndex: null, // 当前选中的二级评论的一级评论索引
      currCommentId: '', // 评论id
      currCommentData: {}, // 当前选中评论项
      isFeature: false, // 当前点击的是否是精选评论列表里的评论
      videoPlayUrl: '',
      videoUrl: '',
      videoContext: null,
      videoImgUrl: '',
      describe: '',
      infoData: {},
      pageSize: 10, //每页多少条
      featureList: [],
      commentList: [],
      lastKeyWord: '', // 获取一级评论列表关键词
      firstLoadStatus: 'loadmore', // 一级评论加载状态
      isSelf: false, // 是否是自己的动态/笔记
      isLongtap: true, // 长按事件是否生效
      isGift: false, // 是否有礼物特权
      isGoodNote: false, // 是否是优质帖子
      showReward: false, // 是否显示打赏弹窗
      showTip: false, // 是否显示赠送积分礼物提示弹窗
      showGiftTip: false, // 是否显示赠送靓靓礼物提示弹窗
      giftData: {}, // 赠送的礼物数据
      moreBtnList: [],
      commentBtnList: ['复制', '举报'],
      tagLabelList: ['GOOD_PHOTO', 'APPOINTMENT', 'TWITTER_FORWARD', 'BIRTHDAY', 'NOTES_FORWARD_TWITTER'],
      // 是否是富文本
      isFwb: false,
      activeheight: 0,
      score: 0,
      isFinished: false, // 是否达到每日加分上限
      showBonus: false
    }
  },
  async onLoad(e) {
    this.twitterId = e.twitterId || ''
    this.pageType = e.pageType || 1
    this.delContent = e.pageType == 2 ? '您确定要删除此笔记？' : '您确定要删除此动态？'
    this.currUserId = load(LOGIN_USERID) || ''
    this.currUserName = load(LOGIN_NICKNAME) || ''

    // try {
    //   this.position = await getLocation()
    // } catch (e) {}
    setTimeout(() => {
      this.$refs.accredit.triggerEvent()
    }, 100)
    this.currUserAvatar = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)).headUrl : 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png'
    this.getDetail(e)
    this.getFeatureList()
    this.getCommentList()
    // #ifdef APP
    if (this.pageType == 2) {
      findModel.enterNotePage({ dynamicId: e.twitterId }).then(res => {})
    }
    // #endif
    // 在页面的onLoad中添加事件监听
    // uni.$on('refreshFindDetailsCount', this.refreshFindDetailsCount)
  },
  onUnload() {
    // 在页面销毁时移除事件监听，避免内存泄露
    // uni.$off('refreshFindDetailsCount', this.refreshFindDetailsCount)
    // #ifdef APP
    if (this.pageType == 2) {
      findModel.leaveNotePage({ dynamicId: this.twitterId }).then(res => {})
    }
    // #endif
  },
  onShow() {
    try {
      const eventChannel = this.getOpenerEventChannel()
      eventChannel.emit('viewCountChange', 'add')
    } catch (e) {
      console.log(`上一个页面的浏览量 +1 失败`)
    }
  },
  onReady() {
    // 视频
    this.videoContext = uni.createVideoContext('videoId')
  },
  onPageScroll({ scrollTop }) {
    this.pageScrollTop = scrollTop
  },
  // 页面触底加载一级评论列表下一页
  onReachBottom() {
    if (this.lastKeyWord && this.firstLoadStatus !== 'nomore') {
      this.firstLoadStatus = 'loading'
      this.getCommentList()
    }
  },
  onBackPress({ from }) {
    if (from == 'navigateBack') {
      return false
    } else {
      this.goBack()
      return true
    }
  },
  methods: {
    async getAddress() {
      try {
        this.position = await getLocation()
      } catch (e) {
        console.log(e)
      }
    },
    // 返回上一页
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 获取详情
    getDetail(e) {
      let params = {
        twitterId: this.twitterId,
        position: this.position
      }
      findModel
        .twitterDetail(params)
        .then(async res => {
          if (res.code == 'SUCCESS') {
            let info = res.data.twitterInfo || {}
            this.describe = info.twitterInfo && info.twitterInfo.content ? info.twitterInfo.content : ''
            this.isFwb = info.twitterInfo && info.twitterInfo.fwb ? true : false
            this.isGift = info.userinfo && info.userinfo.tags && info.userinfo.tags.includes('TAG_GIFTVIP') ? true : false
            this.isGoodNote = info.twitterInfo && info.twitterInfo.goodNote == 2 ? true : false

            let numberId = info.userinfo.numberId || ''
            if (numberId === this.currUserId) {
              // 自己的动态/笔记
              this.moreBtnList = ['删除']
              this.commentBtnList = ['设为精选评论', '复制', '举报']
              this.isSelf = true
              if (this.pageType == 2) {
                this.moreBtnList.unshift('移入合集')
                this.moreBtnList.unshift('编辑')
              }
              if (info.twitterInfo.checkState == 0) {
                if (info.twitterInfo.topOrder == 0) {
                  this.moreBtnList.unshift('置顶')
                } else {
                  this.moreBtnList.unshift('取消置顶')
                }
              }
            } else {
              // 不是自己的动态/笔记
              this.moreBtnList = ['举报']
              this.isSelf = false
              // if (this.pageType == 1) {
              //   this.moreBtnList.unshift('不看TA动态')
              // }
            }
            // #ifdef APP-PLUS
            if (info.twitterInfo.checkState != 1) {
              // 待审核不显示分享
              this.moreBtnList.unshift('分享')
            }
            // #endif

            // 图片视频处理
            if (info.twitterInfo.videoUrl) {
              // 视频
              this.videoUrl = info.twitterInfo.videoUrl
              this.videoImgUrl = info.twitterInfo.imageUrls
            }
            let imgs = info.twitterInfo.imageUrls || ''
            info.twitterInfo.imgList = imgs ? imgs.split('&&') : []
            if (imgs) {
              if (this.pageType == 2) {
                try {
                  let imgHeight = await getImageHeight(info.twitterInfo.imgList[0], 1000)
                  this.swiperHeight = Math.round(imgHeight) + 1
                } catch (error) {}
              }
              // 单张时，处理图片/视频最大宽高
              if (info.twitterInfo.imgList.length === 1 && this.pageType == 1) {
                // let imgObj = await judgeImageSize(info.twitterInfo.imgList[0])
                let imgObj = await handleImgWinthAndHeight(info.twitterInfo.imgSize, info.twitterInfo.imgList[0])
                info.twitterInfo.imgList = [imgObj]
              }
            }

            // 标签数据处理和长度处理最多显示五条
            let topicList = []
            if (info.twitterInfo && info.twitterInfo.markTopic) {
              topicList = info.twitterInfo.markTopic.split('#').filter(v => v && v.trim())
              topicList = topicList.length ? topicList.slice(0, 5) : []
            }
            info.twitterInfo.topicList = topicList

            // 标签卡
            if (info.twitterInfo && info.twitterInfo.quoteInfoDTO && info.twitterInfo.quoteInfoDTO.officialTarget) {
              let cardsInfo = info.twitterInfo.quoteInfoDTO || {}
              info.twitterInfo.quoteInfoDTO.isShow = this.tagLabelList.indexOf(cardsInfo.officialTarget[0].label)
              try {
                JSON.parse(cardsInfo.quoteContent)
                info.twitterInfo.quoteInfoDTO.quoteContent = JSON.parse(cardsInfo.quoteContent)
              } catch (error) {
                info.twitterInfo.quoteInfoDTO.quoteContent = cardsInfo.quoteContent
              }
            }
            this.infoData = { ...info }

            // 从播放视频那边跳转过来start
            if (e.jumpType && e.jumpType == 'comment') {
              // setTimeout(() => {
              //   this.openComment()
              // }, 2000)
            }
            if (e.jumpType && e.jumpType == 'share') {
              this.handleShare()
            }
            // 从播放视频那边跳转过来end

            if (this.describe) {
              setTimeout(() => {
                this.checkTextLines()
              }, 300)
            }
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
            setTimeout(() => {
              uni.navigateBack({ delta: 1 })
            }, 1000)
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 切换展开/收起
    changFold() {
      this.isFold = !this.isFold
    },
    // 判断文本是否超过五行，默认展开
    checkTextLines() {
      const query = uni.createSelectorQuery().in(this)
      query
        .select('#descriptionTxt')
        .boundingClientRect(res => {
          // 获取文本内容的高度
          const contentHeight = res.height
          const lineHeight = rpxTopx(46)
          const lines = Math.ceil(contentHeight / lineHeight)
          // 判断文本行数是否达到了5行
          if (lines > 5) {
            this.showFold = true
          } else {
            this.showFold = false
          }
        })
        .exec()
    },
    // 更多操作
    handleMoreClick(index, item) {
      switch (item) {
        case '置顶':
          this.topUpEvent(true)
          break
        case '取消置顶':
          this.topUpEvent(false)
          break
        case '编辑':
          if (this.isFwb) {
            uni.navigateTo({ url: '/pagesFind/find/releaseArticle?chooseType=s3&operate=editNote&twitterId=' + this.twitterId })
          } else {
            uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s3&operate=editNote&twitterId=' + this.twitterId })
          }
          this.showMoreOperate = false
          break
        case '移入合集':
          this.changeCompilations()
          break
        case '分享':
          this.handleShare()
          break
        case '不看TA动态':
          this.showMoreOperate = false
          this.showBlack = true
          break
        case '删除':
          this.showMoreOperate = false
          this.delContent = this.pageType == 2 ? '您确定要删除此笔记？' : '您确定要删除此动态？'
          this.showDel = true
          break
        case '举报':
          let userId = this.infoData?.userinfo?.numberId
          let reportTargetType = this.pageType == 2 ? 'NOTES' : 'TWITTER'
          uni.navigateTo({ url: '/pagesCommon/message/report?userId=' + userId + '&reportTargetType=' + reportTargetType + '&targetId=' + this.twitterId })
          this.showMoreOperate = false
          break
        default:
          break
      }
    },
    myShowToast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    },
    // 刷新上一页数据
    refreshPageDataList() {
      if (this.pageType == 1) {
        let eventChannel = this.getOpenerEventChannel()
        try {
          let data = {
            functionName: 'refreshList'
          }
          eventChannel.emit('publicChange', data)
        } catch (error) {
          console.log('刷新失败！', error)
        }
      }
    },
    // 置顶 / 取消置顶
    topUpEvent(flag) {
      let str = flag ? '取消置顶' : '置顶'
      let datas = {
        twitterId: this.twitterId
      }
      let topIndex = 0
      // 因app有分享功能
      // #ifdef APP
      topIndex = 1
      // #endif
      if (flag) {
        // 置顶
        findModel.twitterTop(datas).then(res => {
          if (res.code == 'SUCCESS') {
            this.moreBtnList.splice(topIndex, 1, str)
            this.showMoreOperate = false
            this.myShowToast('操作成功')
            this.refreshPageDataList()
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        findModel.twitterCancelTop(datas).then(res => {
          if (res.code == 'SUCCESS') {
            this.moreBtnList.splice(topIndex, 1, str)
            this.showMoreOperate = false
            this.myShowToast('操作成功')
            this.refreshPageDataList()
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 加入黑名单
    addUserBlack() {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let params = {
        userId: load(LOGIN_USERID), // 当前登录用户numberId
        blackUserId: this.infoData.userinfo.numberId // 被举报人numberId
      }
      MyInfo.addUserBlack(params).then(async res => {
        this.showBlack = false
        if (res.code == 'SUCCESS') {
          // #ifdef APP-PLUS
          let result = await this.$store.state.engie.addToBlacklist(String(this.infoData.userinfo.numberId))
          // #endif
          uni.showToast({
            title: '已屏蔽TA的动态',
            icon: 'none'
          })
          // 刷新广场列表、个人主页动态/笔记列表
          setTimeout(() => {
            let pages = getCurrentPages()
            let prevPage = pages[pages.length - 2]
            try {
              prevPage.$vm.refreshList()
            } catch (error) {}
            uni.navigateBack({ delta: 1 })
          }, 800)
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 关注/私信
    handleAttentionOrChat() {
      if (this.infoData.isAtention) {
        // 私信

        // #ifdef H5
        uni.showToast({
          title: '当前环境不支持私信功能，该操作需要在APP内进行',
          icon: 'none'
        })
        return
        // #endif
        let userInfo = this.infoData.userinfo || {}
        uni.navigateTo({ url: '/pagesMessage/privateChat/index?userId=' + userInfo.numberId })
      } else {
        // 关注
        findModel.isAtention(false, { targetNumberId: this.infoData.userinfo.numberId }).then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '关注成功',
              icon: 'none',
              duration: 1000,
              mask: true
            })
            // 手动刷新按钮状态，不频繁调用获取详情接口
            this.infoData.isAtention = !this.infoData.isAtention
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 移除黑名单
    confirmRemoveBlack() {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      MyInfo.removeUserBlack({
        blackUserId: this.infoData.userinfo.numberId
      }).then(async res => {
        this.showRemove = false
        if (res.code == 'SUCCESS') {
          // #ifdef APP-PLUS
          let result = await this.$store.state.engie.removeFromBlacklist(String(this.infoData.userinfo.numberId))
          // #endif
          uni.showToast({
            title: '已移出黑名单',
            icon: 'none'
          })
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    // 点击预览图片
    handlePreviewImg(e) {
      let list = this.infoData.twitterInfo.imgList.map(item => item.replace('!yqyq0606', ''))
      uni.previewImage({
        urls: list,
        current: e
      })
    },
    // 点击播放视频
    playVideo(type) {
      let self = this
      this.videoPlayUrl = type.videoUrl
      // #ifdef H5
      try {
        this.$nextTick(() => {
          self.videoContext.requestFullScreen({ direction: 0 })
        })
      } catch (e) {
        console.log(e)
      }
      // #endif
      // #ifndef H5
      if (this.videoPlayUrl) {
        // let obj = {
        //   _id: this.infoData.twitterInfo.twitterId, //每一个视频独有 id （自定义）
        //   userNumberId: this.infoData.twitterInfo.userNumberId, //作者numberId
        //   nickName: this.infoData.userinfo.nickName, //作者昵称
        //   href: this.infoData.userinfo.headUrl, //作者头像
        //   title: this.infoData.twitterInfo.title || '', //第一行标题
        //   msg: this.infoData.twitterInfo.content || '', //第二行内容
        //   state: 'pause', //初始状态标志（不改）
        //   isZan: this.infoData.isZan, //是否点赞了
        //   isCollect: this.infoData.isCollect, //是否收藏了
        //   zanCount: this.infoData && this.infoData.zanCount ? Number(this.infoData.zanCount) : 0, //点赞数量
        //   collectCount: this.infoData && this.infoData.collectCount ? Number(this.infoData.collectCount) : 0, //收藏数量
        //   commentCount: this.infoData && this.infoData.commentCount ? Number(this.infoData.commentCount) : 0, //评论数量
        //   src: this.infoData.twitterInfo.videoUrl, //视频链接
        //   videoImgUrl: this.infoData.twitterInfo.imageUrls || '', //视频封面
        //   pinlun: [], //评论
        //   playIng: false, //播放（默认这个即可）
        //   isShowimage: false, //是否显示封面（默认这个即可）
        //   isShowProgressBarTime: false, //是否显示进度条（默认这个即可）
        //   isplay: true //是否播放音频（默认这个即可）
        // }
        // uni.navigateTo({
        //   url: '/pages/index/appPlay?videoData=' + encodeURIComponent(JSON.stringify(obj)) + '&pageType=' + this.pageType,
        //   events: {
        //     setFullscreen() {
        //       plus.navigator.setStatusBarStyle('dark')
        //     }
        //   }
        // })
        uni.navigateTo({
          url: '/pages/my/videoPlay?url=' + this.videoPlayUrl,
          events: {
            setFullscreen() {
              plus.navigator.setFullscreen(false)
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    /**
     * @param {Object} e 视频是否进入全屏
     */
    videoFullScreenChange(e) {
      if (e.detail.fullScreen) {
        // 开始播放
        this.videoContext.play()
      } else {
        // 停止播放，销毁数据源
        this.videoContext.pause()
        this.videoPlayUrl = null
      }
    },
    // 获取精选评论列表(不分页)
    getFeatureList() {
      let params = {
        twitterId: this.twitterId,
        commentType: this.pageType == 1 ? 'TWITTER' : 'NOTES'
      }
      findModel
        .getFeatureCommentList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.selectedCommentList || []
            if (list.length) {
              list.map(item => {
                item.imgList = item.contentImg ? item.contentImg.split('&&') : []
                item.contentArr = []
                item.childCommentDTO = []
                try {
                  JSON.parse(item.content)
                  item.contentArr = JSON.parse(item.content)
                } catch (error) {
                  let arr = [{ type: 'text', text: item.content }]
                  item.contentArr = arr
                }
              })
            }
            this.featureList = list
            this.showLoading = false
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 获取一级评论列表(分页)
    getCommentList() {
      let params = {
        twitterId: this.twitterId,
        pageSize: this.pageSize,
        lastKeyWord: this.lastKeyWord
      }
      findModel
        .commentList2(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.commentList.list
            this.firstLoadStatus = !res.data.commentList.hasNextPage ? 'nomore' : 'loadmore'
            if (list.length > 0) {
              list.map(item => {
                item.secondLoadStatus = 'loadmore'
                item.imgList = item.contentImg ? item.contentImg.split('&&') : []
                item.contentArr = []
                item.tempChildArr = [] // 前端存的临时的二级回复数组
                item.childLastKeyword = ''
                try {
                  JSON.parse(item.content)
                  item.contentArr = JSON.parse(item.content)
                } catch (error) {
                  let arr = [{ type: 'text', text: item.content }]
                  item.contentArr = arr
                }
                // 处理一级评论默认显示的第一条二级评论格式
                if (item.childCommentDTO) {
                  let itemData = { ...item.childCommentDTO }
                  itemData.contentArr = []
                  itemData.imgList = itemData.contentImg ? itemData.contentImg.split('&&') : []
                  try {
                    JSON.parse(itemData.content)
                    itemData.contentArr = JSON.parse(itemData.content)
                  } catch (error) {
                    let arr = [{ type: 'text', text: itemData.content }]
                    itemData.contentArr = arr
                  }
                  item.childCommentDTO = [{ ...itemData }]
                  item.tempChildArr = [{ ...itemData }]
                } else {
                  item.childCommentDTO = []
                  item.tempChildArr = []
                }
              })
              this.commentList.push(...list)
              this.lastKeyWord = res.data.commentList.lastKeyWord
            } else {
              this.lastKeyWord = ''
            }
            this.showLoading = false
          } else {
            this.showLoading = false
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 获取评论子集(分页)
    getChildList(item, index) {
      let params = {
        commentId: item.commentId,
        pageSize: this.pageSize,
        lastKeyWord: this.commentList[index].childLastKeyword || ''
      }
      this.commentList[index].secondLoadStatus = 'loading'
      findModel
        .commentChild(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.commentList.list || []
            this.commentList[index].secondLoadStatus = !res.data.commentList.hasNextPage ? 'nomore' : 'loadmore'
            if (list.length > 0) {
              list.map(item => {
                item.imgList = item.contentImg ? item.contentImg.split('&&') : []
                item.contentArr = []
                try {
                  JSON.parse(item.content)
                  item.contentArr = JSON.parse(item.content)
                } catch (error) {
                  let arr = [{ type: 'text', text: item.content }]
                  item.contentArr = arr
                }
              })
              let newList = []
              if (this.commentList[index].tempChildArr.length) {
                // 进行比对剔除重复的再push
                newList = list.filter(item => !this.commentList[index].tempChildArr.some(v => v.commentId === item.commentId))
                this.commentList[index].childCommentDTO.push(...newList)
              } else {
                // 不用比对直接push
                this.commentList[index].childCommentDTO.push(...list)
              }
              this.commentList[index].childLastKeyword = res.data.commentList.lastKeyWord
            } else {
              this.commentList[index].childLastKeyword = ''
            }
          } else {
            this.commentList[index].secondLoadStatus = 'none'
            this.$refs.uToast.show({
              ...res
            })
          }
        })
        .catch(err => {
          this.commentList[index].secondLoadStatus = 'none'
        })
    },
    // 刷新普通评论列表评论点赞状态和点赞数
    refreshCommentZan(arr, data) {
      if (data.isFeature) {
        // 点赞的是精选列表里面的评论，前端无法找到普通列表中对应的评论去刷新，所以重新请求
        this.showLoading = true
        this.commentList = []
        this.lastKeyWord = ''
        this.firstLoadStatus = 'loadmore'
        this.getCommentList()
      } else {
        // 点赞的是普通列表里面的评论，前端刷新
        let list = arr || []
        if (list.length) {
          list.forEach(item => {
            if (item.commentId == data.commentId) {
              item.isZan = !data.isZan
              if (data.isZan) {
                item.zanCount = parseInt(item.zanCount) + 1
              } else {
                item.zanCount = parseInt(item.zanCount) == 1 ? '0' : parseInt(item.zanCount) - 1
              }
            }
          })
        }
      }
    },
    // 点赞评论，type=='first'：一级评论；  否则：二级评论，type为一级评论索引
    handleLikeComment(item, type) {
      let list = []
      if (type == 'first') {
        list = this.commentList
      } else {
        this.currCommentIndex = type
        list = this.commentList[type].childCommentDTO || []
      }
      if (item.isZan) {
        // 取消点赞
        findModel.zanCommentCancel({ commentId: item.commentId }).then(res => {
          if (res.code == 'SUCCESS') {
            // 刷新精选评论列表
            this.featureList.map(v => {
              if (v.commentId == item.commentId) {
                v.isZan = false
                v.zanCount = parseInt(v.zanCount) > 0 ? parseInt(v.zanCount) - 1 : 0
              }
            })
            // 刷新普通评论列表
            this.refreshCommentZan(list, item)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        // 点赞
        findModel.zanComment({ commentId: item.commentId }).then(res => {
          if (res.code == 'SUCCESS') {
            // 刷新精选评论列表
            this.featureList.map(v => {
              if (v.commentId == item.commentId) {
                v.isZan = true
                v.zanCount = parseInt(v.zanCount) + 1
              }
            })
            // 刷新普通评论列表
            this.refreshCommentZan(list, item)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 送礼物
    handleSendGift() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let obj = {
        type: '1',
        openUrl: '/giveGift/searchList/yiqi',
        userId: this.infoData.userinfo.numberId,
        enterType: 1
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    // 点赞动态
    handleLikeDynamic() {
      if (this.infoData.isZan) {
        // 取消点赞
        findModel.zanTwitterCancel({ twitterId: this.twitterId }).then(res => {
          if (res.code == 'SUCCESS') {
            this.infoData.isZan = !this.infoData.isZan
            this.infoData.zanCount = parseInt(this.infoData.zanCount) - 1
            // 刷新上一个页面的点赞数
            try {
              const eventChannel = this.getOpenerEventChannel()
              eventChannel.emit('zanCountChange', 'sub')
            } catch (e) {
              console.log(`上一个页面的点赞数 -1 失败`)
            }
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        // 点赞
        findModel.zanTwitter({ twitterId: this.twitterId }).then(res => {
          if (res.code == 'SUCCESS') {
            this.infoData.isZan = !this.infoData.isZan
            this.infoData.zanCount = parseInt(this.infoData.zanCount) + 1
            // 刷新上一个页面的点赞数
            try {
              const eventChannel = this.getOpenerEventChannel()
              eventChannel.emit('zanCountChange', 'add')
            } catch (e) {
              console.log(`上一个页面的点赞数 +1 失败`)
            }
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 收藏动态
    handleCollect() {
      if (this.infoData.isCollect) {
        // 取消收藏
        findModel.twitterCancelCollect({ twitterId: this.twitterId }).then(res => {
          if (res.code == 'SUCCESS') {
            this.infoData.isCollect = !this.infoData.isCollect
            this.infoData.collectCount = parseInt(this.infoData.collectCount) - 1
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        // 收藏
        findModel.twitterCollect({ twitterId: this.twitterId }).then(res => {
          if (res.code == 'SUCCESS') {
            this.infoData.isCollect = !this.infoData.isCollect
            this.infoData.collectCount = parseInt(this.infoData.collectCount) + 1
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 刷新数量
    refreshFindDetailsCount(data) {
      let { countField, flagField, type } = data
      if (type == 'sub') {
        this.infoData[countField] = Number(this.infoData[countField]) - 1
        this.infoData[flagField] = false
      } else {
        this.infoData[countField] = Number(this.infoData[countField]) + 1
        this.infoData[flagField] = true
      }
    },
    // 转发动态
    handleForward() {
      let data = {
        nickName: this.infoData.userinfo.nickName,
        quoteInfoDTO: this.infoData.twitterInfo.quoteInfoDTO ? this.infoData.twitterInfo.quoteInfoDTO : {},
        twitterId: this.infoData.twitterInfo.twitterId,
        content: this.infoData.twitterInfo.content,
        imageUrls: this.infoData.twitterInfo.imageUrls,
        videoUrl: this.infoData.twitterInfo.videoUrl
      }
      getApp().globalData.transformDynamicData = data
      this.$nextTick(() => {
        uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s1&isTransDynamic=1' })
      })
    },
    // 打开评论动态弹窗
    openComment() {
      this.placeholder = '文明用语，友善交流…'
      this.showComment = true
    },
    // 点击回复
    handleReply(item, index) {
      this.isFeature = item.isFeature
      this.currCommentId = item.commentId
      this.currCommentIndex = index
      this.placeholder = '回复' + item.userinfo.nickName + '：'
      this.showComment = true
    },
    // 发送评论
    async handleSendComment(data, type) {
      await this.getPoints()
      this.showComment = false
      // 刷新上一个页面的评论数，接口有异常，可能会超时，所以提前加，不管接口是否成功
      try {
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.emit('commentCountChange', 'add')
      } catch (e) {
        console.log(`上一个页面的评论数 +1 失败`)
      }
      let params = {
        content: data.content,
        contentImg: data.contentImg || '',
        taNumberIds: data.taNumberIds || '',
        commentType: this.pageType == 2 ? 'NOTES' : 'TWITTER',
        position: this.position
      }
      let contentData = JSON.parse(data.content) ? JSON.parse(data.content) : []
      let contentStr = ''
      if (contentData.length) {
        let contentTextArr = contentData.find(item => item.type == 'text')
        contentStr = contentTextArr.text
      }
      this.showSendLoading = true
      if (type == 2) {
        // 二级评论
        params.commentId = this.currCommentId
        params.reply = true
        findModel
          .commentCreateChild(params)
          .then(res => {
            if (res.code == 'SUCCESS') {
              let comment = res.data.comment
              comment.imgList = comment.contentImg ? comment.contentImg.split('&&') : []
              comment.contentArr = []
              try {
                JSON.parse(comment.content)
                comment.contentArr = JSON.parse(comment.content)
              } catch (error) {
                let arr = [{ type: 'text', text: comment.content }]
                comment.contentArr = arr
              }
              // 总评论数 +1
              this.infoData.commentCount++

              if (this.isFeature) {
                // 精选回复
                // // 往二级评论列表最前方添加数据
                // this.featureList[this.currCommentIndex].childCommentDTO.unshift(comment)

                // 刷新列表
                this.showLoading = true
                this.commentList = []
                this.lastKeyWord = ''
                this.firstLoadStatus = 'loadmore'
                this.getCommentList()
              } else {
                // 普通回复
                // 1. 是否显示“展开”
                let flag = Number(this.commentList[this.currCommentIndex].commentCount) > 1 && this.commentList[this.currCommentIndex].secondLoadStatus === 'loadmore' ? true : false

                if (!flag) {
                  // 没有展开，无需存储临时回复数据进行比对
                  this.commentList[this.currCommentIndex].tempChildArr = []
                } else {
                  // 存储临时回复数据便于与点击展开时获取的数据进行比对去重
                  this.commentList[this.currCommentIndex].tempChildArr.unshift(comment)
                }
                // 避免新push的二级评论下方都出现展开xx条回复
                comment.notShow = true
                // 往二级评论列表最前方添加数据
                this.commentList[this.currCommentIndex].childCommentDTO.unshift(comment)
              }
              this.showSendLoading = false
              uni.showToast({
                title: '评论成功',
                icon: 'none',
                duration: 1000
              })
              if (!this.isFinished && contentStr && contentStr.length >= 5) {
                this.showBonus = true
                setTimeout(() => {
                  this.showBonus = false
                }, 3000)
              }
            } else {
              this.showSendLoading = false
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showSendLoading = false
          })
      } else {
        // 一级评论
        params.twitterId = this.twitterId
        findModel
          .commentCreate(params)
          .then(res => {
            if (res.code == 'SUCCESS') {
              let comment = res.data.comment
              comment.imgList = comment.contentImg ? comment.contentImg.split('&&') : []
              comment.contentArr = []
              comment.tempChildArr = [] // 前端存的临时的二级回复数组
              comment.childLastKeyword = ''
              try {
                JSON.parse(comment.content)
                comment.contentArr = JSON.parse(comment.content)
              } catch (error) {
                let arr = [{ type: 'text', text: comment.content }]
                comment.contentArr = arr
              }
              comment.childCommentDTO = []
              // 总评论数 +1
              this.infoData.commentCount++
              // 往一级评论列表最前方添加数据
              this.commentList.unshift(comment)
              this.showSendLoading = false
              uni.showToast({
                title: '评论成功',
                icon: 'none',
                duration: 1000
              })
              if (!this.isFinished && contentStr && contentStr.length >= 5) {
                this.showBonus = true
                setTimeout(() => {
                  this.showBonus = false
                }, 3000)
              }
            } else {
              this.showSendLoading = false
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showSendLoading = false
          })
      }
    },
    // 查询评论积分
    async getPoints() {
      let res = await MyInfo.getTaskList({ taskNo: 'TK240328006' })
      if (res.code == 'SUCCESS') {
        if (res.data && res.data.list) {
          let list = res.data.list
          this.score = list[0].taskReward ? list[0].taskReward.count : 0
          this.isFinished = list[0].isFinished
        }
      }
    },
    // 长按评论显示更多操作
    openCommentOperate(item, index) {
      this.isFeature = item.isFeature
      this.currCommentIndex = index
      this.currCommentData = { ...item }
      if (this.isSelf) {
        let str = item.isFeature ? '取消精选评论' : '设为精选评论'
        this.commentBtnList.splice(0, 1, str)
      }
      if (item.userinfo.numberId == this.currUserId) {
        this.commentBtnList.splice(this.commentBtnList.length - 1, 1, '删除')
      } else {
        this.commentBtnList.splice(this.commentBtnList.length - 1, 1, '举报')
      }
      this.showCommentOperate = true
    },
    handleBtnClick(index, item) {
      switch (item) {
        case '设为精选评论':
          this.handleSetComment(true)
          break
        case '取消精选评论':
          this.handleSetComment(false)
          break
        case '复制':
          this.handleCopy(2)
          break
        case '删除':
          this.showCommentOperate = false
          this.delContent = '您确定要删除此评论？'
          this.showDel = true
          break
        case '举报':
          let userId = this.currCommentData?.userinfo?.numberId
          uni.navigateTo({ url: '/pagesCommon/message/report?userId=' + userId + '&reportTargetType=COMMENT' + '&targetId=' + this.currCommentData.commentId })
          this.showCommentOperate = false
          break
        default:
          break
      }
    },
    // 设为/取消精选评论
    handleSetComment(flag) {
      if (flag) {
        // 设为精选
        findModel
          .topComment({ commentId: this.currCommentData.commentId })
          .then(res => {
            this.showCommentOperate = false
            if (res.code == 'SUCCESS') {
              uni.showToast({
                title: '设置成功',
                icon: 'none'
              })
              this.showLoading = true
              // 刷新精选评论列表
              this.getFeatureList()
            } else {
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showCommentOperate = false
          })
      } else {
        // 取消精选
        findModel
          .cancelTopComment({ commentId: this.currCommentData.commentId })
          .then(res => {
            this.showCommentOperate = false
            if (res.code == 'SUCCESS') {
              uni.showToast({
                title: '取消精选',
                icon: 'none'
              })
              this.showLoading = true
              // 刷新精选评论列表
              this.getFeatureList()
            } else {
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showCommentOperate = false
          })
      }
    },
    /**
     * 用来解决长按事件敏感触发的问题
     * touchEnd
     * touchMove
     */
    touchEnd() {
      this.isLongtap = true
    },
    // 手指触摸后的移动事件
    touchMove() {
      this.isLongtap = false
    },
    // 复制
    handleCopy(type) {
      if (this.isLongtap) {
        let content = ''
        if (type == 1) {
          // 复制动态/笔记内容
          content = this.describe
        } else {
          // 复制评论内容
          try {
            JSON.parse(this.currCommentData.content)
            let arr = JSON.parse(this.currCommentData.content) || []
            content = arr.map(item => item.text).join('')
          } catch (error) {
            content = this.currCommentData.content || ''
          }
        }
        this.showCommentOperate = false
        uni.setClipboardData({
          data: content,
          success: function () {
            uni.showToast({
              title: '已复制',
              icon: 'none'
            })
          }
        })
      }
    },
    // 删除-确认
    confirmDel() {
      if (this.delContent == '您确定要删除此评论？') {
        // 删除评论
        findModel
          .commentCancel({ commentId: this.currCommentData.commentId })
          .then(res => {
            this.showDel = false
            if (res.code == 'SUCCESS') {
              // 总评论数 -1
              this.infoData.commentCount--
              // 刷新上一个页面的评论数
              try {
                const eventChannel = this.getOpenerEventChannel()
                eventChannel.emit('commentCountChange', 'del')
              } catch (e) {
                console.log(`上一个页面的评论数 -1 失败`)
              }
              this.showLoading = true
              // 刷新精选评论列表
              this.getFeatureList()
              // 刷新普通评论列表
              this.commentList = []
              this.lastKeyWord = ''
              this.firstLoadStatus = 'loadmore'
              this.getCommentList()
            } else {
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showDel = false
          })
      } else {
        // 删除动态/笔记
        findModel
          .twitterDel({ twitterId: this.twitterId })
          .then(res => {
            this.showDel = false
            if (res.code == 'SUCCESS') {
              uni.showToast({
                title: '删除成功',
                icon: 'none',
                mask: true
              })
              setTimeout(() => {
                // 刷新广场/笔记列表、个人主页动态/笔记列表
                let pages = getCurrentPages()
                let prevPage = pages[pages.length - 2]
                try {
                  prevPage.$vm.refreshList()
                } catch (error) {}
                uni.navigateBack({ delta: 1 })
              }, 800)
            } else {
              this.$refs.uToast.show({
                ...res
              })
            }
          })
          .catch(err => {
            this.showDel = false
          })
      }
    },
    // 分享
    handleShare() {
      if (this.infoData.twitterInfo.checkState == 1) {
        return uni.showToast({
          title: '待审核通过后才可分享',
          icon: 'none'
        })
      }
      this.showMoreOperate = false
      // 弹窗分享弹窗
      let title = this.infoData.userinfo.nickName + `的${this.pageType == 1 ? '动态' : '笔记'}`
      let shareObj = {
        type: 5,
        title: title,
        content: this.infoData.twitterInfo.title || this.infoData.twitterInfo.content, // 笔记优先取标题，没写标题就取内容
        imageUrl: 'http://img.yiqitogether.com/static/img/yq_logo.png',
        // 小程序对应页面
        path: `/packageFind/find/findDetails?twitterId=${this.twitterId}&pageType=${this.pageType}`,
        // h5对应页面
        href: `/pages/find/findDetails?twitterId=${this.twitterId}&pageType=${this.pageType}`,
        targetId: this.twitterId,
        // 是否展示推荐/转发
        isShowRecommend: true,
        isShowForward: true
      }
      this.shareData = shareObj
      this.sharePopupFlag = true
    },
    // 去个人主页
    goMyPage(numberId) {
      /**
       * checkedTab： 3笔记、4动态
       */
      let checkedTab = 4
      if (this.pageType == 2) {
        checkedTab = 3
      } else {
        checkedTab = 4
      }
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + numberId + '&checkedTab=' + checkedTab })
    },
    // 去对应的路径
    goJumpUrl(jumpUrl) {
      if (!jumpUrl) {
        return
      }
      uni.navigateTo({ url: jumpUrl })
    },
    // 去话题页面
    goTopic(item) {
      if (this.pageType == 1) {
        // 动态话题
        // uni.navigateTo({ url: '/pagesFind/find/dynamicTag?topicName=' + item })
        uni.navigateTo({ url: '/pagesFind/find/topics?topicName=' + item + '&twitterType=TWITTER' })
      } else {
        // 笔记话题
        // uni.navigateTo({ url: '/pagesFind/find/topic?topicName=' + item })
        uni.navigateTo({ url: '/pagesFind/find/topics?topicName=' + item + '&twitterType=NOTES' })
      }
    },
    // 打开地图
    goMap() {
      let info = {}
      info.place = this.infoData.twitterInfo.positionShortName
      info.position = this.infoData.twitterInfo.position
      openMap(info)
    },
    /**
     * 选择合集，并调用移入合集请求
     */
    changeCompilations() {
      let self = this
      uni.navigateTo({
        url: `/pagesMy/my/compilations/compilationsList?from=release`,
        events: {
          selectGroup: function (noteGroup) {
            self.showMoreOperate = false
            self.shiftInGroup(noteGroup)
          }
        }
      })
    },
    /**
     * 发送请求，将帖子移入指定合集请求
     * noteGroup 合集对象
     */
    shiftInGroup(noteGroup) {
      let params = {
        groupId: noteGroup.groupId || '',
        twitterId: this.twitterId
      }
      findModel.moveToGroup(params).then(res => {
        if (res.code == 'SUCCESS') {
          this.infoData.twitterInfo.groupName = noteGroup.groupName
          const eventChannel = this.getOpenerEventChannel()
          let data = {
            functionName: 'changePageList',
            twitterId: this.twitterId,
            zanCount: this.infoData.zanCount,
            groupId: noteGroup.groupId
          }
          /**
           * 触发笔记瀑布流组件的公共事件
           */
          eventChannel.emit('publicChange', data)
          uni.showToast({
            title: '操作成功',
            icon: 'none'
          })
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    /**
     * 待审核提示
     */
    hint() {
      uni.showToast({
        title: '由于发布的内容存在涉及色情、暴力等敏感信息，需等待系统审核后公开',
        icon: 'none',
        class: 'hint-toast'
      })
    },
    // 赠送积分礼物成功，弹出提示弹窗
    handleTip(data) {
      this.showReward = false
      this.giftData = data
      this.showTip = true
      setTimeout(() => {
        this.showTip = false
      }, 2500)
    },
    // 赠送靓靓礼物成功，弹出提示（方法名是为了同消息那边保持一致）
    scrollToBottom() {
      // this.showReward = false
      // this.showGiftTip = true
      // setTimeout(() => {
      //   this.showGiftTip = false
      // }, 2500)
    }
  }
}
</script>

<style lang="scss" scoped>
.find-details-page {
  width: 100vw;
  min-height: 100vh;
  background-color: #fff;

  .nav-container {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: var(--status-bar-height);
    position: sticky;
    top: 0;
    left: 0;
    z-index: 99;
    background-color: #fff;
    .nav-back {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-title {
      flex: 1;
      display: flex;
      align-items: center;
      .user-avatar {
        width: 70rpx;
        height: 70rpx;
        border-radius: 50%;
        margin-right: 20rpx;
        flex-shrink: 0;
      }
    }
    .nav-btn {
      flex-shrink: 0;
      // font-size: 24rpx;
      // color: #FE5E10;
      // line-height: 32rpx;
      // padding: 8rpx 24rpx;
      // border: 1rpx solid #FE5E10;
      // border-radius: 32rpx;
      margin-left: 20rpx;
    }
    .nav-icon {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 24rpx;
    }
  }
  .fwb-top {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: var(--status-bar-height);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99;
    background: linear-gradient(180deg, rgba(0, 0, 0, 0.26), rgba(0, 0, 0, 0));
    .nav-back {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-title {
      flex: 1;
      display: flex;
      align-items: center;
      .user-avatar {
        width: 70rpx;
        height: 70rpx;
        border-radius: 50%;
        margin-right: 20rpx;
        flex-shrink: 0;
      }
    }
    .nav-icon {
      flex-shrink: 0;
      width: 40rpx;
      height: 40rpx;
      padding: 24rpx;
    }
    .nav-btn {
      flex-shrink: 0;
      // font-size: 24rpx;
      // color: #FE5E10;
      // line-height: 32rpx;
      // padding: 8rpx 24rpx;
      // border: 1rpx solid #FE5E10;
      // border-radius: 32rpx;
      margin-right: 20rpx;
    }
  }

  .user-name {
    font-size: 26rpx;
    color: #484848;
    line-height: 36rpx;
  }

  .lunbo {
    position: relative;
    margin-bottom: 20rpx;

    /deep/ .u-swiper-indicator__wrapper__dot {
      width: 12rpx;
      height: 12rpx;
    }
    /deep/.u-swiper-indicator__wrapper__dot--active {
      width: 12rpx;
    }

    .video-img {
      width: 100%;
      display: block;
    }
    .play-icon {
      width: 112rpx;
      height: 112rpx;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 2;
    }
  }

  .main-container {
    background-color: #fff;
    padding: 0 0 132rpx;
    box-sizing: border-box;
    overflow-y: auto;
    .fwb-box {
      background: #ffffff;
      position: relative;
      z-index: 1;
      margin-top: -60rpx;
      border-radius: 40rpx 40rpx 0 0;
      box-sizing: border-box;
      width: 100%;

      padding-top: 36rpx !important;
    }
    .main-title {
      font-size: 32rpx;
      color: #333333;
      line-height: 48rpx;
      margin-bottom: 20rpx;
      font-weight: bold;
      line-break: anywhere;
      word-break: break-all;
    }
    .main-user {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 30rpx;
      .user-box {
        display: flex;
        align-items: center;
        .user-img {
          width: 40rpx;
          height: 40rpx;
          border-radius: 50%;
          margin-right: 10rpx;
        }
        .user-name {
          font-size: 24rpx;
          color: #484848;
        }
      }
      .user-text {
        width: 130rpx;
        height: 32rpx;
        font-size: 24rpx;
        color: #bdc1c5;
      }
    }

    .top-wrap {
      display: flex;
      margin: 36rpx 0 24rpx;
      align-items: flex-start;
      .avatar-img {
        flex-shrink: 0;
        width: 90rpx;
        height: 90rpx;
        background: #d8d8d8;
        border-radius: 50%;
      }
      .user-info {
        flex: 1;
        margin: 8rpx 20rpx 0;

        .others {
          font-size: 22rpx;
          color: #c0c6cc;
          line-height: 32rpx;
          margin-top: 8rpx;
          display: flex;
          align-items: center;

          .sex-img {
            width: 30rpx;
            height: 30rpx;
            margin-right: 4rpx;
          }
        }
      }
      .attention-btn {
        flex-shrink: 0;
        // width: 104rpx;
        // height: 52rpx;
        // background: linear-gradient(270deg, #ff86be, #ffa59a);
        // border-radius: 28rpx;
        // font-size: 26rpx;
        // color: #fff;
        // text-shadow: 0 2rpx 8rpx 0 rgba(236, 78, 124, 0.5);
        // text-align: center;
        // line-height: 52rpx;
      }
    }

    .word-wrap {
      .fold-text {
        font-size: 28rpx;
        color: #484848;
        line-height: 46rpx;
        text-align: justify;
        word-break: break-all;
        line-break: anywhere;
        white-space: pre-wrap;
      }
      .ellipsis {
        display: -webkit-box;
        overflow: hidden;
        line-clamp: 5;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
      }
      .fold-btn {
        font-size: 28rpx;
        line-height: 46rpx;
        color: #bdc1c5;
      }
    }
    .ql-container {
      width: 100%;
      height: 100%;
      // min-height: 800rpx;
      font-size: 26rpx;
      font-family: Apple Color Emoji, Apple Color Emoji-Regular;
      font-weight: Regular;
      text-align: left;
      color: #2a343e;
      line-height: 46rpx;
      box-sizing: border-box;
    }

    .imgs-wrap {
      margin: 24rpx -6rpx 8rpx 0;
      display: flex;
      flex-wrap: wrap;
      .img-item {
        width: 222rpx;
        height: 222rpx;
        margin-right: 6rpx;
        margin-bottom: 6rpx;
        font-size: 0;
        position: relative;
        .img {
          width: 100%;
          height: 100%;
          border-radius: 16rpx;
        }
        .video-icon {
          width: 52rpx;
          height: 52rpx;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          z-index: 9;
        }
      }
    }

    .card-wrap {
      margin-top: 20rpx;
    }

    .topic-wrap {
      display: flex;
      flex-wrap: wrap;
      margin-left: -10rpx;
      margin-top: 10rpx;
    }
    .tag-box {
      height: 50rpx;
      padding: 0 16rpx;
      background: #f6f6f8;
      border-radius: 22rpx;
      margin: 10rpx;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      .tag-box-icon {
        width: 24rpx;
        height: 24rpx;
      }
      .tag-box-text {
        font-size: 24rpx;
        color: #2a343e;
        line-height: 34rpx;
        font-weight: bold;
      }
    }
    .tag-box1 {
      height: 50rpx;
      padding: 0 16rpx;
      border-radius: 22rpx;
      margin: 10rpx;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      .tag-box-text {
        font-size: 24rpx;
        color: #2a343e;
        line-height: 34rpx;
        font-weight: bold;
      }
      .card-tag-pointIcon {
        width: 24rpx;
        height: 24rpx;
        margin-right: 4rpx;
        vertical-align: middle;
      }
      .card-tag-narright {
        width: 10rpx;
        height: 16rpx;
        margin-left: 10rpx;
      }
    }
    .time-wrap {
      font-size: 24rpx;
      color: #a6acb2;
      line-height: 34rpx;
      margin-top: 20rpx;
    }
    .compilation-icon {
      width: 28rpx;
      height: 28rpx;
      display: inline-block;
    }

    .reward-wrap {
      text-align: center;
      padding: 40rpx 0 20rpx;
      font-size: 0;
      .reward-img {
        width: 130rpx;
        height: 130rpx;
      }
      .reward-text {
        font-size: 20rpx;
        text-align: center;
        color: #9fa7b4;
        line-height: 28rpx;
        margin-top: 12rpx;
      }
    }

    .comment-wrap {
      border-top: 2rpx solid #f9f9fb;
      margin-top: 20rpx;
      background-color: #fff;

      .title-box {
        padding: 20rpx 0;
        font-weight: bold;
        .title-box-text {
          font-size: 28rpx;
          color: #373d44;
          line-height: 40rpx;
          margin-right: 12rpx;
        }
        .title-box-num {
          font-size: 24rpx;
          color: #c7cbcf;
          line-height: 34rpx;
        }
      }

      .input-box {
        display: flex;
        align-items: center;
        &-avatar {
          flex-shrink: 0;
          width: 60rpx;
          height: 60rpx;
          border-radius: 50%;
          margin-right: 24rpx;
        }
        &-tips {
          flex: 1;
          font-size: 26rpx;
          color: #c1c1c1;
          line-height: 36rpx;
          padding: 16rpx 24rpx;
          background: #f6f6f8;
          border-radius: 34rpx;
        }
      }

      .comment-list {
        padding: 48rpx 0 54rpx;
      }
    }
  }

  .bottom-container {
    width: 100%;
    padding: 24rpx 10rpx 30rpx 24rpx;
    box-sizing: border-box;
    background-color: #fff;
    display: flex;
    align-items: center;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 99;

    .left-comment {
      flex: 1;
      height: 76rpx;
      background: #f6f6f8;
      border-radius: 40rpx;
      display: flex;
      align-items: center;
      padding: 0 20rpx;
      font-size: 24rpx;
      color: #adb3ba;
      margin-right: 20rpx;

      .left-icon {
        width: 30rpx;
        height: 30rpx;
        margin-right: 12rpx;
      }
    }
    .right-operate {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      .operate-box {
        flex: 1;
        text-align: center;
        font-size: 0;
        padding: 0 20rpx;
        &-icon {
          width: 44rpx;
          height: 44rpx;
          margin-bottom: 2rpx;
        }
        &-text {
          font-size: 22rpx;
          color: #484848;
          line-height: 32rpx;
          word-break: keep-all;
        }
      }
    }
  }

  .popup-content {
    font-size: 24rpx;
    text-align: center;
    color: #333333;
    line-height: 46rpx;
    padding: 0 50rpx;
    box-sizing: border-box;
  }
}

.fixed-page {
  height: 100vh;
  overflow: hidden;
}
.editor-info-box {
  padding: 0 36rpx;
  font-size: 26rpx;
  color: #484848;
  line-height: 46rpx;
  word-break: break-all;
  white-space: pre-wrap;
  overflow: hidden;
  max-width: 100%;

  img {
    width: 90% !important;
    display: block;
    margin: 10rpx auto;
  }
}
.flex-0 {
  display: flex;
  align-items: center;
}
.peddingbox {
  background: #ffefe7;
  border-radius: 28rpx;
  padding: 6rpx 12rpx;
  .peddingbox-img {
    width: 28rpx;
    height: 28rpx;
    margin-right: 6rpx;
    display: block;
    margin-top: 2rpx;
  }
  .paddingbox-text {
    font-size: 24rpx;
    color: #fd5e0f;
    line-height: 40rpx;
  }
}
.tip-popup {
  /deep/.u-popup__content {
    background-color: transparent;
  }
  /deep/.u-transition {
    justify-content: flex-end !important;
  }
  .tip-box {
    width: 270rpx;
    height: 68rpx;
    background-image: url(../../static/images/reward_tip_bg.png);
    background-size: cover;
    display: flex;
    align-items: center;
    margin-bottom: 220rpx;

    .tip-avatar {
      width: 60rpx;
      height: 60rpx;
      border-radius: 50%;
      margin: 0 4rpx;
    }
    .tip-content {
      width: 108rpx;
      .tip-content-name {
        font-size: 24rpx;
        color: #ffffff;
        line-height: 34rpx;
        font-weight: bold;
      }
      .tip-content-desc {
        font-size: 18rpx;
        color: #fff5ea;
        line-height: 26rpx;
      }
    }
    .tip-img {
      width: 100rpx;
      height: 100rpx;
      margin-top: -20rpx;
    }
  }
  .tip-num {
    font-size: 28rpx;
    font-weight: bold;
    color: #ff945e;
    line-height: 44rpx;
    position: absolute;
    top: -16rpx;
    left: 100%;
  }
  .gift-box {
    width: 380rpx;
    background: #ffffff;
    border-radius: 20rpx;
    padding: 20rpx;
    box-sizing: border-box;
    margin-bottom: 320rpx;

    .gift-top {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32rpx;
      color: #1c1c1c;

      .gift-icon {
        width: 60rpx;
        height: 60rpx;
        margin-right: 8rpx;
      }
    }

    .gift-desc {
      font-size: 24rpx;
      color: #838e9a;
      line-height: 34rpx;
      margin-top: 10rpx;
      text-align: center;
    }
  }
}
</style>
