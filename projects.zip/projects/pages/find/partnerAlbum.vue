<template>
  <view class="partner-album-pages">
    <view class="header-box flex-1">
      <view class="header-box-left flex-0" @click="goBack()">
        <image class="left-icon" src="/static/images/back_black.png" mode="scaleToFill" />
        <view class="left-box"></view>
      </view>
    </view>
    <view class="album-pages-body">
      <view class="body-item">
        <view class="item-box" v-for="(mainItem, mainIndex) in privatePhotoDTO" :key="mainIndex">
          <view class="item-time" v-if="mainIndex == 0 || mainItem.createTime != privatePhotoDTO[mainIndex - 1].createTime">
            <text>{{ mainItem.createTime }}</text>
          </view>
          <view class="item-img-box flex-1">
            <block v-for="(item, index) in mainItem.photoDTOList" :key="index">
              <image class="item-img" :src="item.imgUrl" mode="aspectFill" @click="goPhotoDetails(mainItem, index)" />
            </block>
          </view>
        </view>
      </view>
    </view>
    <view v-if="privatePhotoDTO.length > 0" class="tips-box" @click="loadMore">
      <u-loadmore :status="loadStatus" :fontSize="23" nomore-text="到底了~" />
    </view>
  </view>
</template>
<script>
// 导入接口
import findModel from '@/model/find.js'

// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { LOGIN_USERID } from '@/utils/cacheKey.js'
export default {
  data() {
    return {
      targetNumberId: '',
      privatePhotoDTO: [], // 用户相册
      numberId: load(LOGIN_USERID).toString() || '', // 本人的numberId
      loadStatus: 'loadmore',
      pages: 0,
      pageNumber: 0
    }
  },
  onLoad(e) {
    this.targetNumberId = e.targetNumberId
    console.log('🚀 ~ onLoad ~ this.targetNumberId:', this.targetNumberId)
    this.getDefaultAlbum()
  },
  onReachBottom() {
    this.loadMore()
  },
  methods: {
    /**
     * 获取用户相册
     */
    getDefaultAlbum() {
      let params = {
        pageNo: this.pageNumber + 1,
        pageSize: 10,
        targetNumberId: this.targetNumberId
      }
      console.log('🚀 ~ getDefaultAlbum ~ params:', params)
      findModel
        .getDefaultAlbum(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.defaultAlbum || []
            let previewList = []
            if (list.length) {
              list.map(item => {
                item.createTime = uni.$u.timeFormat(item.dateStamp, 'handleDate')
                item.photoDTOList.map(item => {
                  previewList.push(item)
                })
              })
            }

            setTimeout(() => {
              if (this.privatePhotoDTO.length > 0) {
                for (let i = this.privatePhotoDTO.length - 1; i >= 0; i--) {
                  for (let j = 0; j < list.length; j++) {
                    if (this.privatePhotoDTO[i].createTime == list[j].createTime) {
                      this.privatePhotoDTO[i].photoDTOList = [...this.privatePhotoDTO[i].photoDTOList, ...list[j].photoDTOList]
                      list.splice(j, 1)
                    }
                  }
                }
              }
              this.privatePhotoDTO = [...this.privatePhotoDTO, ...list]
            }, 50)

            this.pages = res.data.pages
            this.pageNumber = res.data.pageNumber
            if (res.data.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.pages <= res.data.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          } else {
            this.loadStatus = 'none'
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 加载更多
     */
    loadMore() {
      if (this.pages > this.pageNumber) {
        this.getDefaultAlbum()
      }
    },
    /**
     * 照片详情
     */
    goPhotoDetails(item, index) {
      getApp().globalData.albumPreviewList = item.photoDTOList
      let isMyself = this.targetNumberId == this.numberId ? true : false
      uni.navigateTo({ url: '/pagesMy/my/myAlbum/photoDetail?isMyself=' + isMyself + '&numberId=' + this.targetNumberId + '&sourcepage=partner' + '&id=' + item.photoDTOList[index].photoId })
    },
    // 返回上一页
    goBack() {
      uni.navigateBack({ delta: 1 })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.partner-album-pages {
  .header-box {
    padding-top: var(--status-bar-height);
    height: 88rpx;
    position: fixed;
    width: 100vw;
    z-index: 1;
    background: #ffffff;
    .header-box-left {
      padding-left: 24rpx;
      .left-icon {
        width: 46rpx;
        height: 46rpx;
        margin-right: 15rpx;
      }
      .left-box {
      }
    }
    .header-box-right {
      padding-right: 24rpx;
      .right-face-btn {
        width: 192rpx;
        padding: 10rpx 0;
        background: #000000;
        border-radius: 28rpx;
        margin-right: 20rpx;
        .face-img {
          width: 30rpx;
          height: 28rpx;
          margin-right: 8rpx;
        }
        .face-text {
          font-size: 28rpx;
          color: #ffffff;
          // line-height: 40rpx;
        }
      }
      .right-screen-btn {
        padding: 10rpx 10rpx;
        background: #000000;
        border-radius: 50%;
        .screen-btn-img {
          width: 36rpx;
          height: 36rpx;
          display: block;
        }
      }
    }
  }
  .album-pages-body {
    padding-top: calc(var(--status-bar-height) + 88rpx);
    .body-item {
      .item-time {
        font-size: 32rpx;
        padding-left: 20rpx;
        margin-bottom: 20rpx;
      }
      .item-img-box {
        margin: 0 20rpx 0rpx;
        flex-wrap: wrap;
      }

      .item-img {
        width: 346rpx;
        height: 346rpx;
        border-radius: 24rpx;
        display: block;
        margin-bottom: 10rpx;
      }
    }
  }
  .tips-box {
    padding: 20rpx 0 50rpx;
  }
}
</style>
