<template>
  <view class="hot-topic-list-page">
    <view class="header">
      <!-- 状态栏 -->
      <view class="status-bar-box" :style="{ 'background-color': `rgba(255,255,255,${navOpacity})` }"></view>
      <!-- 导航栏 -->
      <view class="nav-container" :style="{ 'background-color': `rgba(255,255,255,${navOpacity})` }">
        <image class="nav-back" :style="{ opacity: pageScrollTop > 0 ? navOpacity : 1 }" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" @click="goBack" />
        <view class="nav-title" :style="{ opacity: navOpacity }">热门话题榜</view>
      </view>
    </view>
    <!-- 背景图 -->
    <image class="page-bg" src="http://img.yiqitogether.com/yqyq-app/images/find_topic_bg.png" alt="" mode="widthFix" />
    <!-- 页面内容 -->
    <view class="main-container">
      <view class="top-wrap"></view>
      <!-- 有数据 -->
      <view class="list-wrap" v-if="!showLoading && listData.length">
        <block v-for="(item, index) in listData" :key="item.id">
          <view
            class="list-item"
            @click="
              $u.throttle(() => {
                bannerSkip(item.linkUrl)
              }, 500)
            "
          >
            <view class="list-item-rank" :style="{ color: index == 0 ? '#ff5d3e' : index == 1 ? '#ffa96d' : index == 2 ? '#ffd273' : '#c5c8cc' }">{{ index + 1 }}</view>
            <view class="list-item-content">
              <view class="h-flex-center">
                <view class="topic-title ellipsis-single">{{ item.text || '' }}</view>
                <view :class="['topic-tag', item.tag == '新' ? 'tag-new' : item.tag == '热' ? 'tag-hot' : item.tag == '票' ? 'tag-vote' : '']" v-show="item.tag">{{ item.tag }}</view>
              </view>
              <view class="hot-number">{{ formatKWNumber(item.bannerOrder) || 0 }}热度</view>
            </view>
          </view>
        </block>
        <view class="tips-box">
          <u-loadmore :status="loadStatus" :fontSize="22" nomore-text="到底了~" />
        </view>
      </view>
      <!-- 无数据 -->
      <view v-if="loadStatus == 'none'" class="empty-wrap">
        <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
        <text class="empty-text">暂无内容</text>
      </view>
    </view>
  </view>
</template>

<script>
import IndexModal from '@/model/index'
import { rpxTopx, formatKWNumber } from '@/utils/tools'
export default {
  name: 'hotTopicList',
  data() {
    return {
      navOpacity: 0,
      pageScrollTop: 0,
      showLoading: true,
      statusBarHeight: 0,
      loadStatus: 'loadmore',
      listData: [],
      formatKWNumber,
      bannerDebounce: false
    }
  },
  onLoad() {
    // 获取手机系统信息
    const info = uni.getSystemInfoSync()
    // 设置状态栏高度
    this.statusBarHeight = info.statusBarHeight

    this.getList()
  },
  onPageScroll({ scrollTop }) {
    this.pageScrollTop = scrollTop
    let scrollH = rpxTopx(262) - this.statusBarHeight
    if (scrollTop <= scrollH) {
      this.navOpacity = (scrollTop / scrollH) * 1
    } else {
      this.navOpacity = 1
    }
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 获取列表信息
    getList() {
      let params = {
        bannerType: 'TOPIC'
      }
      IndexModal.getIndexBanner(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.indexBanner || []
            this.listData = list
            this.loadStatus = list.length ? 'nomore' : 'none'
            this.showLoading = false
          } else {
            this.showLoading = false
            this.loadStatus = 'none'
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.showLoading = false

          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * banner跳转
     * 101 内部跳转;  值为/pages/index/index 类型路由
     * 102 webview打开;  值为http://baidu.com 类型链接（靓靓 —— type=1）
     * 103 webview打开;  值为http://baidu.com 类型链接（钱包 —— type=2）
     * 104 不跳转展示提示语;   值为 暂未开发，敬请期待 类型提示语
     * 105 打开通用页面，携带图片链接  值为 图片链接地址
     * 106 其他（自定义）
     * 400 无操作，无提示（理论上不会用到）。
     */
    bannerSkip(path) {
      if (this.bannerDebounce) {
        return
      }
      this.bannerDebounce = true
      // 兼容轮播图数据，path是当前索引值，number类型
      if (typeof path === 'number') {
        path = this.bannerList1[path].linkUrl
      }

      let type = path.substring(0, 3)
      let linkValue = path.substring(3, path.length)
      switch (type) {
        case '101':
          uni.navigateTo({
            url: linkValue,
            fail(e) {
              uni.showToast({
                title: '当前版本暂不支持',
                icon: 'none'
              })
            }
          })
          break
        case '102':
          let obj = {
            type: '1',
            openUrl: linkValue
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
          uni.navigateTo({ url: `/pages/my/webView` })
          break
        case '103':
          let obj2 = {
            type: '2',
            openUrl: linkValue
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj2))
          uni.navigateTo({ url: `/pages/my/webView` })
          break
        case '104':
          uni.showToast({
            title: linkValue,
            icon: 'none'
          })
          break
        case '105':
          uni.navigateTo({
            url: `/pages/index/publicPage?image=${linkValue}`
          })
          break
        case '106':
          if (linkValue == '/recruit') {
            judgeIdentity()
          }
          break
        case '107':
          uni.navigateTo({ url: `/pagesSetting/setting/webView?url=${linkValue}` })
          break
        case '108':
          uni.navigateTo({ url: `/pages/my/loadOtherPages?openUrl=${linkValue}` })
          break
        case '400':
          console.log('无操作，无提示')
          break
        default:
          uni.showToast({
            title: '当前版本暂不支持',
            icon: 'none'
          })
      }
      setTimeout(() => {
        this.bannerDebounce = false
      }, 1000)
    }
  }
}
</script>

<style lang="scss" scoped>
.hot-topic-list-page {
  width: 100vw;
  min-height: 100vh;

  .header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 99;

    .status-bar-box {
      width: 100%;
      height: var(--status-bar-height);
    }

    .nav-container {
      width: 100%;
      height: 88rpx;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;

      .nav-back {
        width: 44rpx;
        height: 44rpx;
        position: absolute;
        left: 24rpx;
        top: 50%;
        transform: translateY(-50%);
        z-index: 99;
      }
      .nav-title {
        font-size: 36rpx;
        color: #333;
        text-align: center;
      }
    }
  }

  .page-bg {
    width: 100%;
    background-size: cover;
    position: relative;
    z-index: -1;
  }
  .main-container {
    margin-top: -34rpx;
    background-color: #fff;
    border-radius: 24rpx 24rpx 0 0;

    .top-wrap {
      height: 60rpx;
      background: linear-gradient(180deg, #eef9ff, #ffffff);
      border-radius: 24rpx 24rpx 0 0;
      box-shadow: 0rpx -6rpx 12rpx 0rpx rgba(211, 206, 255, 0.21);
    }
    .list-wrap {
      margin-top: -26rpx;
      .list-item {
        display: flex;
        align-items: center;
        padding: 20rpx 30rpx;
        box-sizing: border-box;

        &-rank {
          flex-shrink: 0;
          font-size: 28rpx;
          text-align: center;
          line-height: 40rpx;
          margin-right: 30rpx;
        }

        &-img {
          flex-shrink: 0;
          width: 100rpx;
          height: 100rpx;
          border-radius: 16rpx;
          margin-right: 20rpx;
        }
        &-content {
          flex: 1;
          position: relative;
          display: flex;
          justify-content: space-between;
          align-content: center;
          .topic-title {
            font-size: 28rpx;
            color: #484848;
            line-height: 40rpx;
          }

          .topic-tag {
            width: 32rpx;
            height: 32rpx;
            border-radius: 6rpx;
            font-size: 24rpx;
            color: #ffffff;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 8rpx;
            flex-shrink: 0;
          }
          .tag-new {
            background: linear-gradient(90deg, #a4eaae, #79e4b2);
          }
          .tag-hot {
            background: linear-gradient(270deg, #ff7bad, #ffa3b4);
          }
          .tag-vote {
            background: linear-gradient(316deg, #aea5ff 9%, #bbdbff 92%);
          }
        }
        .hot-number {
          font-size: 24rpx;
          color: #bdc1c5;
        }
      }
    }
    .line {
      width: 100%;
      height: 2rpx;
      background: #f6f7f8;
    }

    .tips-box {
      text-align: center;
      padding-bottom: 30rpx;
      /deep/.u-loadmore__content__text {
        line-height: 34rpx !important;
      }
    }
    .empty-wrap {
      text-align: center;
      font-size: 0;
      margin: 100rpx auto 0;
      .empty-img {
        width: 310rpx;
        height: 310rpx;
        background-size: cover;
      }
      .empty-text {
        display: block;
        font-size: 24rpx;
        color: #9fa7b4;
        line-height: 34rpx;
        margin-top: 26rpx;
      }
    }
  }
}
</style>
