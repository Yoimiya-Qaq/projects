<template>
  <view class="partner-details-page" :style="shareFlag ? 'max-height:100vh;overflow:hidden' : ''">
    <!-- 导航 -->
    <view class="header-box flex-1" :style="isscrollTop ? 'background: linear-gradient(rgba(175, 172, 172, 0.8) 0%, rgba(51, 51, 54, 0.75) 85%);' : ''">
      <view class="header-box-left flex-0" @click="goBack()">
        <view class="left-icon-box">
          <image class="left-icon" src="https://img.yiqitogether.com/static/local/myImages/back_02@2x.png" mode="scaleToFill" />
        </view>
        <view class="left-box" v-if="isscrollTop">
          <view class="box-text" v-if="partnerUserInfo.nickName">{{ partnerUserInfo.nickName }}</view>
          <!-- <view class="line-text"></view> -->
        </view>
      </view>
      <view class="header-box-right flex-0" v-if="targetNumberId != numberId">
        <view class="right-face-btn flex-5" @click="$u.throttle(handleFaceAuth, 50)">
          <image class="face-img" src="http://img.yiqitogether.com/yqyq-app/images/face_score_icon.png" mode="scaleToFill" />
          <view class="face-text">颜值圈</view>
        </view>
        <view class="right-screen-btn" @click="openPartnerScreen">
          <image class="screen-btn-img" src="http://img.yiqitogether.com/yqyq-app/images/screen_white_icon.png" mode="scaleToFill" />
        </view>
      </view>
      <view class="header-box-right flex-0" v-else>
        <view class="right-face-btn flex-5" @click="$u.throttle(openPartnerRecommend, 50)">
          <image class="face-img" src="http://img.yiqitogether.com/yqyq-app/images/faceDetails_quanxian.png" mode="scaleToFill" />
          <view class="face-text">
            系统推荐:
            <text style="margin-left: 10rpx">{{ String(partnerUserInfo.isSystemRecommend) == 'true' ? '开' : '关' }}</text>
          </view>
        </view>
      </view>
    </view>

    <view class="page-body" v-if="!showLoading">
      <!-- 顶部  -->
      <view class="body-top">
        <u-swiper :current="current" :list="partnerUserInfo.goodPhotoUrlList" :height="swiperHeight + 'rpx'" :autoplay="false" @change="changeTopfacelist">
          <view slot="indicator" class="indicator">
            <view class="indicator__dot" v-for="(item, index) in partnerUserInfo.goodPhotoUrlList" :key="index" :class="[index === current && 'indicator__dot--active']"></view>
          </view>
        </u-swiper>
        <view class="top-content">
          <view class="content-user">
            <view class="user-name ellipsis-single">{{ partnerUserInfo.nickName }}</view>
            <view class="user-detail">
              <view class="detail-info">
                {{ partnerUserInfo.address }}
                <text v-if="partnerUserInfo.address && partnerUserInfo.constellation" class="info-text">·</text>
                {{ partnerUserInfo.constellation }}
                <text v-if="partnerUserInfo.constellation && partnerUserInfo.age" class="info-text">·</text>
                {{ partnerUserInfo.age }}
                <text v-if="partnerUserInfo.age">岁</text>
              </view>
              <view class="detail-tips flex-0">
                <view v-if="partnerUserInfo.score" class="tips-item">
                  {{ partnerUserInfo.score }}
                  <text style="font-size: 20rpx">分</text>
                </view>
                <view class="tips-item">真实本人</view>
                <view v-if="partnerUserInfo.actMsg" class="tips-item">
                  <text v-if="partnerUserInfo.actMsg == '0分钟前'">刚刚活跃</text>
                  <text v-else>{{ partnerUserInfo.actMsg ? partnerUserInfo.actMsg : '刚刚' }}活跃</text>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
      <!-- 内容 -->
      <view class="body-content">
        <!-- 关于我 -->
        <!-- 自己 -->
        <view class="body-aboutme" v-if="targetNumberId == numberId">
          <view class="aboutme-title flex-1">
            <view class="title-left flex-0">
              <image class="title-img" src="http://img.yiqitogether.com/yqyq-app/images/aboutme_icon.png" mode="scaleToFill" />
              关于我
            </view>
            <view class="title-right flex-0" @click.stop="$u.throttle(editInfo, 500)">
              <view class="right-text">去完善</view>
              <image class="rigth-icon" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="scaleToFill" />
            </view>
          </view>
          <view class="aboutme-signature" v-if="partnerUserInfo.signature">{{ partnerUserInfo.signature }}</view>
          <!-- 用户个性标签 -->
          <view v-if="tagList.length > 0" class="info-box-item flex-0">
            <view class="flex-0" style="flex-shrink: 1; flex-wrap: wrap">
              <u-tag class="info-item-label" v-for="(item, index) in tagList" :key="index" mode="dark" :text="item.name" borderColor="#e8c5a8" color="#e8c5a8" plain shape="circle" name="1"></u-tag>
            </view>
          </view>
          <!-- 系统标签 -->
          <view v-if="sysLableList.length > 0" class="info-box-item flex-0">
            <view class="flex-0" style="flex-shrink: 1; flex-wrap: wrap">
              <view class="sysLabel-item ellipsis-single" v-for="(item, index) in sysLableList" :key="index" :style="`background:${item.color}`">{{ item.name }}</view>
            </view>
          </view>

          <!-- <view class="aboutme-btnbox flex-1" v-if="partnerUserInfo.signature || tagList.length > 0 || sysLableList.length > 0">
            <view
              class="btnbox-btn"
              style="margin-right: 14rpx"
              @click.stop="
                $u.throttle(() => {
                  goHomePages(partnerUserInfo.numberId, 5)
                })
              "
            >
              进入个人主页
            </view>
          </view> -->
        </view>
        <!-- 他人 -->
        <view class="body-aboutme" v-if="targetNumberId != numberId && (partnerUserInfo.signature || tagList.length > 0 || sysLableList.length > 0)">
          <view class="aboutme-title flex-0">
            <view class="title-left flex-0">
              <image class="title-img" src="http://img.yiqitogether.com/yqyq-app/images/aboutme_icon.png" mode="scaleToFill" />
              关于我
            </view>
          </view>
          <view class="aboutme-signature">{{ partnerUserInfo.signature }}</view>
          <!-- 用户个性标签 -->
          <view v-if="tagList.length > 0" class="info-box-item flex-0">
            <view class="flex-0" style="flex-shrink: 1; flex-wrap: wrap">
              <u-tag class="info-item-label" v-for="(item, index) in tagList" :key="index" mode="dark" :text="item.name" borderColor="#e8c5a8" color="#e8c5a8" plain shape="circle" name="1"></u-tag>
            </view>
          </view>
          <!-- 系统标签 -->
          <view v-if="sysLableList.length > 0" class="info-box-item flex-0">
            <view class="flex-0" style="flex-shrink: 1; flex-wrap: wrap">
              <view class="sysLabel-item ellipsis-single" v-for="(item, index) in sysLableList" :key="index" :style="`background:${item.color}`">{{ item.name }}</view>
            </view>
          </view>
          <view class="aboutme-btnbox flex-1" v-if="targetNumberId != numberId">
            <view
              class="btnbox-item"
              style="margin-right: 14rpx"
              @click.stop="
                $u.throttle(() => {
                  goHomePages(partnerUserInfo.numberId, 5)
                })
              "
            >
              去Ta主页
            </view>
            <view class="btnbox-item" @click.stop="toChat" v-if="partnerUserInfo.isAttention">打招呼</view>
            <view class="btnbox-item" @click.stop="toOpenAttention" v-else>关注</view>
          </view>
          <view class="aboutme-btnbox flex-1" v-else>
            <view
              class="btnbox-btn"
              style="margin-right: 14rpx"
              @click.stop="
                $u.throttle(() => {
                  goHomePages(partnerUserInfo.numberId, 5)
                })
              "
            >
              进入个人主页
            </view>
          </view>
        </view>
        <view v-else-if="targetNumberId != numberId" style="margin: 0 15rpx 56rpx">
          <view class="aboutme-btnbox flex-1" style="margin: 0">
            <view
              class="btnbox-item"
              style="margin-right: 14rpx; background: #828080; width: 354rpx"
              @click.stop="
                $u.throttle(() => {
                  goHomePages(partnerUserInfo.numberId, 5)
                })
              "
            >
              去Ta主页
            </view>
            <view class="btnbox-item" @click.stop="toChat" v-if="partnerUserInfo.isAttention" style="background: #828080; width: 354rpx">打招呼</view>
            <view class="btnbox-item" @click.stop="toOpenAttention" v-else style="background: #828080; width: 354rpx">关注</view>
          </view>
        </view>
        <!-- 相册 -->
        <view class="body-photo-album" v-if="privatePhotoDTO.length > 0 && targetNumberId != numberId">
          <view class="ablum-top flex-1">
            <view class="top-title flex-0">
              <image class="title-img" src="http://img.yiqitogether.com/yqyq-app/images/camera.png" mode="aspectFill" />
              <view class="title-text">动态相册</view>
            </view>
            <view class="top-right flex-0" v-if="targetNumberId == numberId" @click="goRelease">
              <view class="right-text">去上传</view>
              <image class="right-img" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="scaleToFill" />
            </view>
          </view>
          <view class="album-box flex-0" style="flex-wrap: wrap" v-if="privatePhotoDTO.length > 0">
            <view class="album-item" v-for="(item, index) in privatePhotoDTO" :key="index" @click="goPhotoDetails(privatePhotoDTO, index)">
              <image class="item-img" :src="item.imgUrl" mode="aspectFill" />
              <view v-show="getMoreAlbum && index == 8" class="item-cover" @click.stop="goAlbum">
                <view class="cover-text">查看更多</view>
                <image class="cover-icon" src="http://img.yiqitogether.com/yqyq-app/images/gengduo.png" mode="apsectFill" />
              </view>
            </view>
          </view>
        </view>
        <view class="body-photo-album" v-if="targetNumberId == numberId">
          <view class="ablum-top flex-1">
            <view class="top-title flex-0">
              <image class="title-img" src="http://img.yiqitogether.com/yqyq-app/images/camera.png" mode="aspectFill" />
              <view class="title-text">动态相册</view>
            </view>
            <view class="top-right flex-0" v-if="targetNumberId == numberId" @click="goRelease">
              <view class="right-text">去上传</view>
              <image class="right-img" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="scaleToFill" />
            </view>
          </view>
          <view class="album-box flex-0" style="flex-wrap: wrap" v-if="privatePhotoDTO.length > 0">
            <view class="album-item" v-for="(item, index) in privatePhotoDTO" :key="index" @click="goPhotoDetails(privatePhotoDTO, index)">
              <image class="item-img" :src="item.imgUrl" mode="aspectFill" />
              <view v-show="getMoreAlbum && index == 8" class="item-cover" @click.stop="goAlbum">
                <view class="cover-text">查看更多</view>
                <image class="cover-icon" src="http://img.yiqitogether.com/yqyq-app/images/gengduo.png" mode="apsectFill" />
              </view>
            </view>
          </view>
        </view>
        <!-- Ta的心愿 -->
        <view
          class="body-wishbox flex-1"
          @click.stop="
            $u.throttle(() => {
              goHomePages(partnerUserInfo.numberId, 6)
            })
          "
        >
          <view class="wishbox-left flex-0">
            <image class="left-icon" src="http://img.yiqitogether.com/yqyq-app/images/gift_icon.png" mode="scaleToFill" />
            <view class="left-title">{{ targetNumberId != numberId ? 'Ta' : '我' }}的心愿</view>
          </view>
          <view class="wishbox-right flex-0">
            <view class="right-text">{{ targetNumberId != numberId ? '去点亮' : '去设置' }}</view>
            <image class="rigth-icon" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="scaleToFill" />
          </view>
        </view>
        <!-- 性格报告 -->
        <view class="body-personality-report" v-if="answerDTOList.length > 0 && targetNumberId != numberId">
          <view class="personality-report-top">
            <view class="report-top flex-1">
              <view class="report-left flex-0">
                <image class="report-img" src="http://img.yiqitogether.com/yqyq-app/images/xingge.png" mode="scaleToFill" />
                <view class="report-text">性格报告</view>
              </view>
            </view>
            <!-- 性格 -->
            <view class="report-swiper">
              <swiper class="swiper" :indicator-dots="answerDTOList.length > 1" circular>
                <swiper-item class="report-swiper-item" v-for="(item, index) in answerDTOList" :key="index">
                  <resultDetails :recordInfo="item" sourcepage="partner"></resultDetails>
                </swiper-item>
              </swiper>
            </view>
          </view>
        </view>
        <view class="body-personality-report" v-if="targetNumberId == numberId">
          <view class="personality-report-top">
            <view class="report-top flex-1">
              <view class="report-left flex-0">
                <image class="report-img" src="http://img.yiqitogether.com/yqyq-app/images/xingge.png" mode="scaleToFill" />
                <view class="report-text">性格报告</view>
              </view>
              <view v-if="answerDTOList.length == 0" class="report-right flex-0" @click="$u.throttle(goPersonality, 500)">
                <view class="right-text">去完善</view>
                <image class="rigth-icon" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="scaleToFill" />
              </view>
            </view>
            <!-- 性格 -->
            <view class="report-swiper" v-if="answerDTOList.length > 0">
              <swiper class="swiper" :indicator-dots="answerDTOList.length > 1" circular>
                <swiper-item class="report-swiper-item" v-for="(item, index) in answerDTOList" :key="index">
                  <resultDetails :recordInfo="item" sourcepage="partner"></resultDetails>
                </swiper-item>
              </swiper>
            </view>
          </view>
        </view>
        <!-- 推荐 -->
        <view class="body-recommendbox">
          <view class="flex-5" @click="handleShare()">
            <image class="recommendbox-img" src="http://img.yiqitogether.com/yqyq-app/images/tuijan.png" mode="aspectFill" />
            <view class="recommendbox-text">推荐给好友</view>
          </view>
        </view>
      </view>
    </view>
    <!-- 右侧固定按钮 -->
    <view class="fixedbtn-box" v-if="targetNumberId != numberId">
      <image @click="clickWishList" class="gift-btn" src="http://img.yiqitogether.com/yqyq-app/images/large_liwu_icon.png" mode="aspectFill" />
      <image @click="$u.throttle(nextGetUserInfo, 300)" class="next-btn" src="http://img.yiqitogether.com/yqyq-app/images/next_icon.png" mode="aspectFill" />
    </view>
    <!-- 筛选弹框 -->
    <partner-screen :showPartnerScreen="showPartnerScreen" :gender="gender" @closePartnerScreen="closePartnerScreen" :openPartnerScreen="openPartnerScreen"></partner-screen>
    <!-- 系统推荐弹框 -->
    <u-popup class="partner-recommend-pop" :show="showPartnerRecommend" @close="closePartnerRecommend" @open="openPartnerRecommend">
      <view class="recommend-pop-content">
        <view class="content-title">系统推荐</view>
        <view class="content-check-box flex-5">
          <view :class="isRecommend == 'true' ? 'active-box-item' : 'box-item'" style="margin-right: 20rpx" @click="changeRecommend('true')">开</view>
          <view :class="isRecommend == 'false' ? 'active-box-item' : 'box-item'" @click="changeRecommend('false')">关</view>
        </view>
        <view v-if="isRecommend == 'true'" class="tips">设置为“开”, 个人信息将在颜值圈内展示</view>
        <view v-else class="tips">设置为“关”, 个人信息将不在颜值圈内展示</view>
        <view class="submit-box" @click="submitIsRecommend">确定</view>
      </view>
    </u-popup>
    <!-- 取消关注 -->
    <custom-modal type="tipsConfirm" :show="attentionShow" :round="24" title="提示" :content="`是否取消关注 ${partnerUserInfo.nickName}?`" themeColor="#FE5E10" cancelText="保持关注" confirmText="取消关注" @cancel="closeAttention" @confirm="toAttention" />
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <!-- 分享弹窗 -->
    <!-- <poster-popup :show="shareFlag" @close="closeSharePop" :activityDetails="partnerUserInfo" pageType="topicsPage"></poster-popup> -->
    <!-- 分享弹窗 -->
    <common-sharing-module :shareData="shareData" v-if="shareFlag" @closePopup="shareFlag = false"></common-sharing-module>
  </view>
</template>
<script>
// 导入接口
import findModel from '@/model/find.js'
import MyInfo from '@/model/my.js'

// 导入组件
import partnerScreen from '@/pages/find/commponent/partner-screen.vue'
import resultDetails from '@/pagesCommon/answers/components/resultDetails.vue'

// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { getImageHeight } from '@/utils/tools'
import { LOGIN_USERID } from '@/utils/cacheKey.js'
import { TAG2 } from '@/utils/cacheKey.js'
export default {
  components: {
    partnerScreen,
    resultDetails
  },
  data() {
    return {
      swiperHeight: 750,
      imageList: [
        'https://img.yiqitogether.com/yyqc/20241029/upload_2awulk8woq98co0bvxppnccyha8vhydf.jpg!yqyq0606',
        'https://img.yiqitogether.com/yyqc/20241029/upload_zpckoy40bwaw02hzj8ewk81iv0feqtpt.jpg!yqyq0606',
        'https://img.yiqitogether.com/yyqc/20241028/upload_dq6ohftmmgkxy1oglicbtsk1j0z0fweh.jpg!yqyq0606',
        'https://img.yiqitogether.com/yyqc/20241029/upload_k114i5aizvedmocmtu16t38jnh683vt3.jpg!yqyq0606',
        'https://im.yiqitogether.com/u/20241030/3vtcidt2kmth2nt45zqdkenup8ugu4yr.jpg',
        'https://img.yiqitogether.com/yyqc/20241030/upload_wpyh96zalbjzuulsontgcs5stjbqk480.JPG',
        'https://im.yiqitogether.com/u/20241030/s1k3ey8wrctdz5k9r5yvc5qt82zwk98f.jpg',
        'https://im.yiqitogether.com/u/20241030/uf5mbqlhq4arq2pfs9iakk56xb5v2ghj.jpg'
      ],
      tipslist: [{ text: '人美声甜' }, { text: '外向孤独患者' }, { text: 'A4腰' }, { text: '颜控' }, { text: '搞笑女' }],
      current: 0, // 当前头部背景图
      targetNumberId: '', // 目标用户的本人numberId
      partnerUserInfo: {},
      showPartnerScreen: false, // 筛选弹框
      gender: '', // 请求的筛选性别
      numberId: load(LOGIN_USERID).toString() || '', // 本人的numberId
      attentionShow: false, // 关注弹框
      showLoading: true,
      tagList: [], // 用户资料标签
      sysLableList: [], // 系统标签
      answerDTOList: [], // 性格报告
      privatePhotoDTO: [], // 用户相册
      shareFlag: false,
      pages: 0,
      pageNumber: 0,
      getMoreAlbum: true,
      isscrollTop: false,
      shareData: {}, // 分享信息
      showPartnerRecommend: false, // 系统推荐弹框
      isRecommend: 'true' // 是否被系统推荐
    }
  },
  onLoad(e) {
    this.targetNumberId = e.targetNumberId
    this.getUserDaziHomePage()
    this.getDefaultAlbum()
  },
  onPageScroll: function (e) {
    //nvue暂不支持滚动监听，可用bindingx代替
    if (e.scrollTop <= 117) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  methods: {
    /**
     * 刷新颜值用户数据
     */
    refreshData() {
      this.showLoading = true
      this.current = 0
      this.getMoreAlbum = false
      this.pages = 0
      this.pageNumber = 0
      this.partnerUserInfo = {}
      this.tagList = []
      this.sysLableList = []
      this.answerDTOList = []
      this.privatePhotoDTO = []
      setTimeout(() => {
        this.getUserDaziHomePage()
        this.getDefaultAlbum()
      }, 100)
    },
    /**
     * 获取用户信息
     */
    getUserDaziHomePage(type) {
      let params = {
        sex: this.gender,
        targetNumberId: this.targetNumberId
      }
      findModel
        .getUserDaziHomePage(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            if (type == 'screen') {
              this.partnerUserInfo.nextNumberId = res.data.userDaziHomePageDTO.nextNumberId
            } else {
              let that = this
              this.partnerUserInfo = res.data.userDaziHomePageDTO
              this.$forceUpdate()
              this.isRecommend = String(this.partnerUserInfo.isSystemRecommend)
              this.partnerUserInfo.goodPhotoUrlList = res.data.userDaziHomePageDTO.goodPhotoUrl ? res.data.userDaziHomePageDTO.goodPhotoUrl.split('&&') : []
              this.answerDTOList = res.data.answerDTOList
              // 用户资料标签处理
              if (this.partnerUserInfo.labelName) {
                let oldLabelName = this.partnerUserInfo.labelName.split('&&')
                // 获取用户自己编辑的个性标签
                let tagColorList = load(TAG2)
                this.tagList = []
                let totalTagList = []
                if (tagColorList) {
                  //取交集
                  let m = tagColorList.filter(item => oldLabelName.includes(item.name))
                  let m2 = oldLabelName.map(item => {
                    return {
                      name: item
                    }
                  })
                  // 两个数组对象取差集
                  let arr = [...m2].filter(x => [...tagColorList].every(y => y.name !== x.name))
                  let tag3 = [...arr]

                  tag3.forEach(item => {
                    item.color = that.getTipsColor(item)
                  })
                  totalTagList = tag3.concat(m)
                  this.tagList.push(...totalTagList)
                } else {
                  totalTagList = oldLabelName.map(item => {
                    return {
                      name: item
                    }
                  })
                  totalTagList.forEach(item => {
                    item.color = that.getTipsColor(item)
                  })
                  this.tagList.push(...totalTagList)
                }
              }
              // 系统标签处理
              if (this.partnerUserInfo.sysLabelName) {
                let sysLableName = []
                sysLableName = this.partnerUserInfo.sysLabelName.split(',')
                sysLableName = sysLableName.map(item => {
                  return {
                    name: item
                  }
                })
                sysLableName.forEach(item => {
                  item.color = that.getSysLabelColor(item)
                })
                this.sysLableList.push(...sysLableName)
              }

              this.$forceUpdate()
              setTimeout(() => {
                this.getimgsHieght(0)
              }, 200)
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false

          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 获取用户相册
     */
    getDefaultAlbum() {
      let params = {
        pageNo: this.pageNumber + 1,
        pageSize: 9,
        targetNumberId: this.targetNumberId
      }
      findModel
        .getDefaultAlbum(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            let data = res.data.defaultAlbum || []
            let list = []
            data.map(item => {
              item.photoDTOList.map(phoitem => {
                list.push(phoitem)
              })
            })
            if (res.data.total > 9) {
              this.getMoreAlbum = true
            }
            this.privatePhotoDTO = [...this.privatePhotoDTO, ...list]
            this.pages = res.data.pages
            this.pageNumber = res.data.pageNumber
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 下一个颜值用户
     */
    nextGetUserInfo() {
      this.targetNumberId = this.partnerUserInfo.nextNumberId
      this.refreshData()
    },
    /**
     * 设置系统推荐
     */
    addSystemRecommend() {
      let params = {
        isSystemRecommend: this.isRecommend
      }
      findModel
        .addSystemRecommend(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '修改成功',
              icon: 'none'
            })
            const pages = getCurrentPages()
            const prePage = pages[pages.length - 2]
            if (prePage.$vm.route == 'pages/find/index') {
              let oldlist = prePage.$vm.partnerList
              let newlist = oldlist.filter(item => item.numberId != this.targetNumberId)
              prePage.$vm.partnerList = newlist
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 标签颜色处理
     * @param item
     */
    getTipsColor(item) {
      // 固定随机颜色
      let colorList = [
        'rgba(255,70,109,0.1)',
        'rgba(255,188,23,0.1)',
        'rgba(255,137,76,0.1)',
        'rgba(2,107,19,0.1)',
        'rgba(255,85,121,0.1)',
        'rgba(228,34,34,0.1)',
        'rgba(110,80,255,0.1)',
        'rgba(236,65,219,0.1)',
        'rgba(139,56,215,0.1)',
        'rgba(66,162,240,0.1)',
        'rgba(255,86,112,0.1)',
        'rgba(255,151,25,0.1)',
        'rgba(86,216,44,0.1)',
        'rgba(30,205,187,0.1)',
        'rgba(15,249,194,0.1)'
      ]
      // 标签处理
      switch (item.name) {
        case '吃货':
          return 'rgba(15,249,194,0.1)'
        case '小姐姐':
          return 'rgba(255,85,121,0.1)'
        case '摄影':
          return 'rgba(30,205,187,0.1)'
        case '旅游':
          return 'rgba(86,216,44,0.1)'
        case '小哥哥':
          return 'rgba(2,107,19,0.1)'
        case '露营':
          return 'rgba(110,80,255,0.1)'
        case '摩托':
          return 'rgba(228,34,34,0.1)'
        case '逛街':
          return 'rgba(236,65,219,0.1)'
        case '电影':
          return 'rgba(255,151,25,0.1)'
        case '喵星人':
          return 'rgba(255,137,76,0.1)'
        case '游戏':
          return 'rgba(255,137,76,0.1)'
        case '大叔':
          return 'rgba(66,162,240,0.1)'
        case '汪星人':
          return 'rgba(255,188,23,0.1)'
        case '萌宠':
          return 'rgba(255,86,112,0.1)'
        default:
          return colorList[Math.floor(Math.random() * colorList.length)]
      }
    },
    /**
     * 系统标签处理
     * @param item
     */
    getSysLabelColor(item) {
      // 固定随机颜色
      let colorList = [
        'linear-gradient(129deg,#fff1e3 3%, #f3eefa 100%);',
        'linear-gradient(129deg,#f7fff6 3%, #c6eef4 100%);',
        'linear-gradient(129deg,#ffe5c7 3%, #f4c6c6 100%);',
        'linear-gradient(129deg,#d6e5ff 3%, #e4faed 100%);',
        'linear-gradient(129deg,#f5e7ff 3%, #eeeefa 100%);',
        'linear-gradient(129deg,#fff6f6 3%, #f4c6c6 100%);',
        'linear-gradient(129deg,#c7f4ff 3%, #fffce6 100%);',
        'linear-gradient(129deg,#fffff4 3%, #ef9830 100%);'
      ]
      // 标签处理
      switch (item.name) {
        case '搞笑担当':
          return 'linear-gradient(129deg,#fff1e3 3%, #f3eefa 100%);'
        case '文艺青年':
          return 'linear-gradient(129deg,#f7fff6 3%, #c6eef4 100%);'
        case '亲和力王者':
          return 'linear-gradient(129deg,#ffe5c7 3%, #f4c6c6 100%);'
        case '潮流玩家':
          return 'linear-gradient(129deg,#d6e5ff 3%, #e4faed 100%);'
        case '电影狂热者':
          return 'linear-gradient(129deg,#f5e7ff 3%, #eeeefa 100%);'
        case '运动健将':
          return 'linear-gradient(129deg,#fff6f6 3%, #f4c6c6 100%);'
        case '旅行探索者':
          return 'linear-gradient(129deg,#c7f4ff 3%, #fffce6 100%);'
        case '逻辑鬼才':
          return 'linear-gradient(129deg,#fffff4 3%, #ef9830 100%);'
        default:
          return colorList[Math.floor(Math.random() * colorList.length)]
      }
    },
    /**
     * 根据图片自身更改显示的高度
     * @param res
     */
    changeTopfacelist(res) {
      this.current = res.current
      this.getimgsHieght(res.current)
    },
    /**
     * 获取图片高度
     * @param index
     */
    async getimgsHieght(index) {
      try {
        let imgHeight = await getImageHeight(this.partnerUserInfo.goodPhotoUrlList[index], 1000)
        this.swiperHeight = Math.round(imgHeight) + 1
      } catch (error) {}
    },
    /**
     * 进入自己的颜值认证页面
     */
    handleFaceAuth() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      uni.navigateTo({
        url: '/pagesMy/my/myFaceScore'
      })
    },
    /**
     * 打开筛选弹框
     */
    openPartnerScreen() {
      this.showPartnerScreen = true
    },
    /**
     * 关闭筛选弹框
     */
    closePartnerScreen(isScreen, gender) {
      this.showPartnerScreen = false
      if (!isScreen) return
      this.gender = gender
      this.getUserDaziHomePage('screen')
    },
    /**
     * 打开系统推荐弹框
     */
    openPartnerRecommend() {
      this.showPartnerRecommend = true
    },
    /**
     * 关闭系统推荐弹框
     */
    closePartnerRecommend() {
      this.showPartnerRecommend = false
      this.isRecommend = String(this.partnerUserInfo.isSystemRecommend)
    },
    /**
     * 选择是否被系统推荐
     */
    changeRecommend(type) {
      this.isRecommend = type
    },
    /**
     * 确认提交是否被系统推荐
     */
    submitIsRecommend() {
      if (this.partnerUserInfo.isSystemRecommend == this.isRecommend) {
        this.closePartnerRecommend()
        return
      }
      this.partnerUserInfo.isSystemRecommend = this.isRecommend
      this.addSystemRecommend()
      setTimeout(() => {
        this.closePartnerRecommend()
      }, 50)
    },
    /**
     * 打开关注弹框
     */
    toOpenAttention() {
      if (this.partnerUserInfo.isAttention) {
        this.attentionShow = true
      } else {
        this.toAttention()
      }
    },
    // 去私聊
    async toChat(user) {
      // #ifdef H5
      uni.showToast({
        title: '当前环境不支持私信功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let that = this
      // #ifdef APP
      // 进私聊页面，清空未读数，说明已读取内容
      let timeFiff = +new Date()
      let code = await this.$store.state.engie.clearUnreadCount(1, that.targetNumberId, null, timeFiff)
      // #endif
      uni.navigateTo({
        url: '/pagesMessage/privateChat/index' + '?userId=' + that.targetNumberId + '&otherNickName=' + that.partnerUserInfo.nickName
      })
    },
    /**
     * 关闭关注弹框
     */
    closeAttention() {
      this.attentionShow = false
    },
    /**
     * 去关注
     */
    toAttention() {
      let pamise = {
        targetNumberId: this.targetNumberId
      }
      if (this.partnerUserInfo.isAttention) {
        MyInfo.cancelAttention(pamise)
          .then(res => {
            if (res.code == 'SUCCESS') {
              this.partnerUserInfo.isAttention = !this.partnerUserInfo.isAttention
              this.$forceUpdate()
              uni.showToast({
                title: '取消关注',
                icon: 'none'
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
          .catch(err => {})
      } else {
        MyInfo.attention(pamise)
          .then(res => {
            if (res.code == 'SUCCESS') {
              this.partnerUserInfo.isAttention = !this.partnerUserInfo.isAttention
              this.$forceUpdate()
              uni.showToast({
                title: '关注成功',
                icon: 'none'
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
          .catch(err => {})
      }

      this.attentionShow = false
    },
    /**
     * 送礼物
     */ clickWishList() {
      // 礼物
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let obj = {
        type: '1',
        openUrl: '/giveGift/searchList/yiqi',
        userId: this.partnerUserInfo.numberId,
        enterType: 1
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({ url: '/pages/my/webView' })
      })
    },
    /**
     * 关闭分享弹框
     */
    closeSharePop() {
      this.shareFlag = false
    },
    // 分享
    handleShare() {
      this.shareFlag = true
      // 弹窗分享弹窗
      let title = this.partnerUserInfo.nickName + `的颜值圈主页`
      let shareObj = {
        type: 0,
        title: title,
        imageUrl: 'http://img.yiqitogether.com/static/img/yq_logo.png',
        // 小程序对应页面
        // path: `/packageFind/find/findDetails?twitterId=${this.twitterId}&pageType=${this.pageType}`,
        // h5对应页面
        href: `/pages/find/partnerDetails?targetNumberId=${this.partnerUserInfo.numberId}`
      }
      this.shareData = shareObj
    },
    /**
     * 预览图片
     * @param urls
     * @param current
     */
    previewImage(urls, current) {
      let list = []
      if (this.privatePhotoDTO.length === 1) {
        list = [this.privatePhotoDTO[0].imgUrl]
      } else {
        list = urls
      }
      let result = list.map(item => {
        return item.imgUrl.replace('!yqyq0606', '')
      })
      current = current || 0
      uni.previewImage({
        urls: result,
        current
      })
    },
    /**
     * 照片详情
     */
    goPhotoDetails(privatePhotoDTO, index) {
      getApp().globalData.albumPreviewList = privatePhotoDTO
      let isMyself = this.targetNumberId == this.numberId ? true : false
      uni.navigateTo({ url: '/pagesMy/my/myAlbum/photoDetail?isMyself=' + isMyself + '&numberId=' + this.targetNumberId + '&sourcepage=partner' + '&id=' + privatePhotoDTO[index].photoId })
    },
    /**
     * 前往默认相册
     */
    goAlbum() {
      console.log('privatePhotoDTO', this.privatePhotoDTO)
      uni.navigateTo({ url: '/pages/find/partnerAlbum?targetNumberId=' + this.targetNumberId })
    },
    /**
     * 前往测试性格
     * @param data
     */
    goPersonality() {
      uni.navigateTo({ url: '/pagesCommon/answers/index' })
    },
    // 前往个人主页
    goHomePages(data, checkedTab) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + data + '&checkedTab=' + checkedTab
      })
    },
    /***
     * 发布动态
     */
    goRelease() {
      uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s1&sourcePage=partnerDetails' })
    },
    /**
     *   编辑资料
     */
    editInfo() {
      uni.navigateTo({
        url: '/pagesMy/my/editPersonalInfo?sourcePage=partnerDetails'
      })
    },
    // 返回上一页
    goBack() {
      uni.navigateBack({ detail: 1 })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.partner-details-page {
  background: #0e0e10;
  min-height: 100vh;
  width: 100vw;
  .header-box {
    padding-top: var(--status-bar-height);
    height: 88rpx;
    position: fixed;
    width: 100vw;
    z-index: 1;
    .header-box-left {
      padding-left: 24rpx;
      .left-icon-box {
        background: #828080;
        text-align: center;
        margin-right: 15rpx;
        padding: 5rpx 5rpx;
        border-radius: 50%;
        .left-icon {
          width: 46rpx;
          height: 46rpx;
          display: block;
          margin-left: -4rpx;
        }
      }
      .left-box {
        .box-text {
          font-size: 36rpx;
          color: #ffffff;
          line-height: 50rpx;
        }
        .line-text {
          width: 112rpx;
          height: 12rpx;
          background: linear-gradient(90deg, rgba(250, 187, 190, 0), #f5b280 69%);
          border-radius: 6rpx;
        }
      }
    }
    .header-box-right {
      padding-right: 24rpx;
      .right-face-btn {
        // width: 192rpx;
        padding: 10rpx 28rpx;
        background: #828080;
        border-radius: 28rpx;
        margin-right: 20rpx;
        .face-img {
          width: 30rpx;
          height: 28rpx;
          margin: 4rpx 8rpx 0 0;
        }
        .face-text {
          font-size: 28rpx;
          color: #ffffff;
          // line-height: 40rpx;
        }
      }
      .right-screen-btn {
        padding: 10rpx 10rpx;
        background: #828080;
        border-radius: 50%;
        .screen-btn-img {
          width: 36rpx;
          height: 36rpx;
          display: block;
        }
      }
    }
  }
  .page-body {
    .body-top {
      position: relative;
      .top-content {
        position: absolute;
        padding: 0 36rpx 70rpx;
        width: 100vw;
        bottom: 0;
        box-sizing: border-box;
        background: linear-gradient(rgba(143, 143, 143, 0) 0%, #0e0e10 100%);
        .content-user {
          .user-name {
            max-width: 400rpx;
            font-size: 44rpx;
            color: #ffffff;
            line-height: 60rpx;
          }
          .user-detail {
            .detail-info {
              margin-top: 6rpx;
              font-size: 28rpx;
              color: #ffffff;
              line-height: 40rpx;
              .info-text {
                margin: 0 20rpx;
              }
            }
            .detail-tips {
              margin-top: 22rpx;
              .tips-item {
                padding: 5rpx 16rpx;
                background: rgba(255, 242, 244, 0.2);
                border-radius: 8rpx;
                margin-right: 12rpx;
                font-size: 24rpx;
                color: #ffffff;
              }
            }
          }
        }
      }
      /deep/.u-swiper__indicator {
        bottom: 70rpx;
        right: 36rpx;
        z-index: 1;
      }
      .indicator {
        @include flex(row);
        justify-content: center;
        padding: 16rpx 40rpx;
        background: rgba(0, 0, 0, 0.5);
        border-radius: 36rpx;
        &__dot {
          height: 8rpx;
          width: 8rpx;
          border-radius: 100px;
          background-color: rgba(255, 255, 255, 0.35);
          margin: 0 4rpx;
          transition: background-color 0.3s;

          &--active {
            width: 28rpx;
            height: 8rpx;
            background-color: #ffffff;
          }
        }
      }

      .indicator-num {
        padding: 2px 0;
        background-color: rgba(0, 0, 0, 0.35);
        border-radius: 100px;
        width: 35px;
        @include flex;
        justify-content: center;

        &__text {
          color: #ffffff;
          font-size: 12px;
        }
      }
    }
    .body-content {
      position: relative;
      margin-top: -20rpx;
      .body-aboutme {
        margin: 0 15rpx;
        padding: 36rpx 32rpx 38rpx;
        background: #828080;
        border-radius: 28rpx;
        .aboutme-title {
          .title-left {
            .title-img {
              width: 36rpx;
              height: 36rpx;
              margin-right: 12rpx;
            }
            font-size: 32rpx;
            color: #ffffff;
          }
        }
        .title-right {
          .right-text {
            font-size: 24rpx;
            color: #ffffff;
            margin-right: 6rpx;
          }
          .rigth-icon {
            width: 28rpx;
            height: 28rpx;
          }
        }
        .aboutme-signature {
          margin: 32rpx 0 24rpx 0;
          font-size: 28rpx;
          color: #ffffff;
          line-height: 40rpx;
          letter-spacing: 0.01rpx;
        }
        .aboutme-tips {
          margin-top: 54rpx;
          flex-wrap: wrap;
          .tips-item {
            padding: 8rpx 26rpx;
            font-size: 24rpx;
            color: #ffdec2;
            margin: 0 20rpx 30rpx 0;
          }
        }
        .info-box-item {
          margin-top: 30rpx;
          .item-title {
            font-size: 28rpx;
            color: #2a343e;
            flex-shrink: 0;
            margin-right: 12rpx;
          }
          .item-right {
            font-size: 24rpx;
            padding: 10rpx 0;
            width: 158rpx;
            background: #f8fbfd;
            border-radius: 26rpx;
            margin-right: 20rpx;
            text-align: center;
            .gender {
              width: 32rpx;
              height: 32rpx;
              margin-right: 14rpx;
            }
            .location {
              width: 32rpx;
              height: 32rpx;
              display: block;
              flex-shrink: 0;
            }
            .item-tips {
              padding: 0 2rpx;
              box-sizing: border-box;
            }
            .constellation-img {
              width: 28rpx;
              height: 28rpx;
              margin-right: 14rpx;
            }
          }
          .info-item-label {
            margin: 0 20rpx 0 0;
          }
          .sysLabel-item {
            width: 148rpx;
            height: 50rpx;
            line-height: 50rpx;
            font-size: 24rpx;
            text-align: center;
            color: #272727;
            border-radius: 26rpx;
            margin: 0 20rpx 30rpx 0;
          }
          .sysLabel-item:nth-child(4n) {
            margin: 0 0 30rpx 0;
          }
        }
      }
      .aboutme-btnbox {
        margin-top: 96rpx;
        .btnbox-item {
          width: 316rpx;
          height: 88rpx;
          background: #a5a5a5;
          border-radius: 44rpx;
          font-size: 28rpx;
          text-align: center;
          color: #ffffff;
          line-height: 88rpx;
        }
        .btnbox-btn {
          width: 648rpx;
          height: 88rpx;
          background: #a5a5a5;
          border-radius: 44rpx;
          font-size: 28rpx;
          text-align: center;
          color: #ffffff;
          line-height: 88rpx;
        }
      }
      .body-photo-album {
        margin: 20rpx 15rpx 0rpx;
        padding: 20rpx 0 20rpx;
        background: #828080;
        border-radius: 28rpx;
        .ablum-top {
          padding: 0 22rpx 5rpx;
          .top-title {
            .title-img {
              width: 72rpx;
              height: 72rpx;
            }
            .title-text {
              font-size: 32rpx;
              color: #ffffff;
            }
          }
          .top-right {
            .right-text {
              font-size: 24rpx;
              color: #ffffff;
              margin-right: 6rpx;
            }
            .right-img {
              width: 28rpx;
              height: 28rpx;
            }
          }
        }
        .album-box {
          /* #ifdef APP */
          margin: 0 0 0 34rpx;
          /* #endif */
          /* #ifndef APP */
          margin: auto;
          /* #endif */
          width: 665rpx;

          .album-item {
            position: relative;
            margin: 0 8rpx 8rpx 0;
            border-radius: 24rpx;
            overflow: hidden;
            text-align: center;

            .item-img {
              display: block;
              width: 216rpx;
              height: 216rpx;
            }
            .item-cover {
              width: 216rpx;
              height: 216rpx;
              background: rgba(0, 0, 0, 0.5);
              position: absolute;
              top: 0;
              padding: 32% 0 0 0;
              box-sizing: border-box;
              text-align: center;
              .cover-text {
                font-size: 20rpx;
                color: #ffffff;
              }
              .cover-icon {
                margin: 12rpx auto 0;
                position: relative;
                width: 28rpx;
                height: 28rpx;
                display: block;
              }
            }
          }
          .album-item:nth-child(3n) {
            margin: 0 0 4rpx 0;
          }
        }
      }
      .body-wishbox {
        margin: 20rpx 15rpx 0;
        padding: 20rpx 26rpx 20rpx 18rpx;
        background: #828080;
        border-radius: 28rpx;
        .wishbox-left {
          .left-icon {
            width: 72rpx;
            height: 72rpx;
          }
          .left-title {
            font-size: 32rpx;
            color: #ffffff;
          }
        }
        .wishbox-right {
          .right-text {
            font-size: 24rpx;
            color: #ffffff;
            margin-right: 6rpx;
          }
          .rigth-icon {
            width: 28rpx;
            height: 28rpx;
          }
        }
      }
      .body-personality-report {
        margin: 20rpx 15rpx 0;
        padding: 14rpx 26rpx 30rpx 18rpx;
        background: #828080;
        border-radius: 28rpx;
        .personality-report-top {
          .report-top {
            .report-left {
              .report-img {
                width: 72rpx;
                height: 72rpx;
                display: block;
              }
              .report-text {
                font-size: 32rpx;
                color: #ffffff;
              }
            }
            .report-right {
              .right-text {
                font-size: 24rpx;
                color: #ffffff;
                margin-right: 6rpx;
              }
              .rigth-icon {
                width: 28rpx;
                height: 28rpx;
              }
            }
          }
          .report-swiper {
            .swiper {
              min-height: 700rpx;
            }
            /deep/.uni-swiper-dot {
              width: 8rpx;
              height: 8rpx;
              background: #d6d6d6;
            }
            /deep/.uni-swiper-dot-active {
              width: 28rpx;
              height: 8rpx;
              background: #ffffff;
              border-radius: 60rpx;
            }
          }
        }
      }
      .body-recommendbox {
        padding: 58rpx 0 96rpx;
        text-align: center;
        .recommendbox-img {
          width: 32rpx;
          height: 32rpx;
          margin-right: 15rpx;
        }
        .recommendbox-text {
          font-size: 28rpx;

          color: #7d7d7d;
        }
      }
    }
  }
  .fixedbtn-box {
    position: fixed;
    bottom: 302rpx;
    right: 50rpx;
    z-index: 1;
    .gift-btn {
      width: 112rpx;
      height: 112rpx;
      display: block;
      margin-bottom: 68rpx;
    }
    .next-btn {
      width: 112rpx;
      height: 112rpx;
      display: block;
    }
  }
  .partner-recommend-pop {
    /deep/.u-popup__content {
      border-radius: 20rpx 20rpx 0rpx 0rpx;
    }
    .recommend-pop-content {
      padding: 48rpx 0 112rpx;
      .content-title {
        font-size: 32rpx;
        text-align: center;
        color: #2a343e;
        margin-bottom: 68rpx;
        font-weight: bold;
      }
      .content-check-box {
        margin-bottom: 30rpx;
        .box-item {
          width: 256rpx;
          height: 68rpx;
          background: #f0f1f3;
          border-radius: 34rpx;
          font-size: 28rpx;
          text-align: center;
          color: #838e9a;
          line-height: 68rpx;
        }
        .active-box-item {
          width: 256rpx;
          height: 68rpx;
          background: #fe5e10;
          border-radius: 34rpx;
          font-size: 28rpx;
          text-align: center;
          color: #ffffff;
          line-height: 68rpx;
        }
      }
      .tips {
        font-size: 24rpx;
        text-align: center;
        color: #9fa7b4;
        margin-bottom: 60rpx;
      }
      .submit-box {
        margin: auto;
        width: 678rpx;
        height: 88rpx;
        background: #fe5e10;
        border-radius: 44rpx;
        font-size: 36rpx;
        text-align: center;
        color: #ffffff;
        line-height: 88rpx;
      }
    }
  }
}
</style>
