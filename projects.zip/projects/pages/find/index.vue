<template>
  <view class="findpage" :class="showChannelState ? 'fixedBgc' : ''">
    <!-- 系统导航栏部分 -->
    <view class="navigate-box"></view>
    <video style="position: absolute; top: 0; left: -750rpx" :src="videoPlayUrl" loop id="videoId" @fullscreenchange="videoFullScreenChange" @play="videoPlayFun"></video>

    <!-- 顶部导航栏 start 状态栏+导航栏 -->
    <view :class="['nav-bar-box', 'h-border-box']" @click="clickSystemNav">
      <!-- 消息提示 -->
      <view class="message-box" @click.stop="openCommentAndZanPage()">
        <image src="@/static/images/find_msg.png" mode="" class="message-icon"></image>
        <view class="red-tips" v-show="unreadObj.hasCommentNewly"></view>
      </view>

      <!-- tab切换 -->
      <view class="tab-text-box flex-4">
        <block v-for="item in topHeadTab" :key="item.text">
          <view :class="[topCheckTabCode == item.code ? 'tab-current' : 'tab-text']" @click.stop="checkFirstTab(item)">{{ item.text }}</view>
        </block>
      </view>

      <view class="right-btn flex-1">
        <view v-if="topCheckTabCode == 'partner'" class="flex-1">
          <image v-show="authGood == 'SUCCESS'" @click.stop="$u.throttle(goDetails, 500)" class="find-face-icon" src="http://img.yiqitogether.com/yqyq-app/images/my_faces_btn.png" mode="scaleToFill" />
          <image style="margin-right: 40rpx" @click.stop="openPartnerScreen" class="find-face-icon" src="http://img.yiqitogether.com/yqyq-app/images/screen_icon.png" mode="scaleToFill" />
        </view>
        <view v-else class="flex-1">
          <!-- 搜索图标 -->
          <image
            src="@/static/images/find_serch.png"
            mode=""
            class="find-serch-icon"
            @click.stop="
              $u.throttle(() => {
                goSearch(topCheckTabCode)
              }, 500)
            "
          ></image>
          <!-- 扫码 -->
          <!-- #ifdef APP-PLUS -->
          <image src="http://img.yiqitogether.com/yqyq-app/images/sweep.png" mode="" class="find-sweep-icon" @click.stop="$noMultipleClicks(sweep)"></image>
          <!-- #endif -->
        </view>
      </view>
    </view>
    <!-- 顶部导航栏 end -->

    <!-- 动态tab -->
    <view v-if="topCheckTabCode == 'plaza'" class="headerTab flex-0">
      <view
        :class="checkTabCode == item.label ? 'li active' : 'li'"
        @click="
          $u.throttle(() => {
            checkSecondTab(item, index)
          }, 500)
        "
        v-for="(item, index) in topHeadTab[0].classList"
        :key="index"
      >
        <view class="li-text">{{ item.text }}</view>
        <view :style="checkTabCode == item.label ? '' : 'visibility: hidden;'" class="headerTab-border"></view>
      </view>
    </view>
    <!-- 发现tab -->
    <noteMenu
      v-if="topCheckTabCode == 'thread'"
      class="headerTab"
      style="padding: 0rpx"
      ref="noteMenuRef"
      :channelData="channelData"
      :navList="myChannelList"
      :currentLabel="myChanneLabel"
      :scrollLabelNav="myChanneLabel"
      @check="checkChannel"
      @saveMyLabel="saveMyLabel"
      @showChannelBox="showChannelState = $event"
    />

    <view v-if="topCheckTabCode != 'partner'" :style="topCheckTabCode == 'plaza' ? 'height: 90rpx;width: 100vw' : 'height: 80rpx;width: 100vw'"></view>
    <swiper @transition="stopChange" :current="checkSwiperIndex" :duration="swiperDuration" :class="[topCheckTabCode == 'partner' ? 'swiper-partner' : 'swiper', control ? 'control' : '']" @change="changeCheckedTabList" :disable-touch="showChannelState || isDisabledTouch" :circular="isCircular">
      <!-- 单独对动态 推荐类型做处理 （原因：有特殊内容-正在热聊） -->
      <swiper-item v-show="topCheckTabCode == 'plaza' && checkTabCode == 'RECOMMEND'">
        <!-- 动态内容 start -->
        <scroll-view
          :scroll-top="scrollTop"
          v-show="topCheckTabCode == 'plaza'"
          class="swiper-scroll"
          :refresher-enabled="refresherEnabled"
          :refresher-triggered="refresherTriggered[0]"
          scroll-y
          :refresher-threshold="150"
          :lower-threshold="800"
          @scrolltolower="loadMore"
          @refresherrefresh="refreshData(0, topHeadTab[0].classList[0], 0)"
          @scroll="handleScroll($event, 'plaza')"
        >
          <!-- 动态 && type == 推荐才展示 -->
          <view v-if="tagList.length > 0">
            <!-- 正在热聊 -->
            <view class="plaza-hot-box">
              <view class="hot-box-title flex-1" @click="goHotTopList">
                <!-- <view>正在热聊</view> -->
                <image class="hot-box-title-img" src="http://img.yiqitogether.com/yqyq-app/images/hot_topic.png" mode="scaleToFill" />
                <image class="hot-box-narrow" src="http://img.yiqitogether.com/yqyq-app/images/more.png" mode="scaleToFill" />
              </view>
              <view class="hot-box">
                <view
                  class="hot-box-item flex-1"
                  v-for="(item, index) in tagList"
                  :key="index"
                  @click="
                    $u.throttle(() => {
                      bannerSkip(item.linkUrl, bannerList1)
                    }, 1000)
                  "
                >
                  <view class="hot-box-item-left flex-0">
                    <image class="item-left-img" src="http://img.yiqitogether.com/yqyq-app/images/ht_icon.png" mode="scaleToFill" />
                    <view class="item-left-text">{{ item.text }}</view>
                  </view>
                  <view class="hot-box-item-right flex-0">
                    <image v-if="index == 0" class="item-right-img" src="http://img.yiqitogether.com/yqyq-app/images/top1.png" mode="scaleToFill" />
                    <image v-if="index == 1" class="item-right-img" src="http://img.yiqitogether.com/yqyq-app/images/top2.png" mode="scaleToFill" />
                    <image v-if="index == 2" class="item-right-img" src="http://img.yiqitogether.com/yqyq-app/images/top3.png" mode="scaleToFill" />
                    <view class="item-right-text" :style="index == 0 ? 'color:#FF6767;' : index == 1 ? 'color:#FB854E;' : 'color:#FBB44E;'">{{ formatNumber(item.bannerOrder) || 0 }}</view>
                  </view>
                </view>
              </view>
            </view>
            <view class="border-line"></view>
          </view>

          <find-plaza-list
            v-show="topHeadTab[0].classList[0] && !topHeadTab[0].classList[0].showLoading"
            :ref="'findPlazaList' + 0"
            :showLoading="topHeadTab[0].classList[0].showLoading"
            :activtyData="topHeadTab[0].classList[0].list"
            @playVideo="playVideo"
            :checkTabCode="checkTabCode"
            @refreshList="refreshList"
            :pageType="'find'"
            @getPersonToPersonLikeList="getPersonToPersonLikeList"
            @deleteInterestPersonList="deleteInterestPersonList"
            @changeRefreshe="changeRefreshe"
          >
            <view class="tips-box" style="padding-top: 24rpx; padding-bottom: 50rpx" @click.stop="$u.throttle(loadMore, 500)">
              <u-loadmore :status="topHeadTab[0].classList[0].loadStatus" :fontSize="20" nomore-text="到底了~" />
            </view>
          </find-plaza-list>
        </scroll-view>
        <!-- 动态内容 end -->
      </swiper-item>

      <swiper-item v-for="(item, index) in [...topHeadTab[0].classList.slice(1)]" :key="index">
        <!-- 动态内容 start -->
        <scroll-view
          :scroll-top="scrollTop"
          v-show="topCheckTabCode == 'plaza'"
          class="swiper-scroll"
          :refresher-enabled="refresherEnabled"
          :refresher-triggered="refresherTriggered[0]"
          scroll-y
          :refresher-threshold="150"
          :lower-threshold="800"
          @scrolltolower="loadMore"
          @refresherrefresh="refreshData(0, item, index)"
          @scroll="handleScroll($event, 'plaza')"
        >
          <find-plaza-list
            v-show="topHeadTab[0].classList[index + 1] && !topHeadTab[0].classList[index + 1].showLoading"
            :ref="'findPlazaList' + (index + 1)"
            :showLoading="topHeadTab[0].classList[index + 1].showLoading"
            :activtyData="topHeadTab[0].classList[index + 1].list"
            @playVideo="playVideo"
            :checkTabCode="checkTabCode"
            @refreshList="refreshList"
            :pageType="'find'"
            @getPersonToPersonLikeList="getPersonToPersonLikeList"
            @deleteInterestPersonList="deleteInterestPersonList"
            @changeRefreshe="changeRefreshe"
          >
            <view class="tips-box" style="padding-top: 24rpx; padding-bottom: 50rpx" @click.stop="$u.throttle(loadMore, 500)">
              <u-loadmore :status="topHeadTab[0].classList[index + 1].loadStatus" :fontSize="20" nomore-text="到底了~" />
            </view>
          </find-plaza-list>
        </scroll-view>
      </swiper-item>

      <!-- 单独对发现 推荐类型做处理 （原因：有特殊内容- banner swiper） -->

      <swiper-item v-show="topCheckTabCode == 'thread' && myChanneLabel == 'RECOMMEND'" class="swiper-scroll">
        <scroll-view
          :scroll-top="scrollTop"
          v-show="topCheckTabCode == 'thread'"
          class="swiper-scroll"
          scroll-y
          :refresher-enabled="refresherEnabled"
          :refresher-triggered="refresherTriggered[1]"
          :refresher-threshold="150"
          @refresherrefresh="refreshData(1, topHeadTab[1].classList[0], 0)"
          @scrolltolower="loadMore"
          @scroll="handleScroll($event, 'note')"
        >
          <block v-if="myChanneLabel == 'RECOMMEND'">
            <!-- 推荐官方限定活动 -->
            <u-swiper
              v-if="bannerList1.length"
              radius="0rpx"
              height="256rpx"
              bgColor="#ffffff"
              :list="bannerList1"
              keyName="bannerUrl"
              :circular="true"
              @click="
                $u.throttle(() => {
                  bannerSkip($event, bannerList1)
                }, 1000)
              "
              class="recommend-note-swiper"
            ></u-swiper>
            <!-- 推荐滑动列表 -->
            <scroll-view class="recommend-note-scollx" scroll-x>
              <view class="note-scollx flex-0">
                <view class="note-scollx-item" v-for="item in subBannerList" :key="item.id">
                  <image
                    class="scollx-item-img"
                    :src="item.bannerUrl"
                    mode="aspectFill"
                    @click="
                      $u.throttle(() => {
                        bannerSkip(item.linkUrl, bannerList1)
                      }, 1000)
                    "
                  />
                </view>
              </view>
            </scroll-view>
          </block>
          <!-- 新人实名抽奖活动 -->
          <view class="new-people-box flex1" v-if="!authSimple" @click="nextNewPeopleLuck">
            <image class="new-people-luck" src="https://img.yiqitogether.com/yqyq-app/images/index-lucky-draw.png" mode="widthFix"></image>
          </view>
          <block v-if="topHeadTab[1].classList[0]">
            <view class="waterfall" v-show="!topHeadTab[1].classList[0].showLoading && topHeadTab[1].classList[0]">
              <post-list :ref="'notePostListRef' + 0" :showLoading="topHeadTab[1].classList[0].showLoading" :list="topHeadTab[1].classList[0].postList.list" :status="topHeadTab[1].classList[0].postList.status" @playVideo="playVideo" @done="noteDone">
                <view class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
                  <u-loadmore :status="topHeadTab[1].classList[0].loadStatus" :fontSize="20" nomore-text="到底了~" loadmore-text="加载中" />
                </view>
              </post-list>
            </view>
          </block>
        </scroll-view>
      </swiper-item>

      <swiper-item v-for="(item, index) in [...topHeadTab[1].classList.slice(1)]" :key="'thread' + index">
        <!-- 发现内容 start -->
        <scroll-view
          :scroll-top="scrollTop"
          v-show="topCheckTabCode == 'thread'"
          class="swiper-scroll"
          scroll-y
          :refresher-enabled="refresherEnabled"
          :refresher-triggered="refresherTriggered[1]"
          :refresher-threshold="150"
          @refresherrefresh="refreshData(1, item, index + 1)"
          @scrolltolower="loadMore"
          @scroll="handleScroll($event, 'note')"
        >
          <block v-if="topHeadTab[1].classList[index + 1]">
            <view class="waterfall" v-show="!topHeadTab[1].classList[index + 1].showLoading && topHeadTab[1].classList[index + 1]">
              <post-list :ref="'notePostListRef' + index + 1" :showLoading="topHeadTab[1].classList[index + 1].showLoading" :list="topHeadTab[1].classList[index + 1].postList.list" :status="topHeadTab[1].classList[index + 1].postList.status" @playVideo="playVideo" @done="noteDone">
                <view class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
                  <u-loadmore :status="topHeadTab[1].classList[index + 1].loadStatus" :fontSize="20" nomore-text="到底了~" loadmore-text="加载中" />
                </view>
              </post-list>
            </view>
          </block>
        </scroll-view>
        <!-- 发现内容 end -->
      </swiper-item>
      <swiper-item>
        <!-- 搭子内容 start -->
        <scroll-view
          :scroll-top="scrollTop"
          v-show="topCheckTabCode == 'partner'"
          scroll-y
          class="facescoreList"
          :refresher-enabled="refresherEnabled"
          :refresher-triggered="refresherTriggered[2]"
          :refresher-threshold="150"
          @refresherrefresh="refreshData(2)"
          @scrolltolower="loadMore"
          @scroll="handleScroll($event, 'partner')"
        >
          <image @click="goFaceVote" class="partner-top" src="http://img.yiqitogether.com/yqyq-app/images/partner_icon.gif" mode="scaleToFill" />
          <partner-list :partnerList="partnerList" :showLoading="showLoading">
            <view style="padding-top: 24rpx; padding-bottom: 50rpx" class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
              <u-loadmore :status="partnerLoadStatus" :fontSize="20" nomore-text="到底了~" />
            </view>
          </partner-list>
        </scroll-view>
        <!-- 搭子内容 end -->
      </swiper-item>
    </swiper>

    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于显示附近的人和活动" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="localTip" isImg isOnShow></accredit-popup>
    <find-blogger-pop :bloggerPopshow="bloggerPopshow" :bloggerPopNotice="bloggerPopNotice" @bloggerPopOpen="bloggerPopOpen" @bloggerPopClose="bloggerPopClose"></find-blogger-pop>
    <!-- 扫码 -->
    <accredit-popup ref="accreditSweep" systemTitle="“一起一起”想访问您的相机" systemContent="用于使用上传照片功能" permisionID="android.permission.CAMERA" cacheId="cameraAccredit" @successAccredit="sweepEvent"></accredit-popup>
    <!-- 搭子筛选弹框 -->
    <partner-screen :showPartnerScreen="showPartnerScreen" :gender="gender" @closePartnerScreen="closePartnerScreen" :openPartnerScreen="openPartnerScreen"></partner-screen>

    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
    <!-- 测试智能助手 勿删！！！ -->
    <!-- <view style="position: fixed; left: 0; top: 300rpx; width: 100rpx; height: 100rpx; border-radius: 20rpx; background-color: aquamarine" @click="testButton">智能助手</view> -->
  </view>
</template>

<script>
// 引用瀑布流组件-帖子
import postList from '@/components/post-list/waterfall-list.vue'
// 导入组件
import findPlazaList from './commponent/find-plaza-list.vue'
import findBloggerPop from './commponent/find-blogger-pop.vue'
import partnerScreen from '@/pages/find/commponent/partner-screen.vue'

// 导入接口
import findModel from '@/model/find.js'
import IndexModal from '@/model/index'
import loginModel from '@/model/login.js'
import MyInfo from '@/model/my.js'

import { getTokenConnectRongYun } from '@/utils/publicRequest.js'

// 导入缓存工具 及 缓存字典
import { clear, load, save } from '@/utils/store.js'
import { judgeImageSize, handleImgWinthAndHeight, formatNumber, getLocation } from '@/utils/tools.js'
import { scanQrcode } from '@/utils/qrcodeScan'
import { ACCESS_LOCATION, LOGIN_USERID, TWITTERRECOMMENDKEYWORD, NOTESRECOMMENDKEYWORD, USER_INFO, AUTH_SIMPLE, CONNECTRONGYUN, EXTERNAL_STORAGE, CAMERA_ACCREDIT, CITY_NAME, POSITION } from '@/utils/cacheKey.js'
import ZeroLazyLoad from '../../uni_modules/zero-lazy-load/components/zero-lazy-load/zero-lazy-load.vue'
import Blogger from '@/model/blogger.js'
import { bannerSkip } from '@/utils/bannerSkip.js'
import partnerList from './commponent/partner-list.vue'
export default {
  components: {
    findPlazaList,
    ZeroLazyLoad,
    postList,
    findBloggerPop,
    partnerList,
    partnerScreen
  },
  data() {
    return {
      bannerSkip,
      authSimple: load(AUTH_SIMPLE) || false,
      // 在当前页点击tabbar，刷新开关。默认关闭，在onshow里先关闭，2s以后再开启
      clickCurrentTabbarFlag: false,
      // 当前视频全屏状态
      currentFullScreenState: null,
      isscrollTop: false, //滑动顶部背景图
      // 未读数量
      unreadObj: {
        commentNewlyNumber: 0,
        hasCommentNewly: false,
        hasZanNewly: false
      },
      videoPlayUrl: '', // video的视频源
      // 最顶部tab
      topHeadTab: [
        {
          id: 2,
          text: '动态',
          code: 'plaza',
          classList: [
            // {
            //   id: 3,
            //   text: '热门',
            //   label: 'HOT',
            //   list: [],
            //   pages: 0,
            //   pageNumber: 1,
            //   dynamiclastKeyWord: '',
            //   loadStatus: 'loadmore'
            // },
            {
              id: 5,
              text: '推荐',
              label: 'RECOMMEND',
              list: [],
              pages: 0,
              pageNumber: 1,
              hasNextPage: false,
              dynamiclastKeyWord: '',
              loadStatus: 'loadmore',
              showLoading: true
            },
            {
              id: 2,
              text: '最新',
              label: 'PUSH',
              list: [],
              pages: 0,
              pageNumber: 1,
              hasNextPage: false,

              dynamiclastKeyWord: '',
              loadStatus: 'loadmore',
              showLoading: true
            },
            {
              id: 1,
              text: '关注',
              label: 'ATENTION',
              list: [],
              pages: 0,
              pageNumber: 1,
              hasNextPage: false,

              dynamiclastKeyWord: '',
              loadStatus: 'loadmore',
              showLoading: true
            },
            {
              id: 0,
              text: '附近',
              label: 'NEAR',
              list: [],
              pages: 0,
              pageNumber: 1,
              hasNextPage: false,

              dynamiclastKeyWord: '',
              loadStatus: 'loadmore',
              showLoading: true
            },
            // 颜值 / 会员
            {
              id: 6,
              text: '会员',
              label: 'GOOD_VIP',
              list: [],
              pages: 0,
              pageNumber: 1,
              hasNextPage: false,
              dynamiclastKeyWord: '',
              loadStatus: 'loadmore',
              showLoading: true
            }

            /**
             * 自定义的类型，后台接口没有该类型，是为了我的收藏中动态列表组件的复用
             */
            // {
            //   id: 4,
            //   txt: '收藏',
            //   code: 'COLLECT'
            // }
          ]
        },
        {
          id: 1,
          text: '发现',
          code: 'thread',
          classList: [
            { text: '推荐', label: 'RECOMMEND', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 },
            { text: '关注', label: 'ATENTION', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 }
          ]
        },
        {
          id: 3,
          text: '颜值圈',
          code: 'partner',
          classList: []
        }
      ],
      topCheckTabCode: 'thread', //最顶部选择tab
      checkTabCode: 'RECOMMEND',
      position: '',
      videoContext: '', //视频
      twitterType: 'TWITTER',
      tagList: [], //话题圈子标签列表
      showLoading: true, //loading加载
      numberId: load(LOGIN_USERID) || '',
      tagLabelList: ['GOOD_PHOTO', 'APPOINTMENT', 'TWITTER_FORWARD', 'BIRTHDAY', 'NOTES_FORWARD_TWITTER'], //活动卡片标签
      hasNextPage: false, //是否有下一页
      formatNumber,
      // 频道列表
      channelData: [],
      // 我的频道列表
      myChannelList: [
        { text: '推荐', label: 'RECOMMEND', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 },
        { text: '关注', label: 'ATENTION', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 }
      ],
      // 我的频道label
      myChanneLabel: 'RECOMMEND',
      bloggerPopshow: false, // 博主打卡提示框
      //频道栏展开状态
      showChannelState: false,
      bloggerPopNotice: {}, // 博主打卡提示信息
      isBlogger: false, // 是否是博主
      // 请求节流阀
      requestFlag: true,
      refresherTriggered: [false, false, false],
      isDisabledTouch: false,
      checkSwiperIndex: 0,
      loadedList: [], // 已加载的tabList
      swiperDuration: 300, // 滑动效果
      indexChangeClick: false, //是否通过点击滑动tab
      refresherEnabled: true, // 是否能够下拉刷新
      isCircular: true, // 是否衔接滑动
      control: true,
      activityType: [], //活动类型
      // 头部卡片
      bannerList: [],
      bannerList1: [],
      // 副轮播
      subBannerList: [],
      // 颜值搭子随机推荐
      personDTOList: [],
      // 可能感兴趣的人列表
      interestPersonDTO: {},
      noClick: true,
      partnerPageNumber: 0,
      partnerList: [], // 搭子列表
      partnerLoadStatus: 'loadmore',
      partnerPageNumber: 0,
      partnerPages: 0,
      showPartnerScreen: false, // 筛选弹框
      gender: '', // 请求的筛选性别
      authGood: false,
      slipdirection: '',
      scrollTop: 0, // 设置swiper滑动距离
      // 记录swiper滑动距离
      old: {
        scrollTop: 0
      }
    }
  },
  onPageScroll(e) {
    //nvue暂不支持滚动监听，可用bindingx代替
    let top
    // #ifdef H5
    top = 117
    // #endif
    // #ifndef H5
    top = 117
    // #endif
    if (e.scrollTop < top) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  onTabItemTap(e) {
    if (this.clickCurrentTabbarFlag) {
      uni.$u.debounce(this.refreshList, 1000)
    }
  },
  watch: {
    checkSwiperIndex: {
      handler(newVal, oldVal) {
        setTimeout(() => {
          this.refresherEnabled = true
          this.$forceUpdate()
        }, 500)
      },
      deep: true
    }
  },
  async onLoad(e) {
    // 如果不是移动端，就跳转到PC
    // #ifdef H5
    let isMobile = this.isMobile()
    if (!isMobile) {
      window.location.href = 'https://www.yiqitogether.com/#/'
    }
    // #endif

    //获取当前页面的webview对象 禁止侧滑
    // #ifdef APP-PLUS
    this.getEngine()
    let currentWebview = this.$mp.page.$getAppWebview()
    currentWebview.setStyle({ popGesture: 'none' })
    // #endif

    // 点击加号，弹出发布框
    uni.$on('openIndexPopup', () => {
      this.$refs.publishPopupRef.onOpen()
    })

    // ----------- 业务代码 start -------------------
    this.getIndexBanner() // 获取首页banner (正在热聊)
    this.getMyChannelEvent() // 获取频道列表
    this.getStatusInfo() // 获取学生认证信息状态
    this.appointmentType() // 获取发现页 banner && tab栏

    // 获取定位
    setTimeout(() => {
      this.$refs.accredit.triggerEvent()
    }, 100)

    //
    this.topCheckTabCode = e.topCheckTabCode ? e.topCheckTabCode : 'thread'
    if (e.topCheckTabCode) {
      this.indexChangeClick = true
    }
    if (e.checkTabCode) {
      this.indexChangeClick = true
      this.checkTabCode = e.checkTabCode
    }
    if (e.topCheckTabCode === 'thread' || this.topCheckTabCode === 'thread') {
      // 获取看帖列表
      this.topCheckTabCode = 'thread'
      this.twitterType = 'NOTES'
      // this.checkTabCode = 'PUSH'
      this.myChanneLabel = e.myChanneLabel || this.myChanneLabel
      // swiper样式设置不固定
      this.control = false
    }

    setTimeout(() => {
      this.refreshList()
    }, 500)
    // ----------- 业务代码 end -------------------
  },
  onShow() {
    this.isBlogger = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)).isBlogger : false
    uni.showTabBar()
    uni.stopPullDownRefresh()
    this.clickCurrentTabbarFlag = false
    setTimeout(() => {
      this.clickCurrentTabbarFlag = true
    }, 1000)
    this.hasNewlyFun()
    this.numberId = load(LOGIN_USERID) || ''
    /**
     * 是博主才调用每日打卡接口
     */
    if (this.isBlogger) {
      this.getBloggerNotice()
    }
  },
  onReady() {
    // 视频
    this.videoContext = uni.createVideoContext('videoId')
  },
  onHide() {
    this.$refs.publishPopupRef.onClose()
    if (this.topCheckTabCode == 'plaza') {
      let that = this
      this.loadedList.map(item => {
        if (item <= 4) {
          let ref
          if (item == 0) {
            ref = eval('that.$refs.findPlazaList' + item)
          } else {
            ref = eval('that.$refs.findPlazaList' + item)[0]
          }
          if (ref) {
            ref.closeMoreClick()
          }
        }
      })
    }
  },
  methods: {
    // 测试按钮 暂时勿删！！！！！
		testButton() {
			uni.navigateTo({
        // url:`/pages/my/webView?destination=3&openUrl=http://192.168.1.157:8082/pages/deepSeek/index/index`
        // url:`/pages/my/webView?destination=3&openUrl=http://192.168.1.71:8080/pages/deepSeek/index/index`
				url:`/pages/my/webView?destination=3&openUrl=https://applet-h5.yiqitogether.com/#/pages/deepSeek/index/index`
			})
			return
		  clear(ACCESS_LOCATION)
		  clear(EXTERNAL_STORAGE)
		  clear(CAMERA_ACCREDIT)
		  clear(CITY_NAME)
		  clear(POSITION)
		},
    /**
     * 扫一扫
     */
    sweep() {
      this.$refs.accreditSweep.triggerEvent()
      this.noClick = false
    },
    sweepEvent() {
      // 允许从相机和相册扫码
      this.noClick = true
      scanQrcode()
      // let that = this
      // uni.scanCode({
      //   success: function (res) {
      //     let strPosition = res.result.indexOf('/pagesCommon/details/details')
      //     let info = res.result.indexOf('"type":"joinGroup"')
      //     let pcLoginInfo = res.result.indexOf('"type":"pcLogin"')
      //     let activityDetails = res.result.indexOf('"type":"eventDetails"')
      //     if (info > -1) {
      //       let a = JSON.parse(res.result)
      //       uni.navigateTo({
      //         url: '/pagesMessage/privateChat/groupConfirm?groupNo=' + a.groupNo
      //       })
      //     } else if (strPosition > -1) {
      //       let path = res.result.substring(strPosition)
      //       uni.navigateTo({
      //         url: path
      //       })
      //     } else if (pcLoginInfo > -1) {
      //       let pcLoginData = JSON.parse(res.result)
      //       let data = {
      //         uuid: pcLoginData.uuid,
      //         numberId: that.numberId
      //       }
      //       loginModel
      //         .getScanQrCode(data)
      //         .then(res => {
      //           if (res.code == 'SUCCESS') {
      //             uni.navigateTo({ url: '/pages/login/scanLoginQrCode?dataInfo=' + JSON.stringify(data) })
      //           } else {
      //             uni.showToast({
      //               title: res.message,
      //               icon: 'none'
      //             })
      //           }
      //         })
      //         .catch(err => {
      //           uni.showToast({
      //             title: err.message,
      //             icon: 'none'
      //           })
      //         })
      //     } else if (activityDetails > -1) {
      //       let activityDetailsInfo = JSON.parse(res.result)
      //       uni.navigateTo({ url: '/pagesCommon/details/details?appointmentNo=' + activityDetailsInfo.appointmentNo })
      //     } else {
      //       uni.showToast({
      //         title: '暂不支持该类型的二维码',
      //         icon: 'none'
      //       })
      //     }
      //   }
      // })
    },
    /**
     * 融云初始化，链接相应的应用
     */
    async getEngine() {
      let that = this
      if (!load(CONNECTRONGYUN)) {
        getTokenConnectRongYun(that)
      }
      this.$store.state.engie.setOnConnectedListener(res => {
        console.log('融云连接的回调', res)
        if (res.code == 0 || res.code == 34001) {
          // 获取融云所有的未读数
          this.getTotalUnreadCount()
        } else {
          console.log('连接异常,请稍后再试')
        }
      })
      this.$store.state.engie.setOnMessageReceivedListener(res => {
        //设置消息监听
        if (res.message.conversationType == 1) {
          // 全局注册事件，目的：当接收到外来消息时，要让私聊页面自动刷新
          uni.$emit('updateHistory', { msg: res })
        } else {
          // 群聊监听
          uni.$emit('updateHistoryGroup', { msg: res })
        }
      })
    },
    // 获取所有的未读数
    async getTotalUnreadCount() {
      this.$store.state.engie.setOnUnreadCountByConversationTypesLoadedListener(res => {
        console.log(res, '未读数数量')
        if (res.count != 0) {
          uni.showTabBarRedDot({
            index: 2
          })
        } else {
          uni.removeTabBarBadge({
            //隐藏数字标
            index: 2 //tabbar下标
          })
          try {
            plus.runtime.setBadgeNumber(0)
            // plus.push.clear()
          } catch (error) {}
        }
      })
      let code = await this.$store.state.engie.getUnreadCountByConversationTypes([1, 2], null, false, null)
      // uni.removeTabBarBadge({
      //   //隐藏数字标
      //   index: 2 //tabbar下标
      // })
    },
    /**
     * 前往新人抽奖
     */
    nextNewPeopleLuck() {
      uni.navigateTo({
        url: '/pagesCommon/authentication/authentication'
      })
    },
    isMobile() {
      const userAgent = navigator.userAgent
      return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)
    },
    stopChange(e) {
      // 滑动时禁止刷新
      this.refresherEnabled = false
      setTimeout(() => {
        if (e.detail.dx == 0) {
          this.refresherEnabled = true
        }
      }, 500)
      // 动态-推荐不能衔接右滑,发现末尾类型可以滑到动态-推荐
      if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
        if (e.detail.dx <= 0) {
          this.control = true
        } else {
          this.control = false
        }
        this.isCircular = false
      } else {
        this.isCircular = true
      }
      if (e.detail.dx < 0) {
        this.slipdirection = 'left'
      } else if (e.detail.dx > 0) {
        this.slipdirection = 'right'
      }
      this.$forceUpdate()
    },
    refreshData(type, item, index) {
      // 禁止用户touch操作
      this.isDisabledTouch = true
      uni.$u.debounce(this.closeTouch, 100)
      if (this.topCheckTabCode == 'plaza') {
        if (this.checkTabCode != item.label) {
          return
        }
      } else if (this.topCheckTabCode == 'thread') {
        if (this.myChanneLabel != item.label) {
          return
        }
      }
      this.refresherTriggered[type] = true
      this.refreshList()
      setTimeout(() => {
        this.refresherTriggered[type] = false
        this.$forceUpdate()
      }, 1500)
    },

    /**
     * 保存选择的发现标签，并重置为全部
     */
    saveMyLabel() {
      // this.currentLabel = 'RECOMMEND'
      this.scrollLabelNav = 'RECOMMEND'
      this.myChanneLabel = 'RECOMMEND'
      this.myChannelList = [
        { text: '推荐', label: 'RECOMMEND', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 },
        { text: '关注', label: 'ATENTION', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 }
      ]
      this.getMyChannelEvent()
      // 发现加载tab清空 保留动态tab
      this.loadedList = this.loadedList.filter(item => item <= 4)
      this.refreshList()
    },
    /**
     * 滚动时触发
     */
    handleScroll(e, type) {
      // 禁止用户touch操作
      this.isDisabledTouch = true
      uni.$u.debounce(this.closeTouch, 100)
      // 记录swiper滑动距离
      this.old.scrollTop = e.detail.scrollTop
    },
    /**
     * 关闭禁止用户touch操作
     */
    closeTouch() {
      this.isDisabledTouch = false
    },
    /**
     * 定位提示 判断显示状态
     */
    localTip() {
      // #ifdef APP-PLUS
      let isIos = plus.os.name == 'iOS'
      if (!isIos) {
        //安卓
        if (load(ACCESS_LOCATION) !== '' && load(ACCESS_LOCATION)) {
          this.getPostion()
        }
      } else {
        this.getPostion()
      }
      // #endif
    },
    // 点击播放视频
    playVideo(type) {
      let self = this
      this.videoPlayUrl = type.videoUrl
      // #ifdef H5
      try {
        this.$nextTick(() => {
          self.videoContext.requestFullScreen({ direction: 0 })
        })
      } catch (e) {
        console.log(e)
      }
      // #endif
      // #ifndef H5
      if (this.videoPlayUrl) {
        uni.navigateTo({
          url: '/pages/my/videoPlay?url=' + this.videoPlayUrl,
          events: {
            setFullscreen() {
              plus.navigator.setFullscreen(false)
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    /**
     * @param {Object} e 视频是否进入全屏
     */
    videoFullScreenChange(e) {
      this.currentFullScreenState = e.detail.fullScreen
      if (e.detail.fullScreen) {
        // 开始播放
        this.videoContext.play()
      } else {
        // 停止播放，销毁数据源
        this.videoContext.pause()
        this.videoPlayUrl = null
      }
    },
    /**
     * 视频播放时，要判断是否为全屏，非全屏则暂停视频
     */
    videoPlayFun() {
      if (!this.currentFullScreenState) {
        this.videoContext.pause()
      }
    },
    // 加载更多
    loadMore() {
      if (this.topCheckTabCode == 'plaza') {
        // 判断属于哪个二级分类加到对应分类的动态列表当中
        let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)

        if (this.topHeadTab[0].classList[checkType].hasNextPage) {
          if (this.topHeadTab[0].classList[checkType].pageNumber == 3 && (this.checkTabCode == 'RECOMMEND' || this.checkTabCode == 'PUSH')) {
            this.getPersonToPersonRandomList()
          } else if (this.topHeadTab[0].classList[checkType].pageNumber == 5 && (this.checkTabCode == 'RECOMMEND' || this.checkTabCode == 'PUSH')) {
            this.getPersonToPersonLikeList()
          }
          this.topHeadTab[0].classList[checkType].loadStatus = 'loading'
          setTimeout(() => {
            this.getActivList(this.topHeadTab[0].classList[checkType].lastKeyWord)
          }, 100)
        }
      } else if (this.topCheckTabCode == 'thread') {
        // 判断属于哪个二级分类加到对应分类的发现列表当中
        let noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)
        if (this.topHeadTab[1].classList[noteCheckType].hasNextPage) {
          this.topHeadTab[1].classList[noteCheckType].loadStatus = 'loading'
          this.getActivList(this.topHeadTab[1].classList[noteCheckType].lastKeyWord)
        }
      } else {
        if (this.partnerPages > this.partnerPageNumber && this.partnerLoadStatus != 'loading') {
          this.partnerLoadStatus = 'loading'
          this.getUserDaziList()
        }
      }
    },
    /**
     * 刷新数据（只刷新当前二级tab下的数据）
     */
    refreshList() {
      // this.showLoading = true
      if (this.topCheckTabCode == 'plaza') {
        // 动态列表置空
        // 判断属于哪个二级分类加到对应分类的动态列表当中
        let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)
        // 清空当前的tab
        if (checkType != -1) {
          this.topHeadTab[0].classList[checkType].pages = 0
          this.topHeadTab[0].classList[checkType].pageNumber = 1
          this.topHeadTab[0].classList[checkType].hasNextPage = false
          this.topHeadTab[0].classList[checkType].list = []
          this.topHeadTab[0].classList[checkType].lastKeyWord = ''
          this.topHeadTab[0].classList[checkType].loadStatus = 'loadmore'
        }
        this.loadedList = this.loadedList.filter(item => item != checkType)
      } else if (this.topCheckTabCode == 'thread') {
        if (this.topHeadTab[1].classList.length < 3) {
          this.myChannelList = [
            { text: '推荐', label: 'RECOMMEND', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 },
            { text: '关注', label: 'ATENTION', postList: { status: 'reset', reset: 'reset', list: [] }, showLoading: true, pageNumber: 1 }
          ]
          this.getMyChannelEvent()
        }
        // 瀑布流数据置空
        // 判断属于哪个二级分类加到对应分类的发现列表当中
        let noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)
        if (noteCheckType != -1) {
          this.topHeadTab[1].classList[noteCheckType].pages = 0
          this.topHeadTab[1].classList[noteCheckType].pageNumber = 1
          this.topHeadTab[1].classList[noteCheckType].hasNextPage = false
          this.topHeadTab[1].classList[noteCheckType].postList = { status: 'reset', reset: 'reset', list: [] }
          this.topHeadTab[1].classList[noteCheckType].lastKeyWord = ''
          this.topHeadTab[1].classList[noteCheckType].loadStatus = 'loadmore'
        }

        // 清空当前的tab
        this.loadedList = this.loadedList.filter(item => item != noteCheckType + 5)
      } else if (this.topCheckTabCode == 'partner') {
        let num = this.topHeadTab[0].classList.length + this.topHeadTab[1].classList.length
        this.loadedList.filter(item => item != num)
        this.partnerPageNumber = 0
        this.partnerPages = 0
        this.partnerList = []
        this.partnerLoadStatus = 'loadmore'
      }

      if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
        this.tagList = []
        // 获取首页banner (正在热聊)
        this.getIndexBanner()
      }
      // 发布发现要用setTimeout  $nextTick苹果有问题
      setTimeout(() => {
        this.getList()
      }, 50)
      this.appointmentType()
    },
    /**
     * 调用tab列表数据接口
     */
    getList(type) {
      // 获取频道列表 (发现、编辑tab保存重新调用getMyChannelEvent)
      // if (this.topCheckTabCode == 'thread' && type != 'clickNoteType') {
      //   this.getMyChannelEvent()
      // }
      /**
       * 动态、发现（推荐列表要读取缓存keyword）
       * 判断条件 动态且为推荐 plaza && RECOMMEND
       * 发现 且 为推荐 thread && RECOMMEND
       */
      let lastKeyWord = ''
      if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
        lastKeyWord = load(TWITTERRECOMMENDKEYWORD) || ''
      } else if (this.topCheckTabCode == 'thread' && this.myChanneLabel == 'RECOMMEND') {
        lastKeyWord = load(NOTESRECOMMENDKEYWORD) || ''
      }
      let index = -1
      // 存储到已加载过的缓存列表当中
      if (this.topCheckTabCode == 'plaza') {
        index = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)
        if (index != -1) {
          this.checkSwiperIndex = index
          this.loadedList.push(this.checkSwiperIndex)
        }
      } else if (this.topCheckTabCode == 'thread') {
        index = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)
        if (index != -1) {
          this.checkSwiperIndex = index + 5
          this.loadedList.push(this.checkSwiperIndex)
        }
      } else if (this.topCheckTabCode == 'partner') {
        index = this.topHeadTab[0].classList.length + this.topHeadTab[1].classList.length
        this.loadedList.push(index)
      }
      this.showLoading = true
      if (this.topCheckTabCode == 'partner') {
        this.getUserDaziList()
      } else {
        this.getActivList(lastKeyWord)
      }
    },
    /**
     * 获取频道列表
     */
    getMyChannelEvent() {
      findModel
        .getMyChannel()
        .then(res => {
          if (res.code == 'SUCCESS') {
            res.data.list.map(item => {
              item.postList = { status: 'reset', reset: 'reset', list: [] }
              item.showLoading = true
              item.pageNumber = 1
            })
            this.channelData = res.data
            this.myChannelList = [...this.myChannelList, ...res.data.list]
            /**
             * swiper类型添加
             */
            this.topHeadTab[1].classList = [...this.myChannelList]
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    // 获取动态动态数据
    getActivList(lastKeyWord) {
      if (!this.requestFlag) {
        return
      }
      this.requestFlag = false
      //获取活动列表数据
      // this.position = uni.getStorageSync('position')
      let params = {
        pageSize: 10, //	String	否	每页请求数据
        lastKeyWord: lastKeyWord || '', //	String	否	分页查询关键词（第一页可不传，其他页必传）
        targetNumberId: '', //	String	否	目标用户ID。如果是看他人主页，必传
        position: this.position, //   31.233815  ，121.390467 {"lat":28.228209,"lon":112.938814}
        twitterType: this.twitterType // 动态类型 NOTES 发现  / TWITTER 动态。默认或不传表示动态
      }
      if (this.topCheckTabCode == 'plaza') {
        // 动态的类型
        params.findType = this.checkTabCode
      } else if (this.topCheckTabCode == 'thread') {
        let noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)
        if (this.topHeadTab[1].classList[noteCheckType] && this.topHeadTab[1].classList[noteCheckType].postList) {
          this.topHeadTab[1].classList[noteCheckType].postList.status = 'loading'
        }
        // 笔记的频道和、关注要在findType里传
        if (this.myChanneLabel == 'RECOMMEND' || this.myChanneLabel == 'ATENTION') {
          params.findType = this.myChanneLabel
        }
        // 频道名称，推荐和关注固定为 RECOMMEND / ATENTION
        params.channelName = this.myChanneLabel
      }
      // this.showLoading = true
      // 判断属于哪个二级分类加到对应分类的动态列表当中
      let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)
      // 判断属于哪个二级分类加到对应分类的发现列表当中
      let noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)

      findModel
        .getFindList(params)
        .then(res => {
          /**
           * 将showLoading放上面是因为瀑布流的渲染时
           * 根据postList.status的值发生改变且值为SUCCESS才会渲染
           */
          this.showLoading = false
          if (res.code == 'SUCCESS') {
            let list = res.data.twitterlist.list || []
            this.hasNextPage = res.data.twitterlist.hasNextPage

            // 缓存推荐 的lastKeyWord
            if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
              save(TWITTERRECOMMENDKEYWORD, res.data.twitterlist.lastKeyWord)
            } else if (this.topCheckTabCode == 'thread' && this.myChanneLabel == 'RECOMMEND') {
              save(NOTESRECOMMENDKEYWORD, res.data.twitterlist.lastKeyWord)
            }
            if (list && list.length > 0) {
              list.forEach(async item => {
                if (this.topCheckTabCode === 'plaza') {
                  // 活动卡片展示处理
                  if (item.twitterInfo.quoteInfoDTO) {
                    item.isContent = item.twitterInfo.quoteInfoDTO.officialTarget ? true : false
                    item.isShow = item.twitterInfo.quoteInfoDTO.officialTarget ? this.tagLabelList.indexOf(item.twitterInfo.quoteInfoDTO.officialTarget[0].label) : -1
                    try {
                      JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                      item.twitterInfo.quoteInfoDTO.quoteContent = JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                    } catch (error) {
                      item.twitterInfo.quoteInfoDTO.quoteContent = item.twitterInfo.quoteInfoDTO.quoteContent
                    }
                    // this.$forceUpdate()
                  } else {
                    item.isContent = false
                    item.isShow = -1
                  }

                  /**
                   * 动态图片处理
                   * - 图片转为数组，且仅为一张图时，将获取图片宽高
                   * - 处理活动卡片逻辑
                   * - 处理礼物按钮逻辑
                   */

                  let arr
                  // 图片处理
                  arr = item.twitterInfo.imageUrls ? item.twitterInfo.imageUrls.split('&&') : []
                  item.twitterInfo.images = arr
                  if (arr.length === 1) {
                    // let imgObj = await judgeImageSize(arr[0])
                    let imgObj = await handleImgWinthAndHeight(item.twitterInfo.imgSize, arr[0])
                    item.twitterInfo.images = [imgObj]
                    item.twitterInfo.itemType = item.twitterInfo.videoUrl ? 'video' : 'image'
                  }

                  // 礼物
                  item.userinfo.isGift = item.userinfo.tags ? item.userinfo.tags.split(',').includes('TAG_GIFTVIP') : false

                  // 更多操作（是否是自己）
                  let numberId = item.userinfo.numberId || ''
                  if (numberId === this.numberId) {
                    item.moreBtnList = ['删除动态']
                    item.isSelf = true
                  } else {
                    // item.moreBtnList = ['不看TA动态', '举报']
                    item.moreBtnList = ['举报']
                    item.isSelf = false
                  }

                  // 标签数据处理和长度处理最多显示五条
                  if (item.twitterInfo.markTopic && item.twitterInfo.markTopic != null && item.twitterInfo.markTopic != '') {
                    let markList = item.twitterInfo.markTopic.split('#').filter(v => v && v.trim())
                    if (markList.length > 5) {
                      item.twitterInfo.markTopics = markList.slice(0, 5)
                    } else {
                      item.twitterInfo.markTopics = markList
                    }
                  } else {
                    item.twitterInfo.markTopics = []
                  }
                }
              })

              if (this.topCheckTabCode == 'plaza') {
                //判断动态是否展示
                list = list.filter(item => {
                  /**
                   *   item.isShow != -1 (不是特殊卡片类型动态或label里没有)
                   *   item.isContent == false 普通动态
                   */
                  if (item.isShow != -1) {
                    return item.isContent == true
                  } else {
                    return item.isContent == false
                  }
                })
                if (checkType != -1) {
                  // 从新获取的数据开始计算，老数据不重复计算(展开、收起)
                  let oldindex = this.topHeadTab[0].classList[checkType].list.length == 0 ? 0 : this.topHeadTab[0].classList[checkType].list.length
                  setTimeout(() => {
                    this.$nextTick(() => {
                      let ref
                      if (this.checkTabCode == 'RECOMMEND') {
                        ref = eval('this.$refs.findPlazaList' + this.checkSwiperIndex)
                      } else {
                        ref = eval('this.$refs.findPlazaList' + this.checkSwiperIndex)[0]
                      }
                      list.forEach((item, index) => {
                        if (!item.contentType && item.contentType != 'goodVip') {
                          ref.isOverflow(item, index + oldindex)
                        } else {
                        }
                      })
                    })
                  }, 300)
                  this.topHeadTab[0].classList[checkType].list.push(...list)
                  if (this.topHeadTab[0].classList[checkType].pageNumber == 3 && this.personDTOList.length > 0 && (this.checkTabCode == 'RECOMMEND' || this.checkTabCode == 'PUSH')) {
                    this.topHeadTab[0].classList[checkType].list.push(...this.personDTOList)
                  }
                  if (this.topHeadTab[0].classList[checkType].pageNumber == 5 && this.interestPersonDTO.list && this.interestPersonDTO.contentType && (this.checkTabCode == 'RECOMMEND' || this.checkTabCode == 'PUSH')) {
                    this.topHeadTab[0].classList[checkType].list.push(this.interestPersonDTO)
                  }
                }
              } else {
                let noteCheckType
                // 如果后台当前页返回数据为空，页面会变成白屏
                if (list.length > 0) {
                  noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == this.myChanneLabel)
                  this.topHeadTab[1].classList[noteCheckType].postList.list = [...list]
                }
                setTimeout(() => {
                  this.topHeadTab[1].classList[noteCheckType].postList.status = 'success'
                }, 50)
              }
              this.$forceUpdate()
            }

            // 处理动态如果当前页没有数据，但有下一页 （主要针对动态做处理）
            if (list && list.length == 0 && res.data.twitterlist.hasNextPage) {
              this.loadMore()
            }

            if (this.topCheckTabCode == 'plaza') {
              this.topHeadTab[0].classList[checkType].pages = res.data.twitterlist.pages
              this.topHeadTab[0].classList[checkType].pageNumber = this.topHeadTab[0].classList[checkType].pageNumber + 1
              this.topHeadTab[0].classList[checkType].hasNextPage = res.data.twitterlist.hasNextPage
              this.topHeadTab[0].classList[checkType].lastKeyWord = res.data.twitterlist.lastKeyWord
              this.topHeadTab[0].classList[checkType].showLoading = false
              if (res.data.twitterlist.total == 0) {
                this.topHeadTab[0].classList[checkType].loadStatus = 'none'
              } else {
                if (!res.data.twitterlist.hasNextPage) {
                  this.topHeadTab[0].classList[checkType].loadStatus = 'nomore'
                } else {
                  this.topHeadTab[0].classList[checkType].loadStatus = 'loadmore'
                }
              }
            } else {
              this.topHeadTab[1].classList[noteCheckType].pages = res.data.twitterlist.pages
              this.topHeadTab[1].classList[noteCheckType].pageNumber = this.topHeadTab[1].classList[noteCheckType].pageNumber + 1
              this.topHeadTab[1].classList[noteCheckType].hasNextPage = res.data.twitterlist.hasNextPage
              this.topHeadTab[1].classList[noteCheckType].lastKeyWord = res.data.twitterlist.lastKeyWord
              this.topHeadTab[1].classList[noteCheckType].showLoading = false
              if (res.data.twitterlist.total == 0) {
                this.topHeadTab[1].classList[noteCheckType].loadStatus = 'none'
                this.closeTouch()
              } else {
                if (!res.data.twitterlist.hasNextPage) {
                  this.topHeadTab[1].classList[noteCheckType].loadStatus = 'nomore'
                } else {
                  this.topHeadTab[1].classList[noteCheckType].loadStatus = 'loadmore'
                }
              }
            }
            this.requestFlag = true
          } else {
            if (this.topCheckTabCode == 'plaza') {
              this.topHeadTab[0].classList[checkType].showLoading = false
            } else {
              this.topHeadTab[1].classList[noteCheckType].showLoading = false
            }

            if (this.checkTabCode == 'NEAR') {
              this.$nextTick(() => {
                this.$refs.accredit.triggerEvent()
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none',
                duration: 3000
              })
            }
            this.requestFlag = true
          }
        })
        .catch(err => {
          this.showLoading = false
          if (this.topCheckTabCode == 'plaza') {
            this.topHeadTab[0].classList[checkType].showLoading = false
          } else {
            this.topHeadTab[1].classList[noteCheckType].showLoading = false
          }
          this.requestFlag = true
        })
    },

    /**
     * 去往发现详情
     */
    goNotesDetails(item) {
      uni.navigateTo({
        url: '/pages/find/findDetails?twitterId=' + item.twitterInfo.twitterId + '&pageType=2'
      })
    },
    /**
     * 猜你喜欢 （可能感兴趣的人）
     */
    getPersonToPersonLikeList(isChange) {
      findModel
        .getPersonToPersonLikeList()
        .then(res => {
          if (res.code == 'SUCCESS') {
            if (isChange) {
              let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)
              if (res.data.personDTOList.length > 0) {
                this.interestPersonDTO.list = res.data.personDTOList
                this.topHeadTab[0].classList[checkType].list.map(item => {
                  if (item.contentType == 'interesting') {
                    item = this.interestPersonDTO
                  }
                })
              } else {
                let index = this.topHeadTab[0].classList[checkType].list.findIndex(item => item.contentType == 'interesting')
                this.topHeadTab[0].classList[checkType].list.splice(index, 1)
              }
              this.$forceUpdate()
            } else {
              if (res.data.personDTOList.length > 0) {
                this.interestPersonDTO.list = res.data.personDTOList
                this.interestPersonDTO.contentType = 'interesting'
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 500
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
          uni.showToast({
            title: err.message,
            icon: 'none',
            duration: 500
          })
        })
    },
    /**
     * 删除可能感兴趣的人数据
     */
    deleteInterestPersonList() {
      let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)
      let index = this.topHeadTab[0].classList[checkType].list.findIndex(item => item.contentType == 'interesting')
      this.topHeadTab[0].classList[checkType].list.splice(index, 1)
      this.$forceUpdate()
    },
    /**
     * 页面随机推荐(颜值搭子)
     */
    getPersonToPersonRandomList() {
      findModel
        .getPersonToPersonRandomList()
        .then(res => {
          if (res.code == 'SUCCESS') {
            res.data.personDTOList.map(item => {
              item.contentType = 'goodVip'
            })
            this.personDTOList = res.data.personDTOList
            this.$forceUpdate()
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 500
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none',
            duration: 500
          })
        })
    },
    // 评论未读数量
    hasNewlyFun() {
      let datas = {}
      findModel.isHasNewly(datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          // 7-1.未读评论数>0，则显示具体数字
          // 7-2.未读评论数=0, 未读点赞数>0, 显示红点
          // 7-3. 未读评论数=0，未读点赞数=0，无提醒
          this.unreadObj = dataRes.data
        } else {
          uni.showToast({
            title: dataRes.message,
            icon: 'none',
            duration: 3000
          })
        }
      })
    },
    /**
     * 动态一级tab切换
     */
    async checkFirstTab(data) {
      let self = this
      this.swiperDuration = 0
      if (data.label === this.topCheckTabCode) return
      this.indexChangeClick = true
      this.topCheckTabCode = data.code
      // 手动点击一级分类”动态“和”发现“，二级分类 默认进推荐栏
      if (data.code === 'plaza') {
        // 动态
        this.twitterType = 'TWITTER'
        // let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == this.checkTabCode)

        let checkType = this.topHeadTab[0].classList.findIndex(item => item.label == 'RECOMMEND')
        this.checkSwiperIndex = checkType == -1 ? 0 : checkType
      } else if (data.code === 'thread') {
        // 发现
        this.loadedList.map(item => {
          if (item <= 4) {
            let ref
            if (item == 0) {
              ref = eval('self.$refs.findPlazaList' + item)
            } else {
              ref = eval('self.$refs.findPlazaList' + item)[0]
            }
            if (ref) {
              ref.closeMoreClick()
            }
          }
        })
        this.twitterType = 'NOTES'
        let noteCheckType = this.topHeadTab[1].classList.findIndex(item => item.label == 'RECOMMEND')
        this.checkSwiperIndex = noteCheckType == -1 ? 5 : noteCheckType + 5
      } else if (data.code === 'partner') {
        this.checkSwiperIndex = this.topHeadTab[0].classList.length + this.topHeadTab[1].classList.length
      }
    },
    /**
     * 切换tab --改变swiper的current
     * 调用changeCheckedTabList
     */
    changeCheckedTabList(e) {
      this.control = false
      // 频繁切换会出现闪频问题 (只能用户触摸、和点击才能切换)
      if (e.detail.source == 'touch' || this.indexChangeClick) {
        this.indexChangeClick = false
        /**
         * 使下次滑动时有动画效果
         */
        this.swiperDuration = 300

        /**
         *  e.detail.current == ( 0 ~ 4 )是动态列表
         *  e.detail.current == ( 5 ~ 末尾 )是发现列表
         */
        this.requestFlag = true

        //  左右滑动，如果是二级分类的切换，跟以前保持不变。如果触发了一级分类的切换，默认进推荐栏
        if (e.detail.current == 4 && this.slipdirection == 'left') {
          this.checkSwiperIndex = 0
        } else if (e.detail.current == this.topHeadTab[0].classList.length + this.topHeadTab[1].classList.length - 1 && this.slipdirection == 'left') {
          this.checkSwiperIndex = 5
        } else {
          this.checkSwiperIndex = e.detail.current
        }
        if (0 <= this.checkSwiperIndex && this.checkSwiperIndex <= 4) {
          this.checkTabCode = this.topHeadTab[0].classList[this.checkSwiperIndex].label
          this.topCheckTabCode = 'plaza'
          if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
            this.control = true
          }
          this.$forceUpdate()
          this.twitterType = 'TWITTER'
          let that = this
          this.loadedList.map(item => {
            if (item <= 4) {
              let ref
              if (item == 0) {
                ref = eval('that.$refs.findPlazaList' + item)
              } else {
                ref = eval('that.$refs.findPlazaList' + item)[0]
              }
              if (ref) {
                ref.closeMoreClick()
              }
            }
          })
          if (this.loadedList.includes(this.checkSwiperIndex)) {
            return
          }
          this.getList()
        } else if (this.checkSwiperIndex < this.topHeadTab[1].classList.length + 5) {
          this.topCheckTabCode = 'thread'
          this.twitterType = 'NOTES'
          this.myChanneLabel = this.topHeadTab[1].classList[this.checkSwiperIndex - 5].label
          this.$forceUpdate()
          // this.currentLabel = this.myChanneLabel
          if (this.loadedList.includes(this.checkSwiperIndex)) {
            return
          }
          // 用户快速滑动后在切换回来，会出现页面数据不加载的情况，只有页面顶部显示了加载更多下面都是空白
          // 禁止用户touch操作 使渲染完成再切换
          this.isDisabledTouch = true
          uni.$u.debounce(this.closeTouch, 100)
          this.getList()
        } else {
          this.topCheckTabCode = 'partner'

          if (this.loadedList.includes(this.checkSwiperIndex)) {
            return
          }
          this.getList()
          this.$forceUpdate()
        }
      } else {
      }
    },
    /**
     * 获取搭子列表
     */
    getUserDaziList() {
      // this.position = uni.getStorageSync('position')
      let params = {
        sex: this.gender,
        pageNo: this.partnerPageNumber + 1,
        pageSize: 10,
        position: this.position
      }

      findModel
        .getUserDaziList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            res.data.UserDaziDTO.map(item => {
              if (item.goodPhotoUrl) {
                let photoList = item.goodPhotoUrl.split('&&')
                item.goodPhotoUrlItem = photoList[Math.floor(Math.random() * photoList.length)]
              }
            })
            this.partnerList = [...this.partnerList, ...res.data.UserDaziDTO]
            this.partnerPageNumber = res.data.pageNumber
            this.partnerPages = res.data.pages
            if (res.data.total == 0) {
              this.partnerLoadStatus = 'none'
            } else {
              if (res.data.pages <= res.data.pageNumber) {
                this.partnerLoadStatus = 'nomore'
              } else {
                this.partnerLoadStatus = 'loadmore'
              }
            }
          } else {
            this.partnerLoadStatus = 'loadmore'

            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.partnerLoadStatus = 'loadmore'
          this.showLoading = false
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    // 最新 关注 附近
    checkSecondTab(data, index) {
      this.slipdirection = ''
      this.indexChangeClick = true
      this.swiperDuration = 0
      this.checkSwiperIndex = index
      this.requestFlag = true
    },
    /**
     * 发现频道 切换
     */
    checkChannel(index) {
      this.slipdirection = ''
      this.requestFlag = true
      this.indexChangeClick = true
      this.swiperDuration = 0
      this.checkSwiperIndex = index + 5
    },
    // 去动态话题页
    goDynamicTag(item) {
      if (item.topicName) {
        uni.navigateTo({
          url: '/pagesFind/find/topics?topicName=' + item.topicName + '&twitterType=TWITTER'
        })
      } else {
        uni.navigateTo({
          url: '/pagesFind/find/topics?topicName=' + item + '&twitterType=TWITTER'
        })
      }
    },
    // 发现顶部搜索
    goSearch(tabType) {
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/indexSearch?tabType=' + tabType
      })
    },
    // 去消息页
    openCommentAndZanPage() {
      uni.navigateTo({
        url: '/pagesFind/find/interaction?unreadNum=' + this.unreadObj.commentNewlyNumber
      })
    },
    // 获取定位
    getPostion() {
      let self = this
      uni.getLocation({
        type: 'gcj02', //gcj02
        success: res => {
          let position = {
            lat: res.latitude,
            lon: res.longitude
          }
          self.position = position
          uni.setStorage({
            key: 'position',
            data: JSON.stringify(position)
          })
          // 此处重新获取数据会导致首页发送两次请求。导致数据异常
          // self.showLoading = true
          // self.getActivList()
        },
        fail: err => {}
      })
    },
    // 热门话题榜
    goHotTopList() {
      uni.navigateTo({ url: '/pages/find/hotTopicList' })
    },
    /**
     * 博主打卡弹窗打开
     */
    bloggerPopOpen() {
      this.bloggerPopshow = true
    },
    /**
     * 博主打卡弹窗关闭
     */
    bloggerPopClose() {
      this.bloggerPopshow = false
    },
    /**
     * 获取是否进行博主打卡提示
     */
    getBloggerNotice() {
      let params = {
        numberId: this.numberId
      }
      Blogger.notice(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.bloggerPopshow = true
            this.bloggerPopNotice = res.data.notice
          } else {
            this.bloggerPopshow = false
          }
        })
        .catch(err => {})
    },
    /**
     * 渲染完成关闭禁止滑动
     */
    noteDone() {
      this.closeTouch()
    },
    /**
     * 活动类型banner
     */
    appointmentType() {
      IndexModal.getActivityTypeV().then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          this.activityType = dataRes.data.appointmentType
          this.bannerList1 = dataRes.data.indexBanner || []
          this.bannerList = dataRes.data.indexBanner2 || []
          // this.bannerListLength = Math.ceil(this.bannerList.length / 5)
          this.subBannerList = this.bannerList
        }
      })
    },
    /**
     * 打开筛选弹框
     */
    openPartnerScreen() {
      this.showPartnerScreen = true
    },
    /**
     * 关闭筛选弹框
     */
    closePartnerScreen(isScreen, gender) {
      this.showPartnerScreen = false
      if (!isScreen) return
      this.gender = gender
      this.refreshList()
    },
    /**
     * 获取首页banner (正在热聊)
     */
    getIndexBanner() {
      let params = {
        bannerType: 'TOPIC'
      }
      IndexModal.getIndexBanner(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            if (res.data.indexBanner.length >= 4) {
              this.tagList = res.data.indexBanner.slice(0, 3)
            } else {
              this.tagList = res.data.indexBanner
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 搭子详情页
     *
     */
    goDetails() {
      uni.navigateTo({ url: '/pages/find/partnerDetails?targetNumberId=' + this.numberId })
    },
    // 获取学生认证信息状态
    getStatusInfo() {
      MyInfo.userInfoStatusV2()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.authGood = res.data.authGood
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 前往颜值投票页面
     */
    goFaceVote() {
      uni.navigateTo({ url: '/pagesMy/my/facialFeaturesVote' })
    },
    /**
     * 点击系统导航栏 滑动到顶部
     */
    clickSystemNav() {
      // 页面滚动
      uni.pageScrollTo({ scrollTop: 0, duration: 300 })
      // swiper滚动
      // 解决view层不同步的问题
      this.scrollTop = this.old.scrollTop
      this.scrollTop = 2
      this.$nextTick(function () {
        this.scrollTop = 0
      })
    },
    /**
     * 刷新状态更新
     */
    changeRefreshe(type) {
      this.refresherEnabled = type
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}

.fixedBgc {
  height: calc(100vh - 100rpx);
  height: 100vh;
  overflow: hidden;
}

.findpage {
  min-height: 100vh;
  overflow: hidden;
  .navigate-box {
    position: fixed;
    height: var(--status-bar-height);
    width: 100%;
    z-index: 9999;
    // background: red;
    text-align: center;
    top: 0;
  }
  .header {
    width: 100%;
    position: fixed;
    // padding-top: var(--status-bar-height);
    background: url('http://img.yiqitogether.com/yqyq-app/images/fx_bg.png');
    z-index: 999;
    background-size: 100% 100%;
    height: 100rpx;
    .nav-container {
      padding: 0 35rpx;
      height: 88rpx;
      .nav-left {
        padding: 20rpx 0;
        .li {
          display: inline-block;
          font-size: 32rpx;
          color: #838e9a;
          margin-right: 50rpx;
          position: relative;
        }
        .active {
          font-weight: bold;
          font-size: 36rpx;
          color: #333333;
        }
        .nav-left-img {
          width: 46rpx;
          height: 46rpx;
          position: absolute;
          top: -13rpx;
          right: -27rpx;
        }
      }
      .nav-right {
        display: flex;
        align-items: center;
        .right-icon {
          width: 48rpx;
          height: 48rpx;
          margin-left: 24rpx;
        }
        .message {
          position: relative;
          font-size: 0;
          .unread-message-number {
            box-sizing: border-box;
            min-width: 32rpx;
            min-height: 32rpx;
            position: absolute;
            padding: 2rpx 4rpx;
            border-radius: 32rpx;
            top: -15rpx;
            left: 75%;
            background-color: #fe5e10;
            color: #fff;
            font-size: 22rpx;
            text-align: center;
          }
          .dot {
            position: absolute;
            width: 16rpx;
            height: 16rpx;
            border-radius: 50%;
            top: -4rpx;
            right: -4px;
            background-color: #fe5e10;
          }
        }
      }
    }
  }
  .headerTab {
    position: fixed;
    width: 100vw;
    height: 80rpx;
    top: calc(var(--status-bar-height) + 88rpx);
    box-sizing: border-box;
    padding: 20rpx 30rpx 10rpx;
    z-index: 3;
    background: #ffffff;
    .li {
      font-size: 28rpx;
      text-align: center;
      color: #c7cdd3;
      margin-right: 40rpx;
      flex-shrink: 0;
      .li-text {
        margin-bottom: 4rpx;
      }
    }
    .active {
      font-size: 28rpx;
      color: #484848;
      text-align: center;
      margin-right: 40rpx;
      font-weight: 700;
    }
    .headerTab-border {
      width: 20rpx;
      height: 6rpx;
      background: #2a343e;
      border-radius: 26rpx;
      margin: auto;
    }
  }

  .swiper {
    width: 100%;
    margin-top: calc(var(--status-bar-height) + 74rpx);
    height: calc(100vh - var(--status-bar-height) - 88rpx - 88rpx);
  }

  .swiper-partner {
    width: 100%;
    margin-top: calc(var(--status-bar-height) + 74rpx);
    height: calc(100vh - var(--status-bar-height) - 88rpx);
  }
  .control {
    /deep/.uni-swiper-slide-frame {
      transform: translate(0%, 0px) translateZ(0px) !important;
    }
  }

  .swiper-scroll {
    box-sizing: border-box;
    height: 100%;
    .border-line {
      width: 750rpx;
      height: 2rpx;
      background: #fcfcfe;
    }
  }

  .plaza-hot-box {
    margin: 0 36rpx;
    .hot-box-title {
      // width: 128rpx;
      height: 44rpx;
      font-size: 32rpx;
      color: #373d44;
      font-weight: bold;
      padding-top: 20rpx;
      margin-bottom: 34rpx;
      .hot-box-title-img {
        width: 182rpx;
        height: 44rpx;
        margin-left: -8rpx;
      }
      .hot-box-narrow {
        width: 24rpx;
        height: 24rpx;
      }
    }
    .hot-box {
      .hot-box-item {
        margin-bottom: 20rpx;
        .hot-box-item-left {
          width: 500rpx;
          .item-left-img {
            width: 32rpx;
            height: 32rpx;
            margin-right: 12rpx;
            display: block;
          }
          .item-left-text {
            flex: 1;
            width: 208rpx;
            height: 40rpx;
            line-height: 40rpx;
            font-size: 28rpx;
            color: #000000;
            font-weight: bold;
          }
        }
        .hot-box-item-right {
          .item-right-img {
            width: 16rpx;
            height: 20rpx;
            margin-right: 6rpx;
            display: block;
          }
          .item-right-text {
            width: 54rpx;
            height: 34rpx;
            line-height: 34rpx;
            font-size: 24rpx;
            color: #ff6767;
          }
        }
      }
    }
  }
}

.nav-bar-box {
  padding-top: 25rpx;
  top: calc(var(--status-bar-height));
  background-color: #fff;
  width: 100vw;
  height: 100rpx;
  position: fixed;
  left: 0;
  z-index: 9;
  color: #484848;

  .message-box {
    // position: relative;
    position: absolute;
    // margin-left: 36rpx;
    left: 30rpx;
    top: 30rpx;

    .message-icon {
      width: 48rpx;
      height: 48rpx;
      display: block;
    }

    .red-tips {
      width: 16rpx;
      height: 16rpx;
      background: #ff0b0b;
      border-radius: 50%;
      position: absolute;
      top: -2rpx;
      right: -2rpx;
    }
  }

  .tab-text-box {
    text-align: center;
    justify-content: center;
    font-size: 36rpx;
    padding-left: 24rpx;
  }
  .tab-text {
    font-size: 36rpx;
    color: #333333;
    padding: 0 10rpx;
  }

  .tab-current {
    font-size: 42rpx;
    color: #333333;
    font-weight: bold;
    padding: 0 10rpx;
  }
  .right-btn {
    position: absolute;
    right: 0;
    top: 30rpx;
    .find-serch-icon {
      width: 48rpx;
      height: 48rpx;
      display: block;
      margin-right: 20rpx;
    }

    .find-sweep-icon {
      margin: 0 35rpx 0 0;
      width: 36rpx;
      height: 36rpx;
      display: block;
    }
    .find-face-icon {
      margin-right: 20rpx;
      width: 44rpx;
      height: 44rpx;
      display: block;
    }
  }
}
.recommend-note-swiper {
  width: 702rpx;
  background: #ffffff;
  border-radius: 20rpx !important;
  margin: 20rpx auto 24rpx;
}
.recommend-note-scollx {
  .note-scollx {
    margin-left: 24rpx;
    .note-scollx-item {
      padding-right: 40rpx;
      .scollx-item-img {
        width: 96rpx;
        height: 130rpx;
      }
    }
  }
}
.facescoreList {
  margin: auto;
  width: 680rpx;
  height: 100%;
  box-sizing: border-box;
  .partner-top {
    margin-top: 40rpx;
    width: 678rpx;
    height: 112rpx;
    display: block;
  }
}
/deep/ .u-icon__icon {
  width: 24rpx !important;
  height: 24rpx !important;
  font-size: 24rpx !important;
}
.tips-box {
  padding-top: 24rpx;
  padding-bottom: 50rpx;
}

.new-people-box {
  width: 100%;
  justify-content: center;
}

.new-people-luck {
  width: 690rpx;
  height: 292rpx;
  margin: 20rpx auto;
}
</style>
