<template>
  <WaterfallList class="list" @playVideo="playVideo" @clearAll="clearAll" :pagetype="pagetype" :myPersonal="myPersonal" :status="list.status" :list="list.list" :reset="list.reset" @done="onDone">
    <slot></slot>
  </WaterfallList>
</template>
<script>
import WaterfallList from '@/uni_modules/helang-waterfall/components/waterfall/waterfall-list.vue'
export default {
  components: { WaterfallList },
  props: {
    list: { type: Object },
    ajax: { type: Object },
    pagetype: {
      type: String,
      default: 'my'
    }
  },
  data() {
    return {
      // 判断他人访问还是本人访问
      myPersonal: true
    }
  },
  methods: {
    playVideo(item) {
      this.$emit('playVideo', item)
    },
    clearAll() {},
    // 瀑布流组件渲染完成
    onDone() {
      this.$emit('onDone')
    }
  }
}
</script>
<style lang="scss" scoped>
.load-txt {
  font-size: 28rpx;
  font-family: OPPOSans, OPPOSans-Medium;
  font-weight: 500;
  background-color: #f0f0f0f0;
  text-align: center;
  color: #adb3ba;
  line-height: 36rpx;
  padding-bottom: 50rpx;
  padding-top: 20rpx;
}
</style>
