<template>
  <view class="partner-list-box">
    <view class="partner-list flex-2" v-if="partnerList.length > 0 && !showLoading">
      <view
        class="list-item"
        @click="
          $u.throttle(() => {
            goDetails(item)
          }, 500)
        "
        v-for="(item, index) in partnerList"
        :key="index"
      >
        <view class="item-imgbox">
          <image v-if="item.goodPhotoUrl" class="imgbox-img" :src="item.goodPhotoUrlItem" mode="aspectFill" />
          <view v-else class="imgbox-img"></view>
          <!-- <image v-show="index == 0 || index == 1" class="imgbox-tips" src="http://img.yiqitogether.com/yqyq-app/images/xin_fx.png" mode="aspectFill" /> -->
        </view>
        <view class="item-userbox">
          <view class="userbox-top flex-0">
            <view class="top-left ellipsis-single">{{ item.nickName }}</view>
            <!-- 他人展示活跃度 -->
            <view class="top-right ellipsis-single" v-if="item.actMsg">
              <text v-if="item.actMsg == '0分钟前'">刚刚活跃</text>
              <text v-else>{{ item.actMsg }}活跃</text>
            </view>
          </view>
          <view class="userbox-center flex-0">
            <view class="center-left">
              {{ item.score }}
              <text style="font-size: 16rpx; line-height: 16rpx">分</text>
            </view>
            <view class="center-right">
              <text>{{ item.constellation || '-·-座' }}</text>
              <text style="margin: 0 10rpx">·</text>
              <text>{{ item.age ? item.age : '-·-' }}岁</text>
            </view>
          </view>
          <view class="userbox-bottom flex-1">
            <view class="bottom-left flex-0">
              <block>
                <image class="postion-img" src="http://img.yiqitogether.com/yqyq-app/images/weizhi_gray.png" mode="aspectFill" />
                <view class="postion-text ellipsis-single">{{ item.address ? item.address : '-·-' }}</view>
              </block>
            </view>
            <view class="bottom-right" v-if="item.distance && item.distance < 100000">{{ item.distance | capitalize }}</view>
          </view>
        </view>
      </view>
    </view>
    <slot v-if="partnerList.length > 0 && !showLoading"></slot>

    <!-- 缺省图 -->
    <view class="normalActivity-empty" v-if="partnerList.length == 0 && !showLoading">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
      <text class="empty-text">暂无内容</text>
    </view>
  </view>
</template>
<script>
export default {
  props: {
    showLoading: {
      type: Boolean,
      default: true
    },
    /**
     * 颜值搭子列表
     */
    partnerList: {
      type: Array,
      default: []
    }
  },
  filters: {
    capitalize: function (value) {
      value = Number(value)
      if (value >= 1000) {
        value = (value / 1000).toFixed(2) + 'km'
      } else {
        value = value ? value.toFixed(2) + 'm' : 0 + 'm'
      }
      return value
    }
  },
  data() {
    return {}
  },
  methods: {
    /**
     * 搭子详情页
     * @param item
     */
    goDetails(item) {
      uni.navigateTo({ url: '/pages/find/partnerDetails?targetNumberId=' + item.numberId })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.partner-list-box {
  margin-top: 20rpx;
  .partner-list {
    flex-wrap: wrap;

    .list-item {
      margin-top: 20rpx;
      .item-imgbox {
        position: relative;
        background: #f6f6f8;
        border-radius: 24rpx;
        min-height: 330rpx;
        width: 330rpx;
        .imgbox-img {
          width: 330rpx;
          height: 330rpx;
          border-radius: 24rpx;
          display: block;
        }
        .imgbox-tips {
          width: 52rpx;
          height: 52rpx;
          position: absolute;
          top: 0;
          left: 20rpx;
        }
      }
      .item-userbox {
        width: 330rpx;
        margin-top: 10rpx;
        overflow: hidden;
        .userbox-top {
          .top-left {
            max-width: 175rpx;
            font-size: 32rpx;
            line-height: 40rpx;
            color: #1c1c1c;
            margin-right: 10rpx;
          }
          .top-right {
            // max-width: 150rpx;
            flex: 1;
            font-size: 22rpx;
            color: #ff9942;
          }
        }
        .userbox-center {
          margin-top: 7rpx;
          padding-bottom: 20rpx;
          .center-left {
            font-size: 18rpx;
            color: #64696f;
            margin-right: 14.5rpx;
            width: 62rpx;
            height: 28rpx;
            line-height: 28rpx;
            text-align: center;
            background: #f7fbff;
            border-radius: 6rpx;
          }
          .center-right {
            font-size: 24rpx;
            color: #64696f;
          }
        }
        .userbox-bottom {
          margin: 0 0 20rpx;
          .bottom-left {
            .postion-img {
              width: 28rpx;
              height: 28rpx;
              margin-right: 6rpx;
            }
            .postion-text {
              max-width: 160rpx;
              font-size: 20rpx;
              color: #9fa7b4;
            }
          }
          .bottom-right {
            font-size: 20rpx;
            color: #9fa7b4;
          }
        }
      }
    }
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    display: block;
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
