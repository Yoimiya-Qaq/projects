<template>
  <u-popup class="partner-screen-pop" :show="showPartnerScreen" @close="close" @open="open">
    <view class="pop-content">
      <view class="content-title">筛选</view>
      <view class="content-center flex-0">
        <view class="center-title">匹配：</view>
        <view :class="checkedGender == item ? 'active-center-item' : 'center-item'" :style="item == '女' ? 'margin: 0' : ''" @click="changeGender(item)" v-for="(item, index) in genderList" :key="index">{{ item ? item : '不限' }}</view>
      </view>
      <view class="content-btnbox" @click="submit">确定</view>
    </view>
  </u-popup>
</template>
<script>
export default {
  props: {
    showPartnerScreen: {
      type: Boolean,
      default: false
    },
    gender: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      genderList: ['', '男', '女'],
      checkedGender: this.gender // 性别
    }
  },
  methods: {
    /**
     * 切换性别
     */
    changeGender(type) {
      this.checkedGender = type
    },
    /**
     * 筛选颜值用户信息
     */
    submit() {
      this.$emit('closePartnerScreen', true, this.checkedGender)
    },
    close() {
      this.$emit('closePartnerScreen', false)
    },
    open() {
      this.$emit('openPartnerScreen')
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.partner-screen-pop {
  /deep/.u-popup__content {
    border-radius: 16rpx 16rpx 0 0;
  }
  .pop-content {
    padding: 48rpx 36rpx 112rpx;
    border-radius: 16rpx 16rpx 0 0;
    .content-title {
      font-size: 32rpx;
      text-align: center;
      color: #2a343e;
      margin-bottom: 68rpx;
    }
    .content-center {
      .center-title {
        font-size: 28rpx;
        color: #9fa7b4;
        // margin-right: 10rpx;
      }
      .center-item {
        width: 184rpx;
        height: 68rpx;
        font-size: 28rpx;
        text-align: center;
        color: #838e9a;
        line-height: 68rpx;
        background: #f0f1f3;
        border-radius: 34rpx;
        margin-right: 20rpx;
      }
      .active-center-item {
        width: 184rpx;
        height: 68rpx;
        font-size: 28rpx;
        text-align: center;
        color: #ffffff;
        line-height: 68rpx;
        background: #fe5e10;
        border-radius: 34rpx;
        margin-right: 20rpx;
      }
    }
    .content-btnbox {
      width: 678rpx;
      height: 88rpx;
      margin: 124rpx auto 0;
      font-size: 36rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
      background: #fe5e10;
      border-radius: 44rpx;
    }
  }
}
</style>
