<template>
  <view>
    <block v-if="imageList.length === 1">
      <block v-for="(item, index) in imageList" :key="index">
        <view class="long-image-box" v-if="item.type === 'longGraph'" :style="customStyle ? `width:${item.width - 50}rpx;height: ${item.height - 50}rpx` : `width:${item.width}rpx;height: ${item.height}rpx`">
          <image class="long-image-item-image" mode="widthFix" :src="item.url" @click.stop="previewImage()"></image>
          <view class="tips">长图</view>
          <image v-if="type == 'video'" src="@/static/images/findVideo.png" alt="" mode="aspectFill" @click.stop="previewImage()" class="videoIcon"></image>
        </view>

        <view class="long-image-box" v-if="item.type === 'normalLongGraph'" :style="customStyle ? `width:${item.width - 50}rpx;height: ${item.height - 50}rpx` : `height: ${item.height}rpx`">
          <image class="long-image-item-image" mode="widthFix" :src="item.url" @click.stop="previewImage()"></image>
          <!-- <view class="tips">普通长图</view> -->
          <image v-if="type == 'video'" src="@/static/images/findVideo.png" alt="" mode="aspectFill" @click.stop="previewImage()" class="videoIcon"></image>
        </view>

        <view class="wide-image-box" :style="customStyle ? `width:${item.width - 50}rpx;height: ${item.height - 50}rpx` : `width:${item.width}rpx;height: ${item.height}rpx`" v-if="item.type === 'wideGraph' || item.type === 'normalWideGraph'">
          <image class="wide-image-item-image" mode="heightFix" :src="item.url" @click.stop="previewImage()"></image>
          <view class="tips" v-if="item.type === 'wideGraph'">宽图</view>
          <!-- <view class="tips" v-else>普通宽图</view> -->
          <image v-if="type == 'video'" src="@/static/images/findVideo.png" alt="" mode="aspectFill" @click.stop="previewImage()" class="videoIcon"></image>
        </view>
      </block>
    </block>

    <!-- 2 / 4张图 -->
    <view class="image-box" v-else-if="imageList.length === 2 || imageList.length === 4">
      <zero-lazy-load
        :class="[
          'img-item-two',
          imageList.length === 2 && index == 0 ? 'border-radius-left' : '',
          imageList.length === 2 && index == 1 ? 'border-radius-right' : '',

          imageList.length === 4 && index == 0 ? 'border-radius-left-top' : '',
          imageList.length === 4 && index == 1 ? 'border-radius-right-top' : '',
          imageList.length === 4 && index == 2 ? 'border-radius-left-bottom' : '',
          imageList.length === 4 && index == 3 ? 'border-radius-right-bottom' : ''
        ]"
        :style="customStyle ? 'width:308rpx;height:308rpx' : ''"
        :image="item"
        :height="338"
        imgMode="aspectFill"
        v-for="(item, index) in imageList"
        :key="index"
        @click.native.stop="previewImage(imageList, index)"
      ></zero-lazy-load>
    </view>

    <!-- 3 / 6 / 9 张图 -->
    <view class="image-box" v-else-if="imageList.length === 3 || imageList.length === 6 || imageList.length === 9">
      <zero-lazy-load
        :class="[
          'img-item-three',
          imageList.length === 3 && index == 0 ? 'border-radius-left' : '',
          imageList.length === 3 && index == 2 ? 'border-radius-right' : '',

          imageList.length === 6 && index == 0 ? 'border-radius-left-top' : '',
          imageList.length === 6 && index == 2 ? 'border-radius-right-top' : '',
          imageList.length === 6 && index == 3 ? 'border-radius-left-bottom' : '',
          imageList.length === 6 && index == 5 ? 'border-radius-right-bottom' : '',

          imageList.length === 9 && index == 0 ? 'border-radius-left-top' : '',
          imageList.length === 9 && index == 2 ? 'border-radius-right-top' : '',
          imageList.length === 9 && index == 6 ? 'border-radius-left-bottom' : '',
          imageList.length === 9 && index == 8 ? 'border-radius-right-bottom' : ''
        ]"
        :style="customStyle"
        :image="item"
        :height="224"
        imgMode="aspectFill"
        v-for="(item, index) in imageList"
        :key="index"
        @click.native.stop="previewImage(imageList, index)"
      ></zero-lazy-load>
    </view>

    <!-- 其他 -->
    <view class="image-box" v-else>
      <zero-lazy-load :class="['img-item-three', 'border-r16']" :style="customStyle" :image="item" :height="224" imgMode="aspectFill" v-for="(item, index) in imageList" :key="index" @click.native.stop="previewImage(imageList, index)"></zero-lazy-load>
    </view>
  </view>
</template>

<script>
export default {
  name: 'image-processing',
  props: {
    // 图片 还是视频
    type: {
      type: String,
      default: 'image'
    },
    // 数据源，格式：['xxxx','xxxx']
    imageList: {
      type: Array
    },
    // 自定义图片样式 (个人主页因时间线占位缩小图片比例)
    customStyle: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {}
  },
  methods: {
    // 预览图片
    previewImage(urls, current) {
      if (this.type == 'video') {
        return this.$emit('playVideo')
      }
      let list = []
      if (this.imageList.length === 1) {
        list = [this.imageList[0].url]
      } else {
        list = urls
      }
      let result = list.map(item => item.replace('!yqyq0606', ''))
      current = current || 0
      uni.previewImage({
        urls: result,
        current
      })
    }
  }
}
</script>

<style scoped lang="scss">
.image-box {
  box-sizing: border-box;
  display: flex;
  flex-wrap: wrap;
  overflow: hidden;
  align-content: space-between;
  margin-bottom: 12rpx;
  position: relative;

  .border-r16 {
    border-radius: 16rpx !important;
  }

  .line-box {
    display: flex;
    flex-wrap: wrap;
  }

  .img-item-two {
    width: 338rpx;
    height: 338rpx;
    background-size: cover;
    margin-right: 3rpx;
    margin-bottom: 3rpx;
  }

  .img-item-two:nth-child(2n) {
    margin-right: 0;
  }

  .img-item-three {
    width: 224rpx;
    height: 224rpx;
    background-size: cover;
    margin-right: 3rpx;
    margin-bottom: 3rpx;
  }

  .img-item-three:nth-child(3n) {
    margin-right: 0;
  }
}

.long-image-box {
  width: 678rpx;
  max-height: 904rpx;
  overflow: hidden;
  position: relative;
  border-radius: 16rpx;
  background-color: #f6f6f8;

  .long-image-item-image {
    width: 678rpx;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
}

.wide-image-box {
  width: 678rpx;
  height: 508rpx;
  overflow: hidden;
  position: relative;
  border-radius: 16rpx;
  background-color: #f6f6f8;

  .wide-image-item-image {
    width: auto;
    height: 100%;
    display: block;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
}

.normal-image-box {
}

.tips {
  position: absolute;
  right: 10rpx;
  bottom: 10rpx;
  font-size: 18rpx;
  padding: 4rpx 6rpx;
  color: #fff;
  background-color: #7d9ecb;
  border-radius: 4rpx;
}

.tips-num {
  position: absolute;
  right: 10rpx;
  bottom: 10rpx;
  font-size: 22rpx;
  padding: 6rpx 10rpx;
  color: #fff;
  background-color: rgba(0, 0, 0, 0.8);
  border-radius: 12rpx;
}
.border-radius-left-top {
  border-radius: 16rpx 0 0 0 !important;
}
.border-radius-left-bottom {
  border-radius: 0 0 0 16rpx !important;
}
.border-radius-right-top {
  border-radius: 0 16rpx 0 0 !important;
}
.border-radius-right-bottom {
  border-radius: 0 0 16rpx 0 !important;
}
.border-radius-left {
  border-radius: 16rpx 0 0 16rpx !important;
}
.border-radius-right {
  border-radius: 0 16rpx 16rpx 0 !important;
}
.videoIcon {
  width: 80rpx;
  height: 80rpx;
  background-size: cover;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -40rpx;
  margin-left: -40rpx;
  transform: translateY(-50%, -50%);
}
</style>
