<template>
  <view class="mainCenter">
    <view class="mainCenter-listBox" v-if="activtyData.length > 0">
      <view class="listBox-activeItem" v-for="(item, index) in activtyData" :key="index">
        <!-- 动态内容 -->
        <block v-if="item.contentType != 'goodVip' && item.contentType != 'interesting'">
          <view
            style="padding: 20rpx 36rpx 0"
            class="flex-2"
            @click="
              $u.throttle(() => {
                goDetail(item, index), 500
              })
            "
          >
            <!-- 个人主页左侧时间线 -->
            <view class="listBox-activeItem-left" v-if="pageType == 'my'">
              <view><image style="width: 20rpx; height: 20rpx" src="@/static/images/sjd.png" mode="scaleToFill" /></view>
              <view class="left-border"></view>
            </view>
            <view class="listBox-activeItem-right">
              <view v-if="item.userinfo && pageType !== 'my'" class="activeItem-headers flex-1">
                <view style="position: relative; font-size: 0">
                  <image
                    class="activeItem-headers-userImage"
                    mode="aspectFill"
                    :src="item.userinfo.headUrl"
                    @click.stop="
                      $u.throttle(() => {
                        goHomePages(item.userinfo.numberId)
                      })
                    "
                  ></image>
                </view>
                <view class="activeItem-headers-userMassge">
                  <view class="headers-userMassge-nameBox flex-1">
                    <view class="nameBox-left flex-0">
                      <view class="nameBox-name">{{ item.userinfo.nickName }}</view>
                    </view>
                    <view class="nameBox-right flex-0">
                      <view
                        class="common-follow-btn-active"
                        v-if="checkTabCode != 'ATENTION' && checkTabCode != 'COLLECT' && item.userinfo.numberId != numberId && !item.isAtention"
                        @click.stop="
                          $u.throttle(() => {
                            follow(item, index, 'activityItem')
                          }, 500)
                        "
                      >
                        {{ item.isAtention ? '私信' : '关注' }}
                      </view>
                      <view class="dianBox" v-if="checkTabCode == 'COLLECT'">
                        <image v-if="!item.canShow" class="deleteImage" src="https://img.yiqitogether.com/yyqc/20231019/upload_c178nl5kgkkxtkur5vdzta3zj4twdear.png" mode=""></image>
                        <image @click.stop="openCollect(item, index)" class="dianImage" src="https://img.yiqitogether.com/yyqc/20231019/upload_ub4zas76szg44xd1jt1ervm6yyjfax2d.png" mode="aspectFill"></image>
                      </view>
                      <!-- 更多操作按钮  我的收藏页面不展示-->
                      <view v-else @click.stop="showMoreOperateBtn(item)">
                        <image class="more-vertical" src="http://img.yiqitogether.com/yqyq-app/images/more-vertical.png" mode="aspectFill" />
                      </view>
                    </view>
                    <view class="more-popup" v-if="item.collectPopur">
                      <image class="more-image" src="https://img.yiqitogether.com/static/local/index/sanjiao@2x.png" mode=""></image>
                      <view class="more-popup-content" @click.stop="cancelCollect(item)">
                        <view class="popup-info">
                          <text>取消收藏</text>
                        </view>
                      </view>
                    </view>
                  </view>
                  <view class="headers-userMassge-subTitle">
                    <image v-if="item.userinfo.sex == '男'" class="subTitle-gender" src="@/static/images/nan.png" mode=""></image>
                    <image v-if="item.userinfo.sex == '女'" class="subTitle-gender" src="@/static/images/nv.png" mode=""></image>
                    <text v-if="item.userinfo.age">
                      {{ item.userinfo.age }}岁
                      <text class="dian">·</text>
                    </text>
                    <!-- 星座 目前不展示，信息过多换行-->
                    <!-- <text v-if="item.userinfo.constellation">
                  {{ item.userinfo.constellation }}
                  <text class="dian">·</text>
                </text> -->
                    <text v-if="item.twitterInfo.createTime && checkTabCode != 'RECOMMEND'">
                      <!-- {{ timeFormat(new Date(item.twitterInfo.createTime).getTime()) }}发布 -->
                      {{ $u.timeFrom(item.twitterInfo.createTime, 'yyyy-mm-dd') }}
                      <text class="dian">·</text>
                    </text>
                    <text v-if="checkTabCode == 'NEAR' && item.distance">
                      {{ item.distance }}
                      <text class="dian">·</text>
                    </text>
                    <!-- <text v-if="checkTabCode == 'NEAR'">{{ item.actTime }}活跃</text> -->
                    <text v-if="item.viewCount">{{ item.viewCount | formatKWNumber }} 浏览</text>
                  </view>
                </view>
              </view>
              <view v-if="pageType == 'my'" class="activeItem-headers flex-1">
                <!-- <text class="timeInfo">{{ item.twitterInfo.createTime | timeFormat }}</text> -->

                <view class="flex-0">
                  <text class="timeInfo">{{ $u.timeFrom(item.twitterInfo.createTime, 'yyyy-mm-dd') }}</text>
                  <image v-if="item.twitterInfo.twitterShowType.text != '公开'" src="https://img.yiqitogether.com/static/local/myImages/+@2x.png" alt="" class="lockImg"></image>
                </view>
                <view class="peddingbox flex-0" @click.stop="hint" v-if="item.twitterInfo.checkState == 1">
                  <image class="peddingbox-img" src="http://img.yiqitogether.com/yqyq-app/images/sh.png" mode="scaleToFill" />
                  <view class="paddingbox-text">待审核</view>
                </view>
              </view>

              <!-- 文本动态 -->
              <view v-if="item.twitterInfo.content" class="activeItem-activeTitle">
                <view :class="['activeItem-activeTitle-activeName', item.isFold ? 'activeName' : '']" :id="'activeItemText' + index">
                  {{ item.twitterInfo.content }}
                </view>

                <view v-if="item.isOverLineFlag == 'true'" class="activeName-btn" @click="$u.throttle(changeOverflow(item), 500)">{{ item.isFold ? '全文' : '收起' }}</view>
              </view>
              <!-- 有卡片展示缩略文字 -->
              <block v-if="item.twitterInfo.quoteInfoDTO.officialTarget && item.twitterInfo.quoteInfoDTO.quoteTitle && item.isShow !== -1">
                <view class="activeItem-activeTitle">
                  <block v-if="!item.twitterInfo.videoUrl && item.twitterInfo.images.length > 0">
                    <text class="shrink-text">
                      <text v-for="(imageItem, index) in item.twitterInfo.images" :key="index">[图片]</text>
                    </text>
                  </block>
                  <block v-if="item.twitterInfo.videoUrl"><text class="shrink-text">[视频]</text></block>
                </view>
              </block>
              <block v-else>
                <!-- 视频动态 -->
                <!-- <view v-if="item.twitterInfo.videoUrl" class="videoInfoBox">
              <image :src="item.twitterInfo.imageUrls" alt="" mode="aspectFill" class="videoImgPic" @click.stop="playVideo(item.twitterInfo)"></image>
              <image src="@/static/images/findVideo.png" alt="" mode="aspectFill" class="videoIcon" @click.stop="playVideo(item.twitterInfo)"></image>
            </view> -->
                <!-- 图片动态 -->
                <view class="h-mg-b-20" style="position: relative" v-if="item.twitterInfo.images.length > 0">
                  <!-- 个人主页时间线占位 多张图片展示缩小 -->
                  <imageProcessing :type="item.twitterInfo.itemType" :imageList="item.twitterInfo.images" v-if="pageType == 'my'" @playVideo="playVideo(item)" :customStyle="{ width: '202rpx', height: '202rpx' }"></imageProcessing>
                  <imageProcessing :type="item.twitterInfo.itemType" :imageList="item.twitterInfo.images" @playVideo="playVideo(item)" v-else></imageProcessing>
                </view>
              </block>

              <!-- 活动卡片 -->
              <block v-if="item.twitterInfo.quoteInfoDTO">
                <custom-tag-card style="margin-bottom: 20rpx" v-if="item.twitterInfo.quoteInfoDTO.officialTarget && item.twitterInfo.quoteInfoDTO.quoteTitle && item.isShow !== -1" :twitterInfo="item.twitterInfo"></custom-tag-card>
              </block>
              <view
                class="card-tag-positionBox1 flex-0"
                v-if="item.twitterInfo.positionShortName"
                @click.stop="
                  $u.throttle(() => {
                    goMap(item)
                  }, 500)
                "
              >
                <image class="card-tag-pointIcon" style="margin-right: 10rpx; margin-top: 2rpx" src="http://img.yiqitogether.com/yqyq-app/images/fx_dingwei.png"></image>
                <text>{{ item.twitterInfo.positionShortName }}</text>
                <image class="card-tag-narright" src="http://img.yiqitogether.com/yqyq-app/images/narrow_right.png" mode="aspectFill" />
              </view>
              <view class="activeItem-card-tag flex" v-if="item.twitterInfo.positionShortName || (item.twitterInfo.markTopics && item.twitterInfo.markTopics.length) || (item.twitterInfo.quoteInfoDTO.officialTarget && item.twitterInfo.quoteInfoDTO.officialTarget.length)">
                <block v-if="item.twitterInfo.quoteInfoDTO">
                  <template v-if="item.twitterInfo.quoteInfoDTO.officialTarget && item.isShow !== -1">
                    <block v-for="i in item.twitterInfo.quoteInfoDTO.officialTarget" :key="i.label">
                      <view
                        @click.stop="
                          $u.throttle(() => {
                            goJumpUrl(i.url)
                          })
                        "
                        class="card-tag-positionBox flex-0"
                        v-if="i.url"
                      >
                        <image class="card-tag-pointIcon" style="margin-right: 10rpx" src="@/static/images/find_vote_tag.png"></image>
                        <text>{{ i.text }}</text>
                      </view>
                    </block>
                  </template>
                </block>
                <template v-if="item.twitterInfo.markTopics">
                  <view class="card-tag-positionBox flex-0" v-for="(i, index) in item.twitterInfo.markTopics" :key="index" @click.stop="goDynamicTag(i)">
                    <!-- <image class="card-tag-pointIcon" src="@/static/images/tagColor.png"></image> -->
                    <text>#{{ i }}</text>
                  </view>
                </template>
              </view>

              <view class="activeItem-bottomBox flex-1">
                <view class="activeItem-bottomBox-left flex-0">
                  <!-- 更多操作按钮  我的收藏页面不展示-->
                  <!-- <view class="activeItem-bottomBox-operate flex-0" @click.stop="showMoreOperateBtn(item)" v-if="pageType !== 'myCollect'">
                <image class="bottomBox-more" src="@/static/images/more.png" mode="widthFix"></image>
              </view> -->
                  <!-- 转发 -->
                  <view
                    class="activeItem-bottomBox-operate flex-0"
                    @click.stop="
                      $u.throttle(() => {
                        transformItem(item)
                      }, 500)
                    "
                  >
                    <image class="bottomBox-operateIcon" src="http://img.yiqitogether.com/yqyq-app/images/zf.png"></image>
                    <text v-if="item.forwardCount > 0">{{ item.forwardCount | formatKWNumber }}</text>
                    <text v-else>转发</text>
                  </view>
                  <!-- 礼物 -->
                  <view v-if="item.userinfo.isGift" class="activeItem-bottomBox-operate flex-0" @click.stop="handleSendGift(item)">
                    <image class="bottomBox-giftIcon" src="http://img.yiqitogether.com/yqyq-app/images/fx_gc_liwu.png"></image>
                  </view>
                </view>

                <view class="activeItem-bottomBox-right flex-0">
                  <!-- 点赞 -->
                  <view
                    class="activeItem-bottomBox-operate flex-0"
                    @click.stop="
                      $u.throttle(() => {
                        Like(item, index)
                      })
                    "
                  >
                    <image class="bottomBox-operateIcon" :src="item.isZan ? require('@/static/images/fx_dz_love-t.png') : require('@/static/images/fx_dz_love-f.png')"></image>
                    <text v-if="item.zanCount > 0">{{ item.zanCount | formatKWNumber }}</text>
                    <text v-else>点赞</text>
                  </view>
                  <!-- 评论 -->
                  <view class="activeItem-bottomBox-operate flex-0">
                    <image class="bottomBox-operateIcon" src="@/static/images/fx_dz_l_02.png"></image>
                    <text v-if="item.commentCount > 0">{{ item.commentCount | formatKWNumber }}</text>
                    <text v-else>评论</text>
                  </view>
                </view>
              </view>
            </view>
          </view>
        </block>
        <!-- 颜值会员内容 -->
        <block v-if="item.contentType == 'goodVip'">
          <view class="good-vip-box flex-1">
            <view class="good-vip-box-left">
              <image class="left-img" :src="item.photoUrl.split('&&')[0]" @click="previewImageItem(item, 0)" mode="aspectFill" />
            </view>
            <view class="good-vip-box-right">
              <view class="right-top flex-1">
                <view class="right-top-left">
                  <view class="right-top-name ellipsis-single">{{ item.niceName }}</view>
                  <view class="top-name-info flex-0">
                    <image v-if="item.sex" class="info-gender" :src="item.sex == '男' ? require('@/static/images/nan.png') : item.sex == '女' ? require('@/static/images/nv.png') : ''" mode=""></image>
                    <view class="info-text flex-0" v-if="item.localArea">
                      <text class="ellipsis-single" style="max-width: 200rpx">{{ item.localArea.substring(0, item.localArea.indexOf('&&')) }}</text>
                      <text v-if="item.constellation && item.localArea" style="padding: 0 6rpx">·</text>
                      {{ item.constellation }}
                    </view>
                  </view>
                </view>
                <view
                  class="right-top-right"
                  @click.stop="
                    $u.throttle(() => {
                      goHomePages(item.numberId)
                    })
                  "
                >
                  <image class="right-top-right-img" :src="item.headImgUrl" mode="aspectFill" />
                </view>
              </view>
              <view class="right-tips">颜值圈新人一枚~很高兴认识大家~</view>
              <view class="right-photo-album flex-1">
                <image class="photo-album-img" v-for="(photoUrlItem, index) in item.photoUrl.split('&&')" :key="index" :src="photoUrlItem" @click="previewImageItem(item, index)" mode="aspectFill" />
              </view>
            </view>
          </view>
        </block>
        <!-- 可能感兴趣的人 -->
        <view class="interesting-box" v-if="item.contentType == 'interesting' && item.list.length > 0">
          <view class="interesting-box-top flex-1">
            <view class="top-title">可能感兴趣的人</view>
            <view class="top-right flex">
              <view class="top-right-text" @click="$u.throttle(changeInterestPerson, 500)">换一批</view>
              <image class="top-right-delimg" @click="deleteInterestPerson" src="http://img.yiqitogether.com/yqyq-app/images/close.png" mode="aspectFill" />
            </view>
          </view>
          <view class="flex-0">
            <view class="interesting-box-item" v-for="(interestItem, interestIndex) in item.list" :key="interestIndex">
              <view class="item-user">
                <image
                  @click.stop="
                    $u.throttle(() => {
                      goHomePages(interestItem.numberId)
                    })
                  "
                  class="user-img"
                  :src="interestItem.headImgUrl"
                  mode="aspectFill"
                />
                <view class="user-name ellipsis-single">{{ interestItem.niceName }}</view>
                <view
                  class="user-btn"
                  @click.stop="
                    $u.throttle(() => {
                      follow(interestItem, index, 'interestPeople', interestIndex)
                    }, 500)
                  "
                  :style="interestItem.isAtention ? 'color:#ADB3BA; border: 2rpx solid #ADB3BA;' : ''"
                  v-if="!interestItem.isAtention"
                >
                  {{ interestItem.isAtention ? '已关注' : '关注' }}
                </view>
                <view v-else class="user-btn" :style="interestItem.isAtention ? 'color:#ADB3BA; border: 2rpx solid #ADB3BA;' : ''">
                  {{ interestItem.isAtention ? '已关注' : '关注' }}
                </view>
              </view>
            </view>
          </view>
        </view>
        <view style="margin-top: 20rpx; width: 100%; height: 1rpx"></view>
        <view v-if="index != activtyData.length - 1" style="width: 100%; height: 3rpx; background: #f7f7f7"></view>
      </view>
      <slot></slot>
    </view>
    <!-- 更多操作弹窗 -->
    <custom-more-operate-popup :show="showMoreOperate" :list="checkedItem.moreBtnList" @close="closeMoreClick" @click="handleMoreClick" />

    <!-- 拉黑提示框 -->
    <custom-modal type="tipsConfirm" :show="showBlack" :round="24" title="是否拉黑TA？" :content="content" cancelText="取消" confirmText="拉黑" @cancel="showBlack = false" @confirm="addUserBlack"></custom-modal>
    <!-- 删除动态/笔记/评论 -->
    <custom-modal type="tipsConfirm" :show="showDel" :round="24" title="提示" content="您确定要删除此动态" cancelText="点错了" confirmText="是的" @cancel="showDel = false" @confirm="confirmDel" />

    <!-- 缺省图 -->
    <view class="normalActivity-empty" v-if="activtyData.length == 0 && checkTabCode != 'NEAR' && !showLoading">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
      <text class="empty-text">暂无内容</text>
    </view>
    <view class="wuImg2" v-if="activtyData.length == 0 && checkTabCode == 'NEAR' && !showLoading">
      <image class="wujilu2" src="https://img.yiqitogether.com/yyqc/20231030/upload_3yaaj51qzcv6ddvxbe7bzavm76058l2b.png" mode="aspectFill" />
      <text class="openPositionBox">开启定位发现更多精彩内容</text>
    </view>
    <u-toast class="toast-style" ref="uToast"></u-toast>
  </view>
</template>
<script>
import { LOGIN_USERID } from '@/utils/cacheKey.js'
import { load } from '@/utils/store.js'
import { dateTimeFormat } from '@/static/common/formatTime.js'
import imageProcessing from '../commponent/image-processing.vue'
import findModel from '@/model/find.js'
import MyInfo from '@/model/my'
import { timeFormat, openMap, rpxTopx } from '@/utils/tools.js'

export default {
  components: {
    imageProcessing
  },
  props: {
    activtyData: {
      type: Array,
      default: []
    },
    checkTabCode: {
      type: String,
      default: ''
    },
    showLoading: {
      type: Boolean
    },
    loadStatus: {
      type: String
    },
    /**
     * 右下角的更多按钮（我的收藏不展示、个人主页展示时间线）
     */
    pageType: {
      type: String,
      default: 'find'
    }
  },
  filters: {
    moonFormat: function (value) {
      let date = ''
      if (value) {
        date = dateTimeFormat(value, 'MM-dd HH:mm')
      }
      return date
    },
    timeFormat: function (value) {
      let date = ''
      let date2 = ''
      if (value) {
        date = dateTimeFormat(value, 'yyyy/MM/dd HH:mm:ss')
        date2 = dateTimeFormat(value, 'MM/dd')
      }
      let createTime = new Date(date).getTime()
      let currentTime = new Date().getTime()

      let countdown = currentTime - createTime
      if (countdown < 0) {
        return '刚刚'
      }
      let days = Math.floor(countdown / (1000 * 60 * 60 * 24))
      let hours = Math.floor((countdown % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      let minutes = Math.floor((countdown % (1000 * 60 * 60)) / (1000 * 60))
      let seconds = Math.floor((countdown % (1000 * 60)) / 1000)
      if (minutes == 0 && hours == 0 && days == 0 && seconds < 60) {
        return '刚刚'
      } else if (minutes < 60 && hours == 0 && minutes > 0 && days == 0) {
        return minutes + '分钟前'
      } else if (days == 0 && hours < 24) {
        return hours + '小时前'
      } else if (days <= 3) {
        return days + '天前'
      } else {
        return date2
      }
    },

    // 处理显示千万
    formatKWNumber: function (str) {
      const num = parseInt(str)
      if (num >= 1000 && num < 10000) {
        const decimal = num % 1000 === 0 ? '' : '.' + Math.floor((num % 1000) / 100)
        return Math.floor(num / 1000) + decimal + 'k'
      } else if (num >= 10000) {
        const decimal = num % 10000 === 0 ? '' : '.' + Math.floor((num % 10000) / 1000)
        return Math.floor(num / 10000) + decimal + 'w'
      } else {
        return num.toString()
      }
    }
  },
  data() {
    return {
      numberId: load(LOGIN_USERID) || '',
      timeFormat,
      moreBtnList: [], //更多操作
      checkedItem: { moreBtnList: [] }, //被操作的对象
      showBlack: false, //拉黑弹框
      showDel: false, // 删除动态二次确认弹窗
      showMoreOperate: false, //更多操作弹框
      content: '你们将收不到对方的消息\n且看不见对方的所有动态',
      contentType: 'activity'
    }
  },
  methods: {
    // 打开视频播放
    playVideo(item) {
      // #ifdef H5
      this.$emit('playVideo', item.twitterInfo)
      // #endif
      // #ifndef H5
      if (item.twitterInfo.videoUrl) {
        let obj = {
          _id: item.twitterInfo.twitterId, //每一个视频独有 id （自定义）
          userNumberId: item.twitterInfo.userNumberId, //作者numberId
          nickName: item.userinfo.nickName, //作者昵称
          href: item.userinfo.headUrl, //作者头像
          title: item.twitterInfo.title || '', //第一行标题
          msg: item.twitterInfo.content || '', //第二行内容
          state: 'pause', //初始状态标志（不改）
          isZan: item.isZan, //是否点赞了
          isCollect: item.isCollect, //是否收藏了
          zanCount: item.zanCount ? Number(item.zanCount) : 0, //点赞数量
          collectCount: item.collectCount ? Number(item.collectCount) : 0, //收藏数量
          commentCount: item.commentCount ? Number(item.commentCount) : 0, //评论数量
          src: item.twitterInfo.videoUrl, //视频链接
          videoImgUrl: item.twitterInfo.imageUrls || '', //视频封面
          pinlun: [], //评论
          playIng: false, //播放（默认这个即可）
          isShowimage: false, //是否显示封面（默认这个即可）
          isShowProgressBarTime: false, //是否显示进度条（默认这个即可）
          isplay: true, //是否播放音频（默认这个即可）
          showPauseIcon: false //是否显示暂停播放图标（默认这个即可）
        }
        uni.navigateTo({
          url: '/pages/index/appPlay?videoData=' + encodeURIComponent(JSON.stringify(obj)) + '&pageType=1',
          events: {
            setFullscreen() {
              plus.navigator.setStatusBarStyle('dark')
            },
            // 刷新点赞/收藏数量
            refreshFindDetailsCount(data) {
              let { countField, flagField, type } = data
              if (type == 'sub') {
                item[countField] = Number(item[countField]) - 1
                item[flagField] = false
              } else {
                item[countField] = Number(item[countField]) + 1
                item[flagField] = true
              }
            },
            // 刷新评论数量
            refreshCommentCount(num) {
              item.commentCount = num
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    // 动态详情
    goDetail(data, index) {
      let self = this
      uni.navigateTo({
        url: '/pages/find/findDetails?twitterId=' + data.twitterInfo.twitterId + '&pageType=1',
        events: {
          /**
           * 评论
           * type ：add  +1  /  del -1
           */
          commentCountChange: function (type) {
            if (type == 'del') {
              self.activtyData[index].commentCount--
            } else {
              self.activtyData[index].commentCount++
            }
            self.$forceUpdate()
          },
          /**
           * 点赞
           *  sub / add
           */
          zanCountChange: function (type) {
            if (type == 'sub') {
              self.activtyData[index].zanCount--
              self.activtyData[index].isZan = false
            } else {
              self.activtyData[index].zanCount++
              self.activtyData[index].isZan = true
            }
            self.$forceUpdate()
          },
          /**
           * 浏览数量
           */
          viewCountChange: function () {
            self.activtyData[index].viewCount++
            self.$forceUpdate()
          },
          /**
           * 公共回调事件，处理特殊回调(置顶)
           */
          publicChange: function (data) {
            self.$emit(data.functionName, data)
          }
        }
      })
    },
    // 前往个人主页
    goHomePages(data) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + data + '&fontId=1'
      })
    },
    // 关注
    follow(data, index, type, interestIndex) {
      let numberId = ''
      numberId = type == 'activityItem' ? data.userinfo.numberId : data.numberId
      if (numberId == this.numberId) {
        uni.showToast({
          title: '自己不能关注自己',
          icon: 'none',
          duration: 3000
        })
        return
      }
      let datas = {
        targetNumberId: numberId
      }
      findModel.isAtention(data.isAtention, datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          if (type == 'activityItem') {
            this.activtyData[index].isAtention = !this.activtyData[index].isAtention
          } else {
            this.activtyData[index].list[interestIndex].isAtention = true
            this.$forceUpdate()
          }
          uni.showToast({
            title: dataRes.message,
            icon: 'none',
            duration: 2000
          })
        } else {
          uni.showToast({
            title: dataRes.message,
            icon: 'none',
            duration: 3000
          })
        }
      })
    },
    // 去官方活动页
    goJumpUrl(item) {
      let facialUrl = item
      uni.navigateTo({
        url: facialUrl
      })
    },
    // 去动态话题页
    goDynamicTag(item) {
      if (item.topicName) {
        uni.navigateTo({
          url: '/pagesFind/find/topics?topicName=' + item.topicName + '&twitterType=TWITTER'
        })
      } else {
        uni.navigateTo({
          url: '/pagesFind/find/topics?topicName=' + item + '&twitterType=TWITTER'
        })
      }
    },
    //赞
    Like(data, index) {
      let datas = {
        twitterId: data.twitterInfo.twitterId
      }
      findModel.isTwitter(data.isZan, datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          this.activtyData[index].isZan = !data.isZan
          if (this.activtyData[index].isZan) {
            this.activtyData[index].zanCount = parseInt(this.activtyData[index].zanCount) + 1
          } else {
            this.activtyData[index].zanCount = parseInt(this.activtyData[index].zanCount) - 1
          }
        } else {
          uni.showToast({
            title: dataRes.message,
            icon: 'none',
            duration: 3000
          })
        }
      })
    },
    // 点击三个点（左上角收藏）
    openCollect(item, index) {
      this.activtyData.forEach(item => {
        item.collectPopur = false
      })
      this.activtyData[index].collectPopur = !this.activtyData[index].collectPopur
      this.$forceUpdate()
    },
    // 取消收藏
    cancelCollect(item) {
      let twitterId = item.twitterInfo.twitterId
      if (item.isCollect) {
        let datas = {
          twitterId: twitterId
        }
        findModel.twitterCancelCollect(datas).then(dataRes => {
          if (dataRes.code == 'SUCCESS') {
            uni.showToast({
              title: '取消收藏',
              icon: 'none'
            })

            let index = this.activtyData.findIndex(item => item.twitterInfo.twitterId == twitterId)
            this.activtyData.splice(index, 1)
          } else {
            this.$refs.uToast.show({
              ...dataRes
            })
          }
        })
      }
    },
    // 转发动态
    transformItem(item) {
      if (item.twitterInfo.checkState == 1) {
        return uni.showToast({
          title: '待审核通过后才可转发',
          icon: 'none'
        })
      }
      let data = {
        nickName: item.userinfo.nickName,
        quoteInfoDTO: item.twitterInfo.quoteInfoDTO ? item.twitterInfo.quoteInfoDTO : {},
        twitterId: item.twitterInfo.twitterId,
        content: item.twitterInfo.content,
        imageUrls: item.twitterInfo.imageUrls,
        videoUrl: item.twitterInfo.videoUrl
      }
      let sourcePage = this.pageType == 'my' ? 'myHomePages' : ''
      // 存储到全局变量中
      getApp().globalData.transformDynamicData = data
      this.$nextTick(() => {
        uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s1&isTransDynamic=1&sourcePage=' + sourcePage })
      })
    },
    // 展示更多操作弹框
    showMoreOperateBtn(checkedItem) {
      this.$emit('changeRefreshe', false)
      this.showMoreOperate = true
      this.checkedItem = { ...checkedItem }
    },
    // 加入黑名单
    addUserBlack() {
      // #ifndef APP-PLUS
      uni.showToast({
        title: '当前环境不支持此功能，该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let number = uni.getStorageSync('numberId')
      let data = {
        userId: number,
        //被举报人id
        blackUserId: this.checkedItem.userinfo.numberId
      }
      MyInfo.addUserBlack(data).then(async res => {
        this.showBlack = false
        // #ifdef APP-PLUS
        let result = await this.$store.state.engie.addToBlacklist(String(this.checkedItem.userinfo.numberId))
        // #endif
        if (res.code == 'SUCCESS') {
          uni.showToast({
            title: '已屏蔽TA的动态',
            icon: 'none'
          })
          this.$emit('refreshList')
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 更多操作的具体按钮
    handleMoreClick(index, item) {
      if (this.checkedItem.isSelf) {
        this.showDel = true
      } else {
        // 举报
        if (item == '举报') {
          let userId = this.checkedItem?.userinfo?.numberId
          uni.navigateTo({ url: '/pagesCommon/message/report?userId=' + userId + '&reportTargetType=TWITTER' + '&targetId=' + this.checkedItem.twitterId })
        } else if (item == '不看TA动态') {
          this.showBlack = true
        }
      }
      this.showMoreOperate = false
      this.$emit('changeRefreshe', true)
    },
    // 取消更多操作
    closeMoreClick() {
      this.showMoreOperate = false
      this.$emit('changeRefreshe', true)
    },
    // 删除-确认
    confirmDel() {
      // 删除动态
      findModel
        .twitterDel({ twitterId: this.checkedItem.twitterInfo.twitterId })
        .then(res => {
          this.showDel = false
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '删除成功',
              icon: 'none',
              mask: true
            })
            // 刷新动态列表
            this.$emit('refreshList')
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.showDel = false
        })
    },
    // 图片预览
    previewImageItem(item, index) {
      uni.previewImage({
        urls: item.photoUrl.split('&&'),
        current: index,
        success: function (data) {},
        fail: function (err) {
          console.log(err.errMsg)
        }
      })
    },
    // 打开地图
    goMap(item) {
      let info = {}
      info.place = item.twitterInfo.positionShortName
      info.position = item.twitterInfo.position
      openMap(info)
    },
    // 送礼物
    handleSendGift(item) {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      let obj = {
        type: '1',
        openUrl: '/giveGift/searchList/yiqi',
        userId: item.userinfo.numberId,
        enterType: 1
      }
      getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
      this.$nextTick(() => {
        uni.navigateTo({
          url: '/pages/my/webView'
        })
      })
    },
    /**
     * 切换全文与收起
     */
    changeOverflow(item) {
      this.activtyData.forEach(res => {
        if (res.twitterInfo.twitterId == item.twitterInfo.twitterId) {
          item.isFold = !item.isFold
        }
      })
      this.$forceUpdate()
    },
    /**
     * 处理超过三行的文本
     */
    isOverflow(item, index) {
      let self = this
      let isOverLineFlag = ''
      uni
        .createSelectorQuery()
        .in(this)
        .select(`#activeItemText${index}`)
        .boundingClientRect(function (res) {
          if (res) {
            // 获取文字的行数
            let lh = rpxTopx(46)
            let lines = parseInt(res.height / lh) //此处的46rpx是文本的行高
            // 判断文字是否超出5行
            if (lines > 5) {
              isOverLineFlag = 'true'
            } else {
              isOverLineFlag = 'no'
            }
            self.activtyData.forEach(res => {
              if (res.twitterInfo && res.twitterInfo.twitterId == item.twitterInfo.twitterId) {
                item.isOverLineFlag = isOverLineFlag
                if (isOverLineFlag == 'true') {
                  item.isFold = true
                } else {
                  item.isFold = false
                }
              }
            })
            self.$forceUpdate()
          }
        })
        .exec()

      return isOverLineFlag
    },
    /**
     * 更换可能感兴趣的人数据
     */
    changeInterestPerson() {
      this.$emit('getPersonToPersonLikeList', true)
    },
    /**
     * 删除可能感兴趣的人数据
     */
    deleteInterestPerson() {
      this.$emit('deleteInterestPersonList')
    },
    /**
     * 待审核提示
     */
    hint() {
      uni.showToast({
        title: '由于发布的内容存在涉及色情、暴力等敏感信息，需等待系统审核后公开',
        icon: 'none',
        class: 'hint-toast'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex {
  display: flex;
}
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  justify-content: center;
}
.mainCenter {
  width: 100%;
  .mainCenter-listBox:last-child {
    border-bottom: 0px;
  }
  .mainCenter-listBox {
    width: 100%;
    height: auto;
    overflow: hidden;
    .listBox-activeItem {
      background: #ffffff;
      position: relative;
      margin-bottom: 4rpx;
      .listBox-activeItem-left {
        width: 20rpx;
        margin-right: 24rpx;
        overflow: hidden;
        flex-shrink: 0;
        .left-border {
          width: 2rpx;
          height: 100%;
          background: #f0f0f0;
          margin: auto;
        }
      }
      .listBox-activeItem-right {
        flex-grow: 1;
        overflow: hidden;
      }
      .activeItem-headers {
        overflow: hidden;
        margin-bottom: 20rpx;
        .activeItem-headers-userImage {
          width: 90rpx;
          height: 90rpx;
          border-radius: 50%;
        }
        .activeItem-headers-userMassge {
          flex: 1;
          margin-left: 20rpx;

          .headers-userMassge-nameBox {
            // margin-bottom: 12rpx;
            .nameBox-left {
              .nameBox-name {
                font-size: 26rpx;
                color: #484848;
                margin-bottom: 8rpx;
                margin-right: 12rpx;
                // font-weight: bold;
              }
            }

            .dianBox {
              display: flex;
              .deleteImage {
                width: 132rpx;
                height: 132rpx;
                background-size: cover;
                margin-right: 20rpx;
                margin-top: -20rpx;
              }
              .dianImage {
                width: 30rpx;
                height: 6rpx;
                background-size: cover;
                // margin-top: 20rpx;
              }
            }
            .more-vertical {
              width: 6rpx;
              height: 30rpx;
              margin-left: 20rpx;
              flex: 1;
            }
            .more-popup {
              position: absolute;
              right: 28rpx;
              top: 72rpx;
              display: flex;
              flex-direction: column;
              align-items: flex-end;
              z-index: 999;

              .more-image {
                margin: 0 10rpx 0 0;
                width: 28rpx;
                height: 14rpx;
              }

              .more-popup-content {
                width: 136rpx;
                background-color: rgba(0, 0, 0, 0.7);
                border-radius: 12rpx;
                margin: 0;
                height: 64rpx;
                line-height: 64rpx;
                .popup-info {
                  width: 100%;
                  height: 64rpx;
                  font-size: 24rpx;
                  font-family: OPPOSans, OPPOSans-Medium;
                  font-weight: 500;
                  text-align: center;
                  color: #ffffff;
                }
              }
            }
          }

          .headers-userMassge-subTitle {
            display: flex;
            justify-content: flex-start;
            flex-wrap: wrap;
            align-items: center;
            font-size: 22rpx;
            color: #c0c6cc;
            .dian {
              margin: 0 6rpx;
            }
            .subTitle-gender {
              width: 28rpx;
              height: 28rpx;
              margin-right: 4rpx;
              // margin-bottom: -6rpx;
            }
          }
        }
        .lockImg {
          margin-left: 6rpx;
          width: 28rpx;
          height: 28rpx;
        }
        .peddingbox {
          background: #ffefe7;
          border-radius: 28rpx;
          padding: 6rpx 12rpx;
          .peddingbox-img {
            width: 28rpx;
            height: 28rpx;
            margin-right: 6rpx;
            display: block;
            margin-top: 2rpx;
          }
          .paddingbox-text {
            font-size: 24rpx;
            color: #fd5e0f;
            line-height: 40rpx;
          }
        }
      }

      .activeItem-activeTitle {
        font-size: 30rpx;
        color: #2a343e;
        line-height: 42rpx;
        height: auto;
        margin-bottom: 20rpx;
        position: relative;
        .activeT {
          color: #ff567a;
          float: left;
          font-size: 14rpx * 2;
          line-height: 18rpx * 2;
          flex-grow: 1;
          word-wrap: break-word;
          width: 100%;
        }
        .activeItem-activeTitle-activeName {
          width: 100%;
          font-size: 28rpx;
          position: relative;
          // text-align: justify;
          // word-break: break-all;
          line-break: anywhere;
          line-height: 46rpx;
          white-space: pre-wrap;
        }
        .activeName {
          display: -webkit-box;
          -webkit-line-clamp: 5;
          -webkit-box-orient: vertical;
          word-break: break-all;
          text-overflow: ellipsis;
          overflow: hidden;
        }
        .activeName-btn {
          font-size: 28rpx;
          line-height: 46rpx;
          color: #bdc1c5;
        }
      }
      .shrink-text {
        color: #fe5e10;
        margin-left: 10rpx;
      }

      .activeImg {
        overflow: hidden;
        margin: 0px auto;
        margin-bottom: 12rpx * 2;
        padding-left: 96rpx;

        .imgS {
          overflow: hidden;
          border-radius: 16rpx;
          margin-right: 5.19rpx * 2;
          position: relative;
          overflow: hidden;
          background-origin: inherit;
          background-position: center;
          background-repeat: no-repeat;
          background-size: 100% 100%;
        }

        .imgboxs {
          position: absolute;
          z-index: 11;
          top: 0px;
          right: 0px;
          left: 0rpx;
          width: 100%;
        }

        .imgS:last-child {
          margin-right: 0px;
        }
      }

      .one {
        .imgS {
          border-radius: 0;
        }
      }

      .tow {
        .imgS {
          width: 123rpx * 2;
          height: 123rpx * 2;
          float: left;
          background-size: cover;
        }

        .imgboxs {
          width: 100%;
          height: 100%;
          border-radius: 16rpx;
        }
      }
      .card-tag-positionBox1 {
        padding: 0 16rpx;
        margin: 10rpx 30rpx 10rpx 0;
        height: 50rpx;
        text-align: center;
        line-height: 50rpx;
        // background: #eef7ff;
        border-radius: 26rpx;
        overflow: hidden;
        color: #2a343e;
        font-size: 24rpx;
        font-weight: bold;

        .card-tag-pointIcon {
          width: 24rpx;
          height: 24rpx;
          margin-right: 4rpx;
          vertical-align: middle;
        }
        .card-tag-narright {
          width: 10rpx;
          height: 16rpx;
          margin-left: 10rpx;
        }

        text {
          display: block;
          max-width: 580rpx;
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          word-break: break-all;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }
      .card-tag-positionBox {
        font-weight: bold;

        padding: 0 16rpx;
        margin: 10rpx 30rpx 10rpx 0;
        height: 50rpx;
        text-align: center;
        line-height: 50rpx;
        background: #f6f6f8;
        border-radius: 26rpx;
        overflow: hidden;
        color: #2a343e;
        font-size: 24rpx;

        .card-tag-pointIcon {
          width: 24rpx;
          height: 24rpx;
          margin-right: 4rpx;
          vertical-align: middle;
        }

        text {
          display: block;
          max-width: 580rpx;
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          word-break: break-all;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }
      .activeItem-card-tag {
        box-sizing: border-box;
        padding-bottom: 24rpx;
        flex-wrap: wrap;
      }

      .activeItem-bottomBox {
        overflow: hidden;
        font-size: 24rpx;
        color: #484848;
        .activeItem-bottomBox-operate {
          margin-right: 36rpx;

          .bottomBox-operateIcon {
            width: 44rpx;
            height: 44rpx;
            margin-right: 6rpx;
          }
          .bottomBox-giftIcon {
            width: 140rpx;
            height: 62rpx;
            margin-right: 6rpx;
          }
          .bottomBox-more {
            width: 30rpx;
            height: 6rpx;
          }
        }
        .activeItem-bottomBox-operate:last-child {
          margin-right: 0;
        }

        .operate:last-child {
          margin-right: 0;
        }
      }
    }
  }
  .h-mg-b-20 {
    margin-bottom: 20rpx;
  }
  .videoInfoBox {
    width: 100%;
    height: 330rpx;
    position: relative;
    margin: 0 0 40rpx 0;
  }

  .videoImgPic {
    width: 330rpx;
    height: 330rpx;
    background-size: cover;
    border-radius: 16rpx;
  }

  .videoIcon {
    width: 52rpx;
    height: 52rpx;
    background-size: cover;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%, -50%);
    // z-index: 99;
  }

  .videoPopup {
    text-align: center;
  }
  .good-vip-box {
    padding: 32rpx 36rpx 0;
    .good-vip-box-left {
      .left-img {
        width: 240rpx;
        height: 320rpx;
        border-radius: 24rpx;
        box-shadow: 8rpx 16rpx 12rpx 0rpx rgba(210, 181, 168, 0.16);
      }
    }
    .good-vip-box-right {
      flex: 1;
      margin-left: 24rpx;
      .right-top {
        .right-top-left {
          .right-top-name {
            width: 260rpx;
            height: 44rpx;
            line-height: 44rpx;
            font-size: 32rpx;
            color: #373d44;
          }
          .top-name-info {
            margin-top: 8rpx;
            line-height: 32rpx;
            .info-gender {
              width: 28rpx;
              height: 28rpx;
              display: block;
              margin-right: 4rpx;
            }
            .info-text {
              height: 32rpx;
              line-height: 32rpx;
              font-size: 22rpx;
              color: #bdc1c5;
            }
          }
        }
        .right-top-right {
          .right-top-right-img {
            width: 60rpx;
            height: 60rpx;
            border-radius: 50%;
          }
        }
      }
      .right-tips {
        width: 414rpx;
        height: 56rpx;
        background: #ffffff;
        border-radius: 20rpx 0rpx 20rpx 0rpx;
        box-shadow: 0rpx 4rpx 10rpx 0rpx rgba(156, 156, 164, 0.12);
        font-size: 24rpx;
        color: #373d44;
        line-height: 56rpx;
        margin: 20rpx 0 28rpx;
        padding-left: 18rpx;
        box-sizing: border-box;
      }
      .right-photo-album {
        .photo-album-img {
          width: 96rpx;
          height: 128rpx;
          border-radius: 12rpx;
        }
      }
    }
  }
  .interesting-box {
    padding: 32rpx 36rpx 0;

    .interesting-box-top {
      margin-bottom: 24rpx;
      height: 36rpx;
      .top-title {
        width: 182rpx;
        font-size: 26rpx;
        line-height: 36rpx;
        color: #484848;
        font-weight: bold;
      }
      .top-right {
        height: 36rpx;
        .top-right-text {
          width: 66rpx;
          line-height: 36rpx;
          font-size: 22rpx;
          color: #adb3ba;
          margin-right: 25rpx;
        }
        .top-right-delimg {
          width: 20rpx;
          height: 20rpx;
          line-height: 40rpx;
          display: block;
          margin-top: 8rpx;
        }
      }
    }
    .interesting-box-item {
      // margin-right: 30rpx;
      padding: 0 30rpx;
      .item-user {
        text-align: center;
        .user-img {
          width: 90rpx;
          height: 90rpx;
          border-radius: 50%;
          display: block;
          // text-align: center;
          margin: auto;
        }
        .user-name {
          width: 112rpx;
          height: 34rpx;
          line-height: 34rpx;
          font-size: 24rpx;
          text-align: center;
          color: #484848;
          margin: 12rpx 0 10rpx;
        }
        .user-btn {
          width: 112rpx;
          height: 52rpx;
          font-size: 26rpx;
          border: 2rpx solid #fd5e0f;
          border-radius: 28rpx;
          text-align: center;
          color: #fd5e0f;
          line-height: 52rpx;
          box-sizing: border-box;
        }
      }
    }
  }
  .wuImg {
    margin-top: 50rpx;
    text-align: center;
    .wujilu {
      width: 310rpx;
      height: 310rpx;
      background-size: cover;
    }
  }
  .wuImg2 {
    width: 380rpx;
    margin: 50rpx auto 20rpx;
    text-align: center;

    .wujilu2 {
      width: 312rpx;
      height: 244rpx;
      background-size: cover;
    }
    .openPositionBox {
      display: block;
      font-size: 24rpx;
      text-align: center;
      color: #a6acb2;
      line-height: 32rpx;
    }
  }
  .normalActivity-empty {
    padding-top: 100rpx;
    height: 50vh;
    margin: auto;
    text-align: center;
    .empty-img {
      width: 312rpx;
      height: 244rpx;
      background-size: cover;
    }
    .empty-text {
      display: block;
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
}
</style>
