<template>
  <u-popup class="blogger-pop" :show="bloggerPopshow" @close="close" mode="center">
    <view class="blogger-pop-box">
      <view class="pop-box-title">
        <image class="box-title-img" src="http://img.yiqitogether.com/yqyq-app/images/qiandao.png" mode="scaleToFill" />
      </view>
      <view class="pop-box-content">
        <view class="content">
          <view class="day-box">
            <view class="day-number">{{ bloggerPopNotice.singUpDay }}</view>
            <view class="day-bg"></view>
          </view>
          <view class="content-tips">
            <view class="tips-text">
              当前已累计
              <text style="font-size: 24rpx; color: #484848; padding: 0 5rpx">{{ formatNumber(bloggerPopNotice.points) || 0 }}</text>
              积点
            </view>
            <view class="tips-text">
              每天坚持笔记打卡获得
              <text style="font-size: 24rpx; color: #ff51c9">万元奖金</text>
            </view>
          </view>
        </view>

        <image class="box-content-bgimg" src="http://img.yiqitogether.com/yqyq-app/images/tc_k.png" mode="scaleToFill" />
      </view>
      <view class="clock-in">
        <image @click="$u.throttle(goBloggerPage, 500)" class="clock-in-img" src="http://img.yiqitogether.com/yqyq-app/images/daka.png" mode="scaleToFill" />
        <image @click="$u.throttle(close, 500)" class="clock-in-close" src="@/static/images/close1.png" mode="scaleToFill" />
      </view>
    </view>
  </u-popup>
</template>
<script>
import { formatNumber } from '@/utils/tools.js'

export default {
  props: {
    // 博主打卡弹窗是否展示
    bloggerPopshow: {
      type: Boolean,
      default: false
    },
    // 博主打卡提示信息
    bloggerPopNotice: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {
      formatNumber
    }
  },
  methods: {
    /**
     * 前往博主页面
     */
    goBloggerPage() {
      this.close()
      uni.navigateTo({ url: '/pagesCommon/blogger/index' })
    },
    /**
     * 博主打卡弹窗打开
     */
    open() {
      this.$emit('bloggerPopOpen')
    },
    /**
     * 博主打卡弹窗关闭
     */
    close() {
      this.$emit('bloggerPopClose')
    }
  }
}
</script>
<style lang="scss" scoped>
.blogger-pop {
  /deep/ .u-popup__content {
    background: transparent;
  }
  .blogger-pop-box {
    .pop-box-title {
      text-align: center;
      .box-title-img {
        width: 310rpx;
        height: 158rpx;
      }
    }

    .pop-box-content {
      position: relative;
      height: 368rpx;
      .content {
        padding-top: 114rpx;
        width: 510rpx;
        .day-box {
          text-align: center;
          width: 170rpx;
          margin: auto;
          .day-number {
            font-size: 52rpx;
            text-align: center;
            color: #2a343e;
            position: relative;
            z-index: 1;
          }
          .day-bg {
            height: 44rpx;
            background: linear-gradient(180deg, rgba(198, 253, 255, 0), #94faff);
            border-radius: 50%;
            filter: blur(6rpx);
            margin-top: -40rpx;
          }
        }
        .content-tips {
          padding-top: 14rpx;
          box-sizing: border-box;
          margin: 24rpx auto 0;
          width: 410rpx;
          height: 118rpx;
          background: linear-gradient(270deg, #f4ecff, #e7f4ff 52%, #dbf7f9 100%);
          border: 2rpx solid #ffffff;
          border-radius: 16rpx;
          .tips-text {
            font-size: 20rpx;
            text-align: center;
            color: #484848;
            line-height: 45rpx;
          }
        }
      }
      .box-content-bgimg {
        z-index: -1;
        top: 0;
        left: 0;
        position: absolute;
        width: 510rpx;
        height: 368rpx;
      }
    }
    .clock-in {
      .clock-in-img {
        width: 254rpx;
        height: 112rpx;
        display: block;
        margin: 32rpx auto 0;
      }
      .clock-in-close {
        width: 50rpx;
        height: 50rpx;
        display: block;
        margin: auto;
      }
    }
  }
}
</style>
