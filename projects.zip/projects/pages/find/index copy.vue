<template>
  <view class="findpage" :class="showChannelState ? 'fixedBgc' : ''">
    <video style="position: absolute; top: 0; left: -750rpx" :src="videoPlayUrl" loop id="videoId" @fullscreenchange="videoFullScreenChange" @play="videoPlayFun"></video>
    <!-- 顶部导航栏 -->
    <view class="header" :style="isscrollTop ? 'background:#ffffff' : ''">
      <view class="nav-container">
        <view class="nav-left">
          <view :class="topCheckTabCode == item.code ? 'li active ' : 'li'" @click="topCheckTab(item)" v-for="(item, index) in topHeadTab" :key="index">
            <view>{{ item.txt }}</view>
            <image v-if="topCheckTabCode == item.code" class="nav-left-img" src="@/static/images/zs.png" mode="scaleToFill" />
          </view>
        </view>

        <view class="nav-right">
          <image
            class="right-icon"
            src="@/static/images/find_serch.png"
            @click="
              $u.throttle(() => {
                goSearch(topCheckTabCode)
              }, 500)
            "
          ></image>
          <view class="message" @click="openCommentAndZanPage()">
            <image class="right-icon" src="@/static/images/find_msg.png"></image>
            <!-- 此处是UI特殊要求，2位数时 最小宽度变化 -->
            <view class="unread-message-number" v-if="unreadObj.hasCommentNewly" :style="{ minWidth: unreadObj.commentNewlyNumber > 9 ? '40rpx' : '' }">{{ unreadObj.commentNewlyNumber > 99 ? '99+' : unreadObj.commentNewlyNumber }}</view>
            <view class="dot" v-else-if="unreadObj.hasZanNewly"></view>
          </view>
        </view>
      </view>
    </view>
    <view class="plazaTop"></view>
    <swiper class="swiper" :current="topCheckTabCode == 'plaza' ? 0 : 1" @change="changeCheckedTabList" :disable-touch="showChannelState || isDisabledTouch">
      <swiper-item>
        <scroll-view class="swiper-scroll" refresher-enabled :refresher-triggered="refresherTriggered[0]" scroll-y :refresher-threshold="150" @scrolltolower="loadMore" @refresherrefresh="refreshData(0)" @scroll="handleScroll($event, 'plaza')">
          <!-- 话题圈子 -->
          <view style="background: #ffffff">
            <view class="tag-box">
              <view class="tag-box-title flex-1">
                <view class="tag-box-title-left">#话题圈子</view>
                <view class="tag-box-title-right flex-0" @click="goHotTopList">
                  <view class="right-left">查看更多</view>
                  <image class="right-icon" src="@/static/images/youjiantou3.png" mode="scaleToFill" />
                </view>
              </view>
              <view class="tag-box-content flex-0">
                <view
                  v-for="(item, index) in tagList"
                  :key="index"
                  class="box-content-item flex-0"
                  @click.stop="
                    $u.throttle(() => {
                      goDynamicTag(item)
                    }, 500)
                  "
                >
                  <view class="content-item-left">
                    <zero-lazy-load class="content-item-img" borderRadius="16" :image="item.topicImg" height="100"></zero-lazy-load>
                  </view>
                  <view class="content-item-right">
                    <view class="item-right-top flex-0">
                      <view class="item-right-top-title ellipsis-single">{{ item.topicName }}</view>
                      <view v-if="item.topicMark" :class="['item-right-top-tag', item.topicMark == '新' ? 'tag-new' : item.topicMark == '热' ? 'tag-hot' : item.topicMark == '票' ? 'tag-vote' : '']">{{ item.topicMark }}</view>
                    </view>
                    <view class="item-right-bottom">{{ formatNumber(item.viewNumber) || 0 }}人阅读</view>
                  </view>
                </view>
              </view>
            </view>
          </view>
          <!-- 优质笔记 -->
          <view v-if="qualityNotesList.length > 0" class="quality-notes">
            <view class="quality-notes-title flex-1">
              <view class="left">优质笔记</view>
              <view
                class="right flex-0"
                @click="
                  topCheckTab({
                    id: 1,
                    txt: '笔记',
                    code: 'thread'
                  })
                "
              >
                <view class="right-left">查看更多</view>
                <image class="right-icon" src="@/static/images/youjiantou3.png" mode="scaleToFill" />
              </view>
            </view>
            <view class="quality-notes-box">
              <scroll-view scroll-x>
                <view class="box-list flex-0">
                  <view
                    class="item"
                    @click="
                      $u.throttle(() => {
                        goNotesDetails(item)
                      }, 500)
                    "
                    v-for="item in qualityNotesList"
                    :key="item.twitterInfo.twitterId"
                  >
                    <view class="image-box">
                      <image class="notes-img" :src="item.twitterInfo.imageUrls.split('&&')[0]" mode="aspectFill" />
                      <image v-if="item.twitterInfo.videoUrl" lazy-load @click.stop="playVideo(item.twitterInfo)" class="video" src="@/static/images/fx_gc_sp.png" mode="scaleToFill" />
                    </view>
                    <!-- 有标题展示标题，没有展示内容 -->
                    <view class="notes-title ellipsis-single">{{ item.twitterInfo.title ? item.twitterInfo.title : item.twitterInfo.content }}</view>
                  </view>
                </view>
              </scroll-view>
            </view>
          </view>
          <!-- 列表类型tab -->
          <view class="headerTab flex-0" :style="{ position: isSticky ? 'fixed' : 'relative', top: 0 + 'px' }" v-show="topCheckTabCode === 'plaza'">
            <view
              :class="tabId == item.id ? 'li active' : 'li'"
              @click="
                $u.throttle(() => {
                  checkTab(item)
                }, 500)
              "
              v-for="(item, index) in headerTab"
              :key="index"
            >
              <view class="li-text">{{ item.txt }}</view>
              <view :style="tabId == item.id ? '' : 'visibility: hidden;'" class="headerTab-border"></view>
            </view>
          </view>
          <!-- 广场内容 start -->

          <find-plaza-list style="background: linear-gradient(180deg, rgba(255, 255, 255, 1), #f6f6f8 14%)" ref="findPlazaList" :showLoading="showLoading" :tabId="tabId" :activtyData="dynamicList" @playVideo="playVideo" :checkTabCode="checkTabCode" @refreshList="refreshList" :pageType="'find'">
            <view class="tips-box" style="padding-top: 24rpx; padding-bottom: 50rpx" @click.stop="$u.throttle(loadMore, 500)">
              <u-loadmore :status="dynamicListloadStatus" :fontSize="20" nomore-text="到底了~" />
            </view>
          </find-plaza-list>
          <!-- 广场内容 end -->
        </scroll-view>
      </swiper-item>
      <swiper-item>
        <noteMenu ref="noteMenuRef" :channelData="channelData" :navList="myChannelList" @check="checkChannel" @saveMyLabel="saveMyLabel" @showChannelBox="showChannelState = $event" />

        <scroll-view
          style="background: linear-gradient(180deg, rgba(255, 255, 255, 1), #f6f6f8 14%)"
          class="swiper-scroll-thread"
          scroll-y
          refresher-enabled
          :refresher-triggered="refresherTriggered[1]"
          :refresher-threshold="150"
          @refresherrefresh="refreshData(1)"
          @scrolltolower="loadMore"
          @scroll="handleScroll($event, 'note')"
        >
          <!-- 看帖内容开始 -->
          <view class="waterfall" v-if="!showLoading">
            <post-list ref="notePostListRef" :showLoading="showLoading" :list="postList.list" :status="postList.status" @playVideo="playVideo">
              <view class="tips-box" @click.stop="$u.throttle(loadMore, 500)">
                <u-loadmore :status="postListloadStatus" :fontSize="20" nomore-text="到底了~" />
              </view>
            </post-list>
          </view>
          <!-- 看帖内容结束-->
        </scroll-view>
      </swiper-item>
    </swiper>

    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于显示附近的人和活动" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="localTip" isImg isOnShow></accredit-popup>
    <find-blogger-pop :bloggerPopshow="bloggerPopshow" :bloggerPopNotice="bloggerPopNotice" @bloggerPopOpen="bloggerPopOpen" @bloggerPopClose="bloggerPopClose"></find-blogger-pop>
    <!-- 发布弹窗 -->
    <custom-publish-popup ref="publishPopupRef" />
  </view>
</template>

<script>
// 引用瀑布流组件-帖子
import postList from '@/components/post-list/waterfall-list.vue'
// 导入组件
import findPlazaList from './commponent/find-plaza-list.vue'
import findBloggerPop from './commponent/find-blogger-pop.vue'
// 导入接口
import findModel from '@/model/find.js'
import { load, save } from '@/utils/store.js'
import { judgeImageSize, formatNumber } from '@/utils/tools.js'
import { ACCESS_LOCATION, LOGIN_USERID, TWITTERRECOMMENDKEYWORD, NOTESRECOMMENDKEYWORD, USER_INFO } from '@/utils/cacheKey.js'
import ZeroLazyLoad from '../../uni_modules/zero-lazy-load/components/zero-lazy-load/zero-lazy-load.vue'
import Blogger from '@/model/blogger.js'
export default {
  components: {
    findPlazaList,
    ZeroLazyLoad,
    postList,
    findBloggerPop
  },
  data() {
    return {
      // 在当前页点击tabbar，刷新开关。默认关闭，在onshow里先关闭，2s以后再开启
      clickCurrentTabbarFlag: false,
      // 当前视频全屏状态
      currentFullScreenState: null,
      isscrollTop: false, //滑动顶部背景图
      // 未读数量
      unreadObj: {
        commentNewlyNumber: 0,
        hasCommentNewly: false,
        hasZanNewly: false
      },
      videoPlayUrl: '', // video的视频源
      // 最顶部tab
      topHeadTab: [
        {
          id: 2,
          txt: '广场',
          code: 'plaza'
        },
        {
          id: 1,
          txt: '笔记',
          code: 'thread'
        }
      ],
      topCheckTabCode: 'plaza', //最顶部选择tab
      // 二级tab
      headerTab: [
        // {
        //   id: 3,
        //   txt: '热门',
        //   code: 'HOT'
        // },
        {
          id: 5,
          txt: '推荐',
          code: 'RECOMMEND'
        },
        {
          id: 2,
          txt: '最新',
          code: 'PUSH'
        },
        {
          id: 1,
          txt: '关注',
          code: 'ATENTION'
        },
        {
          id: 0,
          txt: '附近',
          code: 'NEAR'
        },
        {
          id: 6,
          txt: '颜值',
          code: 'GOOD_VIP'
        }

        /**
         * 自定义的类型，后台接口没有该类型，是为了我的收藏中动态列表组件的复用
         */
        // {
        //   id: 4,
        //   txt: '收藏',
        //   code: 'COLLECT'
        // }
      ],
      tabId: 5, //动态初始展示最新列表
      checkTabCode: 'RECOMMEND',
      // 动态列表
      dynamicList: [],
      dynamicListloadStatus: 'loadmore',
      dynamicpageNumber: 0,
      dynamicpages: 0,
      dynamiclastKeyWord: '', //查询下一页动态关键词
      // 笔记列表
      postList: {
        status: '',
        reset: 'reset',
        list: []
      },
      postListloadStatus: 'loadmore',
      postListpageNumber: 0,
      postListpages: 0,
      postListlastKeyWord: '', //查询下一页笔记键词
      position: '',
      videoContext: '', //视频
      twitterType: 'TWITTER',
      tagList: [], //话题圈子标签列表
      showLoading: true, //loading加载
      numberId: load(LOGIN_USERID) || '',
      tagLabelList: ['GOOD_PHOTO', 'APPOINTMENT', 'TWITTER_FORWARD', 'BIRTHDAY', 'NOTES_FORWARD_TWITTER'], //活动卡片标签
      hasNextPage: false, //是否有下一页
      formatNumber,
      // 频道列表
      channelData: [],
      // 我的频道列表
      myChannelList: [],
      // 我的频道label
      myChanneLabel: 'RECOMMEND',
      qualityNotesList: [], // 优质笔记
      bloggerPopshow: false, // 博主打卡提示框
      //频道栏展开状态
      showChannelState: false,
      bloggerPopNotice: {}, // 博主打卡提示信息
      isBlogger: false, // 是否是博主
      loadedList: [], // 已加载的tab
      isSticky: '', // 判断是否需要吸顶
      // 请求节流阀
      requestFlag: true,
      refresherTriggered: [false, false],
      isDisabledTouch: false
    }
  },
  onPageScroll(e) {
    //nvue暂不支持滚动监听，可用bindingx代替
    let top
    // #ifdef H5
    top = 117
    // #endif
    // #ifndef H5
    top = 117
    // #endif
    if (e.scrollTop < top) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  // onPullDownRefresh() {
  //   if (this.showChannelState) {
  //     uni.stopPullDownRefresh()
  //     return
  //   }
  //   // 获取话题圈子标签列表
  //   this.getTopicList()
  //   this.refreshList()
  //   setTimeout(() => {
  //     uni.stopPullDownRefresh()
  //   }, 1000)
  // },
  onTabItemTap(e) {
    if (this.clickCurrentTabbarFlag) {
      if (this.topCheckTabCode == 'thread') {
        this.$refs.notePostListRef.resetData()
      }
      uni.$u.debounce(this.refreshList, 1000)
    }
  },
  onLoad(e) {
    uni.$on('openFindPopup', () => {
      this.$refs.publishPopupRef.onOpen()
    })
    this.position = uni.getStorageSync('position')
    this.topCheckTabCode = e.topCheckTabCode ? e.topCheckTabCode : 'plaza'

    if (e.checkTabCode) {
      this.headerTab.map(item => {
        if (item.code == e.checkTabCode) {
          this.tabId = item.id
          this.checkTabCode = e.checkTabCode
        }
      })
    }
    // 获取话题标签列表
    this.getTopicList()
    if (e.topCheckTabCode === 'thread') {
      // 获取看帖列表
      this.topCheckTabCode = 'thread'
      this.twitterType = 'NOTES'
      this.checkTabCode = 'PUSH'
    }
    this.refreshList()
  },
  onShow() {
    this.isBlogger = JSON.parse(load(USER_INFO)).isBlogger || false
    uni.showTabBar()
    uni.stopPullDownRefresh()
    this.clickCurrentTabbarFlag = false
    setTimeout(() => {
      this.clickCurrentTabbarFlag = true
    }, 1000)
    this.hasNewlyFun()
    this.numberId = load(LOGIN_USERID) || ''
    /**
     * 是博主才调用每日打卡接口
     */

    if (this.isBlogger) {
      this.getBloggerNotice()
    }
  },
  onReady() {
    // 视频
    this.videoContext = uni.createVideoContext('videoId')
  },
  onHide() {
    this.$refs.publishPopupRef.onClose()
    if (this.$refs.findPlazaList) {
      this.$refs.findPlazaList.closeMoreClick()
    }
  },
  methods: {
    refreshData(index) {
      this.refresherTriggered[index] = true
      if (index == 1) {
        this.$refs.notePostListRef.resetData()
      }
      this.refreshList()
      setTimeout(() => {
        this.refresherTriggered[index] = false
        this.$forceUpdate()
      }, 1500)
    },

    /**
     * 保存选择的笔记标签，并重置为全部
     */
    saveMyLabel() {
      this.checkChannel('RECOMMEND', true)
    },
    /**
     * 判断是否需要吸顶
     */
    handleScroll(e, type) {
      this.isDisabledTouch = true
      if (this.qualityNotesList.length > 0 && type === 'plaza') {
        // 有优质笔记
        this.isSticky = e.detail.scrollTop > 480 // 假设100px时需要吸顶
      } else if (this.qualityNotesList.length === 0 && type === 'plaza') {
        // 无优质笔记
        this.isSticky = e.detail.scrollTop > 215 // 假设100px时需要吸顶
      }
      uni.$u.debounce(this.closeTouch, 100)
    },
    closeTouch() {
      this.isDisabledTouch = false
    },
    /**
     * 定位提示 判断显示状态
     */
    localTip() {
      // #ifdef APP-PLUS
      let isIos = plus.os.name == 'iOS'
      if (!isIos) {
        //安卓
        if (load(ACCESS_LOCATION) !== '' && load(ACCESS_LOCATION)) {
          this.getPostion()
        }
      } else {
        this.getPostion()
      }
      // #endif
    },
    // 点击播放视频
    playVideo(type) {
      let self = this
      this.videoPlayUrl = type.videoUrl
      // #ifdef H5
      try {
        this.$nextTick(() => {
          self.videoContext.requestFullScreen({ direction: 0 })
        })
      } catch (e) {
        console.log(e)
      }
      // #endif
      // #ifndef H5
      if (this.videoPlayUrl) {
        uni.navigateTo({
          url: '/pages/my/videoPlay?url=' + this.videoPlayUrl,
          events: {
            setFullscreen() {
              plus.navigator.setFullscreen(false)
            }
          }
        })
      } else {
        uni.showToast({
          title: '视频地址获取失败',
          icon: 'none',
          mask: true
        })
      }
      // #endif
    },
    /**
     * @param {Object} e 视频是否进入全屏
     */
    videoFullScreenChange(e) {
      this.currentFullScreenState = e.detail.fullScreen
      if (e.detail.fullScreen) {
        // 开始播放
        this.videoContext.play()
      } else {
        // 停止播放，销毁数据源
        this.videoContext.pause()
        this.videoPlayUrl = null
      }
    },
    /**
     * 视频播放时，要判断是否为全屏，非全屏则暂停视频
     */
    videoPlayFun() {
      if (!this.currentFullScreenState) {
        this.videoContext.pause()
      }
    },
    // 加载更多
    loadMore() {
      if (this.topCheckTabCode == 'plaza') {
        if (this.dynamicpages > this.dynamicpageNumber) {
          this.dynamicListloadStatus = 'loading'
          this.getActivList(this.dynamiclastKeyWord)
        }
      } else {
        if (this.postListpages > this.postListpageNumber) {
          this.postListloadStatus = 'loading'
          this.getActivList(this.postListlastKeyWord)
        }
      }
    },
    // 刷新数据
    refreshList() {
      // this.showLoading = true
      // 动态列表置空
      this.dynamicpageNumber = 0
      this.dynamicpages = 0
      this.dynamicList = []
      // 查询动态关键字
      this.dynamiclastKeyWord = ''
      this.dynamicListloadStatus = 'loadmore'

      // 瀑布流数据置空
      this.postList = { status: 'reset', reset: '', list: [] }
      this.postListpageNumber = 0
      this.postListpages = 0
      this.postListloadStatus = 'loadmore'
      // 优质笔记置空
      this.qualityNotesList = []
      // 清空加载的tab
      this.loadedList = [this.topCheckTabCode]
      this.$nextTick(() => {
        this.getList()
      })
    },
    /**
     * 调用tab列表数据接口
     */
    getList(type) {
      if (this.topCheckTabCode == 'plaza') {
        this.getQualityNotesList()
      }
      // 获取频道列表
      if (this.topCheckTabCode == 'thread' && type != 'clickNoteType') {
        this.getMyChannelEvent()
      }
      /**
       * 动态、笔记（推荐列表要读取缓存keyword）
       * 判断条件 广场且为推荐 plaza && PUSH
       * 笔记 且 为推荐 thread && RECOMMEND
       */
      let lastKeyWord = ''
      if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
        lastKeyWord = load(TWITTERRECOMMENDKEYWORD) || ''
      } else if (this.topCheckTabCode == 'thread' && this.myChanneLabel == 'RECOMMEND') {
        lastKeyWord = load(NOTESRECOMMENDKEYWORD) || ''
      }
      this.getActivList(lastKeyWord)
    },
    /**
     * 获取频道列表
     */
    getMyChannelEvent() {
      findModel
        .getMyChannel()
        .then(res => {
          if (res.code == 'SUCCESS') {
            let arr = [
              { text: '推荐', label: 'RECOMMEND' },
              { text: '关注', label: 'ATENTION' }
            ]
            this.channelData = res.data
            this.myChannelList = [...arr, ...res.data.list]
          }
        })
        .catch(err => {})
    },
    // 获取广场动态数据
    getActivList(lastKeyWord) {
      if (!this.requestFlag) {
        return
      }
      this.requestFlag = false
      //获取活动列表数据
      this.position = uni.getStorageSync('position')
      let params = {
        //	String	否	每页请求数据
        pageSize: 10,
        //	String	否	分页查询关键词（第一页可不传，其他页必传）
        lastKeyWord: lastKeyWord || '',
        //	String	否	目标用户ID。如果是看他人主页，必传
        targetNumberId: '',
        //   31.233815  ，121.390467 {"lat":28.228209,"lon":112.938814}
        position: this.position,
        // 动态类型 NOTES 笔记  / TWITTER 动态。默认或不传表示动态
        twitterType: this.twitterType
      }
      if (this.topCheckTabCode == 'plaza') {
        // 动态的类型
        params.findType = this.checkTabCode
      } else if (this.topCheckTabCode == 'thread') {
        this.postList.status = 'loading'
        // 频道名称，推荐和关注固定为 RECOMMEND / ATENTION
        params.channelName = this.myChanneLabel
      }
      // console.log(params)
      // return this.showLoading = false

      findModel
        .getFindList(params)
        .then(res => {
          /**
           * 将showLoading放上面是因为瀑布流的渲染时
           * 根据postList.status的值发生改变且值为SUCCESS才会渲染
           */
          this.showLoading = false
          if (res.code == 'SUCCESS') {
            let list = res.data.twitterlist.list || []
            this.hasNextPage = res.data.twitterlist.hasNextPage

            // 缓存推荐 的lastKeyWord
            if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
              save(TWITTERRECOMMENDKEYWORD, res.data.twitterlist.lastKeyWord)
            } else if (this.topCheckTabCode == 'thread' && this.myChanneLabel == 'RECOMMEND') {
              save(NOTESRECOMMENDKEYWORD, res.data.twitterlist.lastKeyWord)
            }

            if (list && list.length > 0) {
              list.forEach(async item => {
                let arr
                /**
                 * 动态图片处理
                 * - 图片转为数组，且仅为一张图时，将获取图片宽高
                 * - 处理活动卡片逻辑
                 * - 处理礼物按钮逻辑
                 */
                if (this.topCheckTabCode === 'plaza') {
                  // 活动卡片展示处理
                  if (item.twitterInfo.quoteInfoDTO) {
                    item.isContent = item.twitterInfo.quoteInfoDTO.officialTarget ? true : false
                    item.isShow = item.twitterInfo.quoteInfoDTO.officialTarget ? this.tagLabelList.indexOf(item.twitterInfo.quoteInfoDTO.officialTarget[0].label) : -1
                    try {
                      JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                      item.twitterInfo.quoteInfoDTO.quoteContent = JSON.parse(item.twitterInfo.quoteInfoDTO.quoteContent)
                    } catch (error) {
                      item.twitterInfo.quoteInfoDTO.quoteContent = item.twitterInfo.quoteInfoDTO.quoteContent
                    }
                    // this.$forceUpdate()
                  } else {
                    item.isContent = false
                    item.isShow = -1
                  }

                  // 图片处理
                  arr = item.twitterInfo.imageUrls ? item.twitterInfo.imageUrls.split('&&') : []
                  item.twitterInfo.images = arr

                  if (arr.length === 1) {
                    let imgObj = await judgeImageSize(arr[0])
                    item.twitterInfo.images = [imgObj]
                    item.twitterInfo.itemType = item.twitterInfo.videoUrl ? 'video' : 'image'
                  }

                  // 礼物
                  item.userinfo.isGift = item.userinfo.tags ? item.userinfo.tags.split(',').includes('TAG_GIFTVIP') : false
                }

                // 更多操作（是否是自己）
                let numberId = item.userinfo.numberId || ''
                if (numberId === this.numberId) {
                  item.moreBtnList = ['删除动态']
                  item.isSelf = true
                } else {
                  item.moreBtnList = ['不看TA动态', '举报']
                  item.isSelf = false
                }

                // 标签数据处理和长度处理最多显示五条
                if (item.twitterInfo.markTopic && item.twitterInfo.markTopic != null && item.twitterInfo.markTopic != '') {
                  let markList = item.twitterInfo.markTopic.split('#').filter(v => v && v.trim())
                  if (markList.length > 5) {
                    item.twitterInfo.markTopics = markList.slice(0, 5)
                  } else {
                    item.twitterInfo.markTopics = markList
                  }
                } else {
                  item.twitterInfo.markTopics = []
                }
              })

              if (this.topCheckTabCode == 'plaza') {
                list = list.filter(item => {
                  if (item.isShow != -1) {
                    return item.isContent == true
                  } else {
                    // item.isShow != -1 (不是特殊卡片类型动态或label里没有)
                    // item.isContent == false 普通动态
                    return item.isContent == false
                  }
                })
                // 从新获取的数据开始计算，老数据不重复计算(展开、收起)
                let oldindex = this.dynamicList.length == 0 ? 0 : this.dynamicList.length
                setTimeout(() => {
                  list.forEach((item, index) => {
                    this.$refs.findPlazaList.isOverflow(item, index + oldindex)
                  })
                }, 300)
                this.dynamicList.push(...list)
              } else {
                // 如果后台当前页返回数据为空，页面会变成白屏
                if (list.length > 0) {
                  this.postList.list = [...list]
                }
                setTimeout(() => {
                  this.postList.status = 'success'
                }, 50)
              }
              this.$forceUpdate()
            }

            // 处理动态如果当前页没有数据，但有下一页
            if (list && list.length == 0 && res.data.twitterlist.hasNextPage) {
              this.loadMore()
            }

            if (this.topCheckTabCode == 'plaza') {
              this.dynamicpages = res.data.twitterlist.pages
              this.dynamicpageNumber = res.data.twitterlist.pageNumber
              this.dynamiclastKeyWord = res.data.twitterlist.lastKeyWord
              if (res.data.twitterlist.total == 0) {
                this.dynamicListloadStatus = 'none'
              } else {
                if (res.data.twitterlist.pages <= res.data.twitterlist.pageNumber) {
                  this.dynamicListloadStatus = 'nomore'
                } else {
                  this.dynamicListloadStatus = 'loadmore'
                }
              }
            } else {
              this.postListlastKeyWord = res.data.twitterlist.lastKeyWord
              this.postListpageNumber = res.data.twitterlist.pageNumber
              this.postListpages = res.data.twitterlist.pages

              if (res.data.twitterlist.total == 0) {
                this.postListloadStatus = 'none'
              } else {
                if (res.data.twitterlist.pages <= res.data.twitterlist.pageNumber) {
                  this.postListloadStatus = 'nomore'
                } else {
                  this.postListloadStatus = 'loadmore'
                }
              }
            }
            this.requestFlag = true
          } else {
            if (this.tabId == 0) {
              this.$nextTick(() => {
                this.$refs.accredit.triggerEvent()
              })
            } else {
              uni.showToast({
                title: res.message,
                icon: 'none',
                duration: 3000
              })
            }
            this.requestFlag = true
          }
        })
        .catch(err => {
          this.showLoading = false
          this.requestFlag = true
        })
    },
    /**
     * 获取优质笔记
     */
    getQualityNotesList() {
      //获取活动列表数据
      this.position = uni.getStorageSync('position')
      let datas = {
        findType: 'RECOMMEND', // RECOMMEND（'推荐'）
        pageSize: 10, //	String	否	每页请求数据
        lastKeyWord: '',
        targetNumberId: '', //	String	否	目标用户ID。如果是看他人主页，必传
        position: this.position, //   31.233815  ，121.390467 {"lat":28.228209,"lon":112.938814}
        twitterType: 'NOTES'
      }
      findModel
        .getFindList(datas)
        .then(res => {
          if (res.code == 'SUCCESS') {
            /**
             * 后端要求传10个截取前3个
             * 原因：用户删除笔记可能导致当前页的数据为空
             */
            // if (res.data.twitterlist.list.length > 3) {
            //   this.qualityNotesList = res.data.twitterlist.list.splice(0, 3)
            // } else {
            //   this.qualityNotesList = res.data.twitterlist.list || []
            // }
            this.qualityNotesList = res.data.twitterlist.list || []
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              duration: 3000
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 去往笔记详情
     */
    goNotesDetails(item) {
      uni.navigateTo({
        url: '/pages/find/findDetails?twitterId=' + item.twitterInfo.twitterId + '&pageType=2'
      })
    },
    // 评论未读数量
    hasNewlyFun() {
      let datas = {}
      findModel.isHasNewly(datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          // 7-1.未读评论数>0，则显示具体数字
          // 7-2.未读评论数=0, 未读点赞数>0, 显示红点
          // 7-3. 未读评论数=0，未读点赞数=0，无提醒
          this.unreadObj = dataRes.data
        } else {
          uni.showToast({
            title: dataRes.message,
            icon: 'none',
            duration: 3000
          })
        }
      })
    },
    // 广场看帖切换
    async topCheckTab(data) {
      if (data.code === this.topCheckTabCode) return
      if (data.code === 'plaza') {
        // 动态
        this.topCheckTabCode = 'plaza'
        this.twitterType = 'TWITTER'

        this.headerTab.map(item => {
          if (item.id == this.tabId) {
            this.checkTabCode = item.code
          }
        })
      } else {
        // 笔记
        this.topCheckTabCode = 'thread'
        this.twitterType = 'NOTES'
        // this.checkTabCode = 'RECOMMEND'
      }
      // this.refreshList()
    },
    /**
     * 切换tab --改变swiper的current
     * 调用changeCheckedTabList
     */
    changeCheckedTabList(e) {
      this.requestFlag = true
      this.topCheckTabCode = e.detail.current == 0 ? 'plaza' : 'thread'
      this.twitterType = e.detail.current == 0 ? 'TWITTER' : 'NOTES'
      if (this.loadedList.includes(this.topCheckTabCode)) {
        return
      }
      this.loadedList.push(this.topCheckTabCode)
      this.getList()
    },
    // 最新 关注 附近
    checkTab(data) {
      this.requestFlag = true
      this.tabId = data.id
      this.checkTabCode = data.code
      this.twitterType = 'TWITTER'

      this.dynamicpageNumber = 0
      this.dynamicpages = 0
      this.dynamicList = []
      this.dynamiclastKeyWord = ''
      this.dynamicListloadStatus = 'loadmore'
      // this.showLoading = true

      /**
       * 动态、笔记（推荐列表要读取缓存keyword）
       */
      let lastKeyWord = ''
      if (this.topCheckTabCode == 'plaza' && this.checkTabCode == 'RECOMMEND') {
        lastKeyWord = load(TWITTERRECOMMENDKEYWORD) || ''
      } else if (this.topCheckTabCode == 'thread' && this.myChanneLabel == 'RECOMMEND') {
        lastKeyWord = load(NOTESRECOMMENDKEYWORD) || ''
      }
      this.getActivList(lastKeyWord)
    },
    /**
     * 笔记频道 切换
     */
    checkChannel(currentLabel, isRefreshFlag) {
      this.myChanneLabel = currentLabel
      // this.checkTabCode = 'PUSH'
      // 瀑布流数据置空
      this.postList = { status: 'reset', reset: '', list: [] }
      this.postListpageNumber = 0
      this.postListpages = 0
      this.postListloadStatus = 'loadmore'
      // this.showLoading = true
      this.$nextTick(() => {
        this.getList(isRefreshFlag ? '' : 'clickNoteType')
      })
    },
    // 去动态话题页
    goDynamicTag(item) {
      if (item.topicName) {
        uni.navigateTo({
          url: '/pagesFind/find/dynamicTag?topicName=' + item.topicName
        })
      } else {
        uni.navigateTo({
          url: '/pagesFind/find/dynamicTag?topicName=' + item
        })
      }
    },
    // 发现顶部搜索
    goSearch(tabType) {
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/indexSearch?tabType=' + tabType
      })
    },
    // 去消息页
    openCommentAndZanPage() {
      uni.navigateTo({
        url: '/pagesFind/find/interaction?unreadNum=' + this.unreadObj.commentNewlyNumber
      })
    },
    // 获取定位
    getPostion() {
      let self = this
      uni.getLocation({
        type: 'gcj02', //gcj02
        success: res => {
          let position = {
            lat: res.latitude,
            lon: res.longitude
          }
          uni.setStorage({
            key: 'position',
            data: JSON.stringify(position)
          })
          self.showLoading = true
          self.getActivList()
        },
        fail: err => {}
      })
    },
    // 获取话题列表
    getTopicList() {
      findModel.getTopicList().then(res => {
        if (res.data.list.length >= 4) {
          this.tagList = res.data.list.slice(0, 4)
        } else {
          this.tagList = res.data.list
        }
      })
    },
    // 热门话题榜
    goHotTopList() {
      uni.navigateTo({ url: '/pages/find/hotTopicList' })
    },
    /**
     * 博主打卡弹窗打开
     */
    bloggerPopOpen() {
      this.bloggerPopshow = true
    },
    /**
     * 博主打卡弹窗关闭
     */
    bloggerPopClose() {
      this.bloggerPopshow = false
    },
    /**
     * 获取是否进行博主打卡提示
     */
    getBloggerNotice() {
      let params = {
        numberId: this.numberId
      }
      Blogger.notice(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.bloggerPopshow = true
            this.bloggerPopNotice = res.data.notice
          } else {
            this.bloggerPopshow = false
          }
        })
        .catch(err => {})
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}

.fixedBgc {
  height: calc(100vh - 100rpx);
  height: 100vh;
  overflow: hidden;
}

.findpage {
  min-height: 100vh;

  .header {
    width: 100%;
    position: fixed;
    padding-top: var(--status-bar-height);
    background: url('http://img.yiqitogether.com/yqyq-app/images/fx_bg.png');
    z-index: 999;
    background-size: 100% 100%;
    height: 100rpx;

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 35rpx;
      height: 88rpx;

      .nav-left {
        padding: 20rpx 0;
        .li {
          display: inline-block;
          font-size: 32rpx;
          color: #838e9a;
          margin-right: 50rpx;
          font-family: PingFang SC, PingFang SC-Medium;
          position: relative;
        }

        .active {
          font-weight: bold;
          font-size: 36rpx;
          color: #333333;
          font-family: PingFang SC, PingFang SC-Medium;
        }
        .nav-left-img {
          width: 46rpx;
          height: 46rpx;
          position: absolute;
          top: -13rpx;
          right: -27rpx;
        }
      }

      .nav-right {
        display: flex;
        align-items: center;

        .right-icon {
          width: 48rpx;
          height: 48rpx;
          margin-left: 24rpx;
        }

        .message {
          position: relative;
          font-size: 0;
          .unread-message-number {
            box-sizing: border-box;
            min-width: 32rpx;
            min-height: 32rpx;
            position: absolute;
            padding: 2rpx 4rpx;
            border-radius: 32rpx;
            top: -15rpx;
            left: 75%;
            background-color: #fe5e10;
            color: #fff;
            font-size: 22rpx;
            text-align: center;
          }
          .dot {
            position: absolute;
            width: 16rpx;
            height: 16rpx;
            border-radius: 50%;
            top: -4rpx;
            right: -4px;
            background-color: #fe5e10;
          }
        }
      }
    }
  }

  .swiper {
    width: 100%;
    height: calc(100vh - var(--status-bar-height) - 100rpx);
    // min-height: 85vh;
  }

  // .swiper-thread {
  //   min-height: 85vh;
  // }
  .swiper-scroll {
    height: 100%;
  }
  .swiper-scroll-thread {
    box-sizing: border-box;
    padding-bottom: 60rpx;
    height: 100%;
  }
  .tag-box {
    width: 100vw;
    height: 424rpx;
    background: url('http://img.yiqitogether.com/yqyq-app/images/huati_kuang.png') no-repeat;
    background-size: 100% 100%;
    border-radius: 24rpx;
    padding: 48rpx 44rpx;
    box-sizing: border-box;
    .tag-box-title {
      margin-bottom: 44rpx;
      .tag-box-title-left {
        font-size: 36rpx;
        color: #373d44;
        font-weight: 700;
      }
      .tag-box-title-right {
        .right-left {
          font-size: 24rpx;
          color: #838e9a;
          line-height: 36rpx;
        }
        .right-icon {
          width: 20rpx;
          height: 20rpx;
        }
      }
    }
    .tag-box-content {
      flex-wrap: wrap;
      .box-content-item {
        width: 50%;
        padding-bottom: 30rpx;
        .content-item-left {
          .content-item-img {
            width: 100rpx;
            height: 100rpx;
            margin-right: 12rpx;
            border-radius: 16rpx;
          }
        }
        .content-item-right {
          .item-right-top {
            height: 40rpx;
            .item-right-top-title {
              max-width: 166rpx;
              height: 40rpx;
              line-height: 40rpx;
              font-size: 28rpx;
              color: #484848;
              margin-right: 8rpx;
            }
            .item-right-top-tag {
              width: 32rpx;
              height: 32rpx;
              border-radius: 6rpx;
              font-size: 24rpx;
              text-align: center;
              color: #ffffff;
              line-height: 32rpx;
            }
            .tag-new {
              background: #79e4b2;
            }
            .tag-hot {
              background: linear-gradient(180deg, #ff7bad, #ffa3b4);
            }
            .tag-vote {
              background: linear-gradient(316deg, #aea5ff 9%, #bbdbff 92%);
            }
          }
          .item-right-bottom {
            margin-top: 12rpx;
            font-size: 24rpx;
            color: #bdc1c5;
          }
        }

        image {
          width: 24rpx;
          height: 24rpx;
          margin-right: 8rpx;
          flex-shrink: 0;
        }

        text {
          font-size: 24rpx;
          color: #333333;
          line-height: 32rpx;
        }
      }
    }
  }

  .quality-notes {
    background: #ffffff;
    .quality-notes-title {
      padding: 30rpx 36rpx;
      .left {
        font-size: 36rpx;
        color: #2a343e;
        font-weight: bold;
      }
      .right {
        .right-left {
          font-size: 24rpx;
          color: #838e9a;
          line-height: 36rpx;
        }
        .right-icon {
          width: 20rpx;
          height: 20rpx;
        }
      }
    }
    .quality-notes-box {
      padding-right: 36rpx;
      .box-list {
        padding: 0 36rpx 24rpx;
        .item {
          margin-right: 8rpx;
          .image-box {
            position: relative;

            .notes-img {
              width: 272rpx;
              height: 344rpx;
              border-radius: 24rpx;
            }
            .video {
              position: absolute;
              top: 44%;
              right: 45%;
              transform: translate(50%, 0%);
              width: 52rpx;
              height: 52rpx;
            }
          }
          .notes-title {
            margin-top: 8rpx;
            width: 252rpx;
            font-size: 28rpx;
            color: #1c1c1c;
          }
        }
      }
    }
  }
  .headerTab {
    width: 100%;
    box-sizing: border-box;
    padding: 20rpx 30rpx;
    z-index: 3;
    background: #ffffff;
    .li {
      font-size: 26rpx;
      text-align: center;
      color: #c7cdd3;
      margin-right: 40rpx;
      .li-text {
        margin-bottom: 4rpx;
      }
    }

    .active {
      font-size: 26rpx;
      color: #484848;
      text-align: center;
      margin-right: 40rpx;
      font-weight: 700;
    }
    .headerTab-border {
      width: 20rpx;
      height: 4rpx;
      background: #2a343e;
      border-radius: 26rpx;
      margin: auto;
    }
  }
}

/deep/ .u-icon__icon {
  width: 24rpx !important;
  height: 24rpx !important;
  font-size: 24rpx !important;
}
.tips-box {
  padding-top: 24rpx;
  padding-bottom: 50rpx;
}

.plazaTop {
  height: calc(var(--status-bar-height) + 100rpx);
}

.threadTop {
  height: calc(var(--status-bar-height) + 184rpx);
}
</style>
