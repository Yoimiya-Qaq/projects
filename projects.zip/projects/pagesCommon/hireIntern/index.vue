<template>
  <view class="hireInternPage">
    <view class="nav flex-0">
      <view v-if="isFillIn" class="nav_image" @click="goBack">
        <image src="@/static/images/back_black.png" mode="scaleToFill" />
      </view>
      <view class="nav_title">{{ isFillIn ? '预约面试登记表' : '一起一起招人啦！' }}</view>
    </view>
    <block v-if="!isFillIn">
      <image class="bgImg" src="http://img.yiqitogether.com/yqyq-app/images/zhaopin_h5.png" mode="widthFix" />
      <view class="fillinbtnBox">
        <view class="fillInBtn" @click="goFillIn">填写面试人信息</view>
      </view>
    </block>
    <block v-else>
      <view class="registrationFormBox">
        <image class="registrationFormBox-img" src="http://img.yiqitogether.com/yqyq-app/images/zhaopin_h5_1.png" mode="widthFix" alt="" />
        <view class="registrationFormBox-body">
          <view class="formBox">
            <view class="formBox-content">
              <view class="formBox-content-item">
                <view class="content-item-title">姓名</view>
                <u--input fontSize="26" class="content-item-input" placeholder="请填写真实姓名" border="surround" v-model="name"></u--input>
              </view>
              <view class="formBox-content-item">
                <view class="content-item-title">手机号</view>
                <u--input fontSize="26" class="content-item-input" maxlength="11" type="number" placeholder="请填写手机号" border="surround" v-model="phoneNumber"></u--input>
              </view>
              <view class="formBox-content-item">
                <view class="content-item-title">学校</view>
                <view class="content-item-content flex-1" @click="schoolOpen">
                  <view :style="schoolName ? 'color: #434449;' : ''">{{ schoolName ? schoolName : '请选择学校' }}</view>
                  <image class="item-content-narrow" src="@/static/images/hireInternImgs/narrow.png" mode="scaleToFill" />
                </view>
              </view>
              <view class="formBox-content-item">
                <view class="content-item-title">专业</view>
                <u--input fontSize="26" class="content-item-input" placeholder="请填写专业" border="surround" v-model="specialty"></u--input>
              </view>
              <view class="formBox-content-item" style="margin: 0" @click="getGraduationYear">
                <view class="content-item-title">毕业年份</view>
                <view class="content-item-content flex-1">
                  <view :style="graduationYear ? 'color: #434449;' : ''">{{ graduationYear ? graduationYear : '请选择' }}</view>
                  <image v-if="!graduationYearShow" class="item-content-narrow" src="@/static/images/hireInternImgs/narrow.png" mode="scaleToFill" />
                  <image v-else class="item-content-narrow1" src="@/static/images/hireInternImgs/narrow1.png" mode="scaleToFill" />
                </view>
              </view>
              <view v-if="graduationYearShow" class="graduationYear-Box">
                <view class="graduationYear-item" :style="graduationYear == item ? 'color: #434449;' : ''" v-for="(item, index) in yearList" :key="index" @click="checkedGraduationYear(item)">{{ item }}</view>
              </view>
            </view>
          </view>
          <view class="formBox-bottom" @click="$u.throttle(submitInformation, 500)">提交面试信息</view>
        </view>
      </view>
    </block>
    <u-popup class="schoolPop" mode="center" :show="schoolShow" @close="schoolClose" @open="schoolOpen">
      <view class="schoolPop-body">
        <u--input
          fontSize="26"
          class="schoolPop-body-input"
          placeholder="请填写学校名称"
          border="surround"
          v-model="searchValue"
          @input="
            $u.debounce(() => {
              onSearch($event)
            }, 500)
          "
        ></u--input>
        <view class="schoolPop-content">
          <block>
            <view class="list-wrap" v-if="schoolList.length && !showLoading">
              <view class="list-item" :style="item == searchValue ? 'background: #f2fcff;' : ''" v-for="item in schoolList" :key="item.id" @click="handleCheck(item)">
                {{ item }}
              </view>
              <u-loadmore status="nomore" :fontSize="20" :marginTop="22" :marginBottom="22" nomore-text="到底了~" />
            </view>
            <view class="list-wrap" v-if="!schoolList.length && !showLoading">
              <view class="empty-box">
                <image class="empty-img" src="http://img.yiqitogether.com/yqyq-app/images/empty%402x.png" mode="aspectFill" />
                <view class="empty-desc">暂无学校信息</view>
              </view>
            </view>
          </block>
        </view>
        <view class="schoolPop-bottom flex-3">
          <view class="schoolPop-bottom-left" @click="schoolClose">返回</view>
          <view class="schoolPop-bottom-right" @click="getSchoolName">确认</view>
        </view>
      </view>
    </u-popup>
  </view>
</template>
<script>
import { getCollegeList } from '@/utils/tools.js'
import collegeData from '@/static/commonJson/college.json'
import IndexModel from '@/model/index'
export default {
  data() {
    return {
      isFillIn: false, //是否填写
      name: '', //姓名
      phoneNumber: '', //手机号
      schoolName: '', //学校
      specialty: '', //专业
      graduationYear: '', //毕业年份
      schoolShow: false, //选择学校弹框
      graduationYearShow: false, //毕业年份弹框
      searchValue: '', //学校名称搜索
      schoolList: [],
      showList: false,
      showLoading: false,
      isChecked: false, //是否选择了学校
      yearList: ['已毕业', '2024', '2025', '2026', '2027'] //可选年份列表
    }
  },
  methods: {
    // 去填写信息
    goFillIn() {
      this.isFillIn = true
    },
    // 学校弹窗关闭
    schoolClose() {
      this.schoolShow = false
    },
    // 学校弹窗打开
    schoolOpen() {
      this.schoolShow = true
    },
    // 毕业年份弹窗打开
    getGraduationYear() {
      this.graduationYearShow = true
    },
    // 获取学校列表
    getList() {
      this.showList = true
      this.showLoading = true
      let data = getCollegeList(collegeData.data) || []
      if (this.searchValue) {
        this.schoolList = data.filter(item => item.indexOf(this.searchValue) != -1)
        this.showLoading = false
      } else {
        this.schoolList = data
        this.showLoading = false
      }
    },
    // 模糊搜索
    onSearch(e) {
      e = uni.$u.trim(e)
      if (e) {
        this.searchValue = e
        // if (this.isCollege == 1) {
        this.getList()
        // } else {
        //   this.schoolName = e
        // }
      } else {
        this.onClear()
      }
    },
    // 清空搜索条件，重置列表
    onClear() {
      this.searchValue = ''
      this.schoolName = ''
      this.schoolList = []
      // this.showList = false
    },
    // 选择学校
    handleCheck(item) {
      this.searchValue = item
      this.isChecked = true
      // this.showList = false
    },
    // 选择毕业年份
    checkedGraduationYear(item) {
      this.graduationYear = item
      this.graduationYearShow = false
    },
    getSchoolName() {
      if (this.isChecked) {
        this.schoolName = this.searchValue
        this.schoolClose()
      } else {
        if (this.schoolName) {
          this.schoolClose()
        } else {
          uni.showToast({
            title: '请选择学校名称',
            icon: 'none',
            mask: true
          })
        }
      }
      this.isChecked = false
    },
    // 判断是否全部填写
    isAllFillIn() {
      console.log("🚀 ~ isAllFillIn ~ this.name.replace(' '):")

      if (!this.name.replace(/\s/g, '')) {
        uni.showToast({
          title: '请填写真实姓名',
          icon: 'none',
          mask: true
        })
        return false
      } else if (this.phoneNumber.length < 11) {
        uni.showToast({
          title: '请填写正确的手机号',
          icon: 'none',
          mask: true
        })
        return false
      } else if (!this.schoolName) {
        uni.showToast({
          title: '请选择学校',
          icon: 'none',
          mask: true
        })
        return false
      } else if (!this.specialty.replace(/\s/g, '')) {
        uni.showToast({
          title: '请填写专业',
          icon: 'none',
          mask: true
        })
        return false
      } else if (!this.graduationYear) {
        uni.showToast({
          title: '请选择毕业年份',
          icon: 'none',
          mask: true
        })
        return false
      } else {
        return true
      }
    },
    clearInformation() {
      this.isFillIn = false
      this.name = ''
      this.phoneNumber = ''
      this.schoolName = ''
      this.specialty = ''
      this.graduationYear = ''
      this.searchValue = ''
      this.onClear()
    },
    // 提交面试信息
    submitInformation() {
      let allFill = this.isAllFillIn()
      if (!allFill) {
        return
      }
      let data = {
        name: this.name.replace(/\s/g, ''),
        mobilePhone: this.phoneNumber,
        schoolName: this.schoolName,
        major: this.specialty.replace(/\s/g, ''),
        graduationDate: this.graduationYear
      }
      console.log('🚀 ~ submitInformation ~ data:', data)
      IndexModel.getStudentCollect({ ...data })
        .then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '您已成功提交面试信息！请保持电话畅通，等待招聘专员联系面试行程',
              icon: 'none',
              mask: true
            })
            setTimeout(() => {
              this.clearInformation()
            }, 800)
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              mask: true
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none',
            mask: true
          })
        })
    },
    goBack() {
      this.clearInformation()
    }
  }
}
</script>
<style lang="scss" scoped>
.flex {
  display: flex;
}
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.hireInternPage {
  height: 100vh;
  background: #ffffff;
  // overflow: hidden;
  .nav {
    background: #ffffff;
    padding-top: var(--status-bar-height);
    width: 100vw;
    height: 88rpx;
    position: fixed;
    top: var(--status-bar-height);
    z-index: 1;
    .nav_image {
      padding: 0 24rpx;
      width: 44rpx;
      height: 44rpx;
      position: absolute;
      image {
        width: 100%;
        height: 100%;
      }
    }
    .nav_title {
      flex-grow: 1;
      font-size: 32rpx;
      line-height: 44rpx;
      color: #2a343e;
      text-align: center;
    }
  }
  .bgImg {
    margin-top: calc(var(--status-bar-height) + 88rpx);
    width: 100vw;
    display: block;
  }
  .fillinbtnBox {
    width: 100vw;
    height: 176rpx;
    background: #f2fdff;
    padding-top: 24rpx;
    box-sizing: border-box;

    .fillInBtn {
      margin: auto;
      width: 670rpx;
      height: 88rpx;
      background: linear-gradient(270deg, #97beff, #8b6eff);
      border-radius: 44rpx;
      font-size: 32rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
    }
  }
  .registrationFormBox {
    position: relative;
    height: 1496rpx;
    margin-top: calc(var(--status-bar-height) + 88rpx);
    background: #4948ff;
    .registrationFormBox-img {
      width: 750rpx;
    }
    .registrationFormBox-body {
      width: 598rpx;
      position: absolute;
      margin: auto;
      top: calc(var(--status-bar-height) + 340rpx);
      right: 76rpx;
      .formBox {
        height: 862rpx;
        background: #ffffff;
        border: 2rpx solid #262424;
        border-radius: 20rpx;
        position: relative;
        .formBox-content {
          padding-top: 48rpx;
          width: 502rpx;
          margin: auto;
          .formBox-content-item {
            margin-bottom: 36rpx;
            .content-item-title {
              font-size: 28rpx;
              color: #434449;
              font-weight: 600;
              margin-bottom: 8rpx;
            }
            .content-item-input {
              width: 502rpx;
              height: 72rpx;
              background: #f3fbff;
              border-radius: 12rpx;
            }
            .content-item-content {
              width: 502rpx;
              height: 72rpx;
              background: #f3fbff;
              border-radius: 12rpx;
              padding: 0 22rpx !important;
              border: 2rpx solid #262424 !important;
              box-sizing: border-box;
              color: #b6b9c7;
              font-size: 26rpx;
              .item-content-narrow {
                width: 12rpx;
                height: 20rpx;
              }
              .item-content-narrow1 {
                width: 20rpx;
                height: 12rpx;
              }
            }
            /deep/ .u-input {
              padding: 0 22rpx !important;
              border: 2rpx solid #262424 !important;
              box-sizing: border-box;
            }
          }

          .graduationYear-Box {
            z-index: 1;
            width: 502rpx;
            height: 266rpx;
            background: #f2fcff;
            border-radius: 0 0 24rpx 24rpx;
            overflow-y: scroll;
            padding: 32rpx 26rpx 0;
            box-sizing: border-box;
            z-index: 1;
            .graduationYear-item {
              font-size: 24rpx;
              color: #a4a8bd;
              margin-bottom: 26rpx;
            }
          }
        }
      }
      .formBox-bottom {
        width: 598rpx;
        height: 104rpx;
        background: linear-gradient(270deg, #6da0ff, #6ee2cb);
        border-radius: 56rpx;
        box-shadow: 0rpx 14rpx 56rpx 8rpx rgba(255, 255, 255, 0.55);
        font-size: 32rpx;
        text-align: center;
        color: #ffffff;
        line-height: 104rpx;
        margin-top: 52rpx;
      }
    }
  }
  .schoolPop {
    .schoolPop-body {
      width: 590rpx;
      height: 692rpx;
      background: #ffffff;
      padding: 40rpx 44rpx;
      box-sizing: border-box;
      .schoolPop-body-input {
        width: 502rpx;
        height: 72rpx;
        background: #f3fbff;
        border-radius: 12rpx;
      }
      /deep/ .u-input {
        padding: 0 22rpx !important;
        border: 2rpx solid #262424 !important;
        box-sizing: border-box;
      }
      .schoolPop-content {
        margin: 20rpx 0;
        .list-wrap {
          height: 400rpx;

          // height: calc(100vh - 218rpx - var(--status-bar-height));
          // padding: 28rpx 0;
          // padding-bottom: calc(constant(safe-area-inset-bottom) + 28rpx);
          // padding-bottom: calc(env(safe-area-inset-bottom) + 28rpx);
          box-sizing: border-box;
          overflow-y: scroll;
          .list-item {
            height: 78rpx;
            font-size: 26rpx;
            color: #b6b9c7;
            line-height: 78rpx;
            // padding: 28rpx 22rpx;
            padding: 0 18rpx;
            box-sizing: border-box;
            // text-align: center;

            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            word-break: break-all;
          }

          .empty-box {
            text-align: center;
            font-size: 0;
            margin-top: 30rpx;
            .empty-img {
              width: 334rpx;
              height: 248rpx;
              margin-bottom: 26rpx;
            }
            .empty-desc {
              font-size: 24rpx;
              text-align: center;
              color: #bbcde1;
              line-height: 42rpx;
            }
          }
        }
      }
      .schoolPop-bottom {
        .schoolPop-bottom-left {
          width: 234rpx;
          height: 80rpx;
          background: #ecf7ff;
          border-radius: 8rpx;
          font-size: 26rpx;
          color: #40abff;
          line-height: 80rpx;
          text-align: center;
        }
        .schoolPop-bottom-right {
          width: 234rpx;
          height: 80rpx;
          background: #40abff;
          border-radius: 8rpx;
          font-size: 26rpx;
          text-align: center;
          color: #ffffff;
          line-height: 80rpx;
        }
      }
    }
  }
}
</style>
