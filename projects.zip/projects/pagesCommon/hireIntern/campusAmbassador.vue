<template>
  <view class="hireInternPage">
    <image class="bgImg" src="http://img.yiqitogether.com/yqyq-app/images/xyds_changtu.png" mode="widthFix" />
    <view class="bottom-btn-box" v-if="!isscrollTop">
      <view class="fillInBtn" @click="$u.throttle(openAddcampusPop)">立即报名</view>
    </view>
    <view class="right-btn-box flex-5" v-if="isscrollTop">
      <view class="bottom-btn" @click="$u.throttle(openAddcampusPop)">
        立即
        <br />
        报名
      </view>
    </view>

    <u-popup class="addcampuspop" :customStyle="{ bottom: -activeheight + 'px' }" :show="showAddcampusPop" @close="closeAddcampusPop" @open="openAddcampusPop">
      <view class="addcampuspop-body">
        <view class="body-title flex-1">
          <view class="flex-0">
            <view class="left-icon"></view>
            信息收集
          </view>

          <image class="close-icon" @click="closeAddcampusPop" src="http://img.yiqitogether.com/yqyq-app/images/guanbi.png" mode="scaleToFill" />
        </view>
        <view class="body-content">
          <view class="body-content-item">
            <view class="content-item-title">姓名</view>
            <u--input fontSize="26" style="caret-color: #fe5e10" :class="focus == '姓名' ? 'active-content-item-input' : 'content-item-input'" @focus="onfucus('姓名')" @blur="onblur" placeholder="请填写真实姓名" v-model="name"></u--input>
          </view>
          <view class="body-content-item">
            <view class="content-item-title">手机号</view>
            <u--input fontSize="26" style="caret-color: #fe5e10" :class="focus == '手机号' ? 'active-content-item-input' : 'content-item-input'" @focus="onfucus('手机号')" @blur="onblur" maxlength="11" type="number" placeholder="请填写手机号" v-model="phoneNumber"></u--input>
          </view>
          <view class="body-content-item" style="z-index: 2">
            <view class="content-item-title">学校</view>
            <input
              placeholder-style="color:#adb3ba;font-size:26rpx;"
              fontSize="15"
              style="caret-color: #fe5e10"
              :class="focus == '学校' ? 'active-content-item-input' : 'content-item-input'"
              @focus="onfucus('学校')"
              @blur="onblur"
              placeholder="请填写学校名称"
              v-model.trim="searchValue"
              @input="onSearch($event)"
            />
            <view class="content-item-school" v-if="schoolList.length && showLoading">
              <view class="school-wrap">
                <view class="list-item" v-for="item in schoolList" :key="item.id" @click="handleCheck(item)">
                  {{ item }}
                </view>
                <u-loadmore status="nomore" :fontSize="20" :marginTop="22" :marginBottom="22" nomore-text="到底了~" />
              </view>
            </view>
          </view>
          <!-- 用于点击其他区域 学校列表不展示 -->
          <u-overlay :show="schoolshow" @click="closeschoolshow" :z-index="1" :opacity="0"></u-overlay>
          <view class="body-content-item">
            <view class="content-item-title">专业</view>
            <u--input fontSize="26" style="caret-color: #fe5e10" :class="focus == '专业' ? 'active-content-item-input' : 'content-item-input'" @focus="onfucus('专业')" @blur="onblur" class="content-item-input" placeholder="请填写专业" v-model="specialty"></u--input>
          </view>
          <view class="body-content-item">
            <view class="content-item-title">推荐人ID</view>
            <u--input fontSize="26" style="caret-color: #fe5e10" :class="focus == '推荐人ID' ? 'active-content-item-input' : 'content-item-input'" @focus="onfucus('推荐人ID')" @blur="onblur" class="content-item-input" placeholder="请填写ID" v-model="recommendID"></u--input>
          </view>
        </view>
        <view class="body-btn">
          <view :class="name && phoneNumber && searchValue && specialty ? 'active-submit-btn' : 'submit-btn'" @click="$u.throttle(submitInformation, 500)">提交</view>
        </view>
      </view>
    </u-popup>
  </view>
</template>
<script>
import { getCollegeList } from '@/utils/tools.js'
import collegeData from '@/static/commonJson/college.json'
import IndexModel from '@/model/index'
export default {
  data() {
    return {
      // isFillIn: false, //是否填写
      name: '', //姓名
      phoneNumber: '', //手机号
      specialty: '', //专业
      recommendID: '', //毕业年份
      searchValue: '', //学校名称搜索
      schoolList: [],
      showLoading: false,
      isscrollTop: false, //屏幕滑动
      showAddcampusPop: false, //校园大使报名弹框
      focus: false, //是否聚焦
      schoolAllList: [], //全部学校列表
      schoolshow: false, //学校输入展示遮罩层
      activeheight: 0,
      oldheight: 0
    }
  },
  onPageScroll: function (e) {
    let top = 100
    //nvue暂不支持滚动监听，可用bindingx代替
    if (e.scrollTop <= top) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  onLoad(options) {
    let arr = getCollegeList(collegeData.data) || []
    this.schoolAllList = arr
    // #ifdef H5
    // 监听键盘的收起与弹出
    let initialHeight = window.innerHeight
    window.addEventListener('resize', () => {
      let currentHeight = window.innerHeight
      let keyboardHeight = initialHeight - currentHeight
      this.oldheight = keyboardHeight
      // this.activeheight = this.oldheight
      if (this.focus == '学校' || this.focus == '专业' || this.focus == '推荐人ID') {
        this.activeheight = 0
      } else {
        this.activeheight = this.oldheight
      }
    })
    // #endif
    // #ifndef H5
    // 监听键盘的收起与弹出
    uni.onKeyboardHeightChange(this.keyboardheightchange)
    // #endif
  },
  watch: {
    focus(newVal, oldVal) {
      if (newVal == '学校' || newVal == '专业' || newVal == '推荐人ID') {
        this.activeheight = 0
        console.log('走这里')
      } else {
        this.activeheight = this.oldheight
      }
    }
  },
  methods: {
    // 解决弹窗滚动穿透问题
    handleTouchMove(e) {
      e.stopPropagation()
    },
    keyboardheightchange(res) {
      const { height, duration } = res
      // 键盘弹起
      if (height > 0) {
        this.oldheight = height
        this.activeheight = height
      }
      // 键盘收回
      else {
        this.activeheight = 0
      }
    },
    closeschoolshow() {
      this.schoolshow = false
      this.showLoading = false
    },
    onfucus(type) {
      this.focus = type
      if (this.focus == '学校') {
        this.schoolshow = true
      }
    },
    onblur() {
      this.focus = ''
    },
    /**
     * 打开校园大使报名弹框
     */
    openAddcampusPop() {
      this.showAddcampusPop = true
    },
    /**
     * 关闭校园大使报名弹框
     */
    closeAddcampusPop() {
      this.showAddcampusPop = false
    },
    // 获取学校列表
    getList() {
      if (this.searchValue) {
        this.schoolList = this.schoolAllList.filter(item => item.indexOf(this.searchValue) != -1)
        this.showLoading = true
      } else {
        this.schoolList = []
        this.showLoading = false
      }
    },
    // 模糊搜索
    onSearch(e) {
      this.searchValue = e.detail.value
      uni.$u.debounce(this.getList(), 500)
    },
    // 清空搜索条件，重置列表
    onClear() {
      this.searchValue = ''
      this.schoolList = []
    },
    // 选择学校
    handleCheck(item) {
      this.searchValue = item
      this.closeschoolshow()
    },
    // 判断是否全部填写
    isAllFillIn() {
      if (!this.name.replace(/\s/g, '')) {
        uni.showToast({
          title: '请填写真实姓名',
          icon: 'none',
          mask: true
        })
        return false
      } else if (this.phoneNumber.length < 11) {
        uni.showToast({
          title: '请填写正确的手机号',
          icon: 'none',
          mask: true
        })
        return false
      } else if (!this.searchValue) {
        uni.showToast({
          title: '请选择学校',
          icon: 'none',
          mask: true
        })
        return false
      } else if (!this.specialty.replace(/\s/g, '')) {
        uni.showToast({
          title: '请填写专业',
          icon: 'none',
          mask: true
        })
        return false
      } else {
        return true
      }
    },
    clearInformation() {
      this.name = ''
      this.phoneNumber = ''
      this.specialty = ''
      this.recommendID = ''
      this.searchValue = ''
      this.closeAddcampusPop()
      this.onClear()
    },
    // 提交校园大使信息
    submitInformation() {
      let allFill = this.isAllFillIn()
      if (!allFill) {
        return
      }
      let data = {
        name: this.name.replace(/\s/g, ''),
        mobilePhone: this.phoneNumber,
        schoolName: this.searchValue,
        major: this.specialty.replace(/\s/g, ''),
        recommendld: this.recommendID
      }
      IndexModel.getStudentCollect({ ...data })
        .then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '信息收集成功',
              icon: 'none',
              mask: true
            })
            setTimeout(() => {
              this.clearInformation()
            }, 800)
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              mask: true
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none',
            mask: true
          })
        })
    },
    goBack() {
      this.clearInformation()
    }
  }
}
</script>
<style lang="scss" scoped>
.flex {
  display: flex;
}
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-2 {
  display: flex;
  justify-content: space-between;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.hireInternPage {
  height: 100vh;
  background: #ffffff;

  .bgImg {
    width: 100vw;
    display: block;
  }
  .bottom-btn-box {
    width: 100vw;
    height: 176rpx;
    padding-top: 24rpx;
    box-sizing: border-box;
    position: fixed;
    bottom: 72rpx;

    .fillInBtn {
      margin: auto;
      width: 678rpx;
      height: 112rpx;
      font-size: 32rpx;
      text-align: center;
      color: #ffffff;
      line-height: 112rpx;
      background: #000000;
      border-radius: 56rpx;
      box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(0, 0, 0, 0.5);
    }
  }
  .right-btn-box {
    width: 112rpx;
    height: 112rpx;
    background: #232323;
    border-radius: 56rpx;
    box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(0, 0, 0, 0.5);
    position: fixed;
    bottom: 700rpx;
    right: 30rpx;
    .bottom-btn {
      width: 56rpx;
      font-size: 28rpx;
      text-align: center;
      color: #ffffff;
      overflow: hidden;
      white-space: nowrap;
    }
  }

  .addcampuspop {
    /deep/.u-popup__content {
      background: transparent;
    }
    .addcampuspop-body {
      background: url('http://img.yiqitogether.com/yqyq-app/images/bm_tanchuang.png');
      background-size: 100% 100%;
      height: 1374rpx;
      .body-title {
        margin: 80rpx 36rpx 0 36rpx;
        .left-icon {
          width: 8rpx;
          height: 32rpx;
          background: #1f1f1f;
          border-radius: 2rpx;
          margin-right: 10rpx;
        }
        font-size: 36rpx;
        text-align: left;
        color: #1f1f1f;
        line-height: 50rpx;
        font-weight: bold;
        .close-icon {
          width: 40rpx;
          height: 40rpx;
        }
      }
      .body-content {
        margin: 44rpx 0 0 36rpx;
        .body-content-item {
          margin-bottom: 44rpx;
          position: relative;
          .content-item-title {
            font-size: 28rpx;
            color: #2a343e;
            margin-bottom: 16rpx;
            font-weight: bold;
          }
          .content-item-input {
            width: 678rpx;
            height: 80rpx;
            line-height: 80rpx;
            border-radius: 20rpx;
            box-sizing: border-box;
            border: 2rpx solid #a6acb2 !important;
            font-weight: bold !important;
          }
          .active-content-item-input {
            width: 678rpx;
            height: 80rpx;
            line-height: 80rpx;
            border-radius: 20rpx;
            box-sizing: border-box;
            border: 2rpx solid #fe5e10 !important;
            font-weight: bold !important;
          }
          input {
            font-size: 26rpx;
            padding: 0 20rpx;
            font-weight: bold;
          }
          .content-item-school {
            box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(189, 195, 211, 0.5);
            border-radius: 20rpx;
            width: 678rpx;
            padding-bottom: 14rpx;
            position: absolute;
            top: 156rpx;
            z-index: 1;
            .school-wrap {
              width: 678rpx;
              height: 362rpx;
              background: #ffffff;
              overflow-y: scroll;
              padding: 24rpx 24rpx 0rpx 24rpx;
              box-sizing: border-box;
              .list-item {
                height: 78rpx;
                line-height: 78rpx;
                font-size: 28rpx;
                color: #1c1c1c;
                box-sizing: border-box;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                word-break: break-all;
                font-weight: bold;
              }
            }
          }
        }
      }
      .body-btn {
        .submit-btn {
          margin: 106rpx auto 0;
          width: 678rpx;
          height: 112rpx;
          background: #f0f1f3;
          border-radius: 56rpx;
          font-size: 32rpx;
          text-align: center;
          color: #a6acb2;
          line-height: 112rpx;
        }
        .active-submit-btn {
          margin: 106rpx auto 0;
          width: 678rpx;
          height: 112rpx;
          background: #000000;
          border-radius: 56rpx;
          font-size: 32rpx;
          text-align: center;
          color: #ffffff;
          line-height: 112rpx;
        }
      }
    }
  }
}
</style>
