<template>
  <view class="agency-page">
    <view class="page-body">
      <!-- <image src="../../static/images/back_black.png" class="h-icon-back back" mode="" @click="goBack"></image> -->
      <image class="bg" src="http://img.yiqitogether.com/yqyq-app/images/daili_bg.png" mode="widthFix" />
      <view class="body-content">
        <view class="content">
          <block v-if="kefuList.length > 0">
            <view class="title-box flex-0">
              <view class="title-name">联系人</view>
              <view class="title-numberId">一起一起ID</view>
              <view class="title-name">联系人</view>
              <view class="title-numberId">一起一起ID</view>
            </view>
            <scroll-view scroll-y class="scroll">
              <view class="content-box flex-0">
                <view class="content-box-item flex-0" v-for="(item, index) in kefuList" :key="index" :style="item.style ? item.style : ''">
                  <view class="item-name">{{ item.name }}</view>
                  <view
                    class="item-number"
                    @click="
                      $u.throttle(() => {
                        copy(item.id)
                      }, 100)
                    "
                    :style="item.style ? item.style : ''"
                  >
                    <text class="item-text">{{ item.id }}</text>
                  </view>
                </view>
              </view>
            </scroll-view>
          </block>
        </view>
      </view>
    </view>
    <view class="toast" v-show="toastShow">ID已复制</view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      kefuList: [
        { name: '汤汤', id: '331050276' },
        { name: '青木', id: '314205845' },

        { name: '徐南瓜', id: '810174242', style: 'background:#eefdff;' },
        { name: '杨杨', id: '110407798', style: 'background:#eefdff;' },

        { name: '王富贵', id: '954015164' },
        { name: '宋欣欣', id: '376767153' },

        { name: 'ZjLu', id: '618253198', style: 'background:#eefdff;' },
        { name: '晴天', id: '948006023', style: 'background:#eefdff;' },

        { name: 'Jessie', id: '584552067' },
        { name: '雪月', id: '200191942' },

        { name: '小圆', id: '880493594', style: 'background:#eefdff;' },
        { name: '火神', id: '616766303', style: 'background:#eefdff;' },

        { name: 'coco', id: '995982858' },
        { name: '一一', id: '408983399' }
      ],
      toastShow: false
    }
  },
  methods: {
    /**
     * 复制
     */
    copy(data) {
      let that = this
      uni.setClipboardData({
        data: data,
        showToast: false,
        success: function () {
          that.toastShow = true
          setTimeout(() => {
            that.toastShow = false
          }, 1000)
        }
      })
    },
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}

.agency-page {
  position: relative;

  .page-body {
    .back {
      position: fixed;
      top: calc(var(--status-bar-height) + 22rpx);
      left: 35rpx;
      z-index: 9;
    }
    .bg {
      width: 100%;
      height: auto;
      display: block;
    }
    .body-content {
      position: absolute;
      bottom: 166rpx;
      width: 100vw;
      .content {
        overflow: hidden;
        width: 632rpx;
        height: 578rpx;
        margin: auto;
        border: 2rpx solid #e6efff;
        border-radius: 24rpx;
        .title-box {
          background: linear-gradient(90deg, #d9ffea, #aff4fa);
          font-weight: bold;
          color: #3b3b3b;
          font-size: 28rpx;
          text-align: center;
          line-height: 40rpx;

          .title-name {
            width: 84rpx;
            padding: 18rpx 20rpx;
            height: 40rpx;
            flex-shrink: 0;
          }
          .title-numberId {
            width: 150rpx;
            padding: 18rpx 20rpx;
            height: 40rpx;
            flex-shrink: 0;
          }
        }
        .content-box {
          flex-wrap: wrap;
          .content-box-item {
            height: 72rpx;
            font-size: 24rpx;
            text-align: center;
            color: #3b3b3b;
            flex: 1;
            .item-name {
              width: 84rpx;
              padding: 18rpx 20rpx;
              text-align: center;
              flex-shrink: 0;
            }
            .item-number {
              padding: 18rpx 20rpx;
              text-align: center;
              width: 152rpx;
              flex-shrink: 0;
              color: #007aff;
              .item-text {
                border-bottom: 1rpx solid #007aff;
              }
            }
          }
          .scroll {
            height: 580rpx;
          }
        }
      }
    }
  }
}
.toast {
  position: fixed;
  top: 40%;
  left: 40%;
  width: 150rpx;
  height: 60rpx;
  font-size: 30rpx;
  line-height: 60rpx;
  border-radius: 14rpx;
  text-align: center;
  z-index: 5;
  overflow: hidden;
  color: #ffffff;
  background: #616161;
}
</style>
