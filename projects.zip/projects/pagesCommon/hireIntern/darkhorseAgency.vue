<template>
  <view class="darkhorseAgency-page">
    <view class="video-box">
      <!-- <video id="myVideo" class="hourse-video" :autoplay="true" :loop="true" :muted="true" :show-center-play-btn="false" :controls="false" :object-fit="'fill'" src="http://img.yiqitogether.com/yqyq-app/advertisement/heima.mp4" /> -->
      <image class="hourse-video" src="https://img.yiqitogether.com/yqyq-app/advertisement/heima.gif" mode="aspectFill" />
      <image class="video-top" src="http://img.yiqitogether.com/yqyq-app/images/darkhorse_top.png" mode="aspectFill" />
    </view>
    <view class="page-content">
      <image class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/darkhorse_bottom.png" mode="aspectFill" />
      <view class="content">
        <view class="box-top flex-1">
          <image class="top-img" @click="previewImage(imageList, index)" :src="item" v-for="(item, index) in imageList" :key="index" mode="aspectFill" />
        </view>
        <view class="body-content">
          <view class="content-title">
            <block v-if="kefuList.length > 0">
              <view class="title-box flex-1">
                <view class="title-item flex-0">
                  <view class="title-name">联系人</view>
                  |
                  <view class="title-numberId">一起一起ID</view>
                </view>
                <view class="title-item flex-0">
                  <view class="title-name">联系人</view>
                  |
                  <view class="title-numberId">一起一起ID</view>
                </view>
              </view>
              <scroll-view scroll-y class="scroll">
                <view class="content-box flex-1">
                  <view class="content-box-item flex-0" v-for="(item, index) in kefuList" :key="index" :style="item.style ? item.style : ''">
                    <view class="item-name" :style="item.style ? item.style : ''">{{ item.name }}</view>
                    <view
                      class="item-number"
                      @click="
                        $u.throttle(() => {
                          copy(item.id)
                        }, 100)
                      "
                      :style="item.style ? item.style : ''"
                    >
                      <text class="item-text">{{ item.id }}</text>
                    </view>
                  </view>
                </view>
              </scroll-view>
            </block>
          </view>
        </view>
      </view>
    </view>
    <view class="toast" v-show="toastShow">ID已复制</view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      kefuList: [
        { name: '汤汤', id: '331050276', style: 'background:#FFFCF4;' },
        { name: '青木', id: '314205845', style: 'background:#FFFCF4;' },

        { name: '徐南瓜', id: '810174242' },
        { name: '杨杨', id: '110407798' },

        { name: '王富贵', id: '954015164', style: 'background:#FFFCF4;' },
        { name: '宋欣欣', id: '376767153', style: 'background:#FFFCF4;' },

        { name: 'ZjLu', id: '618253198' },
        { name: '晴天', id: '948006023' },

        { name: 'Jessie', id: '584552067', style: 'background:#FFFCF4;' },
        { name: '雪月', id: '200191942', style: 'background:#FFFCF4;' },

        { name: '小圆', id: '880493594' },
        { name: '火神', id: '616766303' },

        { name: 'coco', id: '995982858', style: 'background:#FFFCF4;border-bottom:none' },
        { name: '一一', id: '408983399', style: 'background:#FFFCF4;border-bottom:none' }
      ],
      imageList: ['http://img.yiqitogether.com/yqyq-app/images/darkhorse_zuotu.png', 'http://img.yiqitogether.com/yqyq-app/images/darkhorse_youtu.png'],
      toastShow: false
    }
  },
  methods: {
    // 预览图片
    previewImage(urls, current) {
      let list = []
      if (this.imageList.length === 1) {
        list = this.imageList[0]
      } else {
        list = urls
      }
      current = current || 0
      uni.previewImage({
        urls: list,
        current
      })
    },
    /**
     * 复制
     */
    copy(data) {
      let that = this
      uni.setClipboardData({
        data: data,
        showToast: false,
        success: function () {
          that.toastShow = true
          setTimeout(() => {
            that.toastShow = false
          }, 1000)
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.darkhorseAgency-page {
  .video-box {
    position: relative;
    .hourse-video {
      width: 100vw;
      height: 996rpx;
      position: absolute;
      // left: -2rpx;
      object-fit: contain;
    }
    .video-top {
      width: 100vw;
      height: 338rpx;
      display: block;
      position: absolute;
      z-index: 2;
    }
  }
  .page-content {
    position: absolute;
    margin-top: 900rpx;
    z-index: 2;

    .content-img {
      display: block;
      width: 100vw;
      height: 2424rpx;
    }
    .content {
      position: absolute;
      bottom: 128rpx;
      .box-top {
        margin: 0 84rpx;
        width: 584rpx;

        .top-img {
          width: 286rpx;
          height: 390rpx;
        }
      }
      .body-content {
        // position: absolute;
        // bottom: 166rpx;
        margin: 148rpx auto 0;
        width: 614rpx;

        .content-title {
          overflow: hidden;
          width: 632rpx;
          height: 578rpx;
          margin: auto;
          border-radius: 24rpx;
          .title-box {
            // border-radius: 16rpx 0rpx 0rpx 16rpx;
            font-weight: bold;
            color: #3b3b3b;
            font-size: 28rpx;
            text-align: center;
            line-height: 40rpx;
            .title-item {
              background: linear-gradient(50deg, #f2e6b3 20%, #ffa971 100%);
              width: 304rpx;
              height: 76rpx;
              border-radius: 16rpx 16rpx 0rpx 0rpx;

              .title-name {
                width: 120rpx;
                flex-shrink: 0;
              }
              .title-numberId {
                width: 190rpx;
                flex-shrink: 0;
              }
            }
          }
          .content-box {
            flex-wrap: wrap;
            .content-box-item {
              height: 70rpx;
              font-size: 26rpx;
              text-align: center;
              color: #3b3b3b;
              width: 304rpx;
              border-bottom: 2rpx dashed #979797;

              .item-name {
                width: 120rpx;
                height: 70rpx;
                line-height: 70rpx;
                text-align: center;
                flex-shrink: 0;
                border-right: 2rpx dashed #979797;
              }
              .item-number {
                flex: 1;
                width: 190rpx;
                text-align: center;
                flex-shrink: 0;
                color: #fe5e10;

                // .item-text {
                //   border-bottom: 1rpx solid #007aff;
                // }
              }
            }
            .scroll {
              height: 580rpx;
            }
          }
        }
      }
    }
  }
  .toast {
    position: fixed;
    top: 40%;
    left: 40%;
    font-size: 30rpx;
    width: 150rpx;
    height: 60rpx;
    line-height: 60rpx;
    border-radius: 14rpx;
    text-align: center;
    z-index: 5;
    overflow: hidden;
    color: #ffffff;
    background: #616161;
  }
}
</style>
