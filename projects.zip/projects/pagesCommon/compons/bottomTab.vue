<template>
  <view :class="isApp ? 'bottom-tab' : 'bottom-tab istab'">
    <view :class="item.center == true ? 'bottom-tab-item-center' : 'bottom-tab-item-sider'" @click="changeTap(item)" v-for="(item, index) in tabList" :key="index">
      <image v-if="tabIndex == item.id" class="first-img" :src="item.imgOn"></image>
      <image v-if="tabIndex != item.id" class="first-img" :src="item.imgOff"></image>
      <text :class="tabIndex == item.id ? 'text-position text-on' : 'text-position'">{{ item.name }}</text>
      <text v-if="item.id == 4 && msgNum > 0" class="msg-num">{{ msgNum }}</text>
    </view>
  </view>
</template>

<script>
export default {
  name: 'bottomTab',
  props: {
    tabIndex: {
      //图片的尺寸
      type: Number,
      default: 1,
    },
  },
  data() {
    return {
      curTab: 1,
      tabList: [
        {
          id: 1,
          name: '首页',
          imgOff: 'https://img.yiqitogether.com/static/local/leo/shouye_02@2x.png',
          imgOn: 'https://img.yiqitogether.com/static/local/leo/shouye_01@2x.png',
          url: 'pages/index/index',
        },
        {
          id: 6,
          name: '优选',
          imgOff: 'https://img.yiqitogether.com/static/local/leo/yx-f.png',
          imgOn: 'https://img.yiqitogether.com/static/local/leo/yx-t.png',
          url: 'pages/shop/shop',
        },
        {
          id: 2,
          name: '发现',
          imgOff: 'https://img.yiqitogether.com/static/local/leo/faxian_02@2x.png',
          imgOn: 'https://img.yiqitogether.com/static/local/leo/faxian_02_1@2x.png',
          url: 'pages/find/index',
        },
        // {
        // 	id: 3,
        // 	name: "",
        // 	imgOff: "https://img.yiqitogether.com/static/local/leo/fabuhuodong@2x.png",
        // 	imgOn: "https://img.yiqitogether.com/static/local/leo/fabuhuodong@2x.png",
        // 	"url": "",
        // 	center:true
        // },
        // #ifndef MP-WEIXIN
        {
          id: 4,
          name: '消息',
          imgOff: 'https://img.yiqitogether.com/static/local/leo/xiaoxi_02@2x.png',
          imgOn: 'https://img.yiqitogether.com/static/local/leo/xiaoxi_01@2x.png',
          url: 'pages/message/index',
        },
        // #endif
        {
          id: 5,
          name: '我的',
          imgOff: 'https://img.yiqitogether.com/static/local/leo/wode_02@2x.png',
          imgOn: 'https://img.yiqitogether.com/static/local/leo/wode_01@2x.png',
          url: 'pages/my/index',
        },
      ],
      isApp: true,
      msgNum: 0,
    }
  },
  mounted(e) {
    let that = this
    uni.onNativeEventReceive((event, data) => {
      // let msgsss = '接收到宿主event：' + event +'接收到宿主data：' +  data;
      // uni.showToast({
      //   title: msgsss,
      //   icon: "none",
      //   duration: 2000,
      // })
      if (event == 'androidSwitchTab' && this.tabIndex != data + 1) {
        that.changeTap(that.tabList[data])
      }
      if (event == 'unReadMsgCount') {
        that.msgNum = data
        uni.setStorage({
          key: 'msgNum',
          data: that.msgNum, //
        })
      }
    })
    if (that.msgNum == 0 && uni.getStorageSync('msgNum')) {
      that.msgNum = uni.getStorageSync('msgNum')
    }
  },
  created() {
    // console.log('currentRoute',this.tabIndex)
    // let pages = getCurrentPages() // 获取栈实例
    // let currentRoute = pages[pages.length - 1].route; // 获取当前页面路由
    // console.log(currentRoute)
    // this.tabList.forEach((item) =>{
    // 	if(currentRoute == item.url){
    // 		this.curTab = item.url
    // 	}
    // })
    // #ifdef H5
    // this.isApp = false
    // this.tabList=[{
    // 			id: 1,
    // 			name: "首页",
    // 			imgOff: "../../static/images/leo/shouye_02@2x.png",
    // 			imgOn: "../../static/images/leo/shouye_01@2x.png",
    // 			"url": "pages/index/index"
    // 		},
    // 		{
    // 			id: 2,
    // 			name: "发现",
    // 			imgOff: "../../static/images/leo/faxian_02@2x.png",
    // 			imgOn: "../../static/images/leo/faxian_02_1@2x.png",
    // 			"url": "pages/find/index"
    // 		}]
    // #endif
  },
  methods: {
    changeTap(e) {
      console.log(e.id)
      if (e.id == 3) {
        this.$emit('TabItemTap', e.id)
        return
      }
      if (e.id == 4) {
        // #ifdef  APP-PLUS
        // uni.sendNativeEvent('goMessage', {
        // 	msg: 'go message page!'
        // }, ret => {
        // })
        let testModule = uni.requireNativePlugin('TestModule')
        testModule.goAndroidMsg({}, (ret) => {})
        // #endif
        return
      }
      if (this.tabIndex != e.id) {
        // this.tabIndex = e.url
        // var pages = getCurrentPages() // 获取栈实例
        // let currentRoute = pages[pages.length - 1].route; // 获取当前页面路由
        // console.log("路由当前页面路径"+currentRoute)
        uni.reLaunch({
          url: '/' + e.url,
        })
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.bottom-tab {
  position: fixed;
  background: url('https://img.yiqitogether.com/static/local/leo/daohang_bg@2x.png') no-repeat;
  background-size: 100% 100%;
  bottom: 0%;
  left: 0%;
  width: 100%;
  height: 140rpx;
  z-index: 99999;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  .bottom-tab-item-center {
    width: 20%;
    height: 110rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;
    .first-img {
      width: 82rpx;
      height: 82rpx;
      // margin-top: -0.8rem;
      border-radius: 50%;
      margin-bottom: 6rpx;
    }
    // .text-position{
    // 	margin-top: 0rem;
    // 	font-size: 0.6rem;
    // 	color: #AAAAAA;
    // }
    // .text-on{
    // 	color: #FF466D;
    // }
  }
  .bottom-tab-item-sider {
    width: 20%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 110rpx;
    position: relative;
    .first-img {
      width: 52rpx;
      height: 52rpx;
      margin-bottom: 6rpx;
    }
    .text-position {
      margin-top: 0rem;
      font-size: 24rpx;
      color: #aaaaaa;
    }
    .text-on {
      color: #ff466d;
    }
  }
}
.istab {
  justify-content: space-around;
}
.msg-num {
  width: 28rpx;
  height: 28rpx;
  background: #ff466d;
  border: 2rpx solid #ffffff;
  font-size: 20rpx;
  font-weight: 400;
  text-align: center;
  color: #ffffff;
  line-height: 28rpx;
  border-radius: 50%;
  position: absolute;
  top: 8rpx;
  right: 24%;
}
</style>
