<template>
  <view class="pubPupBox" ref="popBox" :class="PopStatus ? 'popupShow' : ''">
    <view class="pupcenter">
      <view class="textbox">温馨提示</view>
      <view class="textbox">该操作需要在APP内进行</view>
      <view class="textbox">下载参与更多互动</view>
      <view class="btnsBox">
        <view class="centers" @click="closed">取消</view>
        <view class="commitBtn" @click="opendonwload">前往下载</view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  name: 'publicPup',
  props: {
    PopStatus: false
  },
  data() {
    return {
      // pubPopStatus:false
    }
  },
  mounted(e) {},
  created() {},
  methods: {
    handleTouchMove(e) {
      // 阻止弹窗外的触碰事件
      e.stopPropagation()
    },
    closed() {
      this.$emit('change', false)
    },
    opendonwload() {
      uni.navigateTo({
        url: '/pagesMy/my/download'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.popupShow {
  overflow: hidden;
  position: fixed !important;
}

.pubPupBox {
  background-color: rgba(0, 0, 0, 0.5);
  position: absolute;
  z-index: 99999;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  width: 100%;
  height: 100vh;
}
.pupcenter {
  position: fixed;
  z-index: 100001;
  width: 255rpx * 2;
  height: 174rpx * 2;
  background-color: #f6f7f8;
  border-radius: 15rpx * 2;
  overflow: hidden;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  margin: auto;
}
.textbox {
  width: 100%;
  line-height: 30rpx * 2;
  color: #333333;
  font-size: 12rpx * 2;
  text-align: center;
}
.textbox:first-child {
  margin-top: 20rpx * 2;
  font-weight: bold;
}
.btnsBox {
  overflow: hidden;
  margin-top: 20rpx * 2;
}
.centers,
.commitBtn {
  width: 95rpx * 2;
  height: 36rpx * 2;
  border-radius: 20rpx * 2;
  overflow: hidden;
  text-align: center;
  float: left;
  line-height: 36rpx * 2;
  margin-left: 20rpx * 2;
}
.centers {
  background-color: #fff;
  color: #ff466d;
}
.commitBtn {
  background-color: #ff466d;
  color: #fff;
}
</style>
