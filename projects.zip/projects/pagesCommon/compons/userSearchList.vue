<template>
  <view class="user-crad flex1">
    <view class="user-box" v-if="userList.length !== 0">
      <view class="user-item flex1" v-for="(item, i) in userList" :key="i" @click="toPersonalPage(item)">
        <view class="user-l flex1">
          <view class="user-avatar">
            <image class="avatar" :src="item.headUrl" mode="aspectFill"></image>
            <image class="sex" :src="item.sex === '男' ? 'https://img.yiqitogether.com/static/local/index/nan_s@2x.png' : 'https://img.yiqitogether.com/static/local/index/nv_s@2x.png'" mode=""></image>
          </view>
          <view class="user-l-r">
            <view class="user-name">
              {{ item.nickName }}
            </view>
            <view class="user-l-r-m flex1">
              <!-- <view class="top-evaluate">
                <image class="top-evaluate-image" src="https://img.yiqitogether.com/static/local/index/hd_pf@2x.png" mode=""></image>
                <text>{{ item.score !== 'null' ? Number(item.score).toFixed(1) : '0.0' }}分</text>
              </view> -->
              <view class="scores_box">
                {{ item.score !== 'null' ? Number(item.score).toFixed(1) : '0.0' }}
                <text class="score">分</text>
              </view>
              <view class="user-id">ID {{ item.numberId }}</view>
            </view>
            <view class="user-l-r-b">{{ item.twitterCount }}活动 · {{ item.fansCount }}粉丝 · {{ item.atentionCount }}关注</view>
          </view>
        </view>
        <view class="common-follow-btn-active" :class="item.isAtention ? 'user-r-gray' : ''" v-if="userId != item.numberId" @click.stop="attentionButton(item, i)">{{ item.isAtention ? '已关注' : '关注' }}</view>
      </view>
      <slot></slot>
    </view>

    <view v-if="!userList.length && !showLoading" class="normalActivity-empty">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
      <view class="empty-text">暂无内容</view>
    </view>

    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
// 导入接口
import MyInfo from '@/model/my.js'
import { load } from '@/utils/store.js'
import { LOGIN_USERID } from '@/utils/cacheKey.js'
export default {
  props: {
    userList: {
      default() {
        return []
      },
      type: Array
    },
    showLoading: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      userId: load(LOGIN_USERID)
    }
  },
  methods: {
    // 跳转个人主页
    toPersonalPage(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item.numberId
      })
    },
    // 关注/取消关注
    attentionButton(item, i) {
      // console.log(this.copyUserList[i],);
      // return
      let datas = {
        targetNumberId: item.numberId
      }
      if (item.isAtention) {
        //取消关注
        MyInfo.cancelFansAttention(datas).then(res => {
          if (res.code == 'SUCCESS') {
            let data = {
              status: false,
              index: i
            }
            this.$emit('atentionChange', data)
            setTimeout(() => {
              this.showToast1('取消关注')
            }, 100)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        //关注
        MyInfo.fansAttention(datas).then(res => {
          if (res.code == 'SUCCESS') {
            let data = {
              status: true,
              index: i
            }
            this.$emit('atentionChange', data)
            setTimeout(() => {
              this.showToast1('关注成功')
            }, 100)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 提示弹窗
    showToast1(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.user-crad {
  width: 100%;
  flex-direction: column;
}

.flex1 {
  display: flex;
  align-items: center;
}

.user-box {
  width: 95%;

  margin: 0 auto 20rpx;

  padding: 10rpx 0;
}

.user-item {
  width: 100%;
  height: 170rpx;
  padding: 0 24rpx 0 20rpx;
  box-sizing: border-box;
  justify-content: space-between;
  margin-bottom: 16rpx;
  background-color: #fff;
  border-radius: 24rpx;
}

.user-l {
  align-items: flex-start;
}

.user-avatar {
  position: relative;
}

.avatar {
  width: 90rpx;
  height: 90rpx;
  background: #d8d8d8;
  border-radius: 50%;
}

.sex {
  position: absolute;
  top: 66rpx;
  left: 66rpx;
  width: 24rpx;
  height: 24rpx;
  border-radius: 50%;
}

.user-l-r {
  margin-left: 20rpx;
}

.user-name {
  font-size: 26rpx;
  font-family: OPPOSans-Medium;
  font-weight: 500;
  color: #2d3f49;
}

.user-l-r-m {
  margin-top: 8rpx;
}
.scores_box {
  width: 48rpx;
  height: 24rpx;
  margin-right: 8rpx;
  background: #fff2f4;
  border-radius: 12rpx;
  font-size: 16rpx;
  font-family: PingFang SC, PingFang SC-Regular;
  font-weight: Regular;
  color: #ff603d;
  display: flex;
  align-items: center;
  justify-content: center;
}
.score {
  font-size: 13rpx;
}
.user-id {
  font-size: 22rpx;
  font-family: OPPOSans, OPPOSans-Regular;
  color: #3e4144;
  line-height: 38rpx;
  margin-left: 14rpx;
}

.user-l-r-b {
  font-size: 22rpx;
  font-family: OPPOSans, OPPOSans-Regular;
  color: #3e4144;
  margin-top: 8rpx;
}

.user-r {
  width: 106rpx;
  height: 48rpx;
  border: 2rpx solid #f4f6f8;
  border-radius: 26rpx;
  line-height: 48rpx;
  text-align: center;
  font-size: 24rpx;
  font-family: OPPOSans, OPPOSans-Medium;
  color: #fe5e10;
  box-sizing: border-box;
}

.user-r-gray {
  border: 2rpx solid #f4f6f8;
  color: #838e9a;
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
