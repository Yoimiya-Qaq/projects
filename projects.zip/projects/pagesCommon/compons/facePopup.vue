<!-- 人脸识别弹窗 -->
<template>
  <view class="">
    <u-popup :initiateActivity="false" :show="show" mode="center" round="20">
      <view class="refund-pop">
        <image class="img" src="http://img.yiqitogether.com/static/images/detailsImg/renlian.png" mode="heightFix"></image>
        <view class="text1">账户认证</view>
        <view class="text2">该操作需要进行账户认证噢~</view>
        <view class="btn" @click="goAuth">去认证</view>
        <u-icon class="close-icon" name="close" color="#adb3ba" size="26" @click="close"></u-icon>
      </view>
    </u-popup>
  </view>
</template>

<script>
export default {
  name: 'facePopup',
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {}
  },
  methods: {
    close() {
      this.$emit('close', false)
    },
    // 去认证
    goAuth() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif

      uni.navigateTo({
        url: '/pagesCommon/authentication/faceAuthentication?status=NO_AUDIT',
        success: () => {
          this.close()
        }
      })
    }
    // nextFaceAuth() {
    //   let testModule = uni.requireNativePlugin('TestModule')
    //   testModule.goAndroidFaceRealNameAuth(
    //     {
    //       name: 'unimp',
    //       age: 1
    //     },
    //     ret => {}
    //   )
    //   setTimeout(() => {
    //     this.$emit('close', false)
    //   }, 500)
    // }
  }
}
</script>

<style lang="scss" scoped>
.refund-pop {
  position: relative;
  width: 610rpx;
  height: 480rpx;
  background: #ffffff;
  border-radius: 24rpx;
  box-shadow: 14rpx 18rpx 14rpx 0rpx rgba(255, 255, 255, 0.5) inset;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.img {
  height: 150rpx;
  margin-top: 40rpx;
}

.close-icon {
  position: absolute;
  top: 28rpx;
  right: 28rpx;
}

.text1 {
  font-size: 32rpx;
  font-weight: 400;
  color: #333333;
  margin-top: 20rpx;
}

.text2 {
  font-size: 28rpx;
  font-weight: 500;
  color: #333333;
  margin-top: 24rpx;
}

.btn {
  width: 430rpx;
  height: 72rpx;
  background: #fe5e10;
  border-radius: 40rpx;
  line-height: 72rpx;
  text-align: center;
  font-size: 24rpx;
  color: #fff;
  margin-top: 30rpx;
}
</style>
