<template>
	<view class="activity-card">
		<view class="activity-info" v-for="(item, index) in activityList" :key="index">
			<view class="" @click="godetails(item.appointmentNo)">
				<!-- <view class="activity-info-id">
					ID:{{item.appointmentNo}}
				</view> -->
				<view class="activity-info-top">
					<view class="activity-info-top-touxiang" @click.stop="goMyHome(item)">
						<image class="touxiang-image" :src="item.userLogo" mode=""></image>
						<image class="xingbie-image"
							:src="item.sex === '男' ? 'https://img.yiqitogether.com/static/local/index/nan_s@2x.png' : 'https://img.yiqitogether.com/static/local/index/nv_s@2x.png'"
							mode=""></image>
					</view>
					<view class="activity-info-top-right">
						<view class="">
							<view class="top-title">{{ item.userName }}</view>
							<view class="top-evaluate">
								<image class="top-evaluate-image"
									src="https://img.yiqitogether.com/static/local/index/hd_pf@2x.png" mode=""></image>
									<text>{{item.score!== 'null' ? Number(item.score).toFixed(1) : '0.0'}}分</text>
							</view>
						</view>
						<!-- <view class="top-tips" v-if="item.address">{{item.createDate}} · {{item.address.area}} <text
								v-if="item.distance">距您</text>{{item.distance | capitalize}}</view> -->
						<!-- 标签 -->
						<view class="lable-box" style="background: linear-gradient(90deg, #f3f6f9, #f7f8f9);"
							v-show="item.appointmentStateStr == '已完成'">
							<text style="color: #838E9A;">已完成</text>
						</view>
						<view class="lable-box" style="background: #FFF6F0"
							v-show="item.appointmentStateStr == '待开始'">
							<text style="color: #FF811E;">待开始</text>
						</view>
						<view class="lable-box" style="background: linear-gradient(90deg,#fff5f5, #fff7f7);"
							v-show="item.appointmentStateStr == '已开始'">
							<text style="color: #FF466D;">已开始</text>
						</view>
						<view class="lable-box" style="background: linear-gradient(90deg,#f3f6f9, #f7f8f9);"
							v-show="item.appointmentStateStr == '已取消'">
							<text style="color: #B4BABF;">已取消</text>
						</view>
						<view class="lable-box" style="background: linear-gradient(90deg,#fff5f5, #fff7f7);;"
							v-show="item.appointmentStateStr == '进行中'">
							<text style="color: #FF466D;">进行中</text>
						</view>
					</view>
				</view>
				<view class="activity-info-title">
					<view class="title-type"
						:style="{ 'background-color': item.bcolor }">{{ item.appointmentType }}</view>
						<view class="activity-info-text">{{ item.name }}</view> 			
				</view>
				<!-- <view class="activity-info-tips">{{item.description}}</view> -->
				<view class="activity-info-bottom">
					<view class="activity-info-bottom-left">
						<view class="left-info">
							<image class="left-info-image"
								src="https://img.yiqitogether.com/static/local/index/kapian_zhuangtai2@2x.png" mode="">
							</image>
							<text class="left-info-content">{{ item.appointDate }}</text>
						</view>
						<view class="left-info">
							<image class="left-info-image"
								src="https://img.yiqitogether.com/static/local/index/kapian_didian2@2x.png" mode="">
							</image>
							<text class="left-info-content" v-if="item.place">{{ item.place }}</text><text
								class="left-info-content"
								v-if="!item.place && item.address">{{ item.address.detail }}</text>
						</view>
						<!-- 单图 或 双图 -->
						<view class="activity-info-bottom-right1" v-if="item.pic.length == 1">
							<!-- <image class="right-image" v-for="(data, indexs) in item.pic" :key="indexs" :src="data" mode="aspectFill">
							</image> -->
							<zero-lazy-load class="right-image" v-for="(item, index) in item.pic" borderRadius="30" :key="index" :image="item" :height="330"></zero-lazy-load>
						</view>
						<!-- 3张图 -->
						<view class="activity-info-bottom-right3" v-else-if="item.pic.length == 3">
							<image class="right-image" v-for="(data, indexs) in item.pic" :key="indexs" :src="data" mode="aspectFill">
							</image>
						</view>
						<!-- 3张图以上 -->
						<view class="activity-info-bottom-right2" v-else-if="item.pic.length == 2 || item.pic.length > 3">
							<!-- <image class="right-image" v-for="(data, indexs) in item.pic"
							:key="indexs"	:src="data" mode="aspectFill"></image> -->
							<zero-lazy-load class="right-image" v-for="(item, index) in item.pic" borderRadius="30" :key="index" :image="item" :height="210"></zero-lazy-load>
						</view>
						<view class="left-info">
							<!-- <text
								:class="item.appointmentState.label == 'ING' ? 'left-info-tips' : item.appointmentState.label == 'CANCEL' ? 'left-info-tips1' : 'left-info-tips2'">{{ item.currentCount }}
							</text> -->
							<text class="left-info-tips">{{ item.currentCount }}
							</text>
							<text class="left-info-content"> /{{ item.appointmentCount }}人已加入</text>
						</view>
						<view class="left-info">
							<text class="right-tips">{{ item.feeType.text }}</text> · <view class="right-tips">
								{{ item.collectCount }}人感兴趣
							</view>
						</view>
					</view>

					<!-- <view class="left-info">
						<image class="left-info-image"
							src="https://img.yiqitogether.com/static/local/index/kapian_zhuangtai@2x.png" mode="">
						</image>
						状态：<text
							:class="item.appointmentState.label == 'ING'?'left-info-tips':(item.appointmentState.label == 'CANCEL'?'left-info-tips1':'left-info-tips2')">{{item.appointmentState.text}}
						</text> <text
							:class="item.appointmentState.label == 'CANCEL'?'left-info-tips1':'left-info-content'">
							（{{item.currentCount}}/{{item.appointmentCount}})</text>
					</view> -->
				</view>
			</view>
			<!-- 前往评论 -->
			<view class="comment" v-if="commentStatus">
				<view v-if="item.feeType.text == '预付定金'" class="comment-btn" @click="viewOrder(item.systemNo)">
					查看订单
				</view>
				<view v-if="item.appointmentStateStr == '已完成'" class="comment-btn" @click="nextPage(item)">
					前往评价
				</view>
			</view>
		</view>
		<image v-if="activityList.length == 0" class="qs-image"
			src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png"></image>
			<!-- <view v-if="activityList.length == 0" class="activity-info default-diagram" v-for="(item,i) in 3" :key="i">
				<image src="/static/images/gj-min.png" mode="widthFix"></image>
			</view> -->
	</view>
</template>

<script>
	export default {
		components: {},
		props: {
			activityList: {
				default: [],
				type: Array
			},
			commentStatus: {
				default: false,
				type: Boolean
			}
		},
		data() {
			return {}
		},
		watch: {},
		filters: {
			capitalize: function(value) {
				if (value) {
					if (value >= 1000) {
						value = (value / 1000).toFixed(2) + 'km'
					} else {
						value = value.toFixed(2) + 'm'
					}
				}
				return value
			},
		},
		computed: {},
		onLoad(e) {},
		mounted() {},
		onShow() {},
		methods: {
 			nextPage(item) {
				uni.navigateTo({
					url: '/pagesMy/my/activityEvaluate?activityId=' + item.appointmentNo+'&beNumberId=' + item.userId+'&score=' + item.score,
				})
			},
			viewOrder(systemNo) {
				uni.navigateTo({
					url:'/pagesMy/my/myOrder/orderDetail?systemNo=' + systemNo
				})
			},
			godetails(item) {
				uni.navigateTo({
					url: '/pagesCommon/details/details?appointmentNo=' + item,
				})
			},
			goMyHome(item) {
				// #ifdef  APP-PLUS
				uni.navigateTo({
					url: '/pagesMy/my/myHomePages/index?userId=' + item.userId,
				})
				// #endif
			},
		},
	}
</script>
<style lang="scss" scoped>
	.activity-info-text {
		line-height: 56rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		-webkit-line-clamp: 1;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		word-wrap: break-word;
		// font-weight: 500;
		font-family: OPPOSans-Bold;
	}
	
	.default-diagram {
		padding: 0!important;
		image {
			width: 100%;
		}
	}
	
	.activity-card {
		width: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		background-color: #f7f8f8;
		padding-top: 20rpx;

		.activity-info {
			width: 708rpx;
			padding: 30rpx 20rpx;
			background-color: #fff;
			border-radius: 24rpx;
			box-sizing: border-box;
			margin-bottom: 20rpx;
			position: relative;

			.activity-info-id {
				height: 40rpx;
				padding: 0 20rpx 0 16rpx;
				border-radius: 20rpx 0px 0px 20rpx;
				line-height: 40rpx;
				font-size: 24rpx;
				font-weight: 400;
				text-align: center;
				color: #adb3ba;
				background: #f6f7f8;
				position: absolute;
				right: 0;
				top: 24rpx;
			}

			.activity-info-top {
				width: 100%;
				display: flex;
				align-items: center;

				.activity-info-top-touxiang {
					width: 90rpx;
					height: 90rpx;
					position: relative;
					flex-shrink: 0;

					.touxiang-image {
						width: 100%;
						height: 100%;
						border-radius: 50%;
					}

					.xingbie-image {
						width: 24rpx;
						height: 24rpx;
						position: absolute;
						right: 0;
						bottom: 0;
					}
				}

				.activity-info-top-right {
					flex-grow: 1;
					margin-left: 20rpx;
					display: flex;
					align-items: center;
					justify-content: space-between;

					.top-title {
						font-size: 28rpx;
						font-weight: 500;
						text-align: left;
						color: #2d3f49;
					}

					.top-tips {
						font-size: 24rpx;
						font-weight: 500;
						text-align: left;
						color: #adb3ba;
					}
				}
			}

			.activity-info-title {
				width: 100%;
				// height: 56rpx;
				// line-height: 56rpx;
				margin: 24rpx 0 12rpx;
				font-size: 32rpx;
				// font-family: OPPOSans, OPPOSans-Bold;
				color: #333333;
				display: flex;
				align-items: center;
				

				.title-type {
					min-width: 60rpx;
					height: 36rpx;
					display: inline-block;
					background: #977aff;
					border-radius: 3px;
					font-size: 24rpx;
					font-weight: 500;
					text-align: center;
					line-height: 36rpx;
					color: #fff;
					padding: 0 10rpx;
					margin-right: 10rpx;
				}
			}

			.activity-info-tips {
				width: 100%;
				margin-bottom: 24rpx;
				font-size: 24rpx;
				font-weight: 400;
				text-align: left;
				color: #333333;
				display: flex;
				align-items: center;
				overflow: hidden;
				text-overflow: ellipsis;
				-webkit-line-clamp: 1;
				display: -webkit-box;
				-webkit-box-orient: vertical;
			}

			.activity-info-bottom {
				width: 100%;

				// display: flex;
				.activity-info-bottom-left {
					// flex-grow: 1;
					padding-top: 16rpx;

					.left-info {
						width: 100%;
						margin: 0 0 20rpx;
						font-size: 28rpx;
						font-weight: 400;
						text-align: left;
						display: flex;
						align-items: center;
						color: #adb3ba;
						overflow: hidden;
						text-overflow: ellipsis;
						-webkit-line-clamp: 1;
						// display: -webkit-box;
						-webkit-box-orient: vertical;

						.left-info-image {
							width: 32rpx;
							height: 32rpx;
							margin-right: 12rpx;
							vertical-align: middle;
						}

						.left-info-content {
							// font-weight: 400;
							text-align: left;
							color: #333333;
						}

						.left-info-tips {
							// font-weight: 400;
							font-size: 40rpx;
							text-align: left;
							color: #ff466d;
						}

						.left-info-tips1 {
							font-weight: 400;
							text-align: left;
							color: #adb3ba;
						}

						.left-info-tips2 {
							font-weight: 400;
							text-align: left;
							color: #333333;
						}

						.right-tips {
							display: inline-block;
							font-size: 24rpx;
							font-weight: 400;
							color: #adb3ba;
							// margin-left: 12rpx;
						}
					}
				}

				.activity-info-bottom-right1 {
					display: flex;
					margin: 0 0 20rpx;

					.right-image {
						width: 330rpx;
						height: 330rpx;
						margin-right: 10rpx;
						border-radius: 16rpx;
					}
				}

				.activity-info-bottom-right2 {
					width: 100%;
					overflow-x: auto;
					margin: 0 0 20rpx;
					display: flex;
					align-items: center;

					.right-image {
						flex-shrink: 0;
						width: 210rpx;
						height: 220rpx;
						border-radius: 16rpx;
						margin-right: 8rpx;
					}
				}

				.activity-info-bottom-right3 {
					width: 500rpx;
					height: 330rpx;
					margin: 0 0 20rpx;

					// display: flex;
					// align-items: center;
					.right-image {
						// flex-shrink: 0;
						float: left;
						width: 330rpx;
						height: 330rpx;
						border-radius: 16rpx;
						// margin-right: 10rpx;
					}

					.right-image:nth-child(2) {
						// flex-shrink: 0;
						float: right;
						width: 160rpx;
						height: 160rpx;
						border-radius: 16rpx;
						margin-bottom: 12rpx;
					}

					.right-image:nth-child(3) {
						// flex-shrink: 0;
						float: right;
						width: 160rpx;
						height: 160rpx;
						border-radius: 16rpx;
						// margin-right: 10rpx;
					}
				}
			}
		}
	}

	.qs-image {
		width: 310rpx;
		height: 310rpx;
		margin: 80rpx auto 40rpx;
	}

	

	.lable-box {
		width: 132rpx;
		height: 60rpx;
		border-radius: 30rpx 0 0 30rpx;
		line-height: 60rpx;
		text-align: center;
		font-size: 24rpx;
		margin-right: -20rpx;
		// font-family: PingFang SC, PingFang SC-Medium;
		// font-weight: 400;
	}

	.comment {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		border-top: 2rpx solid #f6f7f8;
		padding-top: 20rpx;
		// background-color: #977aff;
	}

	.comment-btn {
		width: 176rpx;
		height: 68rpx;
		border: 2rpx solid #f0f1f3;
		border-radius: 34rpx;
		line-height: 68rpx;
		text-align: center;
		font-size: 28rpx;
		color: #2A343E;
		margin-left: 20rpx;
	}
	
	.top-evaluate {
		width: 115rpx;
		height: 38rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #fff0f0;
		border-radius: 19rpx;
		font-size: 24rpx;
		font-weight: 400;
		color: #333333;
		margin-top: 16rpx;
		white-space: nowrap;
		.top-evaluate-image {
			width: 24rpx;
			height: 24rpx;
			margin-right: 8rpx;
			flex-shrink: 0;
		}
	}
</style>