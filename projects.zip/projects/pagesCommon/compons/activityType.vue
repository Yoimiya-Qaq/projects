<template>
  <view class="activity-type" v-if="isType" @touchmove.stop.prevent="handleTouchMove">
    <view class="activity-type-kong" @click="deleteType()" v-if="authSimple"></view>
    <view class="activity-type-content" v-if="authSimple">
      <image @click="deleteType()" class="activity-type-delete" src="https://img.yiqitogether.com/static/local/compons/bjzl_zybj_delete@2x.png" mode=""></image>
      <view class="type-content-title"><text class="type-content-title-info">你想发起一个什么活动？</text></view>
      <view class="type-content">
        <view class="type-content-info" v-for="(item, index) in activityType" :key="index" @click="selectFun(item)">
          <image class="type-content-info-image" :src="item.url" mode=""></image>
          <view class="type-content-info-name">{{ item.text }}</view>
        </view>
      </view>
    </view>
    <view class="authentication" v-if="!authSimple">
      <image @click="deleteType()" class="activity-type-delete" src="https://img.yiqitogether.com/static/local/compons/bjzl_zybj_delete@2x.png" mode=""></image>
      <image class="authentication-image" src="http://img.yiqitogether.com/static/images/myImgs/icon_shimin.png" mode=""></image>
      <view class="authentication-title">实名认证</view>
      <view class="authentication-tips">为了保障活动出行的安全</view>
      <view class="authentication-tips">需要进行实名认证噢~</view>
      <view class="authentication-button" @click="goRealNameAuthFun()">去认证</view>
    </view>
  </view>
</template>

<script>
import IndexModel from '@/model/index'
export default {
  components: {},
  props: {
    authSimple: {
      default: false,
      type: Boolean
    }
  },
  data() {
    return {
      isType: false,
      activityType: []
    }
  },
  watch: {},
  computed: {},
  onLoad(e) {
    // this.appointmentType()
  },
  mounted() {},
  onShow() {
    // setTimeout(()=>{
    // 	this.appointmentType()
    // },100)
  },
  methods: {
    // 解决弹窗穿透问题
    handleTouchMove(e) {
      e.stopPropagation()
    },
    appointmentType() {
      this.isType = true
      if (this.authSimple) {
        IndexModel.getActivityType().then(dataRes => {
          console.log('活动类型', dataRes)
          if (dataRes.code == 'SUCCESS') {
            this.activityType = dataRes.data.appointmentType
          } else {
            // this.$refs.uToast.show({
            // 	...dataRes
            // })
          }
        })
      } else {
        this.$emit('hiddenTab')
      }
    },
    openType() {
      this.isType = true
    },
    deleteType() {
      this.$emit('close', false)
      this.isType = false
    },
    selectFun(item) {
      // this.$emit('usertype',item);
      uni.navigateTo({
        url: '/pagesInitiateActivity/initiateActivity/initiateActivity?usertypedata=' + item.code + '&activityTypeInfo=' + item.text
      })
      this.deleteType()
    },
    goRealNameAuthFun() {
      this.deleteType()
      // uni.sendNativeEvent('goRealNameAuth', {

      // }, ret => {
      // })
      uni.navigateTo({
        url: '/pagesCommon/authentication/authentication?status=NO_AUDIT'
      })
      // let testModule = uni.requireNativePlugin('TestModule')
      // testModule.goAndroidRealNameAuth(
      //   {
      //     name: 'unimp',
      //     age: 1,
      //   },
      //   (ret) => {}
      // )
    }
  }
}
</script>
<style lang="scss" scoped>
.activity-type {
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  left: 0;
  top: 0;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  align-items: center;
  pointer-events: auto;
  .activity-type-kong {
    flex-grow: 1;
    width: 100%;
  }
  .activity-type-content {
    width: 100%;
    height: 984rpx;
    // padding-bottom: 150rpx;
    flex-shrink: 0;
    position: relative;
    // position: absolute;
    // bottom: 0;
    // left: 0;
    background: url('https://img.yiqitogether.com/static/local/compons/faqi_xuanze@2x.png') no-repeat;
    background-size: 100% 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    .type-content-title {
      width: 100%;
      margin: 72rpx auto 56rpx;
      text-align: center;
      font-size: 32rpx;
      font-weight: 400;
      color: #333333;
      background: bottom center url('https://img.yiqitogether.com/static/local/compons/title@2x.png') no-repeat;
      background-size: 342rpx 16rpx;
      flex-shrink: 0;
      .type-content-title-info {
        display: inline-block;
        padding: 0 0 8rpx 16rpx;
      }
    }
    .type-content {
      width: 720rpx;
      flex-grow: 1;
      overflow-y: auto;
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      margin: 0 auto;
      .type-content-info {
        width: 30%;
        text-align: center;
        margin-bottom: 46rpx;
        .type-content-info-image {
          width: 102rpx;
          height: 100rpx;
          margin: 0 auto 12rpx;
        }
        .type-content-info-name {
          font-size: 24rpx;
          font-weight: 500;
          text-align: center;
          color: #333333;
        }
      }
    }
    .activity-type-delete {
      width: 28rpx;
      height: 28rpx;
      position: absolute;
      right: 30rpx;
      top: 24rpx;
    }
  }
  .authentication {
    width: 610rpx;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 24rpx;
    box-shadow: 7px 9px 7px 0px rgba(255, 255, 255, 0.5) inset;
    padding: 40rpx 0;
    position: absolute;
    top: 400rpx;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    .activity-type-delete {
      width: 16rpx;
      height: 16rpx;
      position: absolute;
      right: 30rpx;
      top: 24rpx;
    }
    .authentication-image {
      width: 150rpx;
      height: 150rpx;
      margin-bottom: 20rpx;
    }
    .authentication-title {
      font-size: 28rpx;
      font-weight: 400;
      text-align: center;
      color: #333333;
      margin-bottom: 20rpx;
    }
    .authentication-tips {
      font-size: 24rpx;
      font-weight: 500;
      text-align: center;
      color: #333333;
      line-height: 46rpx;
    }
    .authentication-button {
      width: 430rpx;
      height: 72rpx;
      background: #fe5e10;
      border-radius: 36rpx;
      font-size: 24rpx;
      font-weight: 400;
      text-align: center;
      color: #ffffff;
      line-height: 72rpx;
      margin: 40rpx auto 10rpx;
    }
  }
}
</style>
