<template>
	<view>
		<view class="result-box">
			<!-- 返回按钮 -->
			<u-icon name="arrow-left" size="44" class="back" @click="backPage"></u-icon>

			<!-- 成功失败图标 -->
			<u-icon v-if="resType == 'SUCCESS'" name="https://img.yiqitogether.com/static/local/zfcg.png" size="90"
				class="pay-icon"></u-icon>
			<u-icon v-else name="https://img.yiqitogether.com/static/local/zfsb.png" size="90"
				class="pay-icon"></u-icon>

			<!-- 文字提示 -->
			<view class="result-text">
				{{ resType == 'SUCCESS' ? '支付成功' : '支付失败' }}
			</view>

			<!-- 功能按钮 -->
			<u-button v-if="resType == 'SUCCESS'" shape="circle" color="#ff466d" type="default" plain text="查看订单" class="btn"
				@click="nextOrderList"></u-button>
			<u-button v-else shape="circle" color="#ff466d" type="primary" text="重新支付" class="btn" @click="backPage"></u-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// true 支付成功   false支付失败。进入页面时需要传递支付状态。
				resType:'',
			}
		},
		onLoad(option) {
			this.resType = option.resType
			this.page = option.page
		},
		methods: {
			nextOrderList() {
				if (this.page == 'orderConfirm') {
					this.nextPage('/pagesMy/my/myOrder/index')
				} else {
					this.nextPage('/pagesShop/shop/shop-order')
				}
			},
			backPage() {
				uni.navigateBack()
			},
			nextPage(url) {
				uni.navigateTo({
					url
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	.result-box {
		width: 750rpx;
		height: 852rpx;
		background-image: url('https://img.yiqitogether.com/static/local/zfcg_bg.png');
		background-size: 100%;
		overflow: hidden;
	}

	.back {
		position: absolute;
		top: 113rpx;
		left: 35rpx;
		z-index: 1;
	}

	.pay-icon {
		width: 90rpx;
		display: block;
		margin: 272rpx auto 40rpx;
	}

	.result-text {
		font-size: 40rpx;
		font-family: Alibaba PuHuiTi, Alibaba PuHuiTi-Medium;
		font-weight: 500;
		text-align: center;
		color: #2a343e;
		margin-bottom: 100rpx;
	}

	.btn {
		width: 566rpx;
		height: 84rpx;
		margin: 0 auto;
	}
</style>