<template>
  <view class="blogger-all" :style="{ overflow: isBlogeer ? 'hidden' : 'auto' }">
    <block>
      <image class="blogger-banner" src="https://img.yiqitogether.com/yyqc/20240628/upload_bo7rjjf9vnypqgkv9rmi7jmvsp4ojcxf.png" alt="" mode="widthFix" />
      <image src="@/static/images/back_black.png" class="h-icon-back" mode="" @click="goBack"></image>
      <view v-if="enrollCheckState == 'PENDING'" class="blogger-btn" @click="toSignUp">报名审核中</view>
      <view v-if="enrollCheckState == 'FAIL'" class="blogger-btn2">审核失败</view>
      <view v-if="enrollCheckState == ''" @click="isBlogeer = true" class="blogger-btn">立即报名</view>
      <view class="blogger-popup" v-if="isBlogeer">
        <view class="popup-content">
          <view class="popup-content-title">您参与优质博主招募计划的主题是？</view>
          <view class="popup-content-input">
            <u--input v-model.trim="bloggerTitle" placeholder="例：出游" border="none" :adjustPosition="false" maxlength="6"></u--input>
            <view class="popup-content-input-num">{{ bloggerTitle.length }}/6</view>
          </view>
          <view class="popup-rule-title">主题说明：</view>
          <view class="popup-rule-content">1. 选择您专注的主题/领域。并以此主题为核心内容，进行每日的打卡发帖，帖子需要贴合您的主题</view>
          <view class="popup-rule-content">2. 主题一旦选择，不允许变更</view>
          <view class="popup-rule-content">3. 平台有权利裁定，将您偏离主题的帖子视为不合格，这可能导致您连续打卡失败</view>
          <view class="popup-btn" @click="enroll()">立即报名</view>
          <view class="popup-tips">
            <image @click="agreementFun()" class="popup-tips-img" :src="isAgreement ? 'http://img.yiqitogether.com/static/images/gx_02.png' : 'http://img.yiqitogether.com/static/images/gx_01.png'" alt="" />
            <view>我已阅读并同意</view>
            <view class="popup-tips-xy" @click="goAgreement()">《一起一起博主合作协议》</view>
          </view>
        </view>
        <image @click="isBlogeer = false" class="popup-close" src="@/static/images/close.png" alt="" />
      </view>
      <u-toast ref="uToast"></u-toast>
    </block>
    <yue-loading :mask="false" loadTxet="正在获取身份..." v-show="!isShow"></yue-loading>
  </view>
</template>

<script>
import blogger from '@/model/blogger'
import { save, load } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'
export default {
  data() {
    return {
      bloggerTitle: '',
      isAgreement: false,
      isBlogeer: false,
      enrollCheckState: '',
      isShow: false
    }
  },
  onLoad(options) {
    // 博主计划
    this.judgeBlogger()
  },
  methods: {
    // 博主计划banner
    judgeBlogger() {
      let userInfo = JSON.parse(load(USER_INFO))
      let isBlogger = userInfo.isBlogger || false
      if (isBlogger) {
        setTimeout(() => {
          uni.redirectTo({
            url: '/pagesCommon/blogger/index'
          })
        }, 500)
      } else {
        this.enrollQuery()
        this.isShow = true
      }
    },
    // 返回
    goBack() {
      uni.navigateBack()
      // uni.redirectTo({ url: '/pagesMy/my/myCertification' })
    },
    goAgreement() {
      // uni.navigateTo({
      //   url: '/pagesCommon/blogger/agreement'
      // })
      let url = 'https://api.yiqitogether.com/bloggerRule.html'
      uni.navigateTo({
        url: '/pagesSetting/setting/webView?url=' + url
      })
    },
    // 博主查询
    async enrollQuery() {
      blogger.enrollQuery().then(res => {
        if (res.code == 'SUCCESS' && res.data) {
          let isBlogger = res.data.enrollDTO?.enrollCheckState.label === 'SUCCESS'
          let userInfo = JSON.parse(load(USER_INFO))
          userInfo.isBlogger = isBlogger
          save(USER_INFO, JSON.stringify(userInfo))

          if (res.data.enrollDTO.enrollCheckState.label == 'PENDING') {
            this.enrollCheckState = res.data.enrollDTO.enrollCheckState.label
          } else if (res.data.enrollDTO.enrollCheckState.label == 'SUCCESS') {
            uni.redirectTo({ url: '/pagesCommon/blogger/index' })
          } else if (res.data.enrollDTO.enrollCheckState.label == 'FAIL') {
            this.enrollCheckState = res.data.enrollDTO.enrollCheckState.label
          }
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    },
    async enroll() {
      let that = this
      if (that.bloggerTitle == '') {
        uni.showToast({
          title: '请先填写主题',
          icon: 'none'
        })
        return
      }
      if (!that.isAgreement) {
        uni.showToast({
          title: '请阅读并勾选一起一起博主合作协议',
          icon: 'none'
        })
        return
      }
      let data = {
        numberId: uni.getStorageSync('numberId'),
        subject: that.bloggerTitle
      }
      let res = await blogger.enroll(data)
      console.log(res, '888')
      if (res.code == 'SUCCESS' && res.data) {
        // if (res.data.enrollCheckState == 'PENDING') {
        //   that.enrollCheckState = res.data.enrollCheckState
        // }
        uni.showToast({
          title: '报名成功',
          icon: 'none'
        })
        this.isBlogeer = false
        that.bloggerTitle = ''
        that.enrollQuery()
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    agreementFun() {
      this.isAgreement = !this.isAgreement
    },
    toSignUp() {
      uni.showToast({
        title: '报名信息审核中',
        icon: 'none'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.blogger-all {
  width: 100%;
  height: 100vh;
  background-color: #dcf5ff;
  overflow-y: auto;
  position: relative;
  .blogger-banner {
    width: 100%;
    height: 3220rpx;
    margin-bottom: 214rpx;
  }
  .h-icon-back {
    width: 44rpx;
    height: 44rpx;
    position: fixed;
    top: 110rpx;
    left: 24rpx;
  }
  .blogger-btn {
    width: 600rpx;
    height: 84rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(270deg, #85f6e7 0%, #6edde7 46%, #62d1ff);
    border-radius: 42rpx;
    color: #fff;
    font-size: 32rpx;
    // margin: 50rpx auto 80rpx;
    position: fixed;
    bottom: 80rpx;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9;
  }
  .blogger-btn2 {
    width: 600rpx;
    height: 84rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ff674d;
    border-radius: 42rpx;
    color: #fff;
    font-size: 32rpx;
    // margin: 50rpx auto 80rpx;
    position: fixed;
    bottom: 80rpx;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9;
  }
  .blogger-popup {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99;
    overflow: hidden;
    .popup-content {
      width: 602rpx;
      height: 855rpx;
      background: url('http://img.yiqitogether.com/static/images/bm_k.png?a=1') no-repeat;
      background-size: 100% 100%;
      margin: 352rpx auto 0;
      padding-top: 1rpx;
      .popup-content-title {
        width: 462rpx;
        margin: 136rpx auto 30rpx;
        font-size: 28rpx;
        color: #2a343e;
        font-weight: Medium;
      }
      .popup-content-input {
        width: 462rpx;
        height: 80rpx;
        background: #f6f6f8;
        display: flex;
        align-items: center;
        padding: 0 20rpx;
        box-sizing: border-box;
        margin: 0 auto;
        border-radius: 16rpx;
        font-size: 24rpx;
        text-align: left;
        color: #cacdd3;
        .popup-content-input-num {
          font-size: 24rpx;
          text-align: right;
          color: #cacdd3;
          margin-left: 20rpx;
        }
      }
      .popup-rule-title {
        width: 462rpx;
        margin: 32rpx auto 0;
        font-size: 24rpx;
        text-align: left;
        color: #484848;
        font-weight: 500;
      }
      .popup-rule-content {
        width: 462rpx;
        margin: 0 auto 0;
        font-size: 24rpx;
        text-align: left;
        color: #97999f;
        line-height: 40rpx;
        font-weight: 400;
      }
      .popup-btn {
        width: 502rpx;
        height: 84rpx;
        margin: 40rpx auto 0;
        border-radius: 42rpx;
        box-shadow: 0px 4px 6px 0px rgba(135, 225, 255, 0.5);
        background: linear-gradient(270deg, #85f6e7 0%, #6edde7 46%, #62d1ff);
        text-align: center;
        font-size: 32rpx;
        color: #ffffff;
        line-height: 84rpx;
      }
      .popup-tips {
        width: 502rpx;
        margin: 30rpx auto 0;
        display: flex;
        align-items: center;
        font-size: 24rpx;
        text-align: left;
        color: #2a343e;
        .popup-tips-img {
          width: 36rpx;
          height: 36rpx;
          margin-right: 10rpx;
        }
        .popup-tips-xy {
          color: #7fe2f4;
        }
      }
    }
    .popup-close {
      width: 70rpx;
      height: 70rpx;
      margin: 30rpx auto 0;
      display: block;
    }
  }
}
</style>
