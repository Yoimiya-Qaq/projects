<template>
  <view class="agreement-all">
    <view :style="{ height: statusBarHeight + 'px', 'z-index': 999 }"></view>
    <view class="header">
      <image src="@/static/images/back_black.png" class="h-icon-back" mode="" @click="goBack"></image>
    </view>
    <view class="agreement-content">
      <view class="agreement-content-title">博主合作协议</view>
      <view class="agreement-content-rule">本协议由以下双方签订：</view>
      <view class="agreement-content-rule">甲方：上海尚潮电子商务有限公司（以下简称“甲方”）</view>
      <view class="agreement-content-rule">乙方：__________________________（以下简称“乙方”）</view>
      <view class="agreement-content-rule">鉴于：</view>
      <view class="agreement-content-rule">1.甲方运营一款名为“一起一起”的应用程序（以下简称“App”），需要优质内容的支持。</view>
      <view class="agreement-content-rule">2.乙方愿意为甲方提供优质内容，并同意遵守本协议的条款。双方在平等、自愿的基础上，经友好协商达成如下协议：</view>
      <view class="agreement-content-rule">一、合作内容</view>
      <view class="agreement-content-rule">1.乙方可自行选择1个领域/主题在“一起一起”App上发布帖子（即笔记）。</view>
      <view class="agreement-content-rule">2.每个账号每天需发布不少于4篇高质量帖子。</view>
      <view class="agreement-content-rule">二、笔记要求</view>
      <view class="agreement-content-rule">1.内容深耕：发布的内容需深入讨论对应领域的话题，主题需保持一致，不得重复。</view>
      <view class="agreement-content-rule">2.形式要求：内容需以图片/视频加文字的形式呈现。</view>
      <view class="agreement-content-rule">3.质量要求：需要独特的见解和分析，能够引发其他用户的深层次思考。</view>
      <view class="agreement-content-rule">4.互动性：内容应能激发读者的兴趣和共鸣，鼓励参与讨论和分享。</view>
      <view class="agreement-content-rule">5.内容长度：每篇文字不少于50字，图片不少于2张。</view>
      <view class="agreement-content-rule">6.帖子保持：帖子一旦发布，一年内不得删除。</view>
      <view class="agreement-content-rule">三、奖励机制</view>
      <view class="agreement-content-rule">1.每个账号完成任务后可获得相应积分。持续完成365天即可获得现金奖励。</view>
      <view class="agreement-content-rule">2.积分规则：发帖日期从第1天开始递增，依次获得1积分、2积分……第365天获得365积分。</view>
      <view class="agreement-content-rule">3.积分兑换：6积分兑换1元。完成365天任务累计66795积分，折合现金奖励11132.5元。</view>
      <view class="agreement-content-rule">四、中断弥补规则</view>
      <view class="agreement-content-rule">1.24小时内补充：若某一天任务未完成，可在24小时内补齐未发笔记数量，积分继续增加。每月最多三次补充机会。</view>
      <view class="agreement-content-rule">2.超过24小时未补：若超过24小时未补齐，之前的积分奖励清零，成为候补博主。审核通过后进入候补池排队。</view>
      <view class="agreement-content-rule">五、候补规则</view>
      <view class="agreement-content-rule">1.奖励池博主数量上限为400个账号，超出部分的账号进入候补池，候补池按照完成笔记任务的积分高低排序。</view>
      <view class="agreement-content-rule">2.若奖励池里的博主笔记任务中断，系统根据候补池里排名情况，按照从高到低的标准进行替换，成为奖励池里博主后保留候补博主积分，在现有积分情况下累计分值。</view>
      <view class="agreement-content-rule">六、知识产权</view>
      <view class="agreement-content-rule">1.乙方在“一起一起”App上发布的所有内容的知识产权归甲方所有。</view>
      <view class="agreement-content-rule">2.乙方保证发布的内容不侵犯任何第三方的知识产权，若因此产生任何法律纠纷，由乙方负责解决并承担相关责任。</view>
      <view class="agreement-content-rule">七、保密条款</view>
      <view class="agreement-content-rule">1.乙方不得向任何第三方透露在合作过程中知悉的甲方的商业秘密及其他保密信息。</view>
      <view class="agreement-content-rule">2.本条款在本协议终止后继续有效。</view>
      <view class="agreement-content-rule">八、协议终止</view>
      <view class="agreement-content-rule">1.双方协商一致可以终止本协议。</view>
      <view class="agreement-content-rule">2.如乙方严重违反本协议条款，甲方有权单方面终止协议，并取消乙方已获得的所有积分。</view>
      <view class="agreement-content-rule">九、争议解决</view>
      <view class="agreement-content-rule">1.本协议在履行过程中如发生争议，双方应友好协商解决。</view>
      <view class="agreement-content-rule">2.若协商不成，任何一方可向甲方所在地有管辖权的法院提起诉讼。</view>
      <view class="agreement-content-rule">十、其他条款</view>
      <view class="agreement-content-rule">1.本协议自乙方在App上勾选同意之日起生效，有效期为一年，期满后如双方无异议自动续期一年。</view>
      <view class="agreement-content-rule">2.本协议以电子文本形式在甲方和乙方之间具有同等法律效力。</view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      statusBarHeight: 0,
      enrollDTO: {},
      taskRecord: [],
      // 笔记列表
      noteList: [],
      // 开始时间
      startTime: '',
      // 上滑显示
      scrollShow: false,
      // 点击更多
      showImageOperate: false,
      ImageBtnList: ['查看活动协议', '退出活动'],
      // 今日帖子数据
      todayRecord: {}
    }
  },
  mounted() {
    //获取手机系统信息
    const info = uni.getSystemInfoSync()
    //设置状态栏高度
    this.statusBarHeight = info.statusBarHeight
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    scrollPage(e) {
      if (e.detail.scrollTop > 20) {
        this.scrollShow = true
      } else {
        this.scrollShow = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.agreement-all {
  width: 100%;
  height: 100vh;
  background-color: #ffffff;
  // overflow-y: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  .blogger-banner {
    width: 100%;
    height: 3220rpx;
    margin-bottom: 214rpx;
  }
  // .h-icon-back{
  // 	width: 44rpx;
  // 	height: 44rpx;
  // 	position: fixed;
  // 	top: 110rpx;
  // 	left: 24rpx;
  // }
  .header {
    display: flex;
    align-items: center;
    padding: 0 24rpx;
    // padding-top: var(--status-bar-height);
    width: 100vw;
    height: 88rpx;
    z-index: 1;
    box-sizing: border-box;
    flex-shrink: 0;
    .h-icon-back {
      width: 44rpx;
      height: 44rpx;
    }
  }
  .agreement-content {
    width: 690rpx;
    margin: 0 auto;
    flex-grow: 1;
    overflow-y: auto;
    padding-bottom: 48rpx;
    .agreement-content-title {
      width: 100%;
      font-size: 32rpx;
      color: #484848;
      text-align: center;
      margin-bottom: 30rpx;
    }
    .agreement-content-rule {
      width: 100%;
      font-size: 24rpx;
      color: #484848;
      text-align: left;
    }
  }
}
</style>
