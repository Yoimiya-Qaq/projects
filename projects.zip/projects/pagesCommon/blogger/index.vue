<template>
  <view class="bloggerPage">
    <view :style="{ height: statusBarHeight + 'px', background: scrollShow ? '#fff' : '', 'z-index': 999 }" v-if="scrollShow"></view>
    <scroll-view scroll-y="true" @scroll="scrollPage" class="scrollHeight">
      <view class="header" :style="{ background: scrollShow ? '#fff' : '' }">
        <view class="navLeft" @click="goBack">
          <image class="leftImage" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="scaleToFill" />
          <view class="title" v-if="scrollShow">365天优质博主计划</view>
        </view>
        <image @click="more()" class="rightImg" src="https://img.yiqitogether.com/yyqc/20231101/upload_jce5f4ltsvxmrpbdi72h8tjg61ld8rko.png" mode="scaleToFill" />
      </view>
      <image class="bgImg" src="https://img.yiqitogether.com/yyqc/20240618/upload_ct0xk6tdmg84lphwypfwcbm7vwhvg5wn.png" mode="widthFix" alt="" />
      <view class="contentInfoBox">
        <view class="contentBox">
          <view class="bjBox">
            <image class="renwuImg" src="https://img.yiqitogether.com/yyqc/20240618/upload_jwcv7hg7jb1kuc3p74f8fenxe63vjlii.png" mode="aspectFill" alt="" />
            <view class="ranking" v-if="enrollDTO.waiting">候选排名 {{ enrollDTO.waitingNumber }}</view>
          </view>
          <view class="middleBox">
            <view class="introduce" v-if="enrollDTO.waiting">
              本次活动报名人数已满，您当前在
              <text style="color: #7fe2f4" @click="clickCandidate">候补博主</text>
              队列中。若已报名用户未完成，您将顺位加入参与活动名额
            </view>
            <view class="introduce" v-if="!enrollDTO.waiting">
              <text v-if="startTime">{{ $u.timeFormat(startTime, 'yyyy年mm月dd日') }}</text>
              前完成可兑换达标奖励，若未达标或断签超过2天积点将清零,并进入
              <text style="color: #7fe2f4" @click="clickCandidate">候补博主</text>
              名单
            </view>

            <view class="timeBox">
              <view class="topTimeBox">
                <!-- <view class="leftBox" v-if="todayRecord.currentCount != 4">今日未完成</view> -->
                <view class="leftBox">连续打卡{{ enrollDTO.singUpDay || 0 }}天</view>
                <view class="rightTime">
                  开始日期
                  <text class="timeInfo" v-if="enrollDTO.startTime">{{ $u.timeFormat(enrollDTO.startTime, 'yyyy年mm月dd日') }}</text>
                </view>
              </view>
              <view class="bottomTimeBox">
                <view class="dateBox" v-for="(item, index) in taskRecordReverse" :key="index" :style="{ background: item.state != 2 ? '#fff' : '' }" @click="clickDatePopup(item)">
                  <view class="leftDateBox">
                    <view class="timeDate">{{ $u.timeFormat(item.taskTimeStamp, 'dd日') }}</view>
                    <view class="timeDate" v-if="item.point">+{{ item.point }}</view>
                  </view>
                  <image
                    class="rightDateImg"
                    :src="
                      item.state == 1
                        ? 'https://img.yiqitogether.com/yyqc/20240619/upload_a7j8uqfxgehz3uohneu5lhtpm4505eym.png'
                        : item.state == 0
                        ? 'https://img.yiqitogether.com/yyqc/20240619/upload_u6kbzd2ntxklrnbe7mkz0s3hyngffhaa.png'
                        : item.state == -1
                        ? 'https://img.yiqitogether.com/yyqc/20240619/upload_5meq72hgjghgg2sozh235spxhcs17502.png'
                        : 'https://img.yiqitogether.com/yyqc/20240619/upload_wduudqpaoeqcn8mvzk0fm1izujr3bwa7.png'
                    "
                    mode="aspectFill"
                    alt=""
                  />
                </view>
              </view>
            </view>
            <view class="dakaBox">
              <view class="dakaTitle" v-if="taskRecord[1] && taskRecord[1].state == 0">昨日打卡</view>
              <view class="dakaTitle" v-else>今日打卡</view>
              <view class="jidian">累计积点 {{ enrollDTO.points }}</view>
            </view>
            <view class="bijiInfo">
              <view class="leftBox">
                <view class="introInfo">
                  发布4篇至少满2图50字的
                  <text style="color: #7fe2f4">{{ enrollDTO.subject }}</text>
                  图文笔记
                </view>
                <view class="finish" v-if="taskRecord[1] && taskRecord[1].state == 0">
                  <text class="finishBox" v-for="item in taskRecord[1].currentCount" :key="item + 50"></text>
                  <text class="unFinishBox" v-for="item in 4 - taskRecord[1].currentCount" :key="item + 100"></text>
                </view>
                <!-- v-else 会报错 -->
                <view class="finish" v-if="(taskRecord[1] && taskRecord[1].state == 1) || (taskRecord[1] && taskRecord[1].state == 2)">
                  <view class="finishInfoBox" v-if="taskRecord[0].currentCount <= 4">
                    <text class="finishBox" v-for="item in taskRecord[0].currentCount" :key="item + 10"></text>
                  </view>
                  <view class="finishInfoBox" v-if="taskRecord[0].currentCount > 4">
                    <view class="finishBox" v-for="item in 4" :key="item + 10"></view>
                  </view>
                  <view class="finishInfoBox" v-if="taskRecord[0].currentCount <= 4">
                    <view class="unFinishBox" v-for="item in 4 - taskRecord[0].currentCount" :key="item + 20"></view>
                  </view>
                </view>
              </view>
              <view class="rightBox" v-if="taskRecord[1] && taskRecord[1].state == 0">+{{ taskRecord[1].point }}积点</view>
              <view class="rightBox" v-if="(taskRecord[1] && taskRecord[1].state == 1 && todayRecord.state != 1) || (taskRecord[1] && taskRecord[1].state == 2 && todayRecord.state != 1)">+{{ todayRecord.point }}积点</view>
              <view class="rightBox" style="background: #e8fcff; border: 0rpx" v-if="todayRecord.state == 1">+{{ todayRecord.point }}积点</view>
            </view>
            <view class="bijiListBox">
              <view class="noteListBox" v-if="taskRecord[1] && taskRecord[1].state == 0 && taskRecord[1].noteList.length > 0">
                <view
                  class="noteItem"
                  v-for="(item, index) in taskRecord[1].noteList"
                  :key="index"
                  @click="
                    $u.throttle(() => {
                      toDetail(item)
                    }, 1000)
                  "
                >
                  <image class="noteImg" :src="item.cover || defaultImg" mode="aspectFill" alt="" />
                  <view class="noteTitle">{{ item.title }}</view>
                </view>
              </view>
              <view class="noteListBox" v-if="(taskRecord[1] && taskRecord[1].state == 1 && taskRecord[0].noteList.length > 0) || (taskRecord[1] && taskRecord[1].state == 2 && taskRecord[0].noteList.length > 0)">
                <view
                  class="noteItem"
                  v-for="(item, index) in taskRecord[0].noteList"
                  :key="index"
                  @click="
                    $u.throttle(() => {
                      toDetail(item)
                    }, 1000)
                  "
                >
                  <image class="noteImg" :src="item.cover || defaultImg" mode="aspectFill" alt="" />
                  <view class="noteTitle">{{ item.title }}</view>
                </view>
                <image v-if="todayRecord.state == 1" class="finishedImg" src="https://img.yiqitogether.com/yyqc/20240620/upload_pn933b4scopgyjujn1azoib2duzcapuz.png" mode="aspectFill" alt="" />
              </view>
              <view class="wuBox" v-if="(taskRecord[1] && taskRecord[1].state == 0 && taskRecord[1].noteList.length == 0) || (taskRecord[1] && taskRecord[1].state == 1 && taskRecord[0].noteList.length == 0) || (taskRecord[1] && taskRecord[1].state == 2 && taskRecord[0].noteList.length == 0)">
                <image class="wuImg" src="https://img.yiqitogether.com/yyqc/20240619/upload_reak2ytunnikvstm8z0zommk9xovofe0.png" mode="aspectFill" alt="" />
                <view class="wuTitle">还未发布笔记噢~</view>
              </view>
            </view>
          </view>
        </view>
        <view class="empty"></view>
      </view>
      <view class="btnBox" v-if="enrollDTO.bottomState && enrollDTO.bottomState.label == 'PUBLISH'" @click="$u.throttle(goRelease, 1000)">前往发布</view>
      <view class="btnBox" v-if="enrollDTO.bottomState && enrollDTO.bottomState.label == 'REWARD_PENDING'">申领审核中</view>
      <view class="submitBtnBox" v-if="enrollDTO.bottomState && enrollDTO.bottomState.label == 'SUBMIT'" @click="$u.throttle(goSubmit, 1000)">提交现金申领</view>
      <view class="submitBtnBox" v-if="enrollDTO.bottomState && enrollDTO.bottomState.label == 'REWARD_SUCCESS'">已领取奖励</view>
      <view class="failBtnBox" v-if="enrollDTO.bottomState && enrollDTO.bottomState.label == 'REWARD_FAIL'" @click="$u.throttle(failSubmit, 1000)">审核失败</view>
    </scroll-view>
    <!-- 更换背景图操作弹窗 -->
    <custom-more-operate-popup :show="showImageOperate" :list="ImageBtnList" @close="closeImageBtnClick" @click="handleImageBtnClick" />
    <u-toast ref="uToast"></u-toast>
    <view class="popup-hb" v-if="isCandidate" @click="isCandidate = false">
      <view class="popup-content">
        <view class="popup-rule-content">1.本活动博主数量上限为400个账号，先报先得，满员后进入候补</view>
        <view class="popup-rule-content">2.候补期间，仍可参与每日打卡 并获得相应积点</view>
        <view class="popup-rule-content">3.若已报名用户未完成博主打卡计划(包括但不限于断签、违规、内容不真实等)，您将获得顺位候补参与活动名额</view>
        <view class="popup-btn">我知道了</view>
      </view>
      <image class="popup-close" src="@/static/images/close.png" alt="" />
    </view>
    <view class="popup-bk" v-if="isSupplement" @click="isSupplement = false">
      <view class="popup-content">
        <view class="popup-rule-content">1.若有遗漏天数，发笔记优先补齐之前天数</view>
        <view class="popup-rule-content">2.如果连续2天未完成，第三天凌晨积点和连续天数会自动清零</view>
        <view class="popup-rule-content">3.每个月最多3次补签机会</view>
      </view>
      <image class="popup-close" src="@/static/images/close.png" alt="" />
    </view>
    <view class="popup-tc" v-if="isExit">
      <view class="popup-content">
        <view class="popup-rule-content">您之前发布的笔记将不再记录本次活动中若想继续参与活动可以重新报名</view>
        <view class="popup-btn">
          <view class="popup-btn1" @click="agreeExit">确认退出</view>
          <view class="popup-btn2" @click="isExit = false">继续参与</view>
        </view>
      </view>
      <image class="popup-close" src="@/static/images/close.png" alt="" @click="isExit = false" />
    </view>

    <view class="popup-sb" v-if="isFail" @click="isFail = false">
      <view class="popup-content">
        <view class="popup-rule-content">失败原因：</view>
        <view class="popup-rule-content">{{ enrollDTO.rewardErrMessage }}</view>
        <view class="popup-btn" @click.stop="toServiceCenter">联系客服</view>
      </view>
      <image class="popup-close" src="@/static/images/close.png" alt="" />
    </view>
  </view>
</template>

<script>
import blogger from '@/model/blogger'
import { USER_INFO } from '@/utils/cacheKey.js'
import { save, load } from '@/utils/store.js'
export default {
  data() {
    return {
      statusBarHeight: 0,
      enrollDTO: {},
      taskRecord: [],
      // 总记录反转
      taskRecordReverse: [],

      // 笔记列表
      noteList: [],
      // 开始时间
      startTime: '',
      // 上滑显示
      scrollShow: false,
      // 点击更多
      showImageOperate: false,
      ImageBtnList: ['查看活动协议', '退出活动'],
      // 今日帖子数据
      todayRecord: {},
      // 默认图
      defaultImg: 'http://img.yiqitogether.com/static/images/messageGray/group_avatar_normal.png',
      // 候补弹窗
      isCandidate: false,
      // 补卡弹窗
      isSupplement: false,
      // 是否退出活动
      isExit: false,
      // 是否申领失败
      isFail: false
    }
  },
  onLoad(e) {
    this.refreshList()
  },
  mounted() {
    //获取手机系统信息
    const info = uni.getSystemInfoSync()
    //设置状态栏高度
    this.statusBarHeight = info.statusBarHeight
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    scrollPage(e) {
      if (e.detail.scrollTop > 20) {
        this.scrollShow = true
      } else {
        this.scrollShow = false
      }
    },
    more() {
      this.showImageOperate = true
    },
    // 取消更多操作
    closeImageBtnClick() {
      this.showImageOperate = false
    },
    // 更多操作的具体按钮
    handleImageBtnClick(index, item) {
      let that = this
      if (item == '查看活动协议') {
        // uni.navigateTo({
        //   url: '/pagesCommon/blogger/agreement'
        // })
        // let url = 'http://192.168.1.136:9999/bloggerRule.html'
        let url = 'https://api.yiqitogether.com/bloggerRule.html'
        uni.navigateTo({
          url: '/pagesSetting/setting/webView?url=' + url
        })
      } else if (item == '退出活动') {
        this.isExit = true
      }
      this.showImageOperate = false
    },
    // 确认退出活动
    agreeExit() {
      this.enrollQuit()
    },
    // 博主查询
    async refreshList() {
      let that = this
      let data = {
        numberId: uni.getStorageSync('numberId')
      }
      let res = await blogger.enrollQuery(data)
      console.log(res, '1888')
      if (res.code == 'SUCCESS' && res.data && res.data.taskRecord) {
        let isBlogger = res.data.enrollDTO?.enrollCheckState.label === 'SUCCESS'
        if (!isBlogger) {
          let userInfo = JSON.parse(load(USER_INFO))
          userInfo.isBlogger = isBlogger
          save(USER_INFO, JSON.stringify(userInfo))
          uni.showToast({
            title: '报名信息发生变更，请重新进入',
            icon: 'none'
          })
          uni.navigateBack()
          return
        }

        this.enrollDTO = res.data.enrollDTO
        if (this.enrollDTO && this.enrollDTO.startTime) {
          // 将时间戳转换为Date对象
          let date = new Date(this.enrollDTO.startTime)
          // 增加一年
          date.setFullYear(date.getFullYear() + 1)
          // 将Date对象转换回时间戳
          this.startTime = date.getTime()
        }
        this.taskRecord = res.data.taskRecord
        // 克隆数组并反转，不会对原数组进行改变
        this.taskRecordReverse = res.data.taskRecord.slice().reverse()

        // 今日的帖子数据
        this.todayRecord = res.data.taskRecord[0]
        this.noteList = res.data.taskRecord[0].noteList
        // console.log(this.taskRecord, '9666')
      } else if (!res.data.taskRecord && !res.data.enrollDTO) {
        let userInfo = JSON.parse(load(USER_INFO))
        userInfo.isBlogger = false
        save(USER_INFO, JSON.stringify(userInfo))
        setTimeout(() => {
          uni.redirectTo({
            url: '/pagesCommon/blogger/signUp'
          })
        }, 500)
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },

    // 博主退出
    async enrollQuit() {
      let that = this
      let data = {
        numberId: uni.getStorageSync('numberId')
      }
      let res = await blogger.enrollQuit(data)
      console.log(res, '111111')
      if (res.code == 'SUCCESS') {
        let userInfo = JSON.parse(load(USER_INFO))
        userInfo.isBlogger = false
        save(USER_INFO, JSON.stringify(userInfo))
        uni.showToast({
          title: '退出成功',
          icon: 'none'
        })
        setTimeout(() => {
          uni.reLaunch({
            url: '/pages/find/index'
          })
        }, 1500)
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    // 前往发布
    goRelease() {
      uni.navigateTo({
        url: '/pagesFind/find/release?chooseType=s3' + '&from=bloggerRelease'
      })
    },
    // 提交现金申领
    async goSubmit() {
      let that = this
      let data = {
        numberId: uni.getStorageSync('numberId')
      }
      let res = await blogger.enrollSubmit(data)
      console.log(res, '111111')
      if (res.code == 'SUCCESS') {
        uni.showToast({
          title: '已提交申领',
          icon: 'none'
        })
        this.refreshList()
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    // 候补弹窗
    clickCandidate() {
      this.isCandidate = true
    },
    // 点击日期，找到补字段
    clickDatePopup(item) {
      if (item.state == 0) {
        this.isSupplement = true
      }
    },
    // 跳转动态详情
    toDetail(item) {
      uni.navigateTo({
        url: '/pages/find/findDetails?twitterId=' + item.id + '&pageType=2'
      })
    },
    // 申领失败
    failSubmit() {
      this.isFail = true
    },
    // 联系客服
    toServiceCenter() {
      this.isFail = false
      uni.navigateTo({
        url: '/pagesMy/my/serviceCenter'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.scrollHeight {
  height: 100vh;
}
.bloggerPage {
  height: 100vh;
  position: relative;
  background-color: #eafcfe;
  padding-bottom: 30rpx;
  // margin-bottom: 130rpx;
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 24rpx;
    padding-top: calc(var(--status-bar-height) + 20rpx);
    padding-bottom: 30rpx;
    width: 100vw;
    height: 128rpx;
    position: fixed;
    // top: var(--status-bar-height);
    top: 0rpx;
    z-index: 1;
    box-sizing: border-box;
    .navLeft {
      display: flex;
      align-items: center;
      .leftImage {
        width: 44rpx;
        height: 44rpx;
      }
      .title {
        font-size: 32rpx;
        font-family: PingFang SC, PingFang SC-Heavy;
        font-weight: Heavy;
        text-align: left;
        color: #484848;
        line-height: 44rpx;
      }
    }
    .rightImg {
      width: 44rpx;
      height: 44rpx;
    }
  }
  .bgImg {
    width: 750rpx;
  }
  .contentInfoBox {
    position: absolute;
    top: 540rpx;
    left: 32rpx;
    border-radius: 32rpx;
    padding-bottom: 100rpx;
    .contentBox {
      width: 690rpx;
      background: linear-gradient(180deg, rgba(209, 254, 255, 0.45), rgba(231, 248, 255, 0));
      border-radius: 32rpx;
      background-color: #fff;
      box-sizing: border-box;
      padding-bottom: 30rpx;

      .bjBox {
        width: 100%;
        height: 130rpx;
        background-image: url('https://img.yiqitogether.com/yyqc/20240619/upload_izre7q198078m2hrxppwes0gnanqv319.png');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .renwuImg {
          width: 192rpx;
          height: 64rpx;
          // margin-top: 40rpx;
          margin-left: 30rpx;
        }
        .ranking {
          height: 48rpx;
          background: linear-gradient(270deg, #70e3ff, #8cbcff);
          border-radius: 120rpx;
          font-size: 24rpx;
          font-family: PingFang SC, PingFang SC-Medium;
          font-weight: Medium;
          text-align: left;
          color: #ffffff;
          line-height: 48rpx;
          padding: 0 26rpx;
          margin-right: 30rpx;
        }
      }
      .middleBox {
        padding: 0 30rpx;
        background-color: #fff;
        // margin-bottom: 100rpx;
        .introduce {
          font-size: 24rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: left;
          color: #b6bdc9;
          line-height: 34rpx;
        }

        .timeBox {
          width: 630rpx;
          height: 200rpx;
          background: #e6fdff;
          border-radius: 16rpx;
          .topTimeBox {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 32rpx;
            .leftBox {
              // width: 152rpx;
              height: 60rpx;
              background: linear-gradient(270deg, #64c0ff 1%, #a0e4f5);
              border-radius: 16rpx 0rpx 16rpx 0rpx;
              font-size: 24rpx;
              font-family: PingFang SC, PingFang SC-Medium;
              font-weight: Medium;
              text-align: left;
              color: #ffffff;
              line-height: 34rpx;
              display: flex;
              justify-content: center;
              align-items: center;
              padding: 0 46rpx 0 32rpx;
            }
            .rightTime {
              font-size: 22rpx;
              font-family: PingFang SC, PingFang SC-Medium;
              font-weight: Medium;
              text-align: right;
              color: #b3d9dc;
              line-height: 32rpx;
              margin-right: 30rpx;
              .timeInfo {
                margin-left: 10rpx;
              }
            }
          }
          .bottomTimeBox {
            margin-top: 20rpx;
            // background-color: pink;
            padding: 0 20rpx 0 28rpx;
            box-sizing: border-box;
            display: flex;
            // justify-content: space-between;
            align-items: center;
            .dateBox {
              width: 134rpx;
              height: 90rpx;
              background: #d6f3f9;
              border-radius: 10rpx;
              margin-right: 14rpx;
              display: flex;
              justify-content: space-between;
              align-items: center;
              .leftDateBox {
                .timeDate {
                  font-size: 24rpx;
                  font-family: PingFang SC, PingFang SC-Medium;
                  font-weight: Medium;
                  text-align: left;
                  color: #72b0d1;
                  line-height: 34rpx;
                  margin-left: 16rpx;
                  // background-color: pink;
                }
              }
              .rightDateImg {
                width: 40rpx;
                height: 40rpx;
                background-size: cover;
                flex-shrink: 0;
                margin-right: 12rpx;
              }
            }
            .dateBox:last-child {
              margin-right: 0 !important;
            }
          }
        }
        .dakaBox {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 38rpx;
          .dakaTitle {
            font-size: 32rpx;
            font-family: PingFang SC, PingFang SC-Heavy;
            font-weight: Heavy;
            text-align: left;
            color: #2a343e;
            line-height: 44rpx;
          }
          .jidian {
            font-size: 28rpx;
            font-family: PingFang SC, PingFang SC-Heavy;
            font-weight: Heavy;
            text-align: left;
            color: #7fe2f4;
            line-height: 40rpx;
          }
        }
        .bijiInfo {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 18rpx;
          .leftBox {
            .introInfo {
              width: 430rpx;
              font-size: 24rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: left;
              color: #2a343e;
              line-height: 34rpx;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
            .finish {
              display: flex;
              margin-top: 20rpx;
              .finishInfoBox {
                display: flex;
              }
              .finishBox {
                display: block;
                width: 40rpx;
                height: 8rpx;
                background: #7fe2f4;
                border-radius: 4rpx;
                margin-right: 6rpx;
              }
              .unFinishBox {
                display: block;
                width: 40rpx;
                height: 8rpx;
                background: #f0f2f2;
                border-radius: 4rpx;
                margin-right: 6rpx;
              }
            }
          }
          .rightBox {
            // width: 172rpx;
            height: 60rpx;
            border: 1rpx solid #7fe2f4;
            border-radius: 31rpx;
            font-size: 24rpx;
            font-family: PingFang SC, PingFang SC-Medium;
            font-weight: Medium;
            text-align: center;
            color: #7fe2f4;
            line-height: 34rpx;
            // padding: 12rpx 46rpx;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0rpx 20rpx;
          }
        }
        .bijiListBox {
          margin-top: 30rpx;
          background: #eafcfe;
          border-radius: 16rpx;
          padding-bottom: 12rpx;
          .noteListBox {
            padding-top: 30rpx;
            padding-left: 24rpx;
            padding-right: 24rpx;
            box-sizing: border-box;
            position: relative;
            .noteItem {
              height: 150rpx;
              background: #fff;
              border-radius: 16rpx;
              display: flex;
              // justify-content: center;
              align-items: center;
              margin-bottom: 20rpx;
              .noteImg {
                width: 118rpx;
                height: 118rpx;
                border-radius: 16rpx;
                margin-left: 16rpx;
                margin-right: 28rpx;
                flex-shrink: 0;
              }
              .noteTitle {
                font-size: 24rpx;
                font-family: PingFang SC, PingFang SC-Heavy;
                font-weight: Heavy;
                text-align: left;
                color: #2a343e;
                line-height: 34rpx;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                margin-right: 28rpx;
              }
            }
            .finishedImg {
              width: 108rpx;
              height: 106rpx;
              position: absolute;
              top: -30rpx;
              right: 0;
            }
          }
          .wuBox {
            text-align: center;
            .wuImg {
              width: 106rpx;
              height: 106rpx;
              margin-top: 62rpx;
            }
            .wuTitle {
              font-size: 22rpx;
              font-family: PingFang SC, PingFang SC-Medium;
              font-weight: Medium;
              text-align: center;
              color: #b3d9dc;
              line-height: 32rpx;
            }
          }
        }
      }
    }
    .empty {
      height: 100rpx;
    }
  }
  .btnBox {
    width: 630rpx;
    height: 84rpx;
    background: linear-gradient(270deg, #85f6e7 0%, #6edde7 46%, #62d1ff);
    border-radius: 42rpx;
    box-shadow: 0rpx 8rpx 12rpx 0rpx rgba(135, 225, 255, 0.5);
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Medium;
    font-weight: Medium;
    text-align: left;
    color: #ffffff;
    line-height: 44rpx;
    text-shadow: 0rpx 8rpx 12rpx 0rpx rgba(135, 225, 255, 0.5);
    position: fixed;
    bottom: 80rpx;
    left: 60rpx;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .submitBtnBox {
    width: 630rpx;
    height: 84rpx;
    background: linear-gradient(90deg, #ffb85b, #ffda67 100%);
    border-radius: 42rpx;
    box-shadow: 0rpx 8rpx 12rpx 0rpx rgba(255, 218, 135, 0.5);
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Medium;
    font-weight: Medium;
    text-align: center;
    color: #ffffff;
    line-height: 44rpx;
    text-shadow: 0rpx 8rpx 12rpx 0rpx rgba(255, 218, 135, 0.5);
    position: fixed;
    bottom: 80rpx;
    left: 60rpx;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .failBtnBox {
    width: 630rpx;
    height: 84rpx;
    background: #ff674d;
    border-radius: 42rpx;
    box-shadow: 0rpx 8rpx 12rpx 0rpx rgba(188, 194, 199, 0.5);
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Medium;
    font-weight: Medium;
    text-align: center;
    color: #ffffff;
    line-height: 44rpx;
    text-shadow: 0rpx 8rpx 12rpx 0rpx rgba(255, 218, 135, 0.5);
    position: fixed;
    bottom: 80rpx;
    left: 60rpx;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
.popup-hb {
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  .popup-content {
    width: 602rpx;
    height: 560rpx;
    background: url('http://img.yiqitogether.com/static/images/hb_k%402x.png') no-repeat;
    background-size: 100% 100%;
    margin: 500rpx auto 0;
    padding-top: 116rpx;
    box-sizing: border-box;
    .popup-rule-content {
      width: 526rpx;
      font-size: 28rpx;
      text-align: left;
      color: #cacdd3;
      line-height: 44rpx;
      margin: 0 auto;
    }
    .popup-btn {
      width: 522rpx;
      height: 66rpx;
      background: #7fe2f4;
      border-radius: 33rpx;
      text-align: center;
      line-height: 66rpx;
      font-size: 28rpx;
      color: #ffffff;
      margin: 30rpx auto 0;
    }
  }
  .popup-close {
    width: 70rpx;
    height: 70rpx;
    margin: 30rpx auto 0;
    display: block;
  }
}
.popup-tc {
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  .popup-content {
    width: 582rpx;
    height: 368rpx;
    background: url('http://img.yiqitogether.com/static/images/tc_k%402x.png') no-repeat;
    background-size: 100% 100%;
    margin: 500rpx auto 0;
    padding-top: 116rpx;
    box-sizing: border-box;
    .popup-rule-content {
      width: 504rpx;
      font-size: 28rpx;
      text-align: center;
      color: #cacdd3;
      line-height: 44rpx;
      margin: 0 auto;
    }
    .popup-btn {
      width: 464rpx;
      height: 60rpx;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin: 60rpx auto 0;
      .popup-btn1 {
        width: 212rpx;
        height: 60rpx;
        background: #f6f6f8;
        border-radius: 30rpx;
        text-align: center;
        line-height: 60rpx;
        font-size: 28rpx;
        color: #cacdd3;
      }
      .popup-btn2 {
        width: 212rpx;
        height: 60rpx;
        background: #7fe2f4;
        border-radius: 30rpx;
        text-align: center;
        line-height: 60rpx;
        font-size: 28rpx;
        color: #ffffff;
      }
    }
  }
  .popup-close {
    width: 70rpx;
    height: 70rpx;
    margin: 30rpx auto 0;
    display: block;
  }
}
.popup-bk {
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  .popup-content {
    width: 602rpx;
    height: 336rpx;
    background: url('http://img.yiqitogether.com/static/images/bk_k%402x.png') no-repeat;
    background-size: 100% 100%;
    margin: 500rpx auto 0;
    padding-top: 116rpx;
    box-sizing: border-box;
    .popup-rule-content {
      width: 526rpx;
      font-size: 28rpx;
      text-align: left;
      color: #cacdd3;
      line-height: 44rpx;
      margin: 0 auto;
    }
  }
  .popup-close {
    width: 70rpx;
    height: 70rpx;
    margin: 30rpx auto 0;
    display: block;
  }
}
.popup-sb {
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  .popup-content {
    width: 602rpx;
    height: 672rpx;
    background: url('https://img.yiqitogether.com/yyqc/20240626/upload_48bybfpim6kgp6etbqgd226qk5tr9ucy.png') no-repeat;
    background-size: 100% 100%;
    margin: 500rpx auto 0;
    padding-top: 330rpx;
    box-sizing: border-box;
    position: relative;
    .popup-rule-content {
      width: 526rpx;
      font-size: 28rpx;
      text-align: left;
      color: #cacdd3;
      line-height: 44rpx;
      margin: 0 auto;

      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 4;
      -webkit-box-orient: vertical;
      white-space: pre-line;
      word-wrap: break-word;
      word-break: break-all;
    }
    .popup-btn {
      width: 522rpx;
      height: 66rpx;
      background: #7fe2f4;
      border-radius: 33rpx;
      text-align: center;
      line-height: 66rpx;
      font-size: 28rpx;
      color: #ffffff;
      margin: 30rpx auto 0;
      position: absolute;
      bottom: 60rpx;
      left: 40rpx;
    }
  }
  .popup-close {
    width: 70rpx;
    height: 70rpx;
    margin: 30rpx auto 0;
    display: block;
  }
}
</style>
