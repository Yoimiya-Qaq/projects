<template>
  <view class="allheaders">
    <view :style="{ height: statusBarHeight + 'px' }" style="background-color: #fff"></view>
    <view class="details-nav">
      <view class="back-info">
        <image @click="goBack()" class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      </view>
      <view class="details-nav-right">红包记录</view>
    </view>
    <view class="choose-box">
      <view class="type" @click="handleOption('F1')">
        <text :class="optionDatas == 'F1' ? 'option-data' : 'text-color'">收到的红包</text>
        <text v-if="optionDatas == 'F1'" class="active-bottom"></text>
      </view>
      <view class="type" @click="handleOption('F2')">
        <text :class="optionDatas == 'F2' ? 'option-data' : 'text-color'">发出的红包</text>
        <text v-if="optionDatas == 'F2'" class="active-bottom"></text>
      </view>
    </view>
    <scroll-view scroll-y="true" @scrolltolower="loadMore()" :style="{ height: scrollH + 'rpx' }">
      <view class="content-box">
        <view class="time-box" @click="chooseSex">
          <view class="time">{{ currentYear }}</view>
          <image src="https://im.yiqitogether.com/u/20241226/blevrtvga7vf2bbccbdhf78ebu4avioq.png" alt="" class="down"></image>
        </view>
        <view class="avatar-box">
          <image :src="userInfo.headUrl" alt="" class="avatar"></image>
        </view>
        <view class="nickname-box">{{ userInfo.nickName }}共{{ optionDatas == 'F1' ? '收到' : '发出' }}</view>
        <view class="price-box">
          <text class="price">{{ totalAmount }}</text>
          <text class="yuan">元</text>
        </view>
        <view class="number-box">{{ optionDatas == 'F1' ? '收到' : '发出' }}{{ optionDatas == 'F1' ? receiveTotal : sendTotal }}个红包</view>
      </view>
      <view class="list-box" v-if="redList.length > 0">
        <view class="item-box" v-for="(item, index) in redList" :key="index">
          <view class="item">
            <view class="left-box">
              <view class="info">
                <view class="name">{{ item.name }}</view>
                <image v-if="item.type == 'RANDOM'" src="https://im.yiqitogether.com/u/20250109/6r1i5a2sxed6n0f980hhcqypmeu1cg3q.png" alt="" class="pin"></image>
              </view>
              <view class="time">{{ item.date }}</view>
            </view>
            <view class="right-box">
              <view class="price-box">
                <text class="price">{{ item.amount }}</text>
                <text class="yuan">元</text>
              </view>
              <view class="number-box" v-if="item.drawInfo">{{ item.drawInfo }}</view>
            </view>
          </view>
        </view>
        <view class="pagesStatus" @click="loadMore()" v-if="optionDatas == 'F1'">
          {{ receivePages == receivePageNumber ? '到底了~' : '加载更多' }}
        </view>
        <view class="pagesStatus" @click="loadMore()" v-else>
          {{ sendPages == sendPageNumber ? '到底了~' : '加载更多' }}
        </view>
      </view>
    </scroll-view>
    <!-- 年份选择器 -->
    <u-picker :show="yearShow" :columns="yearColumns" itemHeight="72" @cancel="cancelSex" @confirm="confirmSex"></u-picker>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>
<script>
import RongYun from '@/model/rongyun'
import { save, load, clear } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'
export default {
  components: {},
  data() {
    return {
      scrollH: 0,
      statusBarHeight: 0,
      // 切换类型 F1: 收到红包  F2: 发出红包
      optionDatas: 'F1',
      // 年份
      currentYear: '',
      // 年份选择器
      yearShow: false,
      // 年份列表
      yearColumns: [[]],
      // 收到红包页码
      receivePages: 1,
      // 收到红包页数
      receivePageNumber: 0,
      // 收到的红包总数
      receiveTotal: '',

      // 发出红包页码
      sendPages: 1,
      // 发出红包页数
      sendPageNumber: 0,
      // 发出的红包总数
      sendTotal: '',
      // 红包列表
      redList: [],
      // 用户信息
      userInfo: JSON.parse(load(USER_INFO)) || '',
      totalAmount: ''
    }
  },
  onLoad() {
    let currentYear = new Date().getFullYear()
    this.currentYear = currentYear
    // 用差值进行循环
    let chaYear = currentYear - 2024
    for (let i = 0; i <= chaYear; i++) {
      this.yearColumns[0].push(currentYear - i)
    }
  },
  mounted() {
    //获取手机系统信息
    const info = uni.getSystemInfoSync()
    //设置状态栏高度
    this.statusBarHeight = info.statusBarHeight
    this.scrollH = this.scrollHs()
    this.myDrawList()
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    // 获取开始滚动距离
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      return winHeight - 20
    },
    // 头部tab切换
    handleOption(type) {
      let that = this
      if (type == this.optionDatas) return
      this.optionDatas = type ? type : this.optionDatas
      if (this.optionDatas == 'F1') {
        this.receivePageNumber = 0
        this.redList = []
        this.myDrawList()
      } else {
        this.sendPageNumber = 0
        this.redList = []
        this.mySendList()
      }
    },
    // 选择年份
    chooseSex() {
      this.yearShow = true
    },
    // 选择年份-取消
    cancelSex() {
      this.yearShow = false
    },
    // 选择年份-确定
    confirmSex(e) {
      this.currentYear = e.value[0]
      this.yearShow = false
      if (this.optionDatas == 'F1') {
        this.receivePageNumber = 0
        this.redList = []
        this.myDrawList()
      } else {
        this.sendPageNumber = 0
        this.redList = []
        this.mySendList()
      }
    },
    // 收到红包接口
    async myDrawList() {
      let that = this
      let data = {
        year: that.currentYear,
        pageNo: that.receivePageNumber + 1,
        pageSize: 10
      }
      console.log(data, '收到红包接口')
      let res = await RongYun.myDrawList(data)
      if (res.code == 'SUCCESS' && res.data) {
        if (that.receivePageNumber == 0) {
          this.totalAmount = res.data.totalDrawAmount
        }
        that.receivePages = res.data.page.pages
        that.receivePageNumber = res.data.page.pageNumber
        that.receiveTotal = res.data.page.total
        this.redList = [...this.redList, ...res.data.page.list]
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    // 发出红包接口
    async mySendList() {
      let that = this
      let data = {
        year: that.currentYear,
        pageNo: that.sendPageNumber + 1,
        pageSize: 10
      }
      console.log(data, '发出红包接口')
      let res = await RongYun.mySendList(data)
      if (res.code == 'SUCCESS' && res.data) {
        if (that.sendPageNumber == 0) {
          this.totalAmount = res.data.totalSendAmount
        }
        that.sendPages = res.data.page.pages
        that.sendPageNumber = res.data.page.pageNumber
        that.sendTotal = res.data.page.total
        this.redList = [...this.redList, ...res.data.page.list]
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },

    // 加载更多
    loadMore() {
      if (this.optionDatas == 'F1' && this.receivePages > this.receivePageNumber) {
        console.log(this.receivePages, '收到加载更多', this.receivePageNumber)
        this.myDrawList()
      } else if (this.optionDatas == 'F2' && this.sendPages > this.sendPageNumber) {
        console.log(this.currentYear, '发出加载更多')
        this.mySendList()
      }
    }
  }
}
</script>
<style scoped lang="scss">
.allheaders {
  width: 100%;
  height: 100vh;
  background: #f9f9f9;
  overflow-y: hidden;
}
.details-nav {
  width: 100%;
  height: 88rpx;
  background-color: #fff;
  position: relative;
  z-index: 999;
  .back-info {
    width: 44rpx;
    height: 44rpx;
    position: absolute;
    left: 24rpx;
    top: 22rpx;
    z-index: 99;
    .back-image {
      width: 100%;
      height: 100%;
    }
  }
  .details-nav-right {
    width: 100%;
    font-size: 36rpx;
    font-weight: 500;
    text-align: center;
    line-height: 88rpx;
    color: #333333;
  }
}
.choose-box {
  width: 100%;
  height: 136rpx;
  display: flex;
  align-items: center;
  justify-content: space-around;
  background-color: #fff;
  z-index: 999;
  // background-color: skyblue;
  .type {
    font-size: 36rpx;
    font-family: PingFang SC, PingFang SC-Medium;
    font-weight: 500;
    text-align: center;
    color: #333333;
    line-height: 50rpx;
    position: relative;
  }
  .option-data {
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Regular;
    font-weight: Regular;
    text-align: left;
    color: #2a343e;
    line-height: 44rpx;
  }
  .text-color {
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Regular;
    font-weight: Regular;
    text-align: left;
    color: #9fa7b4;
    line-height: 44rpx;
  }
  .active-bottom {
    // width: 80%;
    // width: 40rpx;
    // height: 6rpx;
    // background: #2a343e;
    // border-radius: 4rpx;
    // display: block;
    // margin: auto;
    // margin-top: 20rpx;

    width: 40rpx;
    height: 6rpx;
    display: block;
    text-align: center;
    background: #2a343e;
    border-radius: 4rpx;
    position: absolute;
    top: 70rpx;
    left: 60rpx;
  }
}
.content-box {
  width: 100%;
  text-align: center;
  .time-box {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    margin-top: 28rpx;
    .time {
      font-size: 32rpx;
      font-family: PingFang SC, PingFang SC-Regular;
      font-weight: Regular;
      text-align: left;
      color: #cfa255;
      line-height: 44rpx;
      margin-right: 10rpx;
    }
    .down {
      width: 16rpx;
      height: 16rpx;
      margin-right: 40rpx;
    }
  }
  .avatar-box {
    .avatar {
      width: 144rpx;
      height: 144rpx;
      border-radius: 50%;
    }
  }
  .nickname-box {
    font-size: 32rpx;
    font-family: PingFang SC, PingFang SC-Regular;
    font-weight: Regular;
    text-align: center;
    color: #2a343e;
    line-height: 44rpx;
    margin-top: 16rpx;
    // background-color: skyblue;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .price-box {
    margin-top: 28rpx;
    .price {
      font-size: 92rpx;
      font-family: OPPOSans, OPPOSans-Regular;
      font-weight: Regular;
      text-align: center;
      color: #2a343e;
      line-height: 146rpx;
    }
    .yuan {
      font-size: 32rpx;
      font-family: OPPOSans, OPPOSans-Regular;
      font-weight: Regular;
      text-align: center;
      color: #2a343e;
      line-height: 50rpx;
    }
  }
  .number-box {
    font-size: 28rpx;
    font-family: PingFang SC, PingFang SC-Regular;
    font-weight: Regular;
    text-align: center;
    color: #64696f;
    line-height: 40rpx;
    margin-top: 8rpx;
  }
}
.list-box {
  width: 100%;
  // height: 100%;
  background: #ffffff;
  border-radius: 40rpx;
  margin-top: 60rpx;
  margin-bottom: 150rpx;
  padding-bottom: 600rpx;
  .item-box {
    .item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2rpx solid #f0f1f3;
      margin: 0 36rpx;
      .left-box {
        margin-top: 40rpx;
        margin-bottom: 31rpx;
        .info {
          width: 450rpx;
          display: flex;
          align-items: center;
          .name {
            font-size: 28rpx;
            font-family: OPPOSans, OPPOSans-Regular;
            font-weight: Regular;
            text-align: left;
            color: #2d3f49;
            line-height: 36rpx;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
          .pin {
            width: 32rpx;
            height: 32rpx;
            margin-left: 8rpx;
            flex-shrink: 0;
          }
        }
        .time {
          font-size: 24rpx;
          font-family: OPPOSans, OPPOSans-Regular;
          font-weight: Regular;
          text-align: left;
          color: #adb3ba;
          line-height: 32rpx;
          margin-top: 8rpx;
        }
      }
      .right-box {
        .price-box {
          text-align: right;
          .price {
            font-size: 36rpx;
            font-family: Avenir Next, Avenir Next-Medium;
            font-weight: Medium;
            text-align: right;
            color: #2a343e;
            line-height: 50rpx;
            margin-right: 4rpx;
          }
          .yuan {
            font-size: 28rpx;
            font-family: PingFang SC, PingFang SC-Regular;
            font-weight: Regular;
            text-align: right;
            color: #2a343e;
            line-height: 40rpx;
          }
        }
        .number-box {
          font-size: 24rpx;
          font-family: OPPOSans, OPPOSans-Regular;
          font-weight: Regular;
          text-align: right;
          color: #adb3ba;
          line-height: 32rpx;
        }
      }
    }
    .item:last-child {
      border-bottom: none;
    }
  }
  .pagesStatus {
    font-size: 28rpx;
    font-family: OPPOSans, OPPOSans-Medium;
    font-weight: 500;
    text-align: center;
    color: #adb3ba;
    line-height: 36rpx;
    padding-bottom: 40rpx;
    padding-top: 40rpx;
  }
}
/deep/ .u-toolbar__wrapper__confirm {
  color: #0c0c0c !important;
  font-size: 28rpx;
  font-family: PingFang SC, PingFang SC-Regular;
  font-weight: Regular;
  text-align: center;
  line-height: 40rpx;
}
/deep/ .u-toolbar__wrapper__cancel {
  color: #0c0c0c !important;
  font-size: 28rpx;
  font-family: PingFang SC, PingFang SC-Regular;
  text-align: center;
  font-weight: Regular;
  line-height: 40rpx;
}
/deep/ .u-picker__view__column__item {
  width: 620rpx;
  height: 88rpx !important;
  border-radius: 20rpx;
  font-size: 32rpx;
  font-family: PingFang SC, PingFang SC-Regular;
  font-weight: Regular;
  text-align: center;
  color: #2a343e !important;
  line-height: 44rpx;
  background: #f7f7f7;
  margin: 0 auto;
}
/deep/ .uni-picker-view-indicator:before {
  border: none;
}
/deep/ .uni-picker-view-indicator:after {
  border: none;
}
// /deep/ .u-toolbar {
//   // height: 452rpx !important;
//   border-radius: 20rpx 20rpx 0 0 !important;
// }
</style>
