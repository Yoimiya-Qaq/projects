<template>
  <view class="interactive-message-page">
    <view class="nav-container">
      <image class="nav-back" src="@/static/images/back_black.png" mode="aspectFill" @click="goBack" />
      <view class="nav-title">活动信箱</view>
    </view>
    <view class="main-container">
      <scroll-view class="list-wrap" :scroll-y="true" v-if="messageList.length" @scrolltolower="loadMore()">
        <!-- <uni-swipe-action> -->
        <!-- <uni-swipe-action-item v-for="item in messageList" :key="item.uuId" :threshold="0" :auto-close="true" :right-options="rightOptions" @click="btnClick($event, item)"> -->
        <view class="list-item" v-for="(item, index) in messageList" :key="index" @click="goDetail(item)">
          <image
            class="list-item-avatar"
            :src="item.headUrl ? item.headUrl : defaultAvatar"
            mode="aspectFill"
            @click.stop="
              $u.throttle(() => {
                toPersonalPage(item)
              }, 500)
            "
          />
          <view class="list-item-center">
            <view
              class="first-line"
              @click.stop="
                $u.throttle(() => {
                  toPersonalPage(item)
                }, 500)
              "
            >
              <view class="name">{{ item.nikeName || '' }}</view>
              <view class="author" v-if="item.isPromoter">发起人</view>
              <!-- <view class="dot" v-if="!item.read"></view> -->
            </view>
            <view class="second-line" v-if="item.cancel">
              <view class="comment ellipsis-single" style="background-color: #f6f6f8; padding: 4rpx 8rpx; border-radius: 4rpx">该评论已删除</view>
            </view>
            <view class="second-line" v-else>
              <view class="comment ellipsis-single">{{ !item.msgOrReply ? '回复了你：' : '给你留言：' }}{{ item.content }}</view>
              <view class="date">{{ $u.timeFormat(item.createTimeStamp, 'sendMsgFormat') }}</view>
            </view>
          </view>
          <image class="list-item-img" :src="item.cover" mode="aspectFill" />
        </view>
        <!-- </uni-swipe-action-item> -->
        <!-- </uni-swipe-action> -->
        <view @click="loadMore">
          <u-loadmore :status="loadStatus" :fontSize="24" marginTop="24" marginBottom="40" nomore-text="到底了~" />
        </view>
        <view class="space-box"></view>
      </scroll-view>
      <view v-if="loadStatus == 'none'" class="empty-wrap">
        <image class="empty-img" src="https://img.yiqitogether.com/static/local/leo/qs_wuxiaoxi@2x.png" alt="" mode="aspectFill" />
      </view>
    </view>
    <!-- 删除互动消息二次确认弹框 -->
    <custom-modal :show="showDelModal" type="tipsConfirm" title="提示" content="确定删除该消息吗？删除后不可恢复" round="24" @cancel="showDelModal = false" @confirm="confirmDelete" />
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import Blogger from '@/model/blogger'

export default {
  name: 'interactiveMessage',
  data() {
    return {
      // 默认头像
      defaultAvatar: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      showLoading: false,
      pages: 0,
      pageNumber: 1,
      pageSize: 20,
      loadStatus: 'loadmore',
      messageList: [],
      rightOptions: [
        {
          text: '删除',
          style: {
            backgroundColor: '#FB5C4E',
            fontSize: '24rpx',
            width: '150rpx'
          }
        }
      ],
      msgUuid: '',
      showDelModal: false
    }
  },
  onShow() {
    this.pageNumber = 1
    this.messageList = []
    this.getList()
  },
  // onBackPress(e) {
  //   let eventChannel = this.getOpenerEventChannel()
  //   eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //   return false
  // },
  // onUnload() {
  //   let that = this
  //   if (uni.getSystemInfoSync().platform == 'ios') {
  //     try {
  //       let eventChannel = this.getOpenerEventChannel()
  //       eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //     } catch (error) {}
  //   }
  // },
  methods: {
    // 左上角返回
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 获取消息列表
    getList() {
      this.showLoading = true
      Blogger.queryMessageList()
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.list || []
            this.messageList = list
            this.loadStatus = list.length ? 'nomore' : 'none'
          } else {
            this.loadStatus = 'none'
            this.$refs.uToast.show({
              ...res
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
          this.loadStatus = 'none'
        })
    },
    // 加载更多
    loadMore() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.pageNumber++
          this.getList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    },
    // 点击选项按钮时触发事件
    btnClick(e, item) {
      this.showDelModal = true
      this.msgUuid = item.uuId
    },
    // 删除-确定
    confirmDelete() {
      Blogger.deleteMsgReply({
        type: 'ME',
        msgUuid: this.msgUuid
      })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.showDelModal = false
            this.pageNumber = 1
            this.messageList = []
            this.getList()
          }
        })
        .catch(err => {
          this.showDelModal = false
        })
    },
    // 查看详情
    goDetail(item) {
      uni.navigateTo({ url: '/pagesCommon/details/details?appointmentNo=' + item.appointmentNo + '&tabType=ActivityMailbox' })
    },
    // 去个人主页
    toPersonalPage(item) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + item.numberId })
    }
  }
}
</script>

<style lang="scss" scoped>
.interactive-message-page {
  height: 100vh;
  overflow: hidden;
  background-color: #fff;

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    position: relative;
    z-index: 999;
    background-color: #fff;
    padding-top: var(--status-bar-height);
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-title {
      font-size: 36rpx;
      color: #333333;
    }
  }

  .main-container {
    padding: 2rpx 0 0;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
    box-sizing: border-box;

    .list-wrap {
      height: calc(100vh - 88rpx - var(--status-bar-height));
      box-sizing: border-box;
      overflow-y: auto;

      .list-item {
        display: flex;
        align-items: center;
        padding: 24rpx 36rpx;

        &-avatar {
          flex-shrink: 0;
          width: 88rpx;
          height: 88rpx;
          border-radius: 50%;
          margin-right: 24rpx;
        }
        &-center {
          flex: 1;
          .first-line {
            display: inline-flex;
            align-items: center;
            margin-bottom: 4rpx;
            position: relative;
            .name {
              font-size: 28rpx;
              color: #2a343e;
              line-height: 40rpx;
            }
            .author {
              width: 64rpx;
              height: 28rpx;
              font-size: 16rpx;
              color: #fe5e10;
              line-height: 28rpx;
              text-align: center;
              background: #ffede4;
              border-radius: 16rpx;
              margin-left: 8rpx;
            }
            .dot {
              width: 16rpx;
              height: 16rpx;
              background: #fe5e10;
              border-radius: 50%;
              position: absolute;
              right: -18rpx;
              top: 0;
            }
          }
          .second-line {
            display: flex;
            font-size: 20rpx;
            line-height: 28rpx;

            .comment {
              color: #64696f;
            }
            .date {
              flex-shrink: 0;
              color: #c8c8c8;
              margin-left: 24rpx;
            }
          }
        }

        .list-item-img {
          flex-shrink: 0;
          width: 112rpx;
          height: 112rpx;
          border-radius: 8rpx;
          margin-left: 48rpx;
        }
      }
      .list-item:last-child {
        margin-bottom: 0;
      }
    }
    .space-box {
      width: 100%;
      height: 40rpx;
    }
    .empty-wrap {
      text-align: center;
      font-size: 0;
      padding-top: 300rpx;
      .empty-img {
        width: 310rpx;
        height: 310rpx;
        background-size: cover;
      }
    }
  }
}
</style>
