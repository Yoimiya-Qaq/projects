<template>
  <view class="page"> </view>
</template>

<script>
export default {
  components: {},

  data() {
    return {}
  },
  computed: {},
  onLoad(e) {
    // uni.sendNativeEvent('goMessage', {
    // 	msg: 'go message page!'
    // }, ret => {
    // })
    let testModule = uni.requireNativePlugin('TestModule')
    testModule.goAndroidMsg({}, (ret) => {})
  },
  mounted() {},
  onShow() {},
  methods: {},
}
</script>
<style lang="scss" scoped></style>
