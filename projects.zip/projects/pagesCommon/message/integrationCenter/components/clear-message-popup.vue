<template>
  <u-popup class="clearMessagePop" :show="showClearMessage" @close="cancelClearMessage">
    <view class="clearMessagePop_content">
      <view class="content_title">确认删除此条消息?</view>
      <view class="content_submit" @click="$u.throttle(confirmClearMessage, 500)">确定</view>
      <view class="border_line"></view>
      <view class="content_cancel" @click="$u.throttle(cancelClearMessage, 500)">取消</view>
    </view>
  </u-popup>
</template>
<script>
export default {
  props: {
    showClearMessage: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {}
  },
  methods: {
    confirmClearMessage() {
      this.$emit('confirmClearMessage')
    },
    cancelClearMessage() {
      this.$emit('cancelClearMessage')
    }
  }
}
</script>
<style lang="scss" scoped>
.clearMessagePop {
  /deep/.u-popup__content {
    border-radius: 20rpx 20rpx 0rpx 0rpx;
  }
  .clearMessagePop_content {
    padding-top: 38rpx;
    text-align: center;
    .border_line {
      width: 100%;
      height: 0;
      border-bottom: 15rpx solid #f7f7f7;
    }
    .content_title {
      font-size: 32rpx;
      color: #838e9a;
    }
    .content_submit {
      margin: 62rpx 0 38rpx 0;
      font-size: 32rpx;
      color: #fe5e10;
      font-weight: bold;
    }
    .content_cancel {
      margin-top: 28rpx;
      font-size: 32rpx;
      color: #2a343e;
      margin-bottom: 128rpx;
      font-weight: bold;
    }
  }
}
</style>
