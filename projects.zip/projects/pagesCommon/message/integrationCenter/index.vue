<template>
  <view class="integration_center_index_page">
    <view class="nav flex-1">
      <view class="flex-0">
        <image class="nav_image" @click="goBack" src="@/static/images/back_black.png" mode="scaleToFill" />
        <view class="nav_title flex-1">
          <image class="title_img" src="http://img.yiqitogether.com/static/images/messageGray/private_integration.png" mode="scaleToFill" />
          <view class="title_text">积分中心</view>
        </view>
      </view>
      <image class="nav_more" @click="$u.throttle(goSetting, 500)" src="@/static/images/more2.png" mode="scaleToFill" />
    </view>
    <!-- 积分中心列表 -->
    <view class="index_body">
      <view class="body_list" v-if="intergrationList.length !== 0">
        <view class="body_list_item" v-for="(item, index) in intergrationList" :key="index">
          <view class="item_time" v-if="item.isDay">{{ item.createTime }}</view>
          <view class="item_content">
            <view class="content_top flex-1">
              <view class="top_left flex-0">
                <image class="left_img" v-if="item.title == '积分兑换'" src="http://img.yiqitogether.com/static/images/messageGray/intergration_img.png" mode="scaleToFill" />
                <view class="left_text">{{ item.title }}</view>
              </view>
              <image
                class="top_right"
                @click="
                  $u.throttle(() => {
                    openMessageClose(item, index)
                  }, 500)
                "
                src="http://img.yiqitogether.com/static/images/messageGray/intergration_more.png"
                mode="scaleToFill"
              />
            </view>
            <view class="border_line"></view>
            <!-- 通知内容 -->
            <view v-if="!item.isJson && item.content" class="item_text">{{ item.content }}</view>
            <!-- 积分内容 -->
            <view v-if="item.isJson" class="content_detail">
              <view class="detail_img_box" v-if="item.content">
                <image class="box_img" v-if="item.content.goodsUrl" :src="item.content.goodsUrl" mode="aspectFill" />
                <view class="box_text" v-if="item.content.goodsName">{{ item.content.goodsName }}</view>
              </view>
              <view v-if="item.content" class="border_line" style="margin-bottom: 36rpx"></view>
              <view v-if="item.points" class="detail_item flex-0">
                <view class="detail_item_title">支出积分</view>
                <view class="detail_item_text">{{ item.points }}</view>
              </view>
              <view v-if="item.conversionTime" class="detail_item flex-0">
                <view class="detail_item_title">兑换时间</view>
                <view class="detail_item_text">{{ item.conversionTime }}</view>
              </view>
            </view>
          </view>
        </view>
        <view class="tips-box" @click="$u.throttle(loadMore, 500)">
          <u-loadmore :status="loadStatus" :fontSize="23" nomore-text="到底了~" />
        </view>
      </view>
      <view class="body_bottom flex-9">
        <view class="bottom-btn" @click="$u.throttle(goIntegralDetail, 500)">积分明细</view>
        <view class="bottom-btn" @click="$u.throttle(goIntegralCenter, 500)">领更多积分</view>
      </view>
      <view class="normalActivity-empty" v-if="intergrationList.length == 0 && !showLoading">
        <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
        <view class="empty-text">暂无内容</view>
      </view>
    </view>

    <!-- 删除此条消息弹框 -->
    <clearMessagePopup :showClearMessage="showClearMessage" @confirmClearMessage="confirmClearMessage" @cancelClearMessage="cancelClearMessage"></clearMessagePopup>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
  </view>
</template>
<script>
// 导入组件
import clearMessagePopup from './components/clear-message-popup.vue'
// 导入接口
import rongYun from '@/model/rongyun.js'
// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { LOGIN_USERID } from '@/utils/cacheKey.js'

export default {
  components: {
    clearMessagePopup
  },
  data() {
    return {
      pageNo: 0, //页数
      showLoading: true, //加载弹窗
      loadStatus: 'loadmore', //加载状态
      pages: 0,
      pageNumber: 0,
      intergrationList: [], //消息积分列表
      showClearMessage: false, //删除此条消息弹框显示
      checkedItem: {}, //选中删除的消息
      checkedIndex: 0, //选中删除的索引
      numberId: load(LOGIN_USERID).toString() || '' // 本人numberId
    }
  },
  onLoad(e) {
    this.getScoreMessageList()
  },
  onReachBottom() {
    this.loadMore()
  },
  methods: {
    /**
     * 获取积分消息列表
     */
    getScoreMessageList() {
      let data = {
        pageNo: this.pageNumber + 1,
        pageSize: 10
      }
      rongYun
        .getScoreMessageList(data)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.pages = res.data.pager.pages
            this.pageNumber = res.data.pager.pageNumber
            let list = res.data.pager.list
            list.map(item => {
              item.conversionTime = uni.$u.timeFormat(item.createTime, 'yyyy-mm-dd hh:MM:ss')
              item.createTime = uni.$u.timeFormat(item.createTime, 'sendMsgFormat')
              try {
                item.content = JSON.parse(item.content)
                item.isJson = true
              } catch (error) {
                item.isJson = false
              }
            })
            let newlist = [...this.intergrationList, ...list]
            newlist.forEach((item, index) => {
              if (index >= 1) {
                if (newlist[index - 1].createTime == newlist[index].createTime) {
                  item.isDay = false
                } else {
                  item.isDay = true
                }
              } else {
                item.isDay = true
              }
            })
            this.intergrationList = [...newlist]
            if (res.data.pager.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.pager.pages <= res.data.pager.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none',
              mask: true
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    /**
     * 加载更多
     */
    loadMore() {
      if (this.loadStatus != 'nomore') {
        if (this.pages > this.pageNumber) {
          this.getScoreMessageList()
        }
      } else {
        this.loadStatus = 'nomore'
      }
    },
    /**
     * 确认删除积分消息
     */
    async confirmClearMessage() {
      this.showClearMessage = false
      // 调接口删除
      this.toDeleteMessage(this.checkedItem.msgUID)
    },
    /**
     * 删除私聊消息
     */
    async toDeleteMessage(msgUID) {
      let data = {
        numberId: this.numberId,
        msgUID: msgUID
      }
      let res = await rongYun.deleteMessage(data)
      if (res.code == 'SUCCESS') {
        // 删除消息后，无感刷新
        this.intergrationList.splice(this.checkedIndex, 1)
        let index = this.intergrationList.findIndex(item => {
          return this.checkedItem.createTime == item.createTime
        })
        if (index != -1) {
          this.intergrationList[index].isDay = true
        }
        uni.showToast({
          title: '删除成功',
          icon: 'none',
          mask: true
        })
      } else {
        uni.showToast({
          title: res.message,
          icon: 'none',
          mask: true
        })
      }
    },
    /**
     * 取消删除积分消息
     */
    cancelClearMessage() {
      this.showClearMessage = false
    },
    /**
     * 打开删除积分消息弹框
     */
    openMessageClose(item, index) {
      this.showClearMessage = true
      this.checkedIndex = index
      this.checkedItem = { ...item }
    },
    /**
     * 积分中心页面
     */
    goIntegralCenter() {
      uni.navigateTo({ url: '/pagesMy/my/integralCenter/index' })
    },
    /**
     * 积分明细页面
     */
    goIntegralDetail() {
      uni.navigateTo({ url: '/pagesMy/my/integralCenter/integralDetail' })
    },
    /**
     * 设置
     */
    goSetting() {
      let self = this
      uni.navigateTo({
        url: '/pagesCommon/message/messageSetting?pageTitle=积分中心&targetNo=10010',
        events: {
          privateSettingBack: function (data) {
            self.intergrationList = []
          }
        }
      })
    },
    goBack() {
      uni.navigateBack({ delta: 1 })
    }
  }
}
</script>
<style lang="scss" scoped>
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.flex-2 {
  display: flex;
  align-items: center;
}
.flex-3 {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.flex-4 {
  display: flex;
  align-items: flex-end;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.flex-6 {
  display: flex;
  align-items: center;
  justify-content: end;
}
.flex-9 {
  display: flex;
  justify-content: space-between;
}
.integration_center_index_page {
  background: #f6f6f8;
  overflow-y: scroll;
  min-height: 100vh;
  .nav {
    position: fixed;
    background: #f6f6f8;
    width: 100vw;
    align-items: center;
    padding: calc(var(--status-bar-height) + 14rpx) 24rpx 14rpx 24rpx;
    box-sizing: border-box;
    border-bottom: 2rpx #eaeaec solid;
    z-index: 1;
    .nav_image {
      width: 44rpx;
      height: 44rpx;
      image {
        width: 100%;
        height: 100%;
      }
    }
    .nav_title {
      .title_img {
        width: 90rpx;
        height: 90rpx;
        margin: 0 22rpx;
      }
      .title_text {
        font-size: 32rpx;
        color: #2a343e;
      }
    }
    .nav_more {
      width: 24px;
      height: 24px;
      flex-shrink: 0;
    }
  }
  .index_body {
    padding-top: calc(var(--status-bar-height) + 38rpx + 88rpx);
    // overflow: hidden;
    .body_list {
      padding-bottom: 148rpx;

      .body_list_item {
        margin-top: 44rpx;
        .item_time {
          font-size: 24rpx;
          text-align: center;
          color: #adadad;
          margin: 0 auto 32rpx;
        }
        .item_content {
          width: 670rpx;
          background: #ffffff;
          border-radius: 20rpx;
          margin: 0 auto 40rpx;
          padding: 0 28rpx;
          box-sizing: border-box;
          .content_top {
            height: 110rpx;
            .top_left {
              .left_img {
                width: 60rpx;
                height: 60rpx;
                margin-right: 16rpx;
              }
              .left_text {
                font-size: 28rpx;
                color: #2a343e;
              }
            }
            .top_right {
              width: 32rpx;
              height: 32rpx;
            }
          }
          .border_line {
            width: 100%;
            height: 0;
            border-bottom: 1rpx solid #f0f1f3;
          }
          .item_text {
            margin: 36rpx 0 0;
            padding: 0 10rpx 68rpx;
            box-sizing: border-box;
            font-size: 28rpx;
            color: #1c1c1c;
          }
          .content_detail {
            padding: 24rpx 0 16rpx;
            .detail_img_box {
              // margin: auto;
              text-align: center;
              .box_img {
                width: 192rpx;
                height: 192rpx;
                border-radius: 16rpx;
                margin-bottom: 22rpx;
              }
              .box_text {
                margin-bottom: 24rpx;
                font-size: 24rpx;
                color: #838e9a;
              }
            }
            .detail_item {
              padding: 0 0 40rpx;
              .detail_item_title {
                font-size: 28rpx;
                color: #838e9a;
                margin-right: 28rpx;
              }
              .detail_item_text {
                font-size: 28rpx;
                color: #1c1c1c;
              }
            }
          }
        }
      }
    }
    .body_bottom {
      position: fixed;
      bottom: 0;
      width: 100%;
      height: 144rpx;
      background: #ffffff;
      padding-top: 32rpx;
      box-sizing: border-box;
      .bottom-btn {
        font-size: 28rpx;
        color: #2a343e;
        text-align: center;
        flex-grow: 1;
      }
    }
  }
}
.normalActivity-empty {
  padding-top: 100rpx;
  height: 50vh;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
.tips-box {
  padding-bottom: 50rpx;
}
</style>
