<template>
  <view class="fans-message-page">
    <view class="nav-container">
      <image class="nav-back" src="@/static/images/back_black.png" mode="aspectFill" @click="goBack" />
      <view class="nav-title">粉丝消息</view>
    </view>
    <view class="main-container" v-if="fansList.length > 0">
      <view
        class="list-item"
        v-for="(item, index) in fansList"
        :key="item.id"
        @click="
          $u.throttle(() => {
            toPersonalPage(item)
          }, 1000)
        "
      >
        <image :src="item.senderImg ? item.senderImg : defaultAvatar" alt="" mode="aspectFill" class="avatar"></image>
        <view class="right">
          <view class="top">
            <view class="left">
              <text class="title" v-if="item.senderName">{{ item.senderName }}</text>
              <view class="tags">关注了你</view>
              <view class="tagss">{{ $u.timeFormat(item.newCreateTime, 'sendMsgFormat') }}</view>
            </view>
          </view>
        </view>
      </view>
      <view @click="loadMore">
        <u-loadmore :status="loadStatus" :fontSize="20" marginTop="24" marginBottom="40" nomore-text="到底了~" />
      </view>
    </view>
    <view v-if="fansList.length == 0" class="wu">
      <image src="https://img.yiqitogether.com/static/local/myImages/qs_wujilu@2x.png" alt="" class="qs"></image>
    </view>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>
<script>
import IndexModel from '@/model/index'
import MyInfo from '@/model/my.js'
export default {
  data() {
    return {
      // 默认头像
      defaultAvatar: 'https://img.yiqitogether.com/static/local/myImages/touxiang_moren@2x.png',
      pages: 0,
      pageNumber: 0,
      fansList: [],
      isMutual: false,
      loadStatus: 'loadmore',
      linkUrls: 'pages/my/myHomePages/fanList'
    }
  },
  onReachBottom() {
    this.loadMore()
  },
  onLoad(e) {
    this.getFansList()
  },
  // onBackPress(e) {
  //   let eventChannel = this.getOpenerEventChannel()
  //   eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //   return false
  // },
  // onUnload() {
  //   let that = this
  //   if (uni.getSystemInfoSync().platform == 'ios') {
  //     try {
  //       let eventChannel = this.getOpenerEventChannel()
  //       eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //     } catch (error) {}
  //   }
  // },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    // 获取粉丝列表
    getFansList() {
      let data = {
        messageType: 'FANS',
        pageNo: this.pageNumber + 1,
        pageSize: 10
      }
      IndexModel.innerMessage(data)
        .then(res => {
          if (res.code == 'SUCCESS' && res.data) {
            this.pages = res.data.pager.pages
            this.pageNumber = res.data.pager.pageNumber
            this.fansList = [...this.fansList, ...res.data.pager.list]
            if (res.data.pager.total == 0) {
              this.loadStatus = 'none'
            } else {
              if (res.data.pager.pages <= res.data.pager.pageNumber) {
                this.loadStatus = 'nomore'
              } else {
                this.loadStatus = 'loadmore'
              }
            }
          }
        })
        .catch(err => {
          this.loadStatus = 'none'
        })
    },
    // 点头像去个人主页
    toPersonalPage(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item.sender
      })
    },
    addAttention(item) {
      let pamise = {
        targetNumberId: item.sender
      }
      if (item.isMutual) {
        //取消关注
        MyInfo.cancelAttention(pamise).then(res => {
          if (res.code == 'SUCCESS') {
            item.isMutual = !item.isMutual
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      } else {
        MyInfo.attention(pamise).then(res => {
          if (res.code == 'SUCCESS') {
            item.isMutual = !item.isMutual
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 加载更多
    loadMore() {
      if (this.loadStatus !== 'nomore') {
        if (this.pages > this.pageNumber) {
          this.loadStatus = 'loading'
          this.getFansList()
        } else {
          this.loadStatus = 'nomore'
        }
      }
    }
  }
}
</script>
<style scoped lang="scss">
.fans-message-page {
  width: 100%;
  min-height: 100vh;
  background: #fff;
  overflow-y: auto;

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    background-color: #fff;
    padding-top: var(--status-bar-height);
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 0 20rpx 0 30rpx;
    }
    .nav-title {
      font-size: 36rpx;
      color: #333333;
    }
  }
}
.main-container {
  padding-top: calc(var(--status-bar-height) + 108rpx);
  box-sizing: border-box;
  .list-item {
    width: 100%;
    margin-bottom: 40rpx;
    padding: 0 24rpx;
    box-sizing: border-box;
    display: flex;
    .avatar {
      width: 110rpx;
      height: 110rpx;
      background-size: cover;
      border-radius: 50%;
    }
    .right {
      width: 85%;
      margin-left: 20rpx;
      .top {
        display: flex;
        justify-content: space-between;
      }
      .left {
        .title {
          font-size: 28rpx;
          font-family: OPPOSans, OPPOSans-Bold;
          font-weight: 400;
          text-align: left;
          color: #2d3f49;
        }
        .tags {
          font-size: 24rpx;
          font-family: OPPOSans, OPPOSans-Medium;
          font-weight: 500;
          color: #2d3f49;
          margin: 10rpx 0 6rpx;
        }
        .tagss {
          font-size: 24rpx;
          font-weight: 500;
          text-align: left;
          color: #adb3ba;
        }
      }
      .bottom {
        font-size: 24rpx;
        font-family: OPPOSans, OPPOSans-Medium;
        font-weight: 500;
        text-align: left;
        color: #adb3ba;
        line-height: 26rpx;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 1;
        display: -webkit-box;
        -webkit-box-orient: vertical;
      }
    }
  }
}
.pagesStatus {
  font-size: 28rpx;
  font-family: OPPOSans, OPPOSans-Medium;
  font-weight: 500;
  text-align: center;
  color: #adb3ba;
  line-height: 36rpx;
  padding-bottom: 40rpx;
  padding-top: 40rpx;
}
.wu {
  width: 310rpx;
  height: 310rpx;
  margin: 300rpx auto 0;
}
.qs {
  width: 100%;
  height: 100%;
  background-size: cover;
}
</style>
