<template>
  <view class="birthday-message-page">
    <view class="nav-container">
      <image class="nav-back" src="@/static/images/back_black.png" mode="aspectFill" @click="goBack" />
      <image class="nav-img" src="http://img.yiqitogether.com/static/images/messageGray/private_birthday.png" mode="aspectFill" />
      <view class="nav-title">生日提醒</view>
      <image class="nav-icon" v-show="sourcePage != 'index'" mode="aspectFill" src="@/static/images/more2.png" @click="$u.throttle(goSetting, 500)" />
    </view>
    <view class="main-container" v-if="(listData.length || selfList.length) && !showLoading">
      <view class="receive-time">{{ $u.timeFormat(sendDate, 'mm-dd hh:MM') }}</view>
      <!-- 自己的生日 -->
      <swiper class="swiper-wrap" :indicator-dots="selfList.length && listData.length ? true : false" indicator-color="#e8e8e8" indicator-active-color="#fff" next-margin="48rpx" previous-margin="82rpx" :disable-touch="!selfList.length || !listData.length">
        <swiper-item v-if="selfList.length">
          <view class="birthday-self-wrap">
            <image class="self-bg" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_self_bg.png" />
            <view class="self-info">
              <view class="avatar-box">
                <image class="self-info-avatar" mode="aspectFill" :src="selfList[0].headUrl" />
                <image class="self-info-hat" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_hat.png" />
              </view>
              <view class="person-name ellipsis-single">{{ selfList[0].nickName }}</view>
            </view>
            <view class="publish-btn" @click="$u.throttle(handlePublish, 1000)">发布动态</view>
          </view>
        </swiper-item>
        <!-- 好友的生日 -->
        <swiper-item v-if="listData.length">
          <view class="birthday-others-wrap">
            <image class="others-bg" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_others_bg.png" />
            <view class="person-list">
              <view class="list-item" v-for="item in listData" :key="item.numberId" @click="radioChange(item)">
                <!-- 头像 -->
                <view
                  class="avatar-wrap"
                  @click.stop="
                    $u.throttle(() => {
                      goMyPage(item)
                    }, 1000)
                  "
                >
                  <view class="avatar-box">
                    <zero-lazy-load class="avatar-box-img" :borderRadius="144" :image="item.headUrl" :height="144" imgMode="aspectFill"></zero-lazy-load>
                    <view class="avatar-box-date">{{ item.birthday || '' }}</view>
                  </view>
                  <image class="avatar-hat" v-show="item.birthday == '今天生日'" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_hat.png" />
                </view>
                <!-- 昵称 -->
                <view
                  class="person-name ellipsis-single"
                  @click.stop="
                    $u.throttle(() => {
                      goMyPage(item)
                    }, 1000)
                  "
                >
                  {{ item.nickName || '' }}
                </view>
                <!-- 勾选 -->
                <image class="person-radio" mode="aspectFill" :src="item.numberId == checkedId ? 'http://img.yiqitogether.com/static/images/messageGray/icon_checked.png' : 'http://img.yiqitogether.com/static/images/messageGray/icon_uncheck.png'" />
              </view>
            </view>
            <view style="position: relative" @click="$u.throttle(handleBless, 1000)">
              <image class="bless-tip" v-show="listData.length > 1" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_others_tip.png" />
              <image class="bless-btn" mode="aspectFill" src="http://img.yiqitogether.com/static/images/messageGray/birthday_others_btn.png" />
            </view>
          </view>
        </swiper-item>
      </swiper>
    </view>
    <view class="empty-wrap" v-if="!listData.length && !selfList.length && !showLoading">
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
      <view class="empty-text">暂无消息</view>
    </view>
    <!-- loading 弹窗 -->
    <yue-loading :mask="false" loadTxet="加载中..." v-show="showLoading"></yue-loading>
  </view>
</template>

<script>
import FindModel from '@/model/find.js'
import rongYun from '@/model/rongyun.js'
// 导入缓存工具 及 缓存字典
import { load } from '@/utils/store.js'
import { LOGIN_USERID, USER_INFO } from '@/utils/cacheKey.js'
import { unique } from '@/utils/tools'

export default {
  name: 'birthdayMessage',
  data() {
    return {
      showLoading: true,
      currNumberId: load(LOGIN_USERID) || '', // 当前登录用户id
      sendDate: null,
      listData: [], // 好友生日数据
      selfList: [], // 自己的生日数据
      checkedId: '', // 勾选id
      nowDay: '',
      sourcePage: ''
    }
  },
  onLoad(e) {
    this.sourcePage = e.sourcePage || ''
    this.sendDate = e.sendDate
    let info = load(USER_INFO) && JSON.parse(load(USER_INFO)) ? JSON.parse(load(USER_INFO)) : {}
    this.nowDay = uni.$u.timeFormat(new Date().getTime(), 'mm-dd')
    if (info.birthday && info.birthday.slice(5, 10) == this.nowDay) {
      this.selfList = [
        {
          birthday: info.birthday,
          headUrl: info.headUrl,
          nickName: info.nickName,
          numberId: info.numberId
        }
      ]
    }
    if (e.sourcePage != 'index') {
      this.getList()
    } else {
      this.showLoading = false
    }
  },
  methods: {
    // 左上角返回
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 获取生日提醒消息列表
    getList() {
      rongYun
        .getBirthdayMessageList()
        .then(res => {
          if (res.code == 'SUCCESS') {
            let list = res.data.dtoList || []
            this.listData = unique(list, 'numberId')
            this.showLoading = false
          } else {
            this.showLoading = false
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.showLoading = false
        })
    },
    // 设置
    goSetting() {
      let self = this
      uni.navigateTo({
        url: '/pagesCommon/message/messageSetting?pageTitle=生日提醒&targetNo=10011',
        events: {
          privateSettingBack: function (data) {
            self.listData = []
            self.selfList = []
          }
        }
      })
    },
    // 切换选中项
    radioChange(item) {
      this.checkedId = item.numberId
    },
    // 去个人主页
    goMyPage(item) {
      uni.navigateTo({ url: '/pagesMy/my/myHomePages/index?userId=' + item.numberId })
    },
    // 发布动态
    handlePublish() {
      let birthday = uni.$u.timeFormat(new Date().getTime(), 'mm月dd日')
      let params = {
        content: '“ 生日快乐🎂 ”',
        quoteTitle: birthday || '',
        officialTarget: 'BIRTHDAY',
        quoteJumpUrl: '/pages/my/webView',
        quoteHeadImg: this.selfList[0].headUrl || '',
        quoteContent: JSON.stringify({ type: '1', openUrl: '/giveGift/searchList/yiqi', userId: this.currNumberId })
      }
      FindModel.twitterCreate(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            uni.showToast({
              title: '发布成功',
              icon: 'none',
              mask: true
            })
            setTimeout(() => {
              // 跳转并刷新广场-最新列表
              uni.reLaunch({
                url: '/pages/find/index?checkTabCode=PUSH'
              })
            }, 800)
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {})
    },
    // 去送上祝福
    handleBless() {
      // #ifdef H5
      uni.showToast({
        title: '该操作需要在APP内进行',
        icon: 'none'
      })
      return
      // #endif
      if (!this.checkedId) {
        uni.showToast({
          title: '请先选择要送祝福的好友',
          icon: 'none'
        })
        return
      }
      getApp().globalData.webViewOption = { type: '1', openUrl: '/giveGift/searchList/yiqi', userId: this.checkedId }
      this.$nextTick(() => {
        uni.navigateTo({ url: '/pages/my/webView' })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.birthday-message-page {
  height: 100vh;
  overflow: hidden;
  background: #f6f6f8;

  .nav-container {
    width: 100%;
    height: 108rpx;
    display: flex;
    align-items: center;
    position: relative;
    z-index: 999;
    background-color: #f6f6f8;
    padding-top: var(--status-bar-height);
    border-bottom: 0.5px solid #f0f0f2;
    .nav-back {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-img {
      flex-shrink: 0;
      width: 90rpx;
      height: 90rpx;
      border-radius: 50%;
      margin-right: 24rpx;
    }
    .nav-title {
      flex: 1;
      font-size: 36rpx;
      color: #333333;
    }
    .nav-icon {
      flex-shrink: 0;
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 30rpx;
    }
  }

  .main-container {
    height: calc(100vh - var(--status-bar-height) - 110rpx);
    overflow-y: auto;
    padding-bottom: 100rpx;
    box-sizing: border-box;
    .receive-time {
      font-size: 24rpx;
      text-align: center;
      color: #adb3ba;
      line-height: 32rpx;
      padding: 44rpx 0 52rpx;
      margin: 0 auto;
    }

    .swiper-wrap {
      width: 100%;
      height: 1218rpx;

      /deep/.uni-swiper-dot {
        width: 12rpx;
        height: 12rpx !important;
      }
      /deep/ .uni-swiper-dot-active {
        width: 60rpx;
        height: 12rpx;
        border-radius: 6rpx;
      }

      .birthday-self-wrap {
        width: 588rpx;
        height: 1162rpx;
        border-radius: 20rpx;
        position: relative;

        .self-bg {
          width: 588rpx;
          height: 1162rpx;
          border-radius: 20rpx;
          position: absolute;
          top: 0;
          left: 0;
          z-index: -1;
        }
        .self-info {
          padding-top: 330rpx;
          text-align: center;

          .avatar-box {
            position: relative;
            font-size: 0;
            width: 144rpx;
            height: 144rpx;
            margin: 0 auto;

            .self-info-avatar {
              width: 100%;
              height: 100%;
              border-radius: 50%;
            }
            .self-info-hat {
              width: 88rpx;
              height: 88rpx;
              position: absolute;
              left: 56rpx;
              top: -52rpx;
            }
          }
        }
      }

      .birthday-others-wrap {
        width: 588rpx;
        height: 1162rpx;
        background: linear-gradient(180deg, #ffffff, #ffffff 30%, #ffffff);
        border-radius: 20rpx;

        .others-bg {
          width: 588rpx;
          height: 328rpx;
          display: block;
        }
      }

      .person-name {
        width: 140rpx;
        height: 40rpx;
        font-size: 28rpx;
        color: #2a343e;
        line-height: 40rpx;
        text-align: center;
        margin: 24rpx auto 0;
      }

      .person-list {
        width: 100%;
        height: 596rpx;
        overflow-y: auto;
        padding: 0 30rpx;
        box-sizing: border-box;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;

        .list-item {
          margin: 60rpx 16rpx 0;
          text-align: center;

          .avatar-wrap {
            position: relative;
            margin: 0 auto;
            .avatar-box {
              width: 144rpx;
              height: 144rpx;
              border-radius: 50%;
              overflow: hidden;
              position: relative;
              .avatar-box-img {
                width: 144rpx;
                height: 144rpx;
                background: #d8d8d8;
                border-radius: 50%;
                display: block;
              }
              .avatar-box-date {
                position: absolute;
                top: 104rpx;
                width: 142rpx;
                height: 54rpx;
                background: rgba(0, 0, 0, 0.5);
                font-size: 22rpx;
                color: #ffffff;
                line-height: 32rpx;
                text-align: center;
              }
            }
            .avatar-hat {
              width: 88rpx;
              height: 88rpx;
              position: absolute;
              left: 56rpx;
              top: -52rpx;
            }
          }
          .person-radio {
            width: 28rpx;
            height: 28rpx;
            margin-top: 6px;
          }
        }
      }

      .publish-btn {
        width: 452rpx;
        height: 82rpx;
        display: block;
        margin: 452rpx auto 0;
        background-image: url(http://img.yiqitogether.com/static/images/messageGray/birthday_self_btn.png);
        background-size: 100% 100%;
        font-size: 32rpx;
        text-align: center;
        color: #ffffff;
        line-height: 82rpx;
      }
      .bless-btn {
        width: 452rpx;
        height: 146rpx;
        display: block;
        margin: 0 auto;
      }
      .bless-tip {
        width: 196rpx;
        height: 48rpx;
        position: absolute;
        top: 12rpx;
        right: 180rpx;
      }
    }
  }

  .empty-wrap {
    margin: 272rpx auto 0;
    text-align: center;
    font-size: 0;
    .empty-img {
      width: 212rpx;
      height: 212rpx;
      background-size: cover;
    }
    .empty-text {
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
    }
  }
}
</style>
