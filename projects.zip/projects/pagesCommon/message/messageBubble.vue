<template>
  <view class="message-bubble-page">
    <view class="nav-container">
      <image class="nav-icon" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" @click="goBack" />
      <view class="nav-title">气泡</view>
      <view class="nav-btn" v-show="currName != 'bubbleOrange'" @click="showRestore = true">恢复默认</view>
    </view>
    <view class="main-container">
      <view class="list-wrap">
        <view class="list-item" v-for="(item, index) in listData" :key="item.id" @click="handleDress(item)">
          <view class="list-item-card">
            <image class="bubble-img" :style="item.name == 'bubblePanghuhu' ? 'background: #f0f0f0' : ''" :src="item.imgUrl" mode="aspectFill" />
            <view class="bubble-status" v-show="item.name == currName">正在使用</view>
          </view>
          <view class="list-item-bottom">
            <view class="normal-txt" v-if="index == 0">默认气泡</view>
            <!-- <view class="btn-box active" v-if="index != 0 && !item.isDownload" @click="changeStatus(index)">
              <image class="download-icon" src="@/static/images/icon_download_black.png" mode="aspectFill" />
            </view> -->
            <view :class="['btn-box', item.name == currName ? 'disactive' : 'active']" v-else>{{ item.name == currName ? '已装扮' : '装扮' }}</view>
          </view>
        </view>
      </view>
    </view>
    <custom-modal type="tipsConfirm" :show="showDress" title="提示" content="确认使用此气泡吗?" @cancel="showDress = false" @confirm="confirmUse" />
    <custom-modal type="tipsConfirm" :show="showRestore" title="提示" content="确认恢复默认?" @cancel="showRestore = false" @confirm="confirmRestore" />
  </view>
</template>

<script>
import MyInfo from '@/model/my.js'
// 导入缓存工具 及 缓存字典
import { load, save } from '@/utils/store.js'
import { SELFBUBBLE } from '@/utils/cacheKey.js'

export default {
  name: 'messageBubble',
  data() {
    return {
      currName: 'bubbleOrange',
      tempName: 'bubbleOrange',
      showDress: false,
      showRestore: false,
      listData: [
        { id: 0, name: 'bubbleOrange', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/orange.png', isDownload: false },
        { id: 1, name: 'bubblePink', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/pink.png', isDownload: false },
        { id: 2, name: 'bubbleBlue', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/blue.png', isDownload: false },
        { id: 3, name: 'bubblePurple', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/purple.png', isDownload: false },
        { id: 4, name: 'bubbleTianxintang', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/tianxintang.png', isDownload: false },
        { id: 5, name: 'bubbleCaihongxiaoma', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/caihongxiaoma.png', isDownload: false },
        { id: 6, name: 'bubblePanghuhu', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/panghuhu.png', isDownload: false },
        { id: 7, name: 'bubbleWulikanhua', imgUrl: 'http://img.yiqitogether.com/static/images/messageBubble/wulikanhua.png', isDownload: false }
      ]
    }
  },
  onLoad() {
    this.currName = load(SELFBUBBLE) || 'bubbleOrange'
  },
  methods: {
    /**
     * 返回
     */
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    // 装扮
    handleDress(item) {
      if (item.name == this.currName || item.name == 'bubbleOrange') {
        return
      }
      this.tempName = item.name
      this.showDress = true
    },
    // 装扮-确认
    confirmUse() {
      this.handleSetBubble(this.tempName)
    },
    // 恢复默认-确认
    confirmRestore() {
      this.handleSetBubble('bubbleOrange')
    },
    // 设置气泡
    handleSetBubble(bubbleName) {
      MyInfo.addBubble({ bubble: bubbleName })
        .then(res => {
          this.showRestore = false
          this.showDress = false
          if (res.code == 'SUCCESS') {
            this.currName = bubbleName
            save(SELFBUBBLE, bubbleName)
            uni.showToast({
              title: '装扮气泡成功',
              icon: 'none'
            })
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.showRestore = false
          this.showDress = false
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.message-bubble-page {
  height: 100vh;
  overflow: hidden;
  background: #f6f6f8;
  position: relative;

  .nav-container {
    width: 100%;
    height: 88rpx;
    position: relative;
    display: flex;
    align-items: center;
    z-index: 999;
    padding-top: var(--status-bar-height);
    background-color: #f6f6f8;
    .nav-icon {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
      flex-shrink: 0;
    }
    .nav-title {
      flex: 1;
      font-size: 36rpx;
      color: #333;
    }
    .nav-btn {
      flex-shrink: 0;
      font-size: 28rpx;
      color: #fe5e10;
      line-height: 40rpx;
      padding: 22rpx 36rpx;
    }
  }

  .main-container {
    padding: 6rpx 26rpx;
    box-sizing: border-box;

    .list-wrap {
      display: flex;
      flex-wrap: wrap;

      .list-item {
        margin: 24rpx 10rpx;

        .list-item-card {
          width: 212rpx;
          height: 212rpx;
          background: #ffffff;
          border-radius: 16rpx;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;

          .bubble-img {
            width: 212rpx;
            height: 212rpx;
            border-radius: 16rpx;
          }

          .bubble-status {
            width: 96rpx;
            height: 32rpx;
            background: #f78045;
            border-radius: 0 16rpx 0 16rpx;
            position: absolute;
            top: 0;
            right: 0;
            font-size: 18rpx;
            color: #ffffff;
            line-height: 30rpx;
            text-align: center;
          }
        }
        .list-item-bottom {
          margin-top: 16rpx;
          text-align: center;

          .normal-txt {
            font-size: 32rpx;
            color: #4e4e4e;
            line-height: 44rpx;
          }
          .btn-box {
            width: 112rpx;
            height: 44rpx;
            border-radius: 24rpx;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24rpx;
            margin: 0 auto;

            .download-icon {
              width: 44rpx;
              height: 44rpx;
            }
          }
          .active {
            border: 1rpx solid #c5c5c5;
            color: #4e4e4e;
          }
          .disactive {
            border: 1rpx solid #c5c5c5;
            color: #c5c5c5;
          }
        }
      }
    }
  }
}
</style>
