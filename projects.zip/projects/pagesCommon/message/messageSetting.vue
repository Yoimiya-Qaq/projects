<template>
  <view class="message-setting-page">
    <view class="nav-container">
      <image class="nav-back" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" @click="goBack" />
      <view class="nav-title">设置</view>
    </view>
    <view class="main-container">
      <view class="top-wrap">
        <image class="left-img" :src="pageIcon" alt="" />
        <view class="right-title">{{ pageTitle }}</view>
      </view>
      <view class="space-box"></view>
      <view class="cell-box">
        <view class="left-title">消息免打扰</view>
        <u-switch v-model="isDistrub" size="36" activeColor="#FE5E10" inactiveColor="#dcdee1" @change="handleDistrub"></u-switch>
      </view>
      <view class="cell-box">
        <view class="left-title">设为置顶</view>
        <u-switch v-model="isTop" size="36" activeColor="#FE5E10" inactiveColor="#dcdee1" @change="handleTop"></u-switch>
      </view>
      <view class="space-box"></view>

      <!-- 清空聊天记录 -->
      <view class="cell-box" @click="showClear = true">
        <view class="left-title">清空聊天记录</view>
        <image class="right-arrow" src="https://img.yiqitogether.com/static/local/myImages/goTo@2x.png" alt="" />
      </view>
      <view class="space-box"></view>
    </view>
    <!-- 清空聊天记录弹框 -->
    <custom-modal type="tipsConfirm" :show="showClear" :round="24" title="是否清空本地历史消息?" content="将清空此会话的本地历史消息，但不删除此会话。" confirmText="确认" @cancel="showClear = false" @confirm="confirmClear" />
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import rongYun from '@/model/rongyun.js'

export default {
  name: 'groupChatSetting',
  data() {
    return {
      pageTitle: '',
      pageIcon: '',
      otherUserId: '',
      isDistrub: false, // 消息免打扰
      isTop: false, // 置顶
      showClear: false // 清空聊天记录弹窗
    }
  },
  onLoad(e) {
    this.pageTitle = e.pageTitle || ''
    this.otherUserId = e.targetNo || ''
    this.getPageIcon(this.pageTitle)
    this.getInfo()
    this.getDistrubState()
  },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    getPageIcon(title) {
      switch (title) {
        case '生日提醒':
          this.pageIcon = 'http://img.yiqitogether.com/static/images/messageGray/private_birthday.png'
          break
        case '一起钱包':
          this.pageIcon = 'http://img.yiqitogether.com/static/images/messageGray/private_wallet.png'
          break
        case '积分中心':
          this.pageIcon = 'http://img.yiqitogether.com/static/images/messageGray/private_integration.png'
          break
        default:
          break
      }
    },
    // 获取状态
    getInfo() {
      rongYun
        .getUserMianInfo({
          targetNumberId: this.otherUserId
        })
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.isDistrub = res.data.distrub
            this.isTop = res.data.top
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
    },
    // 获取免打扰状态
    async getDistrubState() {
      // #ifdef APP-PLUS
      this.$store.state.engie.setOnConversationNotificationLevelLoadedListener(res => {
        this.isDistrub = res.level == 5 ? true : false
      })
      let callback = await this.$store.state.engie.getConversationNotificationLevel(1, this.otherUserId, null)
      // #endif
    },
    // 消息免打扰
    handleDistrub(val) {
      // #ifdef APP-PLUS
      let params = {
        targetNumberId: this.otherUserId,
        distrub: val
      }
      let flag = val ? 5 : 0
      this.$store.state.engie.changeConversationNotificationLevel(1, this.otherUserId, null, flag).then(ress => {
        rongYun.getDistrub(params).then(res => {
          if (res.code == 'SUCCESS') {
            try {
              let pages = getCurrentPages()
              let index = pages.findIndex(item => item.$page.route == 'pages/message/index')
              pages[index].$vm.refreshList()
            } catch (error) {}
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      })
      // #endif
    },
    // 设为置顶
    handleTop(val) {
      // #ifdef APP-PLUS
      let params = {
        targetNumberId: this.otherUserId,
        top: val
      }
      this.$store.state.engie.changeConversationTopStatus(1, this.otherUserId, null, val).then(ress => {
        rongYun.getTop(params).then(res => {
          if (res.code == 'SUCCESS') {
            try {
              let pages = getCurrentPages()
              let index = pages.findIndex(item => item.$page.route == 'pages/message/index')
              pages[index].$vm.refreshList()
            } catch (error) {}
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      })
      // #endif
    },
    // 清空聊天记录-确定
    async confirmClear() {
      // #ifdef APP-PLUS
      this.$store.state.engie.setOnMessagesClearedListener(res => {})
      let code = await this.$store.state.engie.clearMessages(1, this.otherUserId, null, 0, 2)
      if (code == 0) {
        // 调清空本地列表接口
        this.handleClear()
      }
      // #endif
      this.showClear = false
    },
    // 删除会话列表
    handleClear() {
      let params = {
        type: 'clear',
        userId: this.otherUserId
      }
      rongYun.deleteDialog(params).then(res => {
        if (res.code == 'SUCCESS') {
          uni.showToast({
            title: '清空聊天记录成功',
            icon: 'none'
          })
          let eventChannel = this.getOpenerEventChannel()
          eventChannel.emit('privateSettingBack', { data: '清空聊天记录成功' })
          setTimeout(() => {
            uni.navigateBack()
          }, 800)
        } else {
          this.$refs.uToast.show({
            ...res
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.message-setting-page {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  background-color: #fff;
  .nav-container {
    width: 100%;
    height: 88rpx;
    position: relative;
    display: flex;
    align-items: center;
    z-index: 999;
    padding-top: var(--status-bar-height);
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 0 24rpx;
    }
    .nav-title {
      font-size: 36rpx;
      color: #333333;
    }
  }

  .main-container {
    height: calc(100vh - var(--status-bar-height) - 88rpx);
    overflow-y: auto;
    padding-bottom: 50rpx;
    box-sizing: border-box;

    .top-wrap {
      display: flex;
      align-items: center;
      padding: 40rpx 36rpx 60rpx;

      .left-img {
        width: 90rpx;
        height: 90rpx;
        margin-right: 24rpx;
      }
      .right-title {
        font-size: 28rpx;
        color: #2a343e;
      }
    }

    .space-box {
      width: 100%;
      height: 12rpx;
      background: #f7f7f7;
    }

    .cell-box {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 30rpx 36rpx;
    }
    .left-title {
      flex-shrink: 0;
      font-size: 28rpx;
      color: #2a343e;
      line-height: 36rpx;
    }
    .right-arrow {
      flex-shrink: 0;
      width: 14rpx;
      height: 24rpx;
      padding-left: 20rpx;
      padding-right: 2rpx;
    }
  }
}
</style>
