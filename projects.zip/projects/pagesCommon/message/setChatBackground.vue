<template>
  <view class="set-chat-background-page">
    <view class="nav-container">
      <image class="nav-icon" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode="" @click="goBack" />
      <view class="nav-title">选择背景图</view>
      <view class="nav-btn" :style="disabled ? 'background: #f0f1f3' : 'background: #fe5e10'" @click="$u.throttle(handleFinish, 500)">完成</view>
    </view>
    <view class="main-container">
      <view class="list-wrap">
        <view class="list-item" v-for="item in listData" :key="item.id" @click="handleChange(item)">
          <image class="list-item-img" :src="item.imgUrl" mode="aspectFill" />
          <view class="list-item-bottom" v-if="item.id == currId" :style="item.id == currId ? 'background: #f78045;opacity: 1' : 'background:#bfbfbf; opacity: 0.5'">
            <image class="list-item-icon" src="@/static/images/chat_icon_tick.png" mode="aspectFill" />
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import rongYun from '@/model/rongyun.js'

export default {
  name: 'setChatBackground',
  data() {
    return {
      currId: 0,
      currImg: '',
      targetNo: '',
      chatType: 1, // 1-私聊 2-群聊
      disabled: true,
      listData: [
        { id: 0, imgUrl: '' },
        { id: 1, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_01.png' },
        { id: 2, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_02.png' },
        { id: 3, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_03.png' },
        { id: 4, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_04.png' },
        { id: 5, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_05.png' },
        { id: 6, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_06.png' },
        { id: 7, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_07.png' },
        { id: 8, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_08.png' },
        { id: 9, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_09.png' },
        { id: 10, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_10.png' },
        { id: 11, imgUrl: 'http://img.yiqitogether.com/static/images/messageChatBg/bg_11.png' }
      ]
    }
  },
  onLoad(e) {
    this.targetNo = e.targetNo
    this.chatType = e.chatType
    if (e.bgUrl) {
      this.listData.map(item => {
        if (item.imgUrl == e.bgUrl) {
          this.currId = item.id
          this.currImg = item.imgUrl
          this.disabled = false
        }
      })
    }
  },
  methods: {
    /**
     * 返回
     */
    goBack() {
      uni.navigateBack({ delta: 1 })
    },
    handleChange(item) {
      this.disabled = false
      this.currId = item.id || 0
      this.currImg = item.imgUrl
    },
    /**
     * 完成
     */
    handleFinish() {
      if (this.disabled) {
        return
      }
      rongYun.editBackGroundUrl({ targetNo: this.targetNo, backGroundUrl: this.currImg }).then(res => {
        if (res.code == 'SUCCESS') {
          uni.showToast({
            title: '更新聊天背景成功',
            icon: 'none'
          })
          try {
            // 更新私聊页面背景图
            let pages = getCurrentPages()
            if (this.chatType == 2) {
              let groupChatIndex = pages.findIndex(item => item.$page.route == 'pagesMessage/groupChat/index')
              pages[groupChatIndex].$vm.refreshBg(this.currImg)
            } else {
              let privateChatIndex = pages.findIndex(item => item.$page.route == 'pagesMessage/privateChat/index')
              pages[privateChatIndex].$vm.refreshBg(this.currImg)
            }
          } catch (error) {}
          setTimeout(() => {
            uni.navigateBack({ delta: 2 })
          }, 500)
        } else {
          uni.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.set-chat-background-page {
  height: 100vh;
  overflow: hidden;
  background: #ffffff;
  position: relative;

  .nav-container {
    width: 100%;
    height: 88rpx;
    position: relative;
    display: flex;
    align-items: center;
    z-index: 999;
    padding-top: var(--status-bar-height);
    background-color: #fff;
    .nav-icon {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
      flex-shrink: 0;
    }
    .nav-title {
      flex: 1;
      font-size: 36rpx;
      color: #333;
    }
    .nav-btn {
      flex-shrink: 0;
      font-size: 32rpx;
      color: #fff;
      line-height: 44rpx;
      padding: 8rpx 24rpx;
      border-radius: 30rpx;
      margin: 0 36rpx;
    }
  }

  .main-container {
    padding: 12rpx 32rpx;
    box-sizing: border-box;

    .list-wrap {
      display: flex;
      flex-wrap: wrap;

      .list-item {
        position: relative;
        margin: 12rpx 4rpx;
        font-size: 0;
        .list-item-img {
          width: 220rpx;
          height: 220rpx;
          background: #f6f6f8;
          border-radius: 16rpx;
        }
        .list-item-bottom {
          position: absolute;
          bottom: 0;
          left: 0;
          width: 220rpx;
          height: 30rpx;
          border-radius: 0 0 16rpx 16rpx;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .list-item-icon {
          width: 20rpx;
          height: 20rpx;
        }
      }
    }
  }
}
</style>
