<template>
  <view class="system-message-page">
    <view class="nav-container">
      <image @click="goBack()" class="nav-back" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      <view class="nav-title">系统消息</view>
      <image @click="isdelete = true" class="nav-btn" src="https://img.yiqitogether.com/static/local/index/del@2x.png" mode=""></image>
    </view>
    <scroll-view class="main-container" id="mainContainer" scroll-y="true" :scroll-top="scrollTop" @scrolltoupper="lower()">
      <view class="list-wrap" id="scrollBox">
        <view style="width: 100%; height: 40rpx"></view>
        <view class="list-item" v-for="(item, index) in actionData" :key="index">
          <view v-if="item.iscreateTime" class="send-time">{{ $u.timeFormat(item.newCreateTime, 'sendMsgFormat') }}</view>
          <view class="item-card">
            <view class="card-top">
              <image class="card-avatar" :src="item.senderImg || defaultAvatar" mode="aspectFill" />
              <view>系统通知</view>
            </view>
            <view
              class="card-bottom"
              @click="
                $u.throttle(() => {
                  toWebView(item)
                }, 500)
              "
            >
              <view v-if="item.title" class="message-title">{{ item.title }}</view>
              <view class="message-content">{{ item.content }}</view>
              <view class="btn-box" v-if="item.jumpUrl">
                <view class="view-btn">立即查看</view>
              </view>
            </view>
          </view>
        </view>
        <image v-if="actionData.length == 0" class="qs-image" src="https://img.yiqitogether.com/static/local/index/qs_wuxiaoxi@2x.png"></image>
      </view>
    </scroll-view>
    <!-- 清空弹窗 -->
    <custom-modal type="tipsConfirm" :show="isdelete" title="提示" content="是否清空历史消息？" @cancel="isdelete = false" @confirm="confirmEnd" />
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import IndexModel from '@/model/index'
export default {
  data() {
    return {
      actionData: [],
      pageNumber: 1,
      pages: 1,
      isdelete: false,
      scrollTop: 0,
      scrollBoxHeight: 0,
      // 是否滚动到聊天底部，第一次已经自己发消息时设置为true
      isScroll: true,
      defaultAvatar: 'http://img.yiqitogether.com/static/images/messageGray/private_system.png'
    }
  },
  watch: {
    actionData: function () {
      if (this.isScroll) {
        this.isScroll = false
        // 首次进来滚动
        this.scrollToBottom()
      }
    }
  },
  onLoad() {
    this.getMessage()
  },
  // onBackPress(e) {
  //   let eventChannel = this.getOpenerEventChannel()
  //   eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //   return false
  // },
  // onUnload() {
  //   let that = this
  //   if (uni.getSystemInfoSync().platform == 'ios') {
  //     try {
  //       let eventChannel = this.getOpenerEventChannel()
  //       eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //     } catch (error) {}
  //   }
  // },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    // 获取列表数据
    getMessage() {
      let datas = {
        messageType: 'SYSTEM',
        pageNo: this.pageNumber,
        pageSize: 10
      }
      IndexModel.innerMessage(datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          let actions = dataRes.data.pager.list
          this.actionData = [...actions.reverse(), ...this.actionData]
          this.pageNumber = dataRes.data.pager.pageNumber
          this.pages = dataRes.data.pager.pages
          this.actionDataFun()
          if (this.pageNumber > 1) {
            this.$nextTick(() => {
              this.regainScrollBoxHeight()
            })
          }
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
        }
      })
    },
    actionDataFun() {
      if (this.actionData.length > 0) {
        this.actionData.forEach((item, index) => {
          if (index != 0 && item.createTime == this.actionData[index - 1].createTime) {
            item.iscreateTime = false
          } else {
            item.iscreateTime = true
          }
        })
      }
    },
    // 上拉加载数据
    lower() {
      if (this.pageNumber < this.pages) {
        this.pageNumber++
        this.getMessage()
      }
    },
    // 滚动至聊天底部
    scrollToBottom() {
      setTimeout(() => {
        let query = uni.createSelectorQuery().in(this)
        query.select('#mainContainer').boundingClientRect()
        query.select('#scrollBox').boundingClientRect()
        query.exec(res => {
          if (res && res[1].height > res[0].height) {
            this.scrollBoxHeight = res[1].height
            this.scrollTop = res[1].height - res[0].height
          }
        })
      }, 500)
    },
    // 滚动盒子高度变化后保持滚动位置不变
    regainScrollBoxHeight() {
      let query = uni.createSelectorQuery().in(this)
      query
        .select('#scrollBox')
        .boundingClientRect(data => {
          let scrollH = data.height // 滚动视图高度
          this.scrollTop = scrollH - this.scrollBoxHeight
          this.scrollBoxHeight = scrollH
        })
        .exec()
    },
    // 清空历史消息
    confirmEnd() {
      this.isdelete = false
      if (this.actionData.length > 0) {
        let datas = {}
        IndexModel.deleteMessage(datas).then(res => {
          if (res.code == 'SUCCESS') {
            this.actionData.splice(0, this.actionData.length)
          } else {
            this.$refs.uToast.show({
              ...res
            })
          }
        })
      }
    },
    // 跳转外部链接
    toWebView(item) {
      if (!item.jumpUrl) {
        return
      }
      if (!/^http/.test(item.jumpUrl)) {
        uni.navigateTo({
          url: item.jumpUrl,
          fail: err => {
            uni.showToast({
              title: '当前版本暂不支持',
              icon: 'none'
            })
          }
        })
      } else {
        uni.navigateTo({
          url: '/pagesSetting/setting/webView?url=' + item.jumpUrl,
          fail: err => {
            uni.showToast({
              title: '当前版本暂不支持',
              icon: 'none'
            })
          }
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.system-message-page {
  background-color: #f6f7f8;
  overflow-y: hidden;
  height: 100vh;
  position: relative;
}
.nav-container {
  width: 100%;
  height: 88rpx;
  background-color: #fff;
  position: relative;
  padding-top: var(--status-bar-height);
  z-index: 99;
  display: flex;
  align-items: center;
  .nav-back {
    width: 44rpx;
    height: 44rpx;
    padding: 22rpx 24rpx;
    flex-shrink: 0;
  }
  .nav-title {
    flex: 1;
    font-size: 36rpx;
    color: #333333;
  }
  .nav-btn {
    width: 44rpx;
    height: 44rpx;
    padding: 22rpx 30rpx;
    flex-shrink: 0;
  }
}
.main-container {
  height: calc(100vh - var(--status-bar-height) - 88rpx);
}
.list-wrap {
  background: #f6f7f8;
  .list-item {
    box-sizing: border-box;
    padding: 0 40rpx 30rpx;

    .send-time {
      font-size: 24rpx;
      font-weight: 500;
      text-align: center;
      color: #adb3ba;
      margin-bottom: 30rpx;
    }
    .item-card {
      background: #ffffff;
      border-radius: 20rpx;
      padding: 0 24rpx;

      .card-top {
        display: flex;
        align-items: center;
        font-size: 28rpx;
        color: #2a343e;
        padding: 28rpx 0 14rpx;
        border-bottom: 0.5px solid #f0f1f3;
        .card-avatar {
          flex-shrink: 0;
          width: 60rpx;
          height: 60rpx;
          border-radius: 50%;
          margin-right: 16rpx;
        }
      }

      .card-bottom {
        background-color: #fff;
        border-radius: 16rpx;
        padding: 30rpx 16rpx;
        box-sizing: border-box;
        .message-title {
          font-weight: bold;
          font-size: 32rpx;
          color: #1c1c1c;
          line-height: 44rpx;
          margin-bottom: 12rpx;
        }
        .message-content {
          font-size: 28rpx;
          color: #1c1c1c;
          line-height: 40rpx;
          white-space: pre-wrap;
          word-wrap: break-word;
          word-break: break-all;
        }
      }
    }
  }
}
.qs-image {
  width: 310rpx;
  height: 310rpx;
  display: block;
  margin: 300rpx auto 40rpx;
}
.btn-box {
  margin-top: 36rpx;
  .view-btn {
    width: 144rpx;
    height: 56rpx;
    border: 1rpx solid #fe5e10;
    border-radius: 30rpx;
    font-size: 24rpx;
    color: #fe5e10;
    line-height: 34rpx;
    text-align: center;
    line-height: 56rpx;
    background-color: #fff;
  }
}
</style>
