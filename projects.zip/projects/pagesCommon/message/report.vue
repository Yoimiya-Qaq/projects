<template>
  <view class="report-page">
    <view class="status-bar"></view>
    <view class="details-nav">
      <view class="back-info" @click="goBack()">
        <image class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      </view>
      <view class="details-nav-content">举报</view>
    </view>
    <!-- 内容区域 -->
    <view class="main-container">
      <!-- 举报类型 -->
      <view class="report-type">
        <view class="report-type-title">举报类型</view>
        <view class="report-type-content">
          <view v-for="(item, index) in reportTypeList" :key="index" @click="selectedFun(item)" :class="isSelected == item.code ? 'report-type-infois' : 'report-type-info'">{{ item.text }}</view>
        </view>
      </view>
      <!-- 举报内容 -->
      <view class="initiate-info">
        <view class="initiate-info-title">请填写举报内容</view>
        <view class="initiate-info-textarea">
          <u-textarea height="300" confirm-type="done" v-model.trim="textareavalue" maxlength="500" placeholder="" count></u-textarea>
        </view>
        <view class="initiate-info-title">上传图片</view>
        <view class="initiate-info-upload">
          <u-upload :fileList="fileList1" @afterRead="afterRead" @delete="deletePic" name="1" width="200" height="200" :maxCount="3" :previewFullImage="true" multiple>
            <image src="https://img.yiqitogether.com/static/local/index/tjzp@2x.png" mode="aspectFill" style="width: 200rpx; height: 200rpx"></image>
          </u-upload>
          <view class="mask_box" v-if="!isPermission" @click="accreditBtn"></view>
        </view>
      </view>
      <!-- 投诉热线 -->
      <view class="report-phone">违规内容投诉热线:021-6239 0178</view>
      <view v-if="isSelected" class="report-button" @click="reportInfoFun()">提交</view>
      <view v-if="!isSelected" class="report-button" style="background-color: #ffe2e8">提交</view>
    </view>
    <u-toast ref="uToast"></u-toast>

    <!-- 相册权限弹窗 -->
    <system-popup systemTitle="“一起一起”想访问您的相册" systemContent="用于使用上传照片功能" :isShowSystem="showAccredit" @cancelPoPup="closeBtn" @submitPopup="permitBtn"></system-popup>
  </view>
</template>

<script>
import IndexModel from '@/model/index'
import { uploadFile } from '@/utils/tools'
// APP判断权限
import permision from '@/js_sdk/wa-permission/permission.js'
// 导入缓存工具 及 缓存字典
import { save, load } from '@/utils/store.js'
import { EXTERNAL_STORAGE } from '@/utils/cacheKey.js'
export default {
  data() {
    return {
      // 是否已授权
      isPermission: true,
      // 授权弹窗 显示
      showAccredit: false,
      userId: '',
      groupNo: '',
      textareavalue: '',
      fileList1: [],
      reportTypeList: [],
      isSelected: '',
      reportTargetType: '', // 被举报目标的类型
      targetId: '' // 被举报目标的ID
    }
  },
  onLoad(e) {
    if (e.userId) {
      this.userId = e.userId
      this.getReportType()
    }
    this.reportTargetType = e.reportTargetType || ''
    this.targetId = e.targetId || ''
    this.isUploadMask()
  },
  methods: {
    /**
     * 判断是否需要蒙版
     */
    isUploadMask() {
      // #ifdef APP-PLUS
      let isIos = plus.os.name == 'iOS'
      if (!isIos) {
        if (load(EXTERNAL_STORAGE) !== '' && load(EXTERNAL_STORAGE)) {
          this.isPermission = true
        } else {
          this.isPermission = false
        }
      }
      // #endif
    },
    /**
     *  获取授权状态
     */
    async requestAndroidPermission(permisionID) {
      var result = await permision.requestAndroidPermission(permisionID)
      if (result == 1) {
        save(EXTERNAL_STORAGE, true)
        this.isPermission = true
      }
      this.showAccredit = false
    },
    /**
     * 上传的蒙版点击事件
     */
    accreditBtn() {
      this.showAccredit = true
    },
    /**
     * 授权框 同意按钮
     */
    permitBtn() {
      // 获取授权状态 外部存储(含相册)读取权限
      this.requestAndroidPermission('android.permission.READ_EXTERNAL_STORAGE')
    },
    /**
     * 授权框 拒绝按钮
     */
    closeBtn() {
      this.showAccredit = false
    },
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    // 获取举报类型
    getReportType() {
      IndexModel.getReportType().then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          this.reportTypeList = dataRes.data.reportType || []
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
        }
      })
    },
    // 选择举报类型
    selectedFun(item) {
      this.isSelected = item.code
    },
    // 上传图片
    async afterRead(e) {
      let list = e.file || []
      let arr = list.filter(item => item.url.includes('heic'))
      if (arr.length > 0) {
        uni.showToast({
          title: '暂不支持上传HEIC格式的文件',
          icon: 'none',
          duration: 2000
        })
      }
      list = list.filter(item => !item.url.includes('heic'))
      for (let i = 0; i < list.length; i++) {
        let imgUrl = await uploadFile(list[i].url)
        this.fileList1.push({ url: imgUrl })
      }
    },
    // 删除图片
    deletePic(event) {
      this[`fileList${event.name}`].splice(event.index, 1)
    },
    // 提交
    reportInfoFun() {
      if (this.isSelected == '') {
        uni.showToast({
          title: '请先选择举报类型',
          icon: 'none',
          duration: 1000
        })
        return
      }
      // if (this.textareavalue.replace(/\ +/g, '') == '') {
      //   uni.showToast({
      //     title: '请先输入举报内容',
      //     icon: 'none',
      //     duration: 1000
      //   })
      //   return
      // }
      // if (this.fileList1.length == 0) {
      //   uni.showToast({
      //     title: '请先上传举报照片',
      //     icon: 'none',
      //     duration: 1000
      //   })
      //   return
      // }
      let picss = this.fileList1.map(item => item.url).join('&&')
      let datas = {
        reportType: this.isSelected,
        content: this.textareavalue,
        reportImg: picss,
        reportedPerson: this.userId,
        reportTargetType: this.reportTargetType,
        targetId: this.targetId
      }
      IndexModel.reportAddInfo(datas).then(dataRes => {
        if (dataRes.code == 'SUCCESS') {
          uni.showToast({
            title: '举报成功',
            icon: 'none',
            duration: 1000
          })
          setTimeout(() => {
            uni.navigateBack()
          }, 1000)
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.report-page {
  height: 100vh;
  background-color: #f6f7f8;
  overflow: hidden;

  .status-bar {
    width: 100%;
    height: var(--status-bar-height);
    background-color: #fff;
  }
  .details-nav {
    width: 100%;
    height: 88rpx;
    background-color: rgba(255, 255, 255, 1);
    position: relative;
    z-index: 99;
    .back-info {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
      position: absolute;
      left: 0;
      top: 0;
      z-index: 99;
      .back-image {
        width: 100%;
        height: 100%;
      }
    }
    .details-nav-content {
      width: 100%;
      font-size: 36rpx;
      font-weight: 500;
      text-align: center;
      line-height: 88rpx;
      color: #333333;
    }
  }

  .main-container {
    height: calc(100vh - 88rpx - var(--status-bar-height));
    overflow-y: auto;
    padding: 20rpx 20rpx 100rpx;
    box-sizing: border-box;

    .report-type {
      width: 100%;
      padding: 10rpx 24rpx;
      box-sizing: border-box;
      background-color: #fff;
      border-radius: 24rpx;
      margin-bottom: 20rpx;
      .report-type-title {
        width: 100%;
        padding: 30rpx 0;
        font-size: 28rpx;
        color: #333333;
      }
      .report-type-content {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        .report-type-info {
          height: 60rpx;
          padding: 0 20rpx;
          font-size: 24rpx;
          font-weight: 400;
          text-align: center;
          line-height: 60rpx;
          color: #adb3ba;
          background-color: #f6f7f8;
          margin: 0 30rpx 30rpx 0;
          border-radius: 30rpx;
        }
        .report-type-infois {
          height: 60rpx;
          padding: 0 20rpx;
          font-size: 24rpx;
          font-weight: 400;
          text-align: center;
          line-height: 60rpx;
          color: #fff;
          background-color: #fe5e10;
          margin: 0 30rpx 30rpx 0;
          border-radius: 30rpx;
        }
      }
    }

    .initiate-info {
      width: 100%;
      padding: 10rpx 24rpx 20rpx;
      box-sizing: border-box;
      background-color: #fff;
      border-radius: 24rpx;
      .initiate-info-title {
        width: 100%;
        padding: 30rpx 0;
        font-size: 28rpx;
        font-weight: 500;
        text-align: left;
        color: #333333;
      }
      .initiate-info-textarea {
        width: 100%;
        background-color: #f6f7f8;
        border-radius: 8rpx;
        .u-textarea {
          border: none;
          background-color: #f6f7f8 !important;
          /deep/.u-textarea__count {
            background-color: #f6f7f8 !important;
          }
        }
      }
      .initiate-info-upload {
        position: relative;
        width: 100%;
        box-sizing: border-box;
        /deep/.u-upload__wrap__preview {
          margin-bottom: 0;
        }
        /deep/ .uicon-close {
          font-size: 28rpx !important;
        }

        /deep/ .u-upload__deletable__icon {
          right: -2rpx;
          top: 6rpx;
        }
      }
    }
    .report-phone {
      width: 100%;
      font-size: 24rpx;
      font-weight: 400;
      text-align: center;
      color: #adb3ba;
      margin: 40rpx auto 60rpx;
    }
    .report-button {
      width: 100%;
      height: 84rpx;
      background-color: #fe5e10;
      border-radius: 42rpx;
      font-size: 32rpx;
      font-weight: 400;
      text-align: center;
      line-height: 84rpx;
      color: #ffffff;
    }
  }
}
</style>
