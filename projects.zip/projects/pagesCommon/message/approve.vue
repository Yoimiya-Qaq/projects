<template>
  <view class="allheaders">
    <view class="details-nav">
      <view class="back-info">
        <image @click="goBack()" class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      </view>
      <view class="details-nav-right">申请消息</view>
    </view>
    <scroll-view scroll-y="true" @scrolltolower="lower()" :style="{ height: scrollH + 'rpx' }">
      <view class="approve-top">
        <view class="approve-pending">待处理 {{ applyingCount }}</view>
        <view class="approve-all">共{{ total }}条申请</view>
      </view>
      <view class="approve-content">
        <view class="approve-info" v-for="(item, index) in dataInfo" :key="index">
          <view
            class="approve-info-touxiang"
            @click.stop="
              $u.throttle(() => {
                goHomePages(item.userId)
              }, 500)
            "
          >
            <image class="touxiang-image" :src="item.userLogo" mode=""></image>
            <image class="xingbie-image" :src="item.sex === '男' ? 'https://img.yiqitogether.com/static/local/index/nan_s@2x.png' : 'https://img.yiqitogether.com/static/local/index/nv_s@2x.png'" mode=""></image>
          </view>
          <view class="approve-info-right">
            <view class="top-title">{{ item.userName }}</view>
            <view v-if="item.remark" class="top-remark">{{ item.remark }}</view>
            <view class="top-time">申请加入活动 {{ $u.timeFormat(item.createTimestamp, 'sendMsgFormat') }}</view>
          </view>
          <view class="approve-info-button">
            <view @click="refuseFun(item, true)" class="button-isrefuse" v-if="item.applyState && item.applyState.label == 'CREATE'">同意</view>
            <view @click="refuseFun(item, false)" class="button-isrefuse" v-if="item.applyState && item.applyState.label == 'CREATE'">拒绝</view>
            <view class="info-type" v-if="item.applyState && item.applyState.label != 'CREATE'">
              {{ item.applyState.text }}
            </view>
          </view>
        </view>
        <image v-if="dataInfo.length == 0" class="qs-image" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png"></image>
      </view>
      <view class="hemo-bottom" v-if="dataInfo.length > 0">
        <text v-if="pageNumber < pages" @click="lower()">加载更多</text>
        <text v-if="pageNumber >= pages">到底部了</text>
      </view>
    </scroll-view>
    <!-- 错误提示 -->
    <u-toast ref="uToast"></u-toast>
  </view>
</template>
<script>
import IndexModel from '@/model/index'
export default {
  components: {},
  data() {
    return {
      dataInfo: [],
      appointmentNo: '',
      total: 0,
      applyingCount: 0,
      pageNumber: 1,
      pages: 1,
      scrollH: 0
    }
  },
  onLoad(e) {
    this.appointmentNo = e.appointmentNo
  },
  onShow() {
    this.applyList()
    this.scrollH = this.scrollHs()
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    refuseFun(item, type) {
      let datas = {
        applyId: item.applyId,
        isPass: type
      }
      IndexModel.verifyApply(datas).then(dataRes => {
        console.log('加入申请审批', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.applyList()
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
          this.applyList()
        }
      })
    },
    applyList() {
      let datas = {
        appointmentNo: this.appointmentNo,
        pageNo: 1,
        pageSize: 10
      }
      IndexModel.applyList(datas).then(dataRes => {
        console.log('申请列表', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.applyingCount = dataRes.data.applyingCount
          this.dataInfo = dataRes.data.page.list
          this.total = dataRes.data.page.total
          this.pageNumber = dataRes.data.page.pageNumber
          this.pages = dataRes.data.page.pages
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
        }
      })
    },
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      return winHeight
    },
    lower(e) {
      console.log('已经滚动到底部了111')
      if (this.pageNumber < this.pages) {
        let datas = {
          appointmentNo: this.appointmentNo,
          pageNo: this.pageNumber + 1,
          pageSize: 10
        }
        IndexModel.applyList(datas).then(dataRes => {
          console.log('申请列表', dataRes)
          if (dataRes.code == 'SUCCESS') {
            this.dataInfo.push(...dataRes.data.page.list)
            this.pageNumber = dataRes.data.page.pageNumber
            this.pages = dataRes.data.page.pages
          } else {
            this.$refs.uToast.show({
              ...dataRes
            })
          }
        })
      }
    },
    // 前往个人主页
    goHomePages(userId) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + userId + '&fontId=1'
      })
    }
  }
}
</script>
<style scoped lang="scss">
* {
  margin: 0;
  padding: 0;
  font-style: normal;
  font-weight: normal;
}
.allheaders {
  width: 100%;
  height: 100vh;
  overflow-y: scroll;
  background: #fff;
}
.details-nav {
  width: 100%;
  height: 88rpx;
  background-color: #fff;
  padding-top: 88rpx;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999;
  .back-info {
    width: 44rpx;
    height: 44rpx;
    position: absolute;
    left: 24rpx;
    top: 110rpx;
    z-index: 99;
    .back-image {
      width: 100%;
      height: 100%;
    }
  }
  .details-nav-right {
    width: 100%;
    font-size: 36rpx;
    font-weight: 500;
    text-align: center;
    line-height: 88rpx;
    color: #333333;
  }
}
.approve-top {
  width: 100%;
  padding: 210rpx 30rpx 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .approve-pending {
    font-size: 28rpx;
    font-weight: 500;
    text-align: left;
    color: #333333;
  }
  .approve-all {
    font-size: 24rpx;
    font-weight: 500;
    text-align: right;
    color: #adb3ba;
  }
}
.approve-content {
  width: 100%;
  margin-top: 30rpx;
  .approve-info {
    width: 100%;
    height: 216rpx;
    display: flex;
    align-items: center;
    .approve-info-touxiang {
      width: 110rpx;
      height: 110rpx;
      margin-left: 30rpx;
      position: relative;
      .touxiang-image {
        width: 100%;
        height: 100%;
        border-radius: 50%;
      }
      .xingbie-image {
        width: 24rpx;
        height: 24rpx;
        position: absolute;
        right: 0;
        bottom: 0;
      }
    }
    .approve-info-right {
      flex-grow: 1;
      margin-left: 12rpx;
      margin-top: 25rpx;
      .top-title {
        font-family: OPPOSans, OPPOSans-Bold;
        font-size: 28rpx;
        font-weight: 400;
        text-align: left;
        color: #2d3f49;
        margin-bottom: 10rpx;
      }
      .top-remark {
        font-size: 22rpx;
        font-family: PingFang SC, PingFang SC-Regular;
        font-weight: Regular;
        text-align: left;
        color: #64696f;
        margin: 6rpx 0 18rpx;
      }
      .top-tips {
        font-family: OPPOSans, OPPOSans-Regular;
        font-size: 20rpx;
        font-weight: 400;
        text-align: left;
        color: #c8c8c8;
        margin-bottom: 10rpx;
      }
      .top-time {
        font-size: 24rpx;
        font-weight: 500;
        text-align: left;
        color: #adb3ba;
      }
    }
    .approve-info-button {
      width: 130rpx;
      margin-right: 30rpx;
      margin-top: 24rpx;
      .info-type {
        font-size: 24rpx;
        font-weight: 500;
        text-align: center;
        color: #acb3bb;
      }
      .button-isrefuse {
        width: 112rpx;
        height: 48rpx;
        border-radius: 30rpx;
        background-color: #fe5e10;
        font-size: 26rpx;
        font-weight: 500;
        text-align: center;
        line-height: 48rpx;
        color: #ffffff;
        margin-bottom: 14rpx;
      }
      // .button-refuse {
      //   width: 130rpx;
      //   height: 60rpx;
      //   border-radius: 30rpx;
      //   background-color: #FE5E10;
      //   font-size: 24rpx;
      //   font-weight: 500;
      //   text-align: center;
      //   line-height: 60rpx;
      //   color: #FFFFFF;
      // }
    }
  }
}
.hemo-bottom {
  width: 100%;
  font-size: 24rpx;
  font-weight: 500;
  text-align: center;
  color: #adb3ba;
  padding-bottom: 40rpx;
}
.qs-image {
  width: 310rpx;
  height: 310rpx;
  display: block;
  margin: 300rpx auto 40rpx;
}
</style>
