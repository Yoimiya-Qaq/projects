<template>
  <view class="wallet-page">
    <view class="nav-container">
      <image class="nav-back" src="@/static/images/back_black.png" alt="" @click="goBack()" />
      <view class="nav-box">
        <view class="nav-title">一起钱包</view>
      </view>
      <image class="nav-icon" mode="aspectFill" src="@/static/images/more2.png" @click="$u.throttle(goSetting, 500)"></image>
    </view>
    <scroll-view v-if="billList.length > 0" scroll-y="true" @scrolltolower="lower()" :style="{ height: scrollH + 'rpx' }">
      <view class="wallet-box">
        <view class="wallet-box-list">
          <view class="wallet-box-item" v-for="(item, index) in billList" :key="index">
            <view class="wallet-box-item-time" v-if="item.isVisitDate">{{ $u.timeFormat(item.billDate, 'mm-dd hh:MM') }}</view>
            <view class="wallet-box-item-card">
              <view class="wallet-box-item-top">
                <image class="wallet-box-item-left" mode="aspectFill" :src="item.titleImg" v-if="item.billType != 'back'"></image>
                <view class="wallet-box-item-right">
                  <view class="wallet-box-item-right-title">{{ item.title }}</view>
                  <image
                    class="wallet-box-item-more"
                    mode="aspectFill"
                    src="https://img.yiqitogether.com/yyqc/20240806/upload_jh1kb7kvrdhg7h68824mckl4qckto1b4.png"
                    @click.stop="
                      $u.throttle(() => {
                        toDelete(item, index)
                      }, 500)
                    "
                  ></image>
                </view>
              </view>
              <view class="wallet-title" v-if="item.billType == 'collectMoney'">收款金额</view>
              <view class="wallet-title" v-if="item.billType == 'payMoney'">付款金额</view>
              <view class="wallet-title" v-if="item.billType == 'withdraw'">提现</view>
              <view class="wallet-title" v-if="item.billType == 'recharge'">充值金额</view>
              <view class="wallet-title" v-if="item.billType == 'back'">退款金额</view>
              <view class="wallet-price-box">
                <text class="wallet-icon">¥</text>
                <text class="wallet-price">{{ item.billAmount }}</text>
              </view>
              <view
                class="wallet-detail-box"
                @click.stop="
                  $u.throttle(() => {
                    toDetail(item)
                  }, 500)
                "
              >
                <view class="wallet-detail">查看详情</view>
                <image class="more-icon" mode="aspectFill" src="@/static/images/arrow_right.png"></image>
              </view>
              <view v-if="item.billType == 'collectMoney' || item.billType == 'payMoney'">
                <view class="bottom-item-box" v-if="item.collectChannel">
                  <view class="bottom-item-title">收款账户</view>
                  <view class="bottom-item-info">{{ item.collectChannel }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.collectRemark">
                  <view class="bottom-item-title">收款说明</view>
                  <view class="bottom-item-info">{{ item.collectRemark }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.payChannel">
                  <view class="bottom-item-title">付款方式</view>
                  <view class="bottom-item-info">{{ item.payChannel }}</view>
                </view>
              </view>
              <view v-if="item.billType == 'withdraw'">
                <view class="bottom-item-box" v-if="item.remark">
                  <view class="bottom-item-title">转入账户</view>
                  <view class="bottom-item-info">{{ item.remark }}</view>
                </view>
              </view>
              <view v-if="item.billType == 'recharge'">
                <view class="bottom-item-box" v-if="item.collectChannel">
                  <view class="bottom-item-title">收款账户</view>
                  <view class="bottom-item-info">{{ item.collectChannel }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.remark">
                  <view class="bottom-item-title">充值账户</view>
                  <view class="bottom-item-info">{{ item.remark }}</view>
                </view>
              </view>
              <view v-if="item.billType == 'back'">
                <view class="bottom-item-box" v-if="item.businessType">
                  <view class="bottom-item-title">业务类型</view>
                  <view class="bottom-item-info">{{ item.businessTypeTxt }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.payChannel">
                  <view class="bottom-item-title">退款方式</view>
                  <view class="bottom-item-info">{{ item.payChannel }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.payRemark">
                  <view class="bottom-item-title">退款原因</view>
                  <view class="bottom-item-info">{{ item.payRemark }}</view>
                </view>
                <view class="bottom-item-box" v-if="item.billDate">
                  <view class="bottom-item-title">到账时间</view>
                  <view class="bottom-item-info">{{ $u.timeFormat(item.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
    </scroll-view>
    <view class="normalActivity-empty" v-else>
      <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="widthFix" />
      <view class="empty-text">暂无内容</view>
    </view>
    <!-- 删除此条消息弹框 -->
    <clearMessagePopup :showClearMessage="showClearMessage" @confirmClearMessage="confirmClearMessage" @cancelClearMessage="cancelClearMessage"></clearMessagePopup>

    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import blogger from '@/model/blogger'
// 导入组件
import clearMessagePopup from '../integrationCenter/components/clear-message-popup.vue'
export default {
  data() {
    return {
      scrollH: 0,
      pages: 1,
      pageNumber: 0,
      // 账单列表
      billList: [],
      // 是否显示删除弹框
      showClearMessage: false,
      checkedIndex: '',
      checkedItem: {}
    }
  },
  components: {
    clearMessagePopup
  },
  onLoad(e) {
    this.getBillMessageList()
  },
  onShow() {
    this.scrollH = this.scrollHs()
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      return winHeight - 120
    },
    // 获取账单列表
    async getBillMessageList() {
      let that = this
      let prevTimestamp
      let data = {
        pageNo: that.pageNumber + 1,
        pageSize: 10
      }
      let res = await blogger.billMessageList(data)
      if (res.code == 'SUCCESS' && res.data) {
        that.pages = res.data.pager.pages
        this.pageNumber = res.data.pager.pageNumber
        this.billList = [...this.billList, ...res.data.pager.list]
        if (this.billList.length > 0) {
          this.billList.forEach((item, index) => {
            if (prevTimestamp) {
              // 计算两个Date对象之间的时间差（单位：毫秒）
              // let timediff = Math.abs(1609459320000 - 1609459200000)
              let timediff = Math.abs(item.billDate - prevTimestamp) / 1000
              // 判断时间差是否在两分钟内（单位：秒）
              if (timediff >= 120) {
                item.isVisitDate = true
              } else {
                item.isVisitDate = false
              }
            } else {
              item.isVisitDate = true
            }
            prevTimestamp = item.billDate
            this.getBusinessTypeTxt(item)
          })
        }

        // console.log(this.billList, '处理后的this.billList')
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    },
    // 处理一下业务类型数据
    getBusinessTypeTxt(item) {
      switch (item.businessType) {
        // 性格测试
        case 'AnswerBook':
          item.businessTypeTxt = '性格测试'

          break
        // 活动
        case 'AppointmentJoin':
          item.businessTypeTxt = '活动'

          break
        // 我的认证
        case 'EducationAuth':
          item.businessTypeTxt = '我的认证'
          break
        // 合作商户交易
        case 'MerchantCommission':
          item.businessTypeTxt = '合作商户交易'

          break
        // 企业会员年卡
        case 'MemberCard':
          item.businessTypeTxt = '企业会员年卡'

          break
        // 充值
        case 'Recharge':
          item.businessTypeTxt = '充值'
          break
        // 推广收益
        case 'RegisterReward':
          item.businessTypeTxt = '推广收益'
          break
        // 实习生工资
        case 'UserSalary':
          item.businessTypeTxt = '实习生工资'
          break

        // 靓靓商城
        case 'ShopMall':
          item.businessTypeTxt = '靓靓商城'

          break
        // 幸运彩球
        case 'TicketLottery':
          item.businessTypeTxt = '幸运彩球'

          break
        // 提现
        case 'Withdraw':
          item.businessTypeTxt = '提现'
          break
        // 红包
        case 'Reward':
          item.businessTypeTxt = '一起红包'
          break
        default:
          break
      }
    },
    lower() {
      if (this.pages > this.pageNumber) {
        this.getBillMessageList()
      }
    },
    // 查看详情
    toDetail(item) {
      uni.navigateTo({
        url: '/pagesCommon/message/walletMessage/walletDetail?detailData=' + encodeURIComponent(JSON.stringify(item))
      })
    },
    // 设置
    goSetting() {
      let self = this
      uni.navigateTo({
        url: '/pagesCommon/message/messageSetting?pageTitle=一起钱包&targetNo=10009',
        events: {
          privateSettingBack: function (data) {
            self.billList = []
          }
        }
      })
    },
    // 删除
    toDelete(item, index) {
      this.showClearMessage = true
      this.checkedIndex = index
      this.checkedItem = { ...item }
    },
    // 取消删除
    cancelClearMessage() {
      this.showClearMessage = false
    },
    // 确认删除
    async confirmClearMessage() {
      let that = this
      let data = {
        id: this.checkedItem.id
      }
      console.log(data, 'data')
      that.showClearMessage = false
      let res = await blogger.deleteBillMessage(data)
      if (res.code == 'SUCCESS') {
        uni.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 1500
        })
        that.billList.forEach((item2, index2) => {
          if (item2.id == that.checkedItem.id) {
            that.billList.splice(index2, 1)
          }
        })
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    }
  }
}
</script>

<style scoped lang="scss">
.wallet-page {
  width: 100%;
  height: 100vh;
  background: #f6f6f8;
  overflow: hidden;

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    align-items: center;
    z-index: 999;
    background: #f6f6f8;
    padding-bottom: 10rpx;
    padding-top: calc(var(--status-bar-height) + 10rpx);
    border-bottom: 0.5px solid #f0f0f2;
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-box {
      flex: 1;
      display: flex;
      align-items: center;
      .nav-title {
        font-size: 32rpx;
        color: #2a343e;
        line-height: 44rpx;
      }
    }
    .nav-icon {
      width: 44rpx;
      height: 44rpx;
      padding: 0 30rpx;
    }
  }
  .wallet-box {
    padding-bottom: 100rpx;
    .wallet-box-list {
      margin-top: 44rpx;
      .wallet-box-item {
        text-align: center;
        margin-bottom: 40rpx;
        .wallet-box-item-time {
          font-size: 24rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: center;
          color: #adadad;
          line-height: 34rpx;
          margin-bottom: 28rpx;
        }
        .wallet-box-item-card {
          width: 670rpx;
          background: #ffffff;
          border-radius: 20rpx;
          margin: 0 auto;
          padding: 20rpx 28rpx 38rpx;
          box-sizing: border-box;
          .wallet-box-item-top {
            display: flex;
            align-items: center;
            position: relative;
            padding-bottom: 20rpx;
            &:after {
              position: absolute;
              bottom: 0;
              left: 0;
              right: 0;
              content: '';
              box-sizing: border-box;
              height: 1px;
              border-bottom: 1px solid #f0f1f3;
              transform: scaleY(0.5);
              transform-origin: 0 0;
            }
            .wallet-box-item-left {
              width: 60rpx;
              height: 60rpx;
              margin-right: 16rpx;
            }
            .wallet-box-item-right {
              flex: 1;
              display: flex;
              justify-content: space-between;
              align-items: center;
              .wallet-box-item-right-title {
                font-size: 28rpx;
                font-family: PingFang SC, PingFang SC-Regular;
                font-weight: Regular;
                text-align: left;
                color: #2a343e;
                line-height: 40rpx;
              }
              .wallet-box-item-more {
                width: 32rpx;
                height: 32rpx;
              }
            }
          }
          .wallet-title {
            font-size: 24rpx;
            font-family: PingFang SC, PingFang SC-Regular;
            font-weight: Regular;
            text-align: center;
            color: #838e9a;
            line-height: 34rpx;
            margin-top: 30rpx;
          }
          .wallet-price-box {
            margin-top: 8rpx;
            .wallet-icon {
              font-size: 50rpx;
              font-family: PingFang SC, PingFang SC-Heavy;
              font-weight: Heavy;
              text-align: left;
              color: #1c1c1c;
              line-height: 80rpx;
            }
            .wallet-price {
              font-size: 66rpx;
              font-family: PingFang SC, PingFang SC-Heavy;
              font-weight: Heavy;
              text-align: left;
              color: #1c1c1c;
              line-height: 100rpx;
            }
          }
          .wallet-detail-box {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 8rpx;
            padding-bottom: 25rpx;
            position: relative;
            &:after {
              position: absolute;
              bottom: 0;
              left: 0;
              right: 0;
              content: '';
              box-sizing: border-box;
              height: 1px;
              border-bottom: 1px solid #f0f1f3;
              transform: scaleY(0.5);
              transform-origin: 0 0;
            }
            .wallet-detail {
              font-size: 24rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: center;
              color: #838e9a;
              line-height: 34rpx;
              margin-right: 8rpx;
            }
            .more-icon {
              width: 16rpx;
              height: 16rpx;
            }
          }

          .bottom-item-box {
            display: flex;
            // align-items: center;
            margin-top: 20rpx;
            .bottom-item-title {
              font-size: 28rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: left;
              color: #838e9a;
              line-height: 40rpx;
              margin-right: 28rpx;
            }
            .bottom-item-info {
              flex: 1;
              font-size: 28rpx;
              font-family: PingFang SC, PingFang SC-Regular;
              font-weight: Regular;
              text-align: left;
              color: #1c1c1c;
              line-height: 40rpx;
              // white-space: nowrap;
              // overflow: hidden;
              // text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
              word-break: break-all;
              text-overflow: ellipsis;
              overflow: hidden;
              white-space: pre-wrap;
            }
          }
        }
      }
    }
  }
  .normalActivity-empty {
    padding-top: 100rpx;
    height: 50vh;
    margin: auto;
    text-align: center;
    .empty-img {
      width: 312rpx;
      height: 244rpx;
      background-size: cover;
    }
    .empty-text {
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
}
</style>
