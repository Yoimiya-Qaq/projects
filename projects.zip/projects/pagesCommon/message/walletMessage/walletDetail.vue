<template>
  <view class="wallet-page">
    <view class="nav-container">
      <image class="nav-back" mode="aspectFill" src="@/static/images/back_black.png" alt="" @click="goBack()" />
      <view class="nav-box" @click="$u.throttle(goBill, 500)">全部账单</view>
    </view>
    <view class="card-box">
      <view class="card-top">
        <image class="top-img" mode="aspectFill" :src="detailData.detailImg || detailData.titleImg" alt="" />
        <view class="detail-box" @click="$u.throttle(associationPage, 500)">
          <view class="detail" v-if="detailData.businessType == 'Reward'">
            {{ detailData.detailTitle || detailData.title }}
            <text v-if="detailData.remark">-{{ detailData.remark }}</text>
          </view>
          <view class="detail" v-else>{{ detailData.detailTitle || detailData.title }}</view>
          <!-- 充值，提现，活跃度奖励，企业，实习生工资按钮隐藏 -->
          <!-- 2025/1/8 红包类型按钮隐藏 -->
          <image
            v-if="detailData.businessType != 'Withdraw' && detailData.businessType != 'GeneralReward' && detailData.businessType != 'Recharge' && detailData.businessType != 'MemberCard' && detailData.businessType != 'UserSalary' && detailData.businessType != 'Reward' && !detailData.isExtraJson"
            class="more-icon"
            mode="aspectFill"
            src="@/static/images/arrow_right.png"
          ></image>
        </view>
        <view class="wallet-price-box">
          <text class="wallet-icon" v-if="detailData.billType != 'withdraw' && detailData.financeType == 'in'">+</text>
          <text class="wallet-icon" v-if="detailData.billType != 'withdraw' && detailData.financeType == 'out'">-</text>
          <text class="wallet-price">{{ detailData.billAmount }}</text>
        </view>
      </view>
      <view class="card-bottom">
        <view class="bottom-item-box" v-if="detailData.isAssociation && !detailData.isExtraJson">
          <view class="bottom-item-title">关联订单</view>
          <view class="bottom-item-info-yellow" @click="$u.throttle(associationDetail, 500)">
            <view class="yellow-text">查看关联详情</view>
            <!-- <image class="yellow-icon" mode="aspectFill" src="@/static/images/arrow_right.png"></image> -->
          </view>
        </view>
        <!-- 退款 -->
        <view v-if="detailData.billType == 'back'">
          <view class="bottom-item-box" v-if="detailData.billStates && !detailData.isParentBill" @click="$u.throttle(backDetail, 500)">
            <view class="bottom-item-title">退款记录</view>
            <view class="bottom-item-info-yellow">
              <view class="yellow-text">已退款¥{{ detailData.billAmount }}</view>
              <image class="yellow-icon" mode="aspectFill" src="@/static/images/arrow_right.png" v-if="detailData.parentBill"></image>
            </view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">退款时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
        </view>
        <!-- 退款end -->
        <image class="bottom-line" mode="aspectFill" src="https://img.yiqitogether.com/yyqc/20240806/upload_dq8tv13bbf53vh3hnw3h5a2w9n8og59c.png" alt="" />
        <!-- 退款 -->
        <view v-if="detailData.billType == 'back'">
          <view class="bottom-item-box" v-if="detailData.billStates">
            <view class="bottom-item-title">当前状态</view>
            <!--2025/1/13 已全额退款改为已退款 -->
            <view class="bottom-item-info">{{ detailData.billStates == 'success' ? '支付成功' : detailData.billStates == 'successCollect' ? '已存入零钱' : detailData.billStates == 'back' ? '已退款' : detailData.billStates == 'delete' ? '已删除' : '' }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">支付时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.businessTypeTxt">
            <view class="bottom-item-title">业务类型</view>
            <view class="bottom-item-info">{{ detailData.businessTypeTxt }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.payChannel">
            <view class="bottom-item-title">支付方式</view>
            <view class="bottom-item-info">{{ detailData.payChannel }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.collectRemark">
            <view class="bottom-item-title">提现说明</view>
            <view class="bottom-item-info">{{ detailData.collectRemark }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.requestNo">
            <view class="bottom-item-title">交易单号</view>
            <view class="bottom-item-info">{{ detailData.requestNo }}</view>
          </view>
        </view>
        <!-- 退款end -->
        <!-- 收款 -->
        <view v-if="detailData.billType == 'collectMoney'">
          <view class="bottom-item-box" v-if="detailData.billStates">
            <view class="bottom-item-title">当前状态</view>
            <view class="bottom-item-info">{{ detailData.billStates == 'success' ? '支付成功' : detailData.billStates == 'successCollect' ? '已存入零钱' : detailData.billStates == 'back' ? '已退款' : detailData.billStates == 'delete' ? '已删除' : '' }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.collectChannel">
            <view class="bottom-item-title">收款账户</view>
            <view class="bottom-item-info-yellow" @click="$u.throttle(goPay, 500)">
              <view class="yellow-text">{{ detailData.collectChannel }}</view>
              <image class="yellow-icon" mode="aspectFill" src="@/static/images/arrow_right.png"></image>
            </view>
          </view>
          <view class="bottom-item-box" v-if="detailData.businessType == 'Reward'">
            <view class="bottom-item-title">红包详情</view>
            <view class="bottom-item-info-yellow" @click="$u.throttle(goRedPicket, 500)">
              <view class="yellow-text">查看</view>
              <image class="yellow-icon" mode="aspectFill" src="@/static/images/arrow_right.png"></image>
            </view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">到账时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.requestNo">
            <view class="bottom-item-title">交易单号</view>
            <view class="bottom-item-info">{{ detailData.requestNo }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.collectRemark">
            <view class="bottom-item-title">收款说明</view>
            <view class="bottom-item-info">{{ detailData.collectRemark }}</view>
          </view>
        </view>
        <!-- 收款end -->
        <!-- 付款 -->
        <view v-if="detailData.billType == 'payMoney'">
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">当前状态</view>
            <view class="bottom-item-info">{{ detailData.billStates == 'success' ? '支付成功' : detailData.billStates == 'successCollect' ? '已存入零钱' : detailData.billStates == 'back' ? '已退款' : detailData.billStates == 'delete' ? '已删除' : '' }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">支付时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.businessTypeTxt">
            <view class="bottom-item-title">业务类型</view>
            <view class="bottom-item-info">{{ detailData.businessTypeTxt }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.payChannel">
            <view class="bottom-item-title">支付方式</view>
            <view class="bottom-item-info">{{ detailData.payChannel }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.requestNo">
            <view class="bottom-item-title">交易单号</view>
            <view class="bottom-item-info">{{ detailData.requestNo }}</view>
          </view>
        </view>
        <!-- 付款end -->

        <!-- 提现 -->
        <view v-if="detailData.billType == 'withdraw'">
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">创建时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billAmount">
            <view class="bottom-item-title">提现金额</view>
            <view class="bottom-item-info">¥{{ detailData.billAmount }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billFee">
            <view class="bottom-item-title">服务费</view>
            <view class="bottom-item-info">¥{{ detailData.billFee }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.payRemark">
            <view class="bottom-item-title">提现说明</view>
            <view class="bottom-item-info">{{ detailData.payRemark }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.remark">
            <view class="bottom-item-title">提现账户</view>
            <view class="bottom-item-info">{{ detailData.remark }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.requestNo">
            <view class="bottom-item-title">交易单号</view>
            <view class="bottom-item-info">{{ detailData.requestNo }}</view>
          </view>
        </view>
        <!-- 提现end -->
        <!-- 充值 -->
        <view v-if="detailData.billType == 'recharge'">
          <view class="bottom-item-box" v-if="detailData.billStates">
            <view class="bottom-item-title">当前状态</view>
            <view class="bottom-item-info">{{ detailData.billStates == 'success' ? '支付成功' : detailData.billStates == 'successCollect' ? '已存入零钱' : detailData.billStates == 'back' ? '已退款' : detailData.billStates == 'delete' ? '已删除' : '' }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.remark">
            <view class="bottom-item-title">充值账户</view>
            <view class="bottom-item-info">{{ detailData.remark }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.collectChannel">
            <view class="bottom-item-title">收款账户</view>
            <view class="bottom-item-info-yellow" @click="$u.throttle(goPay, 500)">
              <view class="yellow-text">{{ detailData.collectChannel }}</view>
              <image class="yellow-icon" mode="aspectFill" src="@/static/images/arrow_right.png"></image>
            </view>
          </view>
          <view class="bottom-item-box" v-if="detailData.billDate">
            <view class="bottom-item-title">充值时间</view>
            <view class="bottom-item-info">{{ $u.timeFormat(detailData.billDate, 'yyyy-mm-dd hh:MM:ss') }}</view>
          </view>
          <view class="bottom-item-box" v-if="detailData.requestNo">
            <view class="bottom-item-title">交易单号</view>
            <view class="bottom-item-info">{{ detailData.requestNo }}</view>
          </view>
        </view>
        <!-- 充值end -->
      </view>
      <u-toast ref="uToast"></u-toast>
    </view>
  </view>
</template>

<script>
import RongYun from '@/model/rongyun'
import { load } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey'
export default {
  data() {
    return {
      detailData: {}
    }
  },

  onLoad(e) {
    if (e.detailData) {
      this.detailData = JSON.parse(decodeURIComponent(e.detailData)) || {}
      this.getBusinessTypeTxt()
      console.log(this.detailData, 'detailData')
    }
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    // 去全部账单页面
    goBill() {
      uni.redirectTo({
        url: '/pagesMy/my/myBill'
      })
    },
    // 处理一下业务类型数据
    getBusinessTypeTxt() {
      switch (this.detailData.businessType) {
        // 性格测试
        case 'AnswerBook':
          this.detailData.businessTypeTxt = '性格测试'
          this.detailData.isAssociation = true
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 性格测试(第三方答题)
        case 'GeneralThird':
          this.detailData.businessTypeTxt = '性格测试'
          this.detailData.isAssociation = true
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 活动
        case 'AppointmentJoin':
          this.detailData.businessTypeTxt = '活动'
          this.detailData.billType == 'back' ? (this.detailData.isAssociation = false) : (this.detailData.isAssociation = true)
          // 退款  没有父订单则不显示
          if (this.detailData.billType == 'back' && this.detailData.businessType == 'AppointmentJoin' && !this.detailData.parentBill) {
            this.detailData.isParentBill = true
          }
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 我的认证
        case 'EducationAuth':
          this.detailData.businessTypeTxt = '我的认证'
          break
        // 合作商户交易
        case 'MerchantCommission':
          this.detailData.businessTypeTxt = '合作商户交易'
          break
        // 企业会员年卡
        case 'MemberCard':
          this.detailData.businessTypeTxt = '企业会员年卡'
          this.detailData.isAssociation = true
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 充值
        case 'Recharge':
          this.detailData.businessTypeTxt = '充值'
          break
        // 推广收益
        case 'RegisterReward':
          this.detailData.businessTypeTxt = '推广收益'
          break
        // 实习生工资
        case 'UserSalary':
          this.detailData.businessTypeTxt = '实习生工资'
          break
        // 靓靓商城
        case 'ShopMall':
          this.detailData.businessTypeTxt = '靓靓商城'
          this.detailData.billType == 'back' ? (this.detailData.isAssociation = false) : (this.detailData.isAssociation = true)
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 靓靓商城-商品佣金(24/10/14 新增)
        case 'ShopMall_Discount':
          this.detailData.businessTypeTxt = '靓靓商城'
          this.detailData.billType == 'back' ? (this.detailData.isAssociation = false) : (this.detailData.isAssociation = true)
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 幸运彩球
        case 'TicketLottery':
          this.detailData.businessTypeTxt = '幸运彩球'
          this.detailData.isAssociation = true
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          break
        // 提现
        case 'Withdraw':
          this.detailData.businessTypeTxt = '提现'
          break
        // 活跃度奖励
        case 'GeneralReward':
          this.detailData.businessTypeTxt = '活跃度奖励'
          break
        // 创作奖励
        case 'GeneralReward-Create':
          this.detailData.businessTypeTxt = '创作奖励'
          break
        // 红包类型
        case 'Reward':
          this.detailData.businessTypeTxt = '一起钱包'
          // 红包类型中只有付款才显示关联详情
          if (this.detailData.billType == 'payMoney') {
            this.detailData.isAssociation = true
          }
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            this.detailData.isExtraJson = true
          }
          // 红包不显示收款详情这一项
          this.detailData.collectRemark = ''
          // 退款  没有父订单则不显示，为了展示箭头，给个默认值
          this.detailData.parentBill = '一起红包'
          break
        default:
          break
      }
    },
    // 去关联详情页面
    associationDetail() {
      switch (this.detailData.businessType) {
        // 性格测试
        case 'AnswerBook':
          let answerObj = {
            answerNo: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).answerNo : '',
            title: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).title : '',
            price: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).price : ''
          }
          uni.navigateTo({
            url: `/pagesCommon/answers/unlockReport?answerInfo=${encodeURIComponent(JSON.stringify(answerObj))}`
          })
          break
        // 性格测试(第三方答题)
        case 'GeneralThird':
          let answerObjThird = {
            answerNo: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).answerNo : '',
            title: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).title : '',
            price: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).price : ''
          }
          uni.navigateTo({
            url: `/pagesCommon/answers/unlockReport?answerInfo=${encodeURIComponent(JSON.stringify(answerObjThird))}`
          })
          break
        // 活动
        case 'AppointmentJoin':
          let appointmentNo = this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).appointmentNo : ''
          uni.navigateTo({
            url: '/pagesCommon/details/activitySignIn?appointmentNo=' + appointmentNo
          })
          break
        // 企业会员年卡
        case 'MemberCard':
          let companyId = this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).companyId : ''
          uni.navigateTo({
            url: '/pagesRecruit/recruit/companyHomePage?companyId=' + companyId
          })
          break
        // 靓靓商城
        case 'ShopMall':
          if (this.detailData.billType == 'payMoney' || this.detailData.billType == 'collectMoney') {
            // 商品购买
            let obj = {
              type: '1',
              openUrl: '/unpay/yiqi',
              id: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).id : '',
              dataType: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).dataType : ''
            }
            console.log(obj, 'payMoney')
            getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
            this.$nextTick(() => {
              uni.navigateTo({
                url: '/pages/my/webView'
              })
            })
          }
          break
        // 靓靓商城-商品佣金(24/10/14 新增)
        case 'ShopMall_Discount':
          if (this.detailData.billType == 'collectMoney') {
            // 商品折现
            let obj = {
              type: '1',
              openUrl: '/discountDetail/yiqi',
              id: this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).Id : ''
            }
            console.log(obj, 'collectMoney')
            getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
            this.$nextTick(() => {
              uni.navigateTo({
                url: '/pages/my/webView'
              })
            })
          }
          break
        // 幸运彩球
        case 'TicketLottery':
          let id = this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).id : ''
          uni.navigateTo({
            url: '/pages/index/luckyBallsDraw?id=' + id + '&activityStatus=进行中'
          })
          break
        // 红包
        case 'Reward':
          this.getRedPicketDetail(this.detailData.extraJson)
          break
        default:
          uni.showToast({
            title: '当前版本暂不支持,请升级版本',
            icon: 'none'
          })
          break
      }
    },
    // 去关联页面
    associationPage() {
      switch (this.detailData.businessType) {
        // 性格测试
        case 'AnswerBook':
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            return
          }
          uni.navigateTo({
            url: '/pagesCommon/answers/index'
          })
          break
        // 性格测试(第三方答题)
        case 'GeneralThird':
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            return
          }
          uni.navigateTo({
            url: '/pagesCommon/answers/index'
          })
          break
        // 活动
        case 'AppointmentJoin':
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            return
          }
          // 跳活动详情页
          let appointmentNo = this.detailData.extraJson ? JSON.parse(this.detailData.extraJson).appointmentNo : ''
          uni.navigateTo({
            url: '/pagesCommon/details/details?appointmentNo=' + appointmentNo
          })
          break
        // 我的认证
        case 'EducationAuth':
          uni.navigateTo({
            url: '/pagesMy/my/myCertification'
          })
          break
        // 合作商户交易
        case 'MerchantCommission':
          uni.navigateTo({
            url: '/shangchaoMall/shop/index'
          })
          break
        // 企业会员年卡（不跳转）
        case 'MemberCard':
          break
        // 充值
        case 'Recharge':
          break
        // 推广收益
        case 'RegisterReward':
          let userInfoDTO = JSON.parse(load(USER_INFO)) || {}
          uni.navigateTo({
            url: `/pagesMy/my/myPromotion?name=${userInfoDTO.nickName}&avatar=${userInfoDTO.headUrl}`
          })
          break
        // 实习生工资
        case 'UserSalary':
          break
        // 靓靓商城
        case 'ShopMall':
          // 如果跳转参数不存在，则不显示箭头和关联订单详情那一项
          if (!this.detailData.extraJson) {
            return
          }
          let obj = {
            type: '1',
            openUrl: '/home/yiqi'
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj))
          this.$nextTick(() => {
            uni.navigateTo({
              url: '/pages/my/webView'
            })
          })
          break
        // 靓靓商城-商品佣金(24/10/14 新增)
        case 'ShopMall_Discount':
          let obj2 = {
            type: '1',
            openUrl: '/home/yiqi'
          }
          getApp().globalData.webViewOption = JSON.parse(JSON.stringify(obj2))
          this.$nextTick(() => {
            uni.navigateTo({
              url: '/pages/my/webView'
            })
          })
          break
        // 幸运彩球
        case 'TicketLottery':
          uni.navigateTo({
            url: '/pages/index/luckyBalls'
          })
          break
        // 提现
        case 'Withdraw':
          // 提现不跳转
          break
        // 活跃度奖励
        case 'GeneralReward':
          // 活跃度奖励不跳转
          break
        // 创作奖励
        case 'GeneralReward-Create':
          uni.navigateTo({
            url: '/pagesCommon/originator/details'
          })
          break
        // 红包奖励（不跳转）
        case 'Reward':
          break
        default:
          uni.showToast({
            title: '当前版本暂不支持,请升级版本',
            icon: 'none'
          })
          break
      }
    },
    // 去零钱
    goPay() {
      uni.navigateTo({
        url: '/pagesMy/my/myAccountCenter/index'
      })
    },
    // 退款详情页
    backDetail() {
      if (!this.detailData.parentBill) return
      // 红包类型单独处理，没有父订单，跳转到红包详情页
      if (this.detailData.businessType == 'Reward') {
        // 如果跳转参数不存在，则不跳转
        if (!this.detailData.extraJson) return
        this.getRedPicketDetail(this.detailData.extraJson)
      } else {
        uni.navigateTo({
          url: '/pagesCommon/message/walletMessage/walletDetail?detailData=' + encodeURIComponent(JSON.stringify(this.detailData.parentBill))
        })
      }
    },
    // 跳转红包页面
    goRedPicket() {
      // 如果跳转参数不存在，则不跳转
      if (!this.detailData.extraJson) return
      this.getRedPicketDetail(this.detailData.extraJson)
    },
    // 领取红包接口
    async getRedPicketDetail(requestNo) {
      let data = {
        requestNo: requestNo
      }
      console.log(data, '领取红包接口')
      let res = await RongYun.redPicketDetail(data)
      if (res.code == 'SUCCESS') {
        let rp = res.data.info.rp
        if (rp.subordinationType == 'USER') {
          uni.navigateTo({
            url: '/pagesMessage/privateChat/privateRedpacket?rpData=' + requestNo
          })
        } else {
          uni.navigateTo({
            url: '/pagesMessage/groupChat/groupRedpacket?rpData=' + requestNo
          })
        }
      } else {
        this.$refs.uToast.show({
          ...res
        })
      }
    }
  }
}
</script>

<style scoped lang="scss">
.wallet-page {
  width: 100%;
  height: 100vh;
  background: #fff;
  overflow: hidden;

  .nav-container {
    width: 100%;
    height: 88rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 10rpx;
    padding-top: calc(var(--status-bar-height) + 10rpx);
    .nav-back {
      width: 44rpx;
      height: 44rpx;
      padding: 22rpx 24rpx;
    }
    .nav-box {
      font-size: 32rpx;
      color: #2a343e;
      line-height: 44rpx;
      margin-right: 30rpx;
    }
  }
  .card-box {
    .card-top {
      margin-top: 76rpx;
      text-align: center;

      .top-img {
        width: 144rpx;
        height: 144rpx;
      }
      .detail-box {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 36rpx;
        padding: 0 24rpx;
        .detail {
          // width: 500rpx;
          font-size: 32rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: center;
          color: #2a343e;
          line-height: 44rpx;
          margin-right: 16rpx;
          // overflow: hidden;
          // white-space: nowrap;
          // text-overflow: ellipsis;

          overflow: hidden;
          text-overflow: ellipsis;
          -webkit-line-clamp: 1;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          word-break: break-all;
        }
        .more-icon {
          width: 16rpx;
          height: 16rpx;
        }
      }
      .wallet-price-box {
        margin-top: 44rpx;
        .wallet-icon {
          font-size: 84rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: center;
          color: #2a343e;
          line-height: 118rpx;
          // margin-left: -30rpx;
        }
        .wallet-price {
          font-size: 84rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          // text-align: center;
          color: #2a343e;
          line-height: 118rpx;
        }
      }
    }
    .card-bottom {
      width: 100%;
      padding: 0 36rpx;
      margin-top: 100rpx;
      box-sizing: border-box;
      .bottom-line {
        width: 100%;
        height: 4rpx;
      }
      .bottom-item-box {
        display: flex;
        // align-items: center;
        margin-top: 40rpx;
        .bottom-item-title {
          width: 128rpx;
          font-size: 32rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: left;
          color: #9fa7b4;
          line-height: 44rpx;
          margin-right: 52rpx;
        }
        .bottom-item-info {
          flex: 1;
          font-size: 32rpx;
          font-family: PingFang SC, PingFang SC-Regular;
          font-weight: Regular;
          text-align: left;
          color: #4e4e4e;
          line-height: 44rpx;
          white-space: pre-line;
          word-wrap: break-word;
          word-break: break-all;
          // white-space: nowrap;
          // overflow: hidden;
          // text-overflow: ellipsis;
        }
        .bottom-item-info-yellow {
          flex: 1;
          display: flex;
          align-items: center;
          .yellow-text {
            font-size: 32rpx;
            font-family: PingFang SC, PingFang SC-Regular;
            font-weight: Regular;
            text-align: left;
            color: #ff9942;
            line-height: 44rpx;
          }
          .yellow-icon {
            width: 16rpx;
            height: 16rpx;
            margin-left: 12rpx;
          }
        }
      }
    }
  }
}
</style>
