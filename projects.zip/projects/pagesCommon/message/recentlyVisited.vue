<template>
  <view class="allheaders">
    <view class="details-nav">
      <view class="back-info">
        <image @click="goBack()" class="back-image" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      </view>
      <view class="details-nav-right">
        <view :class="isVisitedMy ? 'visited-title' : 'isVisited-title'" @click="visitedFun(true)"> 谁看过我 </view>
        <view :class="!isVisitedMy ? 'visited-title' : 'isVisited-title'" @click="visitedFun(false)"> 我看过谁 </view>
      </view>
    </view>
    <scroll-view scroll-y="true" @scrolltolower="lower()" :style="{ height: scrollH + 'rpx' }">
      <view class="visited-list">
        <view class="visited-info" v-for="(item, index) in dataInfo" :key="index" @click="goMyHome(item)">
          <image class="visited-info-img" :src="item.senderImg" mode=""></image>
          <view class="visited-info-right">
            <view class="visited-info-name">{{ item.senderName }}</view>
            <view class="visited-info-bottom">
              <view class="visited-info-senderAge">
                <image
                  class="xingbie-image"
                  :src="item.senderSex === '男' ? 'https://img.yiqitogether.com/static/local/index/nan_s@2x.png' : 'https://img.yiqitogether.com/static/local/index/nv_s@2x.png'"
                  mode=""></image>
                <text>{{ item.senderAge }}岁</text>
              </view>
              <view class="visited-info-createTime"> {{ item.createTime }} {{ isVisitedMy ? '访问了你的主页' : '访问主页' }} </view>
            </view>
          </view>
        </view>
        <image v-if="dataInfo.length == 0" class="qs-image" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png"></image>
      </view>
      <view class="hemo-bottom" v-if="dataInfo.length > 0"> <text v-if="pageNumber < pages" @click="lower()">加载更多</text><text v-if="pageNumber >= pages">到底部了</text> </view>
    </scroll-view>
    <u-toast ref="uToast"></u-toast>
  </view>
</template>
<script>
import IndexModel from '@/model/index'
export default {
  components: {},
  data() {
    return {
      dataInfo: [],
      isVisitedMy: true,
      total: 0,
      applyingCount: 0,
      pageNumber: 1,
      pages: 1,
      scrollH: 0,
    }
  },
  onLoad(e) {},
  onShow() {
    this.visitedFun(this.isVisitedMy)
    this.scrollH = this.scrollHs()
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    visitedFun(item) {
      this.isVisitedMy = item
      if (item) {
        this.getMessage()
      } else {
        this.applyList()
      }
    },
    applyList() {
      let datas = {
        pageNo: 1,
        pageSize: 10,
      }
      IndexModel.getISeeMessage(datas).then((dataRes) => {
        console.log('我访问的', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.dataInfo = dataRes.data.pager.list
          this.pageNumber = dataRes.data.pager.pageNumber
          this.pages = dataRes.data.pager.pages
        } else {
          this.$refs.uToast.show({
            ...dataRes,
          })
        }
      })
    },
    getMessage() {
      let datas = {
        messageType: 'ACCESS',
        pageNo: 1,
        pageSize: 10,
      }
      IndexModel.innerMessage(datas).then((dataRes) => {
        console.log('谁看过我', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.dataInfo = dataRes.data.pager.list
          this.pageNumber = dataRes.data.pager.pageNumber
          this.pages = dataRes.data.pager.pages
        } else {
          this.$refs.uToast.show({
            ...dataRes,
          })
        }
      })
    },
    goMyHome(item) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + item.sender,
      })
    },
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      return winHeight - 20
    },
    lower(e) {
      console.log('已经滚动到底部了111')
      if (this.pageNumber < this.pages) {
        if (this.isVisitedMy) {
          let datas = {
            messageType: 'ACCESS',
            pageNo: this.pageNumber + 1,
            pageSize: 10,
          }
          IndexModel.innerMessage(datas).then((dataRes) => {
            console.log('谁看过我', dataRes)
            if (dataRes.code == 'SUCCESS') {
              this.dataInfo.push(...dataRes.data.pager.list)
              this.pageNumber = dataRes.data.pager.pageNumber
              this.pages = dataRes.data.pager.pages
            } else {
              this.$refs.uToast.show({
                ...dataRes,
              })
            }
          })
        } else {
          let datas = {
            pageNo: this.pageNumber + 1,
            pageSize: 10,
          }
          IndexModel.getISeeMessage(datas).then((dataRes) => {
            console.log('我访问的', dataRes)
            if (dataRes.code == 'SUCCESS') {
              this.dataInfo.push(...dataRes.data.pager.list)
              this.pageNumber = dataRes.data.pager.pageNumber
              this.pages = dataRes.data.pager.pages
            } else {
              this.$refs.uToast.show({
                ...dataRes,
              })
            }
          })
        }
      }
    },
  },
}
</script>
<style scoped lang="scss">
* {
  margin: 0;
  padding: 0;
  font-style: normal;
  font-weight: normal;
}
.allheaders {
  width: 100%;
  height: 100vh;
  // overflow-y: scroll;
  background: #fff;
}
.details-nav {
  width: 100%;
  height: 88rpx;
  background-color: #fff;
  padding-top: 88rpx;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999;
  .back-info {
    width: 44rpx;
    height: 44rpx;
    position: absolute;
    left: 24rpx;
    top: 110rpx;
    z-index: 99;
    .back-image {
      width: 100%;
      height: 100%;
    }
  }
  .details-nav-right {
    width: 100%;
    font-size: 36rpx;
    font-weight: 500;
    text-align: center;
    line-height: 88rpx;
    color: #333333;
    display: flex;
    align-items: center;
    justify-content: center;
    .visited-title {
      font-size: 32rpx;
      font-weight: 400;
      margin: 0 20rpx;
    }
    .isVisited-title {
      font-size: 28rpx;
      font-weight: 500;
      margin: 0 20rpx;
    }
  }
}
.visited-list {
  width: 100%;
  margin: 206rpx auto 0;
  padding-top: 1rpx;
  .visited-info {
    width: 702rpx;
    margin: 0 auto 40rpx;
    display: flex;
    align-items: center;
    .visited-info-img {
      width: 110rpx;
      height: 110rpx;
      margin-right: 20rpx;
      border-radius: 50%;
    }
    .visited-info-right {
      flex-grow: 1;
      .visited-info-name {
        font-size: 28rpx;
        font-weight: 400;
        text-align: left;
        color: #2d3f49;
        margin-bottom: 8rpx;
      }
      .visited-info-bottom {
        width: 100%;
        display: flex;
        align-items: center;
        .visited-info-senderAge {
          padding: 0 20rpx;
          height: 40rpx;
          border-radius: 20rpx;
          display: flex;
          align-items: center;
          background: #edf6ff;
          font-size: 24rpx;
          font-weight: 500;
          color: #333333;
          .xingbie-image {
            width: 24rpx;
            height: 24rpx;
            margin-right: 8rpx;
          }
        }
        .visited-info-createTime {
          margin-left: 16rpx;
          font-size: 24rpx;
          font-weight: 500;
          text-align: left;
          color: #adb3ba;
        }
      }
    }
  }
}
.hemo-bottom {
  width: 100%;
  font-size: 24rpx;
  font-weight: 500;
  text-align: center;
  color: #adb3ba;
  margin-bottom: 100rpx;
}
.qs-image {
  width: 310rpx;
  height: 310rpx;
  display: block;
  margin: 300rpx auto 40rpx;
}
</style>
