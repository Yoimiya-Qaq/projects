<template>
  <view class="page">
    <view class="details-nav">
      <image @click="goBack()" class="nav-back" src="https://img.yiqitogether.com/static/local/index/back@2x.png" mode=""></image>
      <view class="nav-title">活动消息</view>
    </view>
    <scroll-view scroll-y="true" @scrolltolower="lower()" :style="{ height: scrollH + 'rpx' }">
      <view class="action">
        <view class="action-list" v-for="(item, index) in actionData" :key="index">
          <view class="action-title">
            <view class="action-title-name">{{ item.title }}</view>
            <view class="action-title-time">{{ $u.timeFormat(item.newCreateTime, 'sendMsgFormat') }}</view>
          </view>
          <view class="action-content" @click="goDetails(item.activityId)">
            <image class="action-content-img" :src="item.senderImg || 'https://img.yiqitogether.com/static/local/myImagesV2/moren_hd@2x.png'" mode="aspectFill"></image>
            <view class="action-content-content">{{ item.content }}</view>
          </view>
          <view v-if="item.isActivityCreator" class="action-button" @click="goApprove(item.activityId, 'approve')">前往查看</view>
          <view v-if="item.title == '您已被移除活动'" class="action-button1" @click="goApprove(item.activityId, 'details')">重新申请</view>
        </view>
        <image v-if="actionData.length == 0" class="qs-image" src="https://img.yiqitogether.com/static/local/index/qs_wuxiaoxi@2x.png"></image>
      </view>
      <view class="hemo-bottom" v-if="actionData.length > 0">
        <text v-if="pageNumber < pages" @click="lower()">加载更多</text>
        <text v-if="pageNumber >= pages">到底部了</text>
      </view>
    </scroll-view>
    <!-- 错误提示 -->
    <u-toast ref="uToast"></u-toast>
  </view>
</template>

<script>
import IndexModel from '@/model/index'

export default {
  components: {},

  data() {
    return {
      actionData: [],
      pageNumber: 1,
      pages: 1,
      scrollH: 0,
      linkUrls: 'pages/message/actionMessage'
    }
  },
  computed: {},
  onLoad(e) {},
  mounted() {},
  onShow() {
    this.getMessage()
    this.scrollH = this.scrollHs()
  },
  // onBackPress(e) {
  //   let eventChannel = this.getOpenerEventChannel()
  //   eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //   return false
  // },
  // onUnload() {
  //   let that = this
  //   if (uni.getSystemInfoSync().platform == 'ios') {
  //     try {
  //       let eventChannel = this.getOpenerEventChannel()
  //       eventChannel.emit('pagePrivateBack', { data: '页面返回' })
  //     } catch (error) {}
  //   }
  // },
  methods: {
    // 返回上一页
    goBack() {
      uni.navigateBack()
    },
    getMessage() {
      let datas = {
        messageType: 'ACTIVITY',
        pageNo: 1,
        pageSize: 10
      }
      IndexModel.innerMessage(datas).then(dataRes => {
        console.log('获取消息列表', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.actionData = dataRes.data.pager.list
          this.pageNumber = dataRes.data.pager.pageNumber
          this.pages = dataRes.data.pager.pages
        } else {
          this.$refs.uToast.show({
            ...dataRes
          })
        }
      })
    },
    goDetails(item) {
      uni.navigateTo({
        url: '/pagesCommon/details/details?appointmentNo=' + item
      })
    },
    goApprove(item, text) {
      console.log(item)
      var Url
      if (text == 'approve') {
        Url = '/pagesCommon/message/approve?appointmentNo=' + item
      } else if (text == 'details') {
        Url = '/pagesCommon/details/details?appointmentNo=' + item
      }
      uni.navigateTo({
        url: Url
      })
    },
    scrollHs() {
      let sys = uni.getSystemInfoSync()
      let winWidth = sys.windowWidth
      let winrate = 750 / winWidth
      let winHeight = parseInt(sys.windowHeight * winrate)
      return winHeight
    },
    lower(e) {
      console.log('已经滚动到底部了111')
      if (this.pageNumber < this.pages) {
        let datas = {
          messageType: 'ACTIVITY',
          pageNo: this.pageNumber + 1,
          pageSize: 10
        }
        IndexModel.innerMessage(datas).then(dataRes => {
          console.log('谁看过我', dataRes)
          if (dataRes.code == 'SUCCESS') {
            this.actionData.push(...dataRes.data.pager.list)
            this.pageNumber = dataRes.data.pager.pageNumber
            this.pages = dataRes.data.pager.pages
          } else {
            this.$refs.uToast.show({
              ...dataRes
            })
          }
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.page {
  //position: relative;
  background-color: #f6f7f8;
  // padding-bottom: 40rpx;
  overflow-y: auto;
  height: 100vh;
  position: relative;
  padding-bottom: 100rpx;
  box-sizing: border-box;
  /deep/.u-grid-item {
    margin-bottom: 28rpx;
  }
}
.details-nav {
  width: 100%;
  height: 88rpx;
  background-color: rgba(255, 255, 255, 1);
  padding-top: 88rpx;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  display: flex;
  align-items: center;

  .nav-back {
    width: 44rpx;
    height: 44rpx;
    padding: 22rpx 24rpx;
  }
  .nav-title {
    font-size: 36rpx;
    color: #333333;
  }
}
.action {
  padding-top: 196rpx;
  .action-list {
    width: 710rpx;
    padding: 30rpx 20rpx;
    box-sizing: border-box;
    background-color: #fff;
    border-radius: 24rpx;
    margin: 0 auto 20rpx;
    .action-title {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .action-title-name {
        font-size: 28rpx;
        font-weight: 500;
        text-align: left;
        color: #333333;
      }
      .action-title-time {
        font-size: 24rpx;
        font-weight: 500;
        text-align: right;
        color: #adb3ba;
      }
    }
    .action-content {
      width: 100%;
      height: 130rpx;
      background-color: #f6f7f8;
      border-radius: 16rpx;
      display: flex;
      align-items: center;
      margin-top: 30rpx;
      .action-content-img {
        flex-shrink: 0;
        width: 90rpx;
        height: 90rpx;
        border-radius: 16rpx;
        margin: 0 12rpx 0 20rpx;
      }
      .action-content-content {
        flex-grow: 1;
        font-size: 28rpx;
        text-align: left;
        color: #2d3f49;
      }
    }
    .action-button {
      width: 188rpx;
      height: 64rpx;
      background-color: #fe5e10;
      border-radius: 32rpx;
      line-height: 64rpx;
      font-size: 24rpx;
      font-weight: 500;
      text-align: center;
      color: #ffffff;
      margin: 30rpx 0rpx 0 480rpx;
    }
  }
}

.action-button1 {
  width: 188rpx;
  height: 64rpx;
  border: 2rpx solid #f0f1f3;
  border-radius: 32rpx;
  line-height: 64rpx;
  text-align: center;
  color: #2a343e;
  font-family: OPPOSans, OPPOSans-Regular;
  font-size: 24rpx;
  margin: 30rpx 0rpx 0 480rpx;
}

.hemo-bottom {
  width: 100%;
  font-size: 24rpx;
  font-weight: 500;
  text-align: center;
  color: #adb3ba;
  padding-bottom: 40rpx;
}
.qs-image {
  width: 310rpx;
  height: 310rpx;
  display: block;
  margin: 300rpx auto 40rpx;
}
</style>
