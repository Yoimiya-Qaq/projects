<template>
  <view class="main allheader">
    <scroll-view scroll-y="true" :scroll-top="scrollTop" class="scrollHeight">
      <!-- 顶部 -->
      <!-- #ifdef APP -->
      <view class="status_bar"></view>
      <!-- #endif -->
      <!-- #ifdef MP-WEIXIN -->
      <view :style="'padding-top:' + statusHeight + 'px;'"></view>
      <!-- #endif -->
      <view class="location-search h-flex h-flex-center">
        <image src="@/static/images/back_black.png" class="h-icon-back h-mg-l-25" mode="" @click="back"></image>
        <view class="h-flex-1" style="position: relative">
          <input v-model="searchData" class="search-input" confirm-type="search" placeholder="搜索城市名" type="text" @change="inputChange()" @confirm="inputChange()" />
          <image class="search-img" src="https://img.yiqitogether.com/static/local/leo/sousuo@2x.png" alt=""></image>
        </view>
      </view>

      <view class="placeholder_box"></view>

      <view v-if="!isSearch" class="mainCenter">
        <view class="locatBox">
          <view class="locatTitle">当前定位</view>
          <view class="curr-local-box">
            <view class="left-local" @click="getCityLocationFun(locationCityData)">
              <image src="https://img.yiqitogether.com/static/local/dizhi_s@2x.png" class="currIcon"></image>
              <view class="currLocal">{{ handleCityName(locationCityData) }}</view>
            </view>
            <view class="right-btn" @click="$refs.accredit.triggerEvent()">
              <image src="https://img.yiqitogether.com/static/local/dingwei@2x.png" class="resetIcon"></image>
              <view class="resetLocal">重新定位</view>
            </view>
          </view>
        </view>
        <view class="cityList">
          <view class="locatTitle mb20">热门城市</view>
          <view v-for="(data, index) in HotCity" :key="index" class="hotcityName" @click="getCityLocationFun(data)">
            {{ data }}
          </view>
        </view>
        <view class="cityList" v-for="(item, key, index) in city" :key="index">
          <view class="locatTitle">{{ key }}</view>
          <view v-for="(data, indexs) in item" :key="indexs" class="cityName" @click="getCityLocationFun(data.name)">
            {{ data.name }}
          </view>
        </view>
      </view>
      <view class="mainCenter" v-if="isSearch">
        <view v-for="(data, index) in searchCitydata" :key="index" class="cityName" @click="getCityLocationFun(data.name)">{{ data.name }}</view>
      </view>
      <view class="beakong" v-if="xianshikong">
        <image class="kongImage" src="http://img.yiqitogether.com/yqyq-app/images/qs_wujilu.png" alt=""></image>
      </view>
    </scroll-view>
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于获取当前城市位置" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="getLoc" isImg></accredit-popup>
  </view>
</template>

<script>
/**
 * events 事件名:"getCityName"
 * 本页面为城市选择页面，主要功能有2个
 * - 选择城市，并获取经纬度，存储为全局使用;
 * - 选择城市名称，并将其返,不修改之前的选择的地址缓存;
 *
 * 页面接收参数 e.typeOfOperation
 * - saveStorage ，选择地址时会存储选择的城市名以及经纬度
 * - getCityName || 不传 ，仅返回城市名称
 *
 * 跳转示例 '/pagesCommon/cityList/cityList?typeOfOperation=saveStorage'
 */
import ToolsModel from '@/model/tools'
import city from '../../static/common/city'
// 导入缓存工具 及 缓存字典
import { save, load } from '@/utils/store.js'
import { POSITION, CITY_NAME } from '@/utils/cacheKey.js'
import { getLocation } from '@/utils/tools.js'
export default {
  name: 'location',
  data() {
    return {
      locationCityData: '北京市',
      scrollTop: 0,
      city: {},
      searchData: '',
      isSearch: false,
      searchCitydata: [],
      xianshikong: false,
      HotCity: [],
      iscampus: '',
      statusBarHeight: 25,
      // urlId: '',
      typeOfOperation: '',
      cityName: '',
      statusHeight: 0
    }
  },
  onLoad(e) {
    if (e.typeOfOperation) {
      this.typeOfOperation = e.typeOfOperation
    }
    // 城市名称js
    this.city = city
    // #ifdef MP-WEIXIN
    // 获取胶囊按钮位置
    let res = uni.getMenuButtonBoundingClientRect()
    // 获取状态栏高度
    let res1 = uni.getSystemInfoSync()
    // this.statusHeight = res1.statusBarHeight
    this.statusHeight = Number(res.top) - 9
    // (88 - 64)/4= 6px
    // #endif
    this.locationCityData = load(CITY_NAME) || this.locationCityData
  },

  onShow() {
    this.getHotCity()
    //获取手机系统信息
    const info = uni.getSystemInfoSync()
    //设置状态栏高度
    this.statusBarHeight = info.statusBarHeight
  },
  methods: {
    back() {
      uni.navigateBack()
    },
    /**
     * 去除城市中多余的市
     */
    handleCityName(str) {
      let char = '市'
      const regex = new RegExp(`${char}+`, 'g')
      return str.replace(regex, char)
    },

    /**
     * 根据输入的关键字搜索城市
     */
    inputChange() {
      let that = this
      if (that.searchData == '') {
        that.isSearch = false
        that.xianshikong = false
      } else {
        that.isSearch = true
        that.searchCitydata = []
        Object.keys(that.city).forEach(function (key) {
          that.city[key].forEach((item, index) => {
            if (item.name.indexOf(that.searchData) != -1) {
              let isy = true
              that.searchCitydata.forEach((data, index) => {
                if (data.name == that.searchData) {
                  isy = false
                }
              })
              if (isy) {
                that.searchCitydata.push(item)
              }
            }
          })
        })
        if (that.searchCitydata.length == 0) {
          that.xianshikong = true
        } else {
          that.xianshikong = false
        }
      }
    },

    /**
     * 获取热门城市
     */
    getHotCity() {
      ToolsModel.getHotCity().then(dataRes => {
        // console.log('热门城市', dataRes)
        if (dataRes.code == 'SUCCESS') {
          this.HotCity = dataRes.data.cityList
        }
      })
    },

    /**
     * 点击选择城市
     * @param {Object} item 城市名称
     */
    getCityLocationFun(item) {
      console.log(item, 1)
      item = this.handleCityName(item)
      item = item.split('市')[0]
      console.log(item, 2)
      console.log(`当前选中的市，${item}`)
      if (this.typeOfOperation == 'saveStorage') {
        save(CITY_NAME, item + '市')
        ToolsModel.getCityLocation({
          city: item + '市'
        }).then(res => {
          console.log(``)
          let pos = res.data.location
          delete pos.present
          save(POSITION, pos)
          // 触发跳转时的event事件
          const eventChannel = this.getOpenerEventChannel()
          eventChannel.emit('getCityName', item + '市')
          uni.navigateBack()
        })
      } else {
        // 不放在上面，是为了防止请求还未返回
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.emit('getCityName', item + '市')
        uni.navigateBack()
      }
    },

    /**
     * 获取当前定位
     */
    async getLoc() {
      // #ifdef H5
      uni.showToast({
        title: '当前环境定位不可用，请手动选择',
        icon: 'none'
      })
      return
      // #endif
      let that = this
      let latlon = ''
      try {
        latlon = await getLocation()
      } catch (e) {
        //TODO handle the exception
        return uni.showToast({
          title: '获取定位失败，请检查权限或网络',
          icon: 'none'
        })
      }
      ToolsModel.getAddressInfo({ position: latlon }).then(res => {
        if (res.code == 'SUCCESS') {
          this.locationCityData = res.data.city
          console.log(`城市名称：${res.data.city},位置：${JSON.stringify(latlon)}`)
          // 乐哥要求，点击重新定位后，更新缓存位置
          if (this.typeOfOperation == 'saveStorage') {
            save(POSITION, latlon)
            save(CITY_NAME, res.data.city)
          }
          const eventChannel = that.getOpenerEventChannel()
          eventChannel.emit('getCityName', res.data.city)
          uni.navigateBack()
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.status_bar {
  height: var(--status-bar-height);
  width: 100%;
  background-color: #fff;
  position: fixed;
  top: 0;
  z-index: 9;
}

.main {
  display: flex;
  flex-direction: column;
}

// .scrollHeight  {
// height: 100vh;
// }

.location-search {
  width: 100%;
  height: 50rpx * 2;
  position: fixed;
  top: var(--status-bar-height);
  background-color: #fff;
  padding: 14rpx 0 0;
  box-sizing: border-box;
  flex-shrink: 0;
  z-index: 9;
}

.placeholder_box {
  height: calc(var(--status-bar-height) + 100rpx);
  width: 100%;
  background-color: #fff;
}

.search-input {
  width: 90%;
  height: 60rpx;
  border-radius: 12rpx * 2;
  font-size: 26rpx;
  box-sizing: border-box;
  outline: none;
  border: 0px;
  margin: 0 auto 0;
  display: block;
  padding: 0 24rpx 0 68rpx;
  /* background-color: rgba(0, 0, 0, 0.1); */
  background: #f7f6fb;
  position: relative;
}

.search-img {
  width: 32rpx;
  height: 32rpx;
  position: absolute;
  left: 7%;
  top: 27%;
}

.mainCenter {
  overflow-y: scroll;
  padding: 12px;
  box-sizing: border-box;
  height: auto;
  flex-grow: 0;
}

.locatBox {
  width: 100%;
  height: auto;
  clear: both;
  overflow: hidden;
}

.locatTitle {
  opacity: 1;
  font-size: 16rpx * 2;
  font-family: PingFangSC, PingFangSC-Regular;
  font-weight: 400;
  text-align: left;
  color: #999999;
  line-height: 30px;
}

.locatList,
.locatList ul {
  width: 100%;
  height: auto;
}

.locatList ul li {
  float: left;
  width: 210rpx;
  height: 72rpx;
  opacity: 1;
  background: #f4f6f8;
  border-radius: 10rpx;
  font-size: 14rpx * 2;
  font-family: PingFangSC, PingFangSC-Regular;
  font-weight: 400;
  text-align: center;
  color: #f11010;
  line-height: 72rpx;
  padding: 0px 0.16rem 0px 0.16rem;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  margin-bottom: 0.24rem;
  margin-right: 0.24rem;
}

.locatList ul li:nth-child(3n) {
  margin-right: 0px;
}

.curr-local-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20rpx 0;

  .left-local {
    width: 210rpx;
    height: 72rpx;
    background: #f4f6f8;
    border-radius: 10rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 24rpx;
    font-size: 0;
    padding: 0 16rpx;
    box-sizing: border-box;

    .currIcon {
      width: 22rpx;
      height: 26rpx;
      margin-right: 8rpx;
      flex-shrink: 0;
    }

    .currLocal {
      font-size: 30rpx;
      color: #f11010;
      font-family: PingFangSC, PingFangSC-Regular;
      font-weight: 400;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }

  .right-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10rpx 20rpx;
    font-size: 0;

    .resetIcon {
      width: 22rpx;
      height: 22rpx;
      margin-right: 10rpx;
      flex-shrink: 0;
    }

    .resetLocal {
      font-size: 28rpx;
      color: #333;
      font-family: PingFangSC, PingFangSC-Regular;
      font-weight: 400;
    }
  }
}

.mb20 {
  margin-bottom: 20rpx;
}

.locIcon01 {
  width: 22rpx;
  height: 26rpx;
  margin-right: 0.08rem;
}

.resetLoca {
  opacity: 1;
  font-size: 14rpx * 2;
  font-family: PingFangSC, PingFangSC-Regular;
  font-weight: 400;
  text-align: left;
  color: #000000;
  float: right;
}

.locIcon02 {
  width: 22rpx;
  height: 22rpx;
  float: left;
  margin-right: 10rpx;
  margin-top: 10rpx;
}

.cityList {
  width: 100%;
}

.cityName {
  width: 100%;
  margin: 0 auto;
  color: #333333;
  font-size: 14rpx * 2;
  padding: 24rpx 0;
  box-sizing: border-box;
  border-bottom: 2rpx solid #f4f4f4;
}

.hotcityName {
  /* float: left; */

  width: 210rpx;
  height: 72rpx;
  opacity: 1;
  background: #f4f6f8;
  border-radius: 8rpx;
  font-size: 15rpx * 2;
  font-family: PingFangSC, PingFangSC-Regular;
  font-weight: 400;
  text-align: center;
  color: #333333;
  line-height: 72rpx;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  margin-bottom: 24rpx;
  margin-right: 24rpx;
  display: inline-block;
}

.cityList .hotcityName:nth-child(3n + 1) {
  margin-right: 0px;
}

.beakong {
  width: 100%;
  text-align: center;
}

.kongImage {
  width: 310rpx;
  height: 310rpx;
  display: block;
  margin: 250rpx auto 0;
}

.kongtext {
  font-size: 0.32rem;
  color: #666666;
}
</style>
