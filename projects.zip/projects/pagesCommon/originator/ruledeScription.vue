<template>
  <view class="ruledescription-page">
    <view class="header flex-1">
      <image src="http://img.yiqitogether.com/yqyq-app/images/originator_fanhui.png" class="h-icon-back back-icon" mode="" @click="goBack"></image>
      <view class="header-text">规则说明</view>
    </view>
    <image class="originator_bg" src="http://img.yiqitogether.com/yqyq-app/images/originator_shuoming.png" mode="aspectFill" />
  </view>
</template>
<script>
export default {
  data() {
    return {}
  },
  methods: {
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>
<style lang="scss" scoped>
.ruledescription-page {
  .header {
    padding-top: var(--status-bar-height);
    position: fixed;
    width: 100vw;
    height: 88rpx;
    z-index: 1;
    background-color: #fff;
    .back-icon {
      position: absolute;
      left: 6rpx;
      top: calc(var(--status-bar-height) + 22rpx);
      width: 48rpx;
      height: 48rpx;
      padding: 0 26rpx;
    }
    .header-text {
      font-size: 32rpx;
      text-align: center;
      color: #2a343e;
      line-height: 88rpx;
    }
  }
  .originator_bg {
    position: absolute;
    margin-top: calc(var(--status-bar-height) + 88rpx);
    display: block;
    height: 3276rpx;
    width: 750rpx;
  }
}
</style>
