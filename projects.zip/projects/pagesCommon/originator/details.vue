<template>
  <view :class="['originator-details', isFixedBgc ? 'fixedBgc' : '']">
    <image class="details-bgimg" src="http://img.yiqitogether.com/yqyq-app/images/originator_beijing.png" mode="scaleToFill" />

    <view :class="['header', headerScrollTop ? 'headerstylebg' : '', headerScrollTop > 200 ? 'headerstyleheight' : '']">
      <view class="header-box flex-1">
        <image src="http://img.yiqitogether.com/yqyq-app/images/originator_fanhui.png" class="h-icon-back back-icon" mode="" @click="goBack"></image>
        <view class="header-text" @click="$u.throttle(goRuledescription, 100)">规则说明</view>
      </view>
      <view class="bgImg-box">
        <!-- <image class="header-bgimg" src="http://img.yiqitogether.com/yqyq-app/images/originator_beijing.png" mode="scaleToFill" /> -->
      </view>
    </view>

    <view class="originator-details-body">
      <view class="body-top">
        <view class="money-box">
          <view class="money-box-top flex-1">
            <view class="money-box-left">
              <view class="left-title">创作总收益</view>
              <view class="left-money">{{ numFormat(totalReward) }}</view>
            </view>
            <view class="money-box-right flex-0" @click="rewardListOpen">
              <view class="right-text">收益流水</view>
              <image class="right-narrow" src="http://img.yiqitogether.com/yqyq-app/images/originator_jiantou.png" mode="scaleToFill" />
              <image class="right-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_yumao.png" mode="scaleToFill" />
            </view>
          </view>
          <view class="money-box-btn flex-5" @click="$u.throttle(goRelease, 100)">
            <image class="btn-icon" src="http://img.yiqitogether.com/yqyq-app/images/originator_jiahao.png" mode="scaleToFill" />
            <view>去创作</view>
          </view>
        </view>
        <view class="active-box flex-1">
          <view class="box-item flex-0" @click="tipsOpen('活跃度')">
            <image class="item-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_huoyue.png" mode="scaleToFill" />
            <view class="item-right">
              <view class="right-title">连续活跃度</view>
              <view v-if="activeDay != 0" :class="activeDay == 0 ? 'right-intro-active' : 'right-intro'">已活跃 {{ activeDay }}天</view>
              <view v-else :class="activeDay == 0 ? 'right-intro-active' : 'right-intro'">今日未活跃</view>
            </view>
          </view>
          <view class="box-item flex-0" @click="inviteOpen">
            <image class="item-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_yaoqing.png" mode="scaleToFill" />
            <view class="item-right">
              <view class="right-title">邀请好友创作</view>
              <view class="right-intro flex-0">
                已邀请 {{ recommendCount }}人
                <image class="right_img" src="http://img.yiqitogether.com/yqyq-app/images/originator_right_narrow.png" mode="scaleToFill" />
              </view>
            </view>
          </view>
        </view>
      </view>
      <view class="body-content">
        <view class="content-tab flex-0">
          <view :class="checkedTab.text == tabitem.text ? 'tab-item-active' : 'tab-item '" @click="changeTab(tabitem)" v-for="tabitem in tabList" :key="tabitem.text">
            {{ tabitem.text }}
            <view class="active-line" :style="checkedTab.text == tabitem.text ? '' : 'visibility: hidden;'"></view>
          </view>
        </view>
        <view class="content-list-box">
          <swiper :current="checkSwiperIndex" class="box-scroll" @change="changeCheckedTabList">
            <swiper-item v-for="(item, index) in tabList" :key="index">
              <scroll-view class="box-scroll" v-if="tabList[index].twitterlist.length > 0 && !showLoading" :scroll-y="isscrollTop" @scrolltolower="$u.throttle(twitterlistLoadMore, 100)">
                <view class="content-list flex-1">
                  <view class="list-item" @click="goDetail(item)" v-for="(item, index) in tabList[index].twitterlist" :key="index">
                    <view class="item-imgbox">
                      <image class="imgbox-img" :src="item.imageUrls.split('&&')[0]" mode="aspectFill" />
                      <!-- <view class="cover-box" v-if="checkedTab.text == '审核失败'">
                        <view class="cover-box-center" @click.stop="openNoteMessage(item)">
                          <image class="center-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_shibai.png" mode="scaleToFill" />
                          <view class="center-text">审核失败 ></view>
                        </view>
                        <view class="center-btn" @click.stop="goDetail(item)">预览</view>
                      </view> -->
                    </view>
                    <view class="item-text-box" v-if="checkedTab.text == '已通过'">
                      <view class="item-text">
                        作品过审奖励
                        <text style="color: #fe5e10; margin-left: 6rpx">{{ item.amount }}元</text>
                      </view>
                      <view class="item-time">{{ $u.timeFrom(item.createTime, 'mm-dd') }}</view>
                    </view>
                    <view class="item-text-box" v-if="checkedTab.text == '审核中'">
                      <view class="item-text" style="color: #fe5e10">审核中</view>
                    </view>
                    <view class="item-text-box" @click.stop="openNoteMessage(item)" v-if="checkedTab.text == '审核失败'">
                      <view class="item-text" style="color: #fe5e10">
                        失败原因
                        <image class="item-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_icon_right.png" mode="scaleToFill" />
                      </view>
                    </view>
                  </view>
                </view>
                <view class="tips-box" @click.stop="$u.throttle(twitterlistLoadMore, 500)">
                  <u-loadmore :status="twitterlistLoadStatus" :fontSize="23" nomore-text="到底了~" />
                </view>
              </scroll-view>
              <!-- 缺省图 -->
              <view class="normalActivity-empty" v-if="tabList[index].twitterlist.length == 0 && !showLoading">
                <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
                <text class="empty-text">暂无内容</text>
              </view>
            </swiper-item>
          </swiper>
        </view>
      </view>
    </view>
    <!-- 邀请弹框 -->
    <u-popup class="invite-pop" :show="inviteShow" @close="inviteClose">
      <view class="invite-pop-content">
        <view class="content-title flex-5">
          邀请好友创作
          <image @click="tipsOpen('邀请好友')" class="content-title-icon" src="http://img.yiqitogether.com/yqyq-app/images/originator_intro.png" mode="scaleToFill" />
        </view>
        <view class="content-tips-box flex-5" v-if="userInvitationDTO.length > 0">
          <image class="tips-box-icon" src="http://img.yiqitogether.com/yqyq-app/images/originator_zuo.png" mode="scaleToFill" />
          <view class="tips-box-text">当前已邀请 {{ userInvitationDTO.length || 0 }} 人进行创作</view>
          <image class="tips-box-icon" src="http://img.yiqitogether.com/yqyq-app/images/originator_you.png" mode="scaleToFill" />
        </view>
        <view class="content-userbox">
          <scroll-view class="content-userbox-scroll" scroll-y @scrolltolower="inviteLoadMore">
            <view class="userbox-item flex-1" v-for="(item, index) in userInvitationDTO" :key="index">
              <view
                class="item-left flex-0"
                @click="
                  $u.throttle(() => {
                    goHomePages(item.numberId)
                  }, 500)
                "
              >
                <image class="item-avatar" :src="item.headImgUrl" mode="aspectFill" />
                <view class="item-name ellipsis-single">{{ item.nickName }}</view>
              </view>
              <view class="item-right">{{ $u.timeFrom(item.invitationTime, 'yyyy-mm-dd hh:MM') }}</view>
            </view>
            <!-- 缺省图 -->
            <view class="normalActivity-empty" v-if="userInvitationDTO.length == 0">
              <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
              <text class="empty-text">暂无邀请好友</text>
            </view>
          </scroll-view>
        </view>
      </view>
      <view class="invite-pop-btn" @click="getInvitationCode">邀好友创作</view>
    </u-popup>
    <!-- 收益流水弹窗 -->
    <u-popup class="rewardList-pop" :show="rewardListShow" @close="rewardListClose">
      <view class="rewardList-content">
        <view class="content-title">收益流水</view>
        <view class="content-list">
          <scroll-view v-if="rewardList.length > 0 && !showLoading" class="content-rewardListbox-scroll" scroll-y @scrolltolower="rewardLoadMore">
            <view class="content-list-box" v-for="(item, index) in rewardList" :key="index">
              <view class="list-box-time" v-if="item.isDay">{{ item.createTime }}</view>
              <view class="list-box-item flex-1">
                <view class="box-item-left flex-0">
                  <image class="left-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_chuangzuo.png" mode="scaleToFill" />
                  <view class="left-box">
                    <view class="box-title">{{ item.type }}</view>
                    <view class="box-time">{{ $u.timeFrom(item.date, 'mm-dd hh:MM') }}</view>
                  </view>
                </view>
                <view class="box-item-right">
                  <text v-if="item.amount">
                    <text v-if="item.amount > 0">+</text>
                    <text v-if="item.amount < 0">-</text>
                    {{ numFormat(item.amount) }}
                  </text>
                  <text v-else>0</text>
                </view>
              </view>
            </view>
          </scroll-view>
          <!-- 缺省图 -->
          <view class="normalActivity-empty" v-if="rewardList.length == 0 && !showLoading">
            <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
            <text class="empty-text">暂无内容</text>
          </view>
        </view>
      </view>
    </u-popup>
    <!-- 提示框 -->
    <u-popup class="tips-pop" :show="tipsShow" @close="tipsClose" mode="center">
      <view class="tips-pop-content">
        <view class="content-title">
          <text v-if="tipsType == '活跃度'">连续活跃度说明</text>
          <text v-if="tipsType == '邀请好友'">邀请好友创作说明</text>
        </view>
        <image v-if="tipsType == '活跃度'" class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_lxhyd.png" mode="scaleToFill" />
        <image v-if="tipsType == '邀请好友'" class="content-img" src="http://img.yiqitogether.com/yqyq-app/images/originator_yqhysm.png" mode="scaleToFill" />
        <view class="content-btn" @click="tipsClose">我知道了</view>
      </view>
    </u-popup>

    <!-- 错误提示框 -->
    <custom-modal type="know" :show="showNoteMessage" :round="24" :content="checkedNoteMessage" confirmText="我知道了" @cancel="showNoteMessage = false" @confirm="showNoteMessage = false"></custom-modal>
    <!-- 分享弹窗 -->
    <common-sharing-module :shareData="shareData" v-if="sharePopupFlag" @closePopup="sharePopupFlag = false"></common-sharing-module>
    <!-- loading 弹窗 -->
    <yue-loading :mask="true" loadTxet="加载中..." v-show="showLoading"></yue-loading>
    <accredit-popup ref="accredit" systemTitle="“一起一起”想要获取您的定位" systemContent="便于获取当前城市位置" permisionID="android.permission.ACCESS_FINE_LOCATION" cacheId="accessLocation" @successAccredit="getAddress" isImg isOnShow></accredit-popup>
  </view>
</template>

<script>
// 导入接口
import findModel from '@/model/find.js'
import MyInfo from '@/model/my'

// 导入缓存工具 及 缓存字典
import { USER_INFO } from '../../utils/cacheKey'
import { getLocation, numFormat } from '@/utils/tools'

import { load } from '../../utils/store'
export default {
  data() {
    return {
      numFormat,
      showLoading: true,
      position: '',
      tabList: [
        { text: '已通过', code: 'SUCCESS', twitterlist: [] },
        { text: '审核中', code: 'PENDING', twitterlist: [] },
        { text: '审核失败', code: 'FAIL', twitterlist: [] }
      ],
      checkedTab: { text: '已通过', code: 'SUCCESS', twitterlist: [] },
      inviteShow: false,
      sharePopupFlag: false,
      userinfo: JSON.parse(load(USER_INFO)),
      headerScrollTop: false, // 滑动距离
      isscrollTop: false, // 滑动距离
      totalReward: 0,
      activeDay: 0,
      recommendCount: 0,
      rewardListShow: false, // 收益流水弹窗
      userInvitPageNo: 0, // 邀请页数
      userInvitPageNumber: 0, // 邀请当前页数
      userInvitationLoadStatus: 'loadmore',
      userInvitationDTO: [], // 邀请列表
      rewardPages: 0, // 收益页数
      rewardPageNumber: 0, // 收益当前页数
      rewardList: [], // 收益列表
      rewardLoadStatus: 'loadmore',
      twitterlistPages: 0, // 列表页数
      twitterlistPageNumber: 0, //  列表当前页数
      // twitterlist: [], // 邀请列表
      twitterlistLastKeyWord: '', // 列表关键字
      hasNextPage: '', // 列表是否有下一页
      currentShareCode: 0, // 当前用户邀请码
      showNoteMessage: false, // 审核失败原因弹框
      checkedNoteMessage: '笔记内容重复率过高', // 审核失败原因内容
      isFixedBgc: false,
      checkSwiperIndex: 0,
      tipsShow: false, // 提示框展示
      tipsType: '' // 提示框展示类型
    }
  },
  onPageScroll: function (e) {
    let top = 80
    //nvue暂不支持滚动监听，可用bindingx代替
    if (e.scrollTop <= 20) {
      this.headerScrollTop = false
    } else {
      this.headerScrollTop = e.scrollTop
    }
    //nvue暂不支持滚动监听，可用bindingx代替
    if (e.scrollTop < top) {
      this.isscrollTop = false
    } else {
      this.isscrollTop = true
    }
  },
  watch: {
    rewardListShow(newVal, oldVal) {
      if (newVal == true) {
        this.isFixedBgc = true
      } else {
        this.isFixedBgc = false
      }
    },
    inviteShow(newVal, oldVal) {
      if (newVal == true) {
        this.isFixedBgc = true
      } else {
        this.isFixedBgc = false
      }
    },
    tipsShow(newVal, oldVal) {
      if (newVal == true) {
        this.isFixedBgc = true
      } else {
        this.isFixedBgc = false
      }
    }
  },
  onLoad(e) {
    setTimeout(() => {
      this.$refs.accredit.triggerEvent()
    }, 100)
    this.getOriginatoriIndex()
    this.getMyGoodNotes()
  },
  methods: {
    async getAddress() {
      try {
        this.position = await getLocation()
      } catch (e) {
        console.log(e)
      }
    },
    /**
     * 刷新数据
     */
    refreshList() {
      this.twitterlistPageNo = 0
      this.twitterlistPageNumber = 0
      this.tabList.map(item => {
        item.twitterlist = []
      })
      this.twitterlistLastKeyWord = ''
      this.hasNextPage = false
      setTimeout(() => {
        this.getMyGoodNotes()
      }, 100)
    },
    /**
     * 获取创作者页面详情
     */
    getOriginatoriIndex() {
      findModel
        .getOriginatoriIndex()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.totalReward = res.data.dto.totalReward || 0
            this.activeDay = res.data.dto.activeDay || 0
            this.recommendCount = res.data.dto.recommendCount || 0
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 获取创作者页面详情
     */
    getRewardList() {
      let params = {
        pageNo: this.rewardPageNumber + 1,
        pageSize: 10
      }
      findModel
        .getRewardList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.rewardPages = res.data.page.pages
            this.rewardPageNumber = res.data.page.pageNumber
            let list = res.data.page.list
            list.map(item => {
              item.createTime = uni.$u.timeFormat(item.date, 'handleDate')
            })

            let newlist = [...this.rewardList, ...list]
            newlist.forEach((item, index) => {
              if (index >= 1) {
                if (newlist[index - 1].createTime == newlist[index].createTime) {
                  item.isDay = false
                } else {
                  item.isDay = true
                }
              } else {
                item.isDay = true
              }
            })
            this.rewardList = [...newlist]
            if (res.data.page.total == 0) {
              this.rewardLoadStatus = 'none'
            } else {
              if (res.data.page.pages <= res.data.page.pageNumber) {
                this.rewardLoadStatus = 'nomore'
              } else {
                this.rewardLoadStatus = 'loadmore'
              }
            }
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 获取邀请列表
     */
    getUserInvitationList() {
      let params = {
        pageNo: this.userInvitPageNumber + 1,
        pageSize: 10
      }
      findModel
        .getUserInvitationList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.userInvitPageNo = res.data.pages
            this.userInvitPageNumber = res.data.pageNumber
            this.userInvitationDTO = [...this.userInvitationDTO, ...res.data.UserInvitationDTO]
            if (res.data.total == 0) {
              this.userInvitationLoadStatus = 'none'
            } else {
              if (res.data.pages <= res.data.pageNumber) {
                this.userInvitationLoadStatus = 'nomore'
              } else {
                this.userInvitationLoadStatus = 'loadmore'
              }
            }
          } else {
            this.userInvitationLoadStatus = 'loadmore'
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.userInvitationLoadStatus = 'loadmore'
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 获取笔记列表
     */
    getMyGoodNotes() {
      let params = {
        pageSize: 10, //	String	否	每页请求数据
        lastKeyWord: this.twitterlistLastKeyWord || '', //	String	否	分页查询关键词（第一页可不传，其他页必传）
        notesRecordState: this.checkedTab.code
      }
      findModel
        .getMyGoodNotes(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.twitterlistPages = res.data.pager.pages
            this.twitterlistPageNumber = res.data.pager.pageNumber
            this.twitterlistLastKeyWord = res.data.pager.lastKeyWord
            let index = this.tabList.findIndex(item => item.code == this.checkedTab.code)
            this.tabList[index].twitterlist = [...this.tabList[index].twitterlist, ...res.data.pager.list]
            this.hasNextPage = res.data.pager.hasNextPage
            if (res.data.pager.total == 0) {
              this.twitterlistLoadStatus = 'none'
            } else {
              if (res.data.pager.pages <= res.data.pager.pageNumber) {
                this.twitterlistLoadStatus = 'nomore'
              } else {
                this.twitterlistLoadStatus = 'loadmore'
              }
            }
          } else {
            this.twitterlistLoadStatus = 'loadmore'
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
          this.showLoading = false
        })
        .catch(err => {
          this.showLoading = false
          this.twitterlistLoadStatus = 'loadmore'
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    // 获取用户邀请码
    getInvitationCode() {
      MyInfo.getInvitationCode()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.currentShareCode = res.data.invitationCode
            this.handleShare()
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 更改tab
     */
    changeTab(item) {
      this.checkedTab = { ...item }
      this.checkSwiperIndex = this.tabList.findIndex(item => item.code == this.checkedTab.code)
      this.showLoading = true
      this.refreshList()
    },
    /**
     *
     */
    changeCheckedTabList(e) {
      if (this.checkSwiperIndex != e.detail.current) {
        this.checkSwiperIndex = e.detail.current
        this.changeTab(this.tabList[e.detail.current])
      }
    },
    /**
     * 分享
     */
    handleShare() {
      // 弹窗分享弹窗
      let title = '一起一起创作者招募 - 去赚稿费'
      let shareObj = {
        type: 5,
        title: title,
        // content: this.userinfo.twitterInfo.title || this.userinfo.twitterInfo.content, // 笔记优先取标题，没写标题就取内容
        imageUrl: 'http://img.yiqitogether.com/static/img/yq_logo.png',
        // 小程序对应页面
        path: `/packageSignUp/signUp/signUp?shareCode=${this.currentShareCode}`,
        // h5对应页面
        href: `/pagesCommon/originator/index?shareCode=${this.currentShareCode}`
      }
      this.shareData = shareObj
      this.sharePopupFlag = true
    },
    /**
     * 去往详情页
     */
    goDetail(item, tag, index) {
      uni.navigateTo({
        url: '/pages/find/findDetails?twitterId=' + item.uuId + '&pageType=2'
      })
    },
    /**
     *  笔记加载更多
     */
    twitterlistLoadMore() {
      if (this.twitterlistPages > this.twitterlistPageNumber && this.hasNextPage) {
        this.getMyGoodNotes()
      }
    },
    /**
     *  邀请共创用户加载更多
     */
    inviteLoadMore() {
      if (this.userInvitPageNo > this.userInvitPageNumber) {
        this.getUserInvitationList()
      }
    },
    /**
     *  收益流水加载更多
     */
    rewardLoadMore() {
      if (this.rewardPages > this.rewardPageNumber) {
        this.getRewardList()
      }
    },
    /**
     * 规则说明页面
     */
    goRuledescription() {
      uni.navigateTo({ url: '/pagesCommon/originator/ruledeScription' })
    },
    /**
     * 去创作
     */
    goRelease() {
      uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s3&sourcePage=creator' })
    },
    /**
     * 前往个人主页
     * @param numberId
     */
    goHomePages(numberId) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + numberId
      })
    },
    openNoteMessage(item) {
      this.checkedNoteMessage = item.remark
      this.showNoteMessage = true
    },
    rewardListOpen() {
      this.rewardListShow = true
      this.getRewardList()
    },
    rewardListClose() {
      this.rewardListShow = false
    },
    inviteOpen() {
      this.inviteShow = true
      this.getUserInvitationList()
    },
    inviteClose() {
      this.inviteShow = false
    },
    tipsOpen(type) {
      this.tipsType = type
      this.tipsShow = true
    },
    tipsClose() {
      this.tipsShow = false
    },
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>

<style scoped lang="scss">
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.fixedBgc {
  height: 100vh;
  overflow: hidden;
}
.originator-details {
  min-height: 100vh;
  position: relative;
  .details-bgimg {
    display: block;
    min-height: 100vh;
    // height: 1624rpx;
    width: 100%;
    position: fixed;
    top: 0;
  }
  .header {
    width: 100vw;
    height: 88rpx;
    z-index: 1;
    padding-top: calc(var(--status-bar-height));
    position: fixed;
    .header-box {
      position: relative;
      z-index: 2;
      padding-top: 22rpx;
      .back-icon {
        width: 48rpx;
        height: 48rpx;
        padding: 0 26rpx;
      }
      .header-text {
        width: 112rpx;
        height: 40rpx;
        font-size: 28rpx;
        color: #42240e;
        padding: 0 36rpx;
      }
    }
    .bgImg-box {
      width: 100vw;
      height: 88rpx;
      position: absolute;
      top: 0;
    }
  }
  .headerstylebg {
    background: linear-gradient(90deg, #efe8e0 9%, #efe8e0 9%, #e4dbd1 91%);
  }
  .headerstyleheight {
    height: 120rpx;
  }
  .originator-details-body {
    position: absolute;
    margin-top: calc(var(--status-bar-height) + 108rpx);

    .body-top {
      .money-box {
        background: url('http://img.yiqitogether.com/yqyq-app/images/originator_shouyi_bj.png');
        background-size: 100% 100%;
        margin: 0 36rpx;
        width: 678rpx;
        height: 280rpx;
        padding: 28rpx;
        box-sizing: border-box;
        .money-box-top {
          .money-box-left {
            .left-title {
              font-size: 20rpx;
              color: #9fa7b4;
            }
            .left-money {
              font-size: 60rpx;
              color: #fe5e10;
            }
          }
          .money-box-right {
            background: linear-gradient(90deg, #efe8e0 9%, #efe8e0 9%, #e4dbd1 91%);
            width: 192rpx;
            height: 72rpx;
            border-radius: 12rpx;
            .right-text {
              width: 80rpx;
              height: 28rpx;
              font-size: 20rpx;
              color: #3e2512;
              margin: 0 6rpx 0 20rpx;
            }
            .right-narrow {
              width: 12rpx;
              height: 12rpx;
            }
            .right-img {
              width: 68rpx;
              height: 68rpx;
            }
          }
        }
        .money-box-btn {
          margin: 20rpx auto 0;
          width: 622rpx;
          height: 88rpx;
          background: #3e2512;
          border-radius: 16rpx;
          font-size: 32rpx;
          text-align: center;
          line-height: 88rpx;
          color: #ffffff;
          .btn-icon {
            width: 32rpx;
            height: 32rpx;
            margin-right: 16rpx;
          }
        }
      }
      .active-box {
        margin: 40rpx 36rpx 20rpx;
        .box-item {
          width: 334rpx;
          height: 112rpx;
          background: #ffffff;
          border-radius: 20rpx;
          .item-img {
            width: 80rpx;
            height: 80rpx;
            margin: 0 4rpx 0 34rpx;
          }
          .item-right {
            .right-title {
              font-size: 24rpx;
              color: #3e2512;
            }
            .right-intro-active {
              font-size: 20rpx;
              color: #fe5e10;
            }
            .right-intro {
              font-size: 20rpx;
              color: #adb3ba;
            }
            .right_img {
              width: 16rpx;
              height: 16rpx;
              display: block;
              margin-top: 2rpx;
            }
          }
        }
      }
    }
    .body-content {
      background: #ffffff;
      border-radius: 40rpx 40rpx 0rpx 0rpx;
      min-height: 60vh;
      .content-tab {
        position: sticky;
        border-radius: 40rpx 40rpx 0rpx 0rpx;
        background: #ffffff;
        z-index: 3;
        width: 100vw;
        top: calc(84rpx + var(--status-bar-height));
        padding: 24rpx 0;
        // box-sizing: border-box;
        .tab-item {
          width: 220rpx;
          font-size: 28rpx;
          color: #1c1c1c;
          text-align: center;
          flex: 1;
        }
        .tab-item-active {
          flex: 1;

          width: 220rpx;
          text-align: center;
          font-size: 28rpx;
          text-align: center;
          color: #fe5e10;
        }
        .active-line {
          width: 30rpx;
          height: 6rpx;
          background: #fe5e10;
          margin: 4rpx auto 0;
          border-radius: 24rpx;
        }
      }

      .content-list-box {
        padding: 0 36rpx;
        margin-top: 28rpx;
        .box-scroll {
          height: 84vh;
          .content-list {
            flex-wrap: wrap;
            .list-item {
              margin-bottom: 15rpx;
              .item-imgbox {
                position: relative;
                .imgbox-img {
                  width: 332rpx;
                  height: 420rpx;
                  border-radius: 20rpx;
                }
                .cover-box {
                  width: 332rpx;
                  height: 420rpx;
                  border-radius: 20rpx;
                  position: absolute;
                  top: 0;
                  background: rgba(0, 0, 0, 0.5);
                  .cover-box-center {
                    margin: 37% auto 0;
                    .center-img {
                      margin: auto;
                      display: block;
                      width: 88rpx;
                      height: 96rpx;
                    }
                    .center-text {
                      margin-top: 12rpx;
                      text-align: center;
                      font-size: 24rpx;
                      color: #ffffff;
                    }
                  }
                  .center-btn {
                    margin: 82rpx auto 0;
                    width: 256rpx;
                    height: 48rpx;
                    background: #ffffff;
                    border-radius: 12rpx;
                    font-size: 24rpx;
                    text-align: center;
                    color: #fe5e10;
                    line-height: 48rpx;
                  }
                }
              }
              .item-text-box {
                .item-text {
                  font-size: 24rpx;
                  font-weight: bold;
                  color: #1c1c1c;
                }
                .item-time {
                  font-size: 24rpx;
                  color: #838e9a;
                  margin-top: 4rpx;
                }
                .item-img {
                  width: 16rpx;
                  height: 16rpx;
                  margin-left: 8rpx;
                }
              }
            }
          }
        }
      }
    }
  }
  .invite-pop {
    /deep/.u-popup__content {
      border-radius: 20rpx 20rpx 0rpx 0rpx;
    }
    .invite-pop-content {
      width: 750rpx;
      // min-height: 506rpx;
      background: #ffffff;
      border-radius: 20rpx 20rpx 0rpx 0rpx;
      .content-title {
        padding-top: 48rpx;
        font-weight: bold;
        font-size: 32rpx;
        text-align: center;
        color: #2a343e;

        .content-title-icon {
          width: 32rpx;
          height: 32rpx;
          margin-left: 8rpx;
        }
      }
      .content-tips-box {
        margin-top: 20rpx;
        .tips-box-icon {
          width: 72rpx;
          height: 6rpx;
        }
        .tips-box-text {
          font-size: 24rpx;
          color: #fe5e10;
          margin: 0 12rpx;
          font-weight: bold;
        }
      }
      .content-userbox {
        overflow: hidden;
        margin: 46rpx 0;
        .content-userbox-scroll {
          height: 658rpx;
          .userbox-item {
            padding: 0 40rpx;
            margin-bottom: 34rpx;
            .item-left {
              .item-avatar {
                width: 88rpx;
                height: 88rpx;
                border-radius: 50%;
              }
              .item-name {
                margin-left: 20rpx;
                width: 192rpx;
                line-height: 88rpx;
                font-size: 32rpx;
                color: #2a343e;
              }
            }
            .item-right {
              font-size: 28rpx;
              color: #9fa7b4;
            }
          }
        }
      }
    }
    .invite-pop-btn {
      margin: 0 auto 130rpx;
      width: 678rpx;
      height: 88rpx;
      background: #fe5e10;
      border-radius: 44rpx;
      font-size: 36rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
    }
  }
  .rewardList-pop {
    /deep/.u-popup__content {
      border-radius: 20rpx 20rpx 0rpx 0rpx;
    }
    .rewardList-content {
      height: 1006rpx;
      background: #ffffff;
      border-radius: 20rpx 20rpx 0rpx 0rpx;

      .content-title {
        padding: 48rpx 0 54rpx;
        font-size: 32rpx;
        font-weight: bold;
        text-align: center;
        color: #2a343e;
      }
      .content-list {
        .content-rewardListbox-scroll {
          height: 800rpx;
          .content-list-box {
            margin: 0 46rpx;
            .list-box-time {
              font-size: 32rpx;
              color: #2a343e;
              margin-bottom: 16rpx;
            }
            .list-box-item {
              margin-left: 14rpx;
              padding: 28rpx 0;
              .box-item-left {
                .left-img {
                  width: 88rpx;
                  height: 88rpx;
                }
                .left-box {
                  margin-left: 16rpx;
                  .box-title {
                    font-size: 28rpx;
                    color: #2a343e;
                    margin-bottom: 2rpx;
                  }
                  .box-time {
                    font-size: 24rpx;
                    color: #838e9a;
                  }
                }
              }
              .box-item-right {
                font-size: 32rpx;
                color: #1c1c1c;
                font-weight: bold;
              }
            }
          }
        }
      }
    }
  }
  .tips-pop {
    /deep/.u-popup__content {
      border-radius: 20rpx;
    }
    /deep/.u-fade-enter-active {
      z-index: 10075 !important;
    }
    .tips-pop-content {
      width: 536rpx;
      height: 664rpx;
      background: #ffffff;
      border-radius: 20rpx;
      font-weight: bold;
      .content-title {
        padding-top: 40rpx;
        font-size: 34rpx;
        text-align: center;
        color: #484848;
        margin-bottom: 40rpx;
      }
      .content-img {
        width: 512rpx;
        height: 412rpx;
        margin: auto;
        display: block;
      }
      .content-btn {
        position: absolute;
        bottom: 0;
        width: 100%;
        border-top: 2rpx solid #f7f7f7;
        padding: 22rpx 0 32rpx;
        font-size: 28rpx;
        text-align: center;
        color: #fe5e10;
        line-height: 40rpx;
      }
    }
  }
}
.tips-box {
  padding-top: 24rpx;
  padding-bottom: 50rpx;
}

.normalActivity-empty {
  padding-top: 100rpx;
  margin: auto;
  text-align: center;
  .empty-img {
    width: 312rpx;
    height: 244rpx;
    background-size: cover;
  }
  .empty-text {
    display: block;
    font-size: 24rpx;
    color: #9fa7b4;
    line-height: 34rpx;
    margin-top: 26rpx;
  }
}
</style>
