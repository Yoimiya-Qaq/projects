<template>
  <view v-if="showPageFlag" :class="['originator-page', isFixedBgc ? 'fixedBgc' : '']">
    <view class="header flex-1">
      <image src="http://img.yiqitogether.com/yqyq-app/images/originator_fanhui.png" class="h-icon-back back-icon" mode="" @click="goBack"></image>
    </view>
    <view class="header-text" @click="$u.throttle(goRuledescription, 100)">规则说明</view>

    <image class="originator_bg" src="http://img.yiqitogether.com/yqyq-app/images/originator_changtu.png" mode="aspectFill" />
    <!-- <view class="bottom-box"></view> -->
    <view class="originator_btn flex-1">
      <view class="btn_item" @click="inviteOpen">邀请好友</view>
      <view class="btn_item" @click="$u.throttle(openInvitePopup, 500)">立即报名</view>
    </view>
    <!-- 报名弹框 -->
    <u-popup class="applypop" mode="center" :show="showApply" @close="closeApply">
      <view class="applypop_content">
        <view class="applypop_top flex-5">
          <image class="top_img" src="http://img.yiqitogether.com/yqyq-app/images/originator_chenggong.png" mode="scaleToFill" />
          <view class="top_text">恭喜您报名成功</view>
        </view>
        <view class="applypop_bottom" @click="$u.throttle(goRelease, 100)">现在去创作 ></view>
      </view>
      <image @click="closeApply" class="applypop_close" src="http://img.yiqitogether.com/yqyq-app/images/originator_icon.png" mode="scaleToFill" />
    </u-popup>
    <!-- 邀请弹框 -->
    <u-popup class="invite-pop" :show="inviteShow" @close="inviteClose">
      <view class="invite-pop-content">
        <view class="content-title">邀请好友创作</view>
        <view class="content-userbox">
          <scroll-view class="content-userbox-scroll" scroll-y @scrolltolower="inviteLoadMore">
            <view class="userbox-item flex-1" v-for="(item, index) in userInvitationDTO" :key="index">
              <view
                class="item-left flex-0"
                @click="
                  $u.throttle(() => {
                    goHomePages(item.numberId)
                  }, 500)
                "
              >
                <image class="item-avatar" :src="item.headImgUrl" mode="aspectFill" />
                <view class="item-name ellipsis-single">{{ item.nickName }}</view>
              </view>
              <view class="item-right">{{ $u.timeFrom(item.invitationTime, 'yyyy-mm-dd hh:MM') }}</view>
            </view>
            <!-- 缺省图 -->
            <view class="normalActivity-empty" v-if="userInvitationDTO.length == 0">
              <image class="empty-img" src="http://img.yiqitogether.com/static/images/detailsImg/zanwupingjia.png" alt="" mode="aspectFill" />
              <text class="empty-text">暂无邀请好友</text>
            </view>
          </scroll-view>
        </view>
      </view>
      <view class="invite-pop-btn" @click="getInvitationCode">邀好友创作</view>
    </u-popup>
    <!-- 分享弹窗 -->
    <common-sharing-module :shareData="shareData" v-if="sharePopupFlag" @closePopup="sharePopupFlag = false"></common-sharing-module>
    <!-- loading 弹窗 -->
    <yue-loading :mask="true" loadTxet="加载中..." v-show="showLoading"></yue-loading>

    <!-- 填写邀请码弹窗 -->
    <u-popup :show="inVitePopup" :round="20" mode="bottom" @close="closeInvitePopup">
      <view class="write-invite-popup">
        <view class="invite-title">
          <view class="title-con">
            邀请码
            <view class="optional-text">(选填)</view>
          </view>
          <view class="skip-text" @click="submitApply()">跳过</view>
        </view>
        <!-- 搜索框 -->
        <view class="code-input">
          <u-input v-model.trim="inviteCode" @change="changeInput" type="number" placeholder="请填写邀请码" placeholder-style="font-size:28rpx;color: #9fa7b4;">
            <template slot="suffix">
              <image src="http://img.yiqitogether.com/yqyq-app/images/originator_search.png" class="search-icon" @click="handelSearch(inviteCode)"></image>
            </template>
          </u-input>
        </view>
        <!-- 邀请人 -->
        <view class="invite-people-wrap" v-if="invitationUserData && invitationUserData.invitationCode">
          <image :src="invitationUserData.headUrl" class="head-img"></image>
          <view class="invite-people-right">
            <view class="name">{{ invitationUserData.nickName }}</view>
            <view class="id">ID:{{ invitationUserData.invitationCode }}</view>
          </view>
        </view>
        <view class="invite-people-wrap" v-if="isClickSearch && !isInvitationUserData && inviteCode">
          <view class="wrap-empty">
            未搜索到相关信息
            <br />
            请核实邀请码,重新搜索
          </view>
        </view>
        <!-- 确认按钮 -->
        <u-button type="primary" text="确认" color="#fe5e10" class="confrim-btn" @click="submitApply(inviteCode)" :disabled="!inviteCode"></u-button>
      </view>
    </u-popup>
  </view>
</template>

<script>
// 导入接口
import findModel from '@/model/find.js'
import MyInfo from '@/model/my'

// 导入缓存工具 及 缓存字典
import { load, save } from '@/utils/store.js'
import { USER_INFO } from '@/utils/cacheKey.js'

export default {
  data() {
    return {
      showLoading: false,
      showApply: false, // 是否报名成功
      userInfo: load(USER_INFO) ? JSON.parse(load(USER_INFO)) : {},
      isSignUpParticipate: true,
      sharePopupFlag: false,
      currentShareCode: '', // 当前用户邀请码
      shareCode: '', //邀请人的邀请码
      inviteShow: false,
      userInvitPageNo: 0, // 邀请页数
      userInvitPageNumber: 0, // 邀请当前页数
      userInvitationDTO: [], // 邀请列表
      userInvitationLoadStatus: 'loadmore',
      isFixedBgc: false,
      showPageFlag: false, // 页面展示flag，延时0.5s展示
      inVitePopup: false, // 填写邀请码弹窗是否显示
      inviteCode: '', // 邀请码
      invitationUserData: {}, // 邀请用户信息
      isInvitationUserData: false, // 是否搜索到用户信息
      isClickSearch: false // 是否点击搜索
    }
  },
  onLoad(e) {
    setTimeout(() => {
      this.showPageFlag = true
    }, 500)
    let isSignUpParticipate = this.userInfo?.isSignUpParticipate || false
    if (isSignUpParticipate) {
      uni.redirectTo({
        url: '/pagesCommon/originator/details'
      })
    }
    this.shareCode = e.shareCode || ''
  },
  watch: {
    inviteShow(newVal, oldVal) {
      if (newVal == true) {
        this.isFixedBgc = true
      } else {
        this.isFixedBgc = false
      }
    },
    inVitePopup(newVal, oldVal) {
      if (newVal == true) {
        this.isFixedBgc = true
      } else {
        this.isFixedBgc = false
      }
    }
  },
  methods: {
    openApply() {
      this.showApply = true
    },
    closeApply() {
      this.showApply = false
    },
    /**
     * 打开填写邀请码弹窗
     */
    openInvitePopup() {
      this.inVitePopup = true
      this.handelSearch(this.shareCode)
    },
    /**
     * 关闭填写邀请码弹窗
     */ closeInvitePopup() {
      this.inVitePopup = false
      this.inviteCode = ''
      this.invitationUserData = {}
    },
    /**
     * 清除邀请码
     */
    changeInput(e) {
      this.isClickSearch = false
      if (e.length == 0) {
        this.inviteCode = ''
        this.invitationUserData = {}
      }
    },
    /**
     * 根据邀请码搜索邀请人信息
     */
    handelSearch(shareCode) {
      this.inviteCode = shareCode
      findModel
        .getByInvitationCodeInfo({ invitationCode: shareCode })
        .then(res => {
          this.isClickSearch = true
          if (res.code === 'SUCCESS') {
            this.invitationUserData = res.data
            this.isInvitationUserData = res.data ? true : false
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
            this.isInvitationUserData = false
            this.invitationUserData = {}
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     * 去报名
     */
    submitApply(inviteCode) {
      let params = {}
      if (inviteCode != 0) {
        params = {
          invitationCode: inviteCode || ''
        }
      }
      findModel
        .originatorSignUp(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.closeInvitePopup()
            setTimeout(() => {
              this.openApply()
            }, 50)
            let userInfo = this.userInfo
            userInfo.isSignUpParticipate = true
            save(USER_INFO, JSON.stringify(userInfo))
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
      // uni.navigateTo({ url: '/pagesCommon/originator/details' })
    },
    /**
     * 分享
     */
    handleShare() {
      // 弹窗分享弹窗
      let title = '一起一起创作者招募 - 去赚稿费'
      let shareObj = {
        type: 5,
        title: title,
        // content: this.userinfo.twitterInfo.title || this.userinfo.twitterInfo.content, // 笔记优先取标题，没写标题就取内容
        imageUrl: 'http://img.yiqitogether.com/static/img/yq_logo.png',
        // 小程序对应页面
        path: `/packageSignUp/signUp/signUp?shareCode=${this.currentShareCode}`,
        // h5对应页面
        href: `/pagesCommon/originator/index?shareCode=${this.currentShareCode}`
      }
      this.shareData = shareObj
      this.sharePopupFlag = true
    },
    // 获取用户邀请码
    getInvitationCode() {
      MyInfo.getInvitationCode()
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.currentShareCode = res.data.invitationCode
            this.handleShare()
          } else {
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    inviteOpen() {
      this.inviteShow = true
      this.getUserInvitationList()
    },
    inviteClose() {
      this.inviteShow = false
    },
    /**
     * 获取邀请列表
     */
    getUserInvitationList() {
      let params = {
        pageNo: this.userInvitPageNumber + 1,
        pageSize: 10
      }
      findModel
        .getUserInvitationList(params)
        .then(res => {
          if (res.code == 'SUCCESS') {
            this.userInvitPageNo = res.data.pages
            this.userInvitPageNumber = res.data.pageNumber
            this.userInvitationDTO = [...this.userInvitationDTO, ...res.data.UserInvitationDTO]
            if (res.data.total == 0) {
              this.userInvitationLoadStatus = 'none'
            } else {
              if (res.data.pages <= res.data.pageNumber) {
                this.userInvitationLoadStatus = 'nomore'
              } else {
                this.userInvitationLoadStatus = 'loadmore'
              }
            }
          } else {
            this.userInvitationLoadStatus = 'loadmore'
            uni.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          this.userInvitationLoadStatus = 'loadmore'
          uni.showToast({
            title: err.message,
            icon: 'none'
          })
        })
    },
    /**
     *  邀请共创用户加载更多
     */
    inviteLoadMore() {
      if (this.userInvitPageNo > this.userInvitPageNumber) {
        this.getUserInvitationList()
      }
    },
    /**
     * 前往个人主页
     * @param numberId
     */
    goHomePages(numberId) {
      uni.navigateTo({
        url: '/pagesMy/my/myHomePages/index?userId=' + numberId
      })
    },
    /**
     * 去创作
     */
    goRelease() {
      uni.navigateTo({ url: '/pagesFind/find/release?chooseType=s3&sourcePage=creator' })
    },
    /**
     * 规则说明页面
     */
    goRuledescription() {
      uni.navigateTo({ url: '/pagesCommon/originator/ruledeScription' })
    },
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>

<style scoped lang="scss">
.flex-0 {
  display: flex;
  align-items: center;
}
.flex-1 {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.flex-5 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.fixedBgc {
  height: 100vh;
  overflow: hidden;
}
.originator-page {
  .header {
    top: var(--status-bar-height);
    position: fixed;
    width: 100vw;
    height: 88rpx;
    z-index: 1;
    .back-icon {
      width: 48rpx;
      height: 48rpx;
      padding: 0 26rpx;
    }
  }
  .header-text {
    top: var(--status-bar-height);
    right: 0;
    position: absolute;
    width: 112rpx;
    height: 88rpx;
    line-height: 88rpx;
    font-size: 28rpx;
    color: #42240e;
    padding: 0 36rpx;
    z-index: 1;
  }
  .originator_bg {
    height: 3196rpx;
    display: block;
    width: 100%;
  }
  .bottom-box {
    width: 100%;
    height: 160rpx;
  }
  .originator_btn {
    position: fixed;
    bottom: 0rpx;
    padding: 0 38rpx;
    box-sizing: border-box;
    width: 100%;
    height: 228rpx;
    background: linear-gradient(180deg, rgba(239, 233, 224, 0) 36%, #cdbdae 100%);
    .btn_item {
      width: 330rpx;
      height: 104rpx;
      background: #3e2512;
      border-radius: 52rpx;
      font-size: 36rpx;
      text-align: center;
      color: #ffffff;
      line-height: 104rpx;
    }
  }
  .invite-pop {
    /deep/.u-popup__content {
      border-radius: 20rpx 20rpx 0rpx 0rpx;
    }
    .invite-pop-content {
      width: 750rpx;
      // min-height: 506rpx;
      background: #ffffff;
      border-radius: 20rpx 20rpx 0rpx 0rpx;
      .content-title {
        padding-top: 48rpx;
        font-weight: bold;
        font-size: 32rpx;
        text-align: center;
        color: #2a343e;
      }
      .content-userbox {
        overflow: hidden;
        margin: 46rpx 0;
        .content-userbox-scroll {
          height: 658rpx;
          .userbox-item {
            padding: 0 40rpx;
            margin-bottom: 34rpx;
            .item-left {
              .item-avatar {
                width: 88rpx;
                height: 88rpx;
                border-radius: 50%;
              }
              .item-name {
                margin-left: 20rpx;
                width: 192rpx;
                line-height: 88rpx;
                font-size: 32rpx;
                color: #2a343e;
              }
            }
            .item-right {
              font-size: 28rpx;
              color: #9fa7b4;
            }
          }
        }
      }
    }
    .invite-pop-btn {
      margin: 0 auto 130rpx;
      width: 678rpx;
      height: 88rpx;
      background: #fe5e10;
      border-radius: 44rpx;
      font-size: 36rpx;
      text-align: center;
      color: #ffffff;
      line-height: 88rpx;
    }
  }
  .applypop {
    /deep/.u-popup__content {
      height: 248rpx;
      border-radius: 20rpx;
    }
    .applypop_content {
      width: 560rpx;
      height: 248rpx;
      background: #ffffff;
      border-radius: 20rpx;
      .applypop_top {
        padding: 52rpx 0 44rpx;
        border-bottom: 2rpx solid #f7f7f7;
        .top_img {
          width: 68rpx;
          height: 68rpx;
          margin-right: 16rpx;
          display: block;
        }
        .top_text {
          width: 238rpx;
          height: 48rpx;
          font-size: 34rpx;
          font-weight: bold;
          color: #484848;
        }
      }
      .applypop_bottom {
        padding-top: 22rpx;
        font-size: 28rpx;
        text-align: center;
        color: #fe5e10;
      }
    }
    .applypop_close {
      position: absolute;
      left: 252rpx;
      bottom: -80rpx;
      width: 52rpx;
      height: 52rpx;
    }
  }
  .normalActivity-empty {
    padding-top: 100rpx;
    margin: auto;
    text-align: center;
    .empty-img {
      width: 312rpx;
      height: 244rpx;
      background-size: cover;
    }
    .empty-text {
      display: block;
      font-size: 24rpx;
      color: #9fa7b4;
      line-height: 34rpx;
      margin-top: 26rpx;
    }
  }
  .write-invite-popup {
    min-height: 800rpx;
    padding: 40rpx;
    box-sizing: border-box;
    .invite-title {
      width: 100%;
      margin-bottom: 72rpx;
      .title-con {
        font-size: 32rpx;
        color: #2a343e;
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        .optional-text {
          color: #838e9a;
          font-size: 26rpx;
          font-weight: normal;
        }
      }
      .skip-text {
        position: absolute;
        top: 46 rpx;
        right: 40rpx;
        font-size: 24rpx;
        color: #a6acb2;
      }
    }
    .code-input {
      width: 638rpx;
      margin: 0 auto;
      /deep/ .u-input {
        box-shadow: none;
        border: none;
        background: #f0f1f3;
        border-radius: 20rpx;
        height: 88rpx;
        padding: 22rpx 24rpx;
        box-sizing: border-box;
      }
      .search-icon {
        width: 44rpx;
        height: 44rpx;
      }
    }
    .invite-people-wrap {
      width: 638rpx;
      height: 152rpx;
      background: #f0f1f3;
      border-radius: 20rpx;
      display: flex;
      margin: 0 auto;
      align-items: center;
      margin-top: 12rpx;
      padding: 20rpx;
      box-sizing: border-box;
      .wrap-empty {
        font-size: 24rpx;
        flex: 1;
        text-align: center;
        color: #9fa7b4;
        line-height: 34rpx;
      }
      .head-img {
        width: 112rpx;
        height: 112rpx;
        margin-right: 16rpx;
        border-radius: 50%;
      }
      .invite-people-right {
        .name {
          font-size: 28rpx;
          color: #1c1c1c;
          font-weight: bold;
        }
        .id {
          font-size: 24rpx;
          color: #64696f;
        }
      }
    }
    /deep/.u-button {
      width: 638rpx;
      height: 88rpx;
      border-radius: 44rpx;
      margin: 0 auto;
      position: fixed;
      bottom: 190rpx;
      left: 50%;
      transform: translate(-50%);
    }
  }
}
</style>
