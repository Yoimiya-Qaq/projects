<script>
import Vue from 'vue'
import { save, load, clear } from '@/utils/store.js'
import { LOGIN_TOKEN, CONNECTRONGYUN, TABBAR_PATH_LIST, rongyunToken, BUBBLESTYLEDATA, DOWNLOAD_TIME } from '@/utils/cacheKey.js'
import RCIMIWEngine from '@/uni_modules/RongCloud-IMWrapper-V2/js_sdk/RCIMEngine'
import loginModel from '@/model/login.js'
import toolsModel from '@/model/tools.js'
import { saveUserInfo, getBubbles } from '@/utils/tools.js'
export default {
  onLaunch: async function (option) {
    let self = this
    clear(CONNECTRONGYUN)
    // #ifdef APP
		// 5s内流程未走完，也需要启动图。不允许长时间白屏
		setTimeout(()=>{
			if(plus.navigator.hasSplashscreen()){
				plus.navigator.closeSplashscreen()
			}
		},5000)
    // 获取下载的时间，若为空，则将当前时间存入
    if (!load(DOWNLOAD_TIME)) {
      let timestampInSeconds = new Date().getTime()
      console.log(timestampInSeconds)
      save(DOWNLOAD_TIME, timestampInSeconds)
    }

    uni.addInterceptor('share', {
      invoke(args) {
        let path = args.miniProgram ? args.miniProgram.path : args.href
        let params = {
          path: path,
          shareChannel: 'WECHAT',
          shareType: args.scene
        }
        toolsModel.shareStatistics(params)
        console.log('开始分享', args)
      }
    })
    this.connectRongyun()
    // 获取聊天气泡数据
    try {
      let bubbleData = await getBubbles()
      if (bubbleData) {
        save(BUBBLESTYLEDATA, bubbleData)
      }
    } catch (error) {}

    // 强制竖屏
    plus.screen.lockOrientation('portrait-primary')
    // 获取设备信息
    const client = uni.getSystemInfoSync().platform
    // 获取登录状态
    const userToken = load(LOGIN_TOKEN)

    // 监听到在线通知
    plus.push.addEventListener('receive', this.onlineNotificationProcessing, false)
    //消息点击事件
    //【APP在线】，收到透传消息通过，不会提醒至通知栏目，需要发送本地消息，再进行点击触发的点击事件。
    //【APP离线】，收到离线透传消息，必须通过Java后台的Intent字符串携带payload，且符合格式才能触发click事件，格式不符合不会触发

    plus.push.addEventListener(
      'click',
      function (msg) {
        console.log('(click):' + JSON.stringify(msg))
        let payload = {}
        if (client == 'ios') {
          payload = msg.type == 'click' ? msg.payload : JSON.parse(msg.payload)
        } else if (client == 'android') {
          payload = msg.payload
        }
        // 登录状态下才进行跳转
        if (userToken) {
          self.jumpPage(payload.path)
        } else {
          plus.navigator.closeSplashscreen()
        }
      },
      false
    )

    // 登录跳转
    if (userToken && option.launcher != 'push' && option.launcher != 'scheme') {
      console.log('刷新token')
      // 登录状态，刷新token，判断是否需要跳转到商家入职
      loginModel
        .tokenLogin()
        .then(res => {
          if (res.code == 'SUCCESS') {
            saveUserInfo(res.data.userDto)
            console.log(res.data.userDto)
          }
          if (res.data && res.data.userDto && res.data.userDto.merchantIndex) {
            setTimeout(() => {
              uni.reLaunch({
                url: '/shangchaoMall/index',
                success() {
                  plus.navigator.closeSplashscreen()
                }
              })
            }, 200)
          } else {
            setTimeout(() => {
              self.jumpPage('/pages/find/index')
            }, 200)
          }
        })
        .catch(() => {
          self.jumpPage('/pages/find/index')
        })
    } else if (!userToken) {
      console.log('没有token，进入登录页')
      plus.navigator.closeSplashscreen()
    } else {
      console.log('通过横幅打开，不执行该段逻辑')
    }

    // #endif

    uni.onTabBarMidButtonTap(res => {
      uni.$u.throttle(() => {
        //  获取当前页面栈
        let pages = getCurrentPages()
        // 获取当前页面实例
        let currentPage = pages[pages.length - 1]
        // 获取当前页面路径
        let currentPath = currentPage.$page.path
        switch (currentPath) {
          case '/pages/find/index':
          case '/':
            uni.$emit('openIndexPopup')
            break
          case '/pages/index/goPlay':
            uni.$emit('openFindPopup')
            break
          case '/pages/message/index':
            uni.$emit('openMessagePopup')
            break
          case '/pages/my/index':
            uni.$emit('openMyPopup')
            break
          default:
            break
        }
      }, 500)
    })
  },
  globalData: {
    /**
     * 打开靓靓的参数 type 和 openUrl会被剔除，其余参数会被循环拼接在url后面
     * @openurl 要打开的页面url
     * @type 要打开的域名  1为靓靓   2 为钱包
     * @token 打开钱包时必传
     */
    webViewOption: {
      // 靓靓 或者 钱包
      type: '1',
      // 要打开的地址
      openUrl: '',
      // 打开靓靓时必须携带
      token: ''
    },
    /**
     * 发布活动参数
     */
    publishActivityFiles: {},
    /**
     * 探索好店-确认下单商品数组
     */
    shopConfirmOrderList: [],
    /***
     * 转发动态参数
     */
    transformDynamicData: {},
    /**
     * 发现详情被艾特的好友参数
     */
    interactionAtUserList: [],
    /**
     * 答题模块各类型配置
     */
    answerTypeConfiguration: {},
    /**
     * 答题模块各类型答题记录相关参数
     */
    answerTypeRecordData: {},
    /**
     * 消息转发的数据
     */
    forwardMessageData: {},
    /**
     * 相册-预览照片数组
     */
    albumPreviewList: [],
    /**
     * 商户版块webView参数
     */
    shangChaoWebView: {
      // 打开地址
      openUrl: ''
    }
  },

  methods: {
    jumpPage(path) {
      path = path ? path : '/pages/find/index'
      let isTabber = TABBAR_PATH_LIST.includes(path)
      // tabbar跳转，无需重定向
      uni.switchTab({
        url: isTabber ? path : '/pages/find/index',
        success() {
          plus.navigator.closeSplashscreen()
          // 二级页面跳转，先跳转首页，然后重定向到二级页面
          if (!isTabber) {
            uni.navigateTo({
              url: path
            })
          }
        },
        fail() {
          plus.navigator.closeSplashscreen()
        }
      })
    },
    // 创建融云链接
    async connectRongyun() {
      try {
        let res = await RCIMIWEngine.create(rongyunToken, {})
        this.$store.state.engie = res
      } catch (error) {
        console.log('🚀 ~ 应用启动创建融云链接失败 ~ error:', error)
      }
    },
    // 在线推送处理回调
    onlineNotificationProcessing(msg) {
      console.log('(receive):' + JSON.stringify(msg))
      let payload = JSON.parse(msg.payload)
      if (payload.path === '/shangchaoMall/index') {
        let messageTitle = msg.title
        let messageContent = msg.content
        //创建本地消息,发送的本地消息也会被receive方法接收到，但没有type属性，且aps是null
        plus.push.createMessage(messageContent, JSON.stringify(payload), {
          title: messageTitle
        })
      }
    }
  }
}
</script>

<style lang="scss">
@import '@/uni_modules/uview-ui/index.scss';
@import 'static/style/public.css';
@import 'static/style/common.css';
@import 'static/style/shangchaoMall/style.css';

.flex1 {
  display: flex;
  align-items: center;
}

/* #ifdef H5 */
uni-modal {
  z-index: 99999 !important;
}

/* #endif */

/* #ifndef APP-PLUS-NVUE */
page {
  // font-family: OPPOSans-Medium; //PingFang-M
  --recruit-color: #3a9aff;
  --recruit-light-color: #e3f0ff;
}

button {
  margin-bottom: 15px;
}

.user-marker {
  // width: 44rpx !important;
  // height: 44rpx !important;
  background: url('static/images/address-marker.png') no-repeat;
  background-size: 100% 100%;
  // background-color:pink;
}

// 单行文本超出省略
.ellipsis-single {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  word-break: break-all;
  text-overflow: ellipsis;
  overflow: hidden;
}
.hint-toast {
  /deep/.uni-sample-toast {
    width: 500rpx !important;
  }
}
//#endif

.ql-editor.ql-blank:before {
  color: #bdc1c5;
  font-size: 28rpx;
  font-family: PingFang SC;
  font-weight: 500;
}

</style>
